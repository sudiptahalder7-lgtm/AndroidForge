# QX Smart Scanner — Android Trading Signal Assistant

## Project Overview
QX Smart Scanner is an Android application engineered to observe and analyze visible 1-minute Quotex trading charts on-device via Android MediaProjection Screen Capture, without connecting to any external market-data API.

## Core Features
- **10 REAL Market Pairs**: GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD, NZD/USD, EUR/GBP, EUR/JPY, EUR/AUD, GBP/JPY
- **10 OTC Market Pairs**: GBP/USD (OTC), USD/JPY (OTC), USD/CHF (OTC), AUD/USD (OTC), USD/CAD (OTC), NZD/USD (OTC), EUR/GBP (OTC), EUR/JPY (OTC), EUR/AUD (OTC), GBP/JPY (OTC)
- **Zero API Dependency**: Does not invent prices or candle data. Analyzes visible pixels only.
- **7-Second Pre-Close Timing Engine**: Activates analysis strictly during the final 7 seconds (<= 7s and >= 1s) to deliver validated signals ~1 second before candle expiration.
- **9-Gate Signal Validation Engine**: If any validation rule fails, enforces `NO TRADE` fallback with explicit cause.
- **Draggable Floating Assistant**: Compact circular button with neon glow, expanding into an over-app scanning panel.
- **Local History & Statistics**: Room database with strict REAL vs OTC segregation and sample size tracking.

## Android Studio Build Instructions
1. Download the complete ZIP from the QX Smart Scanner studio or clone the repository.
2. Open Android Studio (Hedgehog, Iguana, or newer) and select **Open** -> choose this folder.
3. Ensure JDK 17 is selected in **Settings** -> **Build, Execution, Deployment** -> **Build Tools** -> **Gradle** -> **Gradle JDK**.
4. Sync Gradle files (`Sync Project with Gradle Files`).
5. Run unit tests via `./gradlew test` or run on physical device / emulator:
   ```bash
   ./gradlew assembleDebug
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## Required Android Permissions
- `android.permission.FOREGROUND_SERVICE`: Foreground processing.
- `android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION`: Screen capture frames.
- `android.permission.SYSTEM_ALERT_WINDOW`: Floating overlay assistant.
- `android.permission.POST_NOTIFICATIONS`: Ongoing capture status alert.

## Known Limitations
1. Does not predict the future with 100% certainty (market trading involves inherent risk).
2. Does not execute trades automatically.
3. Must have Quotex chart clearly visible on screen; cannot scan obscured or hidden charts.