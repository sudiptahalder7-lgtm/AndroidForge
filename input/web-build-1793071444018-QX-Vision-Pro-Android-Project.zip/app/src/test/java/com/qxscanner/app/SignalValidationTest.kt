package com.qxscanner.app

import com.qxscanner.app.data.MarketPairsConfig
import org.junit.Assert.assertEquals
import org.junit.Test

class SignalValidationTest {
    @Test
    fun testMarketPairsExact20() {
        assertEquals(20, MarketPairsConfig.TOTAL_PAIRS)
        assertEquals(10, MarketPairsConfig.REAL_PAIRS_COUNT)
        assertEquals(10, MarketPairsConfig.OTC_PAIRS_COUNT)
    }
}