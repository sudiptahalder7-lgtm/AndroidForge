package com.qxscanner.app.engine

class CandleTimingEngine {
    data class TimingEvaluation(
        val isWindowActive: Boolean,
        val secondsRemaining: Int?,
        val confidenceScore: Int,
        val statusMessage: String
    )

    fun evaluateTiming(countdownSeconds: Int?, confidence: Int): TimingEvaluation {
        if (countdownSeconds == null || confidence < 60) {
            return TimingEvaluation(false, null, 0, "Countdown timer unreadable or missing")
        }
        return when {
            countdownSeconds in 1..7 -> TimingEvaluation(true, countdownSeconds, confidence, "Final 7s pre-close active ($countdownSeconds s)")
            countdownSeconds > 7 -> TimingEvaluation(false, countdownSeconds, confidence, "Awaiting final 7s window ($countdownSeconds s)")
            else -> TimingEvaluation(false, countdownSeconds, confidence, "Candle expired")
        }
    }
}