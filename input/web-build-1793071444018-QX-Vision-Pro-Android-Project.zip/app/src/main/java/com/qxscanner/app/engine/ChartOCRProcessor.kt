package com.qxscanner.app.engine

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class ChartOCRProcessor {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    data class OcrResult(
        val rawText: String,
        val recognizedSymbol: String?,
        val isOtc: Boolean,
        val timeframe: String?,
        val countdownSeconds: Int?,
        val confidence: Int
    )

    suspend fun processHeaderAndTiming(headerBitmap: Bitmap, countdownBitmap: Bitmap?): OcrResult {
        val headerText = recognizeText(headerBitmap)
        val countdownText = countdownBitmap?.let { recognizeText(it) } ?: ""
        val combined = "$headerText\n$countdownText"
        val isOtc = combined.contains("OTC", ignoreCase = true)
        val symbol = Regex("([A-Z]{3}/[A-Z]{3})").find(combined)?.value
        val timeframe = Regex("\\b(1M|01:00|M1)\\b", RegexOption.IGNORE_CASE).find(combined)?.value?.uppercase()
        val countdownSeconds = Regex("(?:00:0?|0:0?|:0?)([0-5]?[0-9])\\b").find(combined)?.groupValues?.get(1)?.toIntOrNull()

        return OcrResult(
            rawText = combined,
            recognizedSymbol = symbol,
            isOtc = isOtc,
            timeframe = timeframe,
            countdownSeconds = countdownSeconds,
            confidence = if (symbol != null && timeframe != null) 90 else 50
        )
    }

    private suspend fun recognizeText(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { cont.resume(it.text) }
            .addOnFailureListener { cont.resume("") }
    }
}