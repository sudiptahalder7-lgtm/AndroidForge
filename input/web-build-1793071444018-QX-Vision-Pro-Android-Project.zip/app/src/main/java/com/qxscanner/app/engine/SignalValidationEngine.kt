package com.qxscanner.app.engine

import com.qxscanner.app.data.model.*
import java.util.UUID

class SignalValidationEngine {
    fun validateAndGenerate(
        screenCaptureActive: Boolean,
        selectedPairSymbol: String,
        selectedMarketMode: MarketMode,
        extractedData: ExtractedChartData?,
        currentTimeMs: Long = System.currentTimeMillis()
    ): SignalResult {
        val id = "sig_${currentTimeMs}_${UUID.randomUUID().toString().take(5)}"
        val isSelectedOtc = selectedMarketMode == MarketMode.OTC

        if (!screenCaptureActive) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.SCREEN_CAPTURE_STOPPED, "Screen capture permission not active.")
        }
        if (extractedData == null || extractedData.detectedCandles.size < 5) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.NO_TRADE_INSUFFICIENT_DATA, "Insufficient candles detected (< 5).")
        }
        if (!extractedData.imageClear || extractedData.sharpnessScore < 55) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.NO_TRADE_LOW_IMAGE_QUALITY, "Image quality below threshold.")
        }
        if (extractedData.frameAgeMs > 2000) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.NO_TRADE_STALE_FRAME, "Frame is stale.")
        }

        val cleanSelected = selectedPairSymbol.replace("(OTC)", "").replace("\\s+".toRegex(), "").uppercase()
        val cleanVisible = (extractedData.recognizedSymbol ?: "").replace("(OTC)", "").replace("\\s+".toRegex(), "").uppercase()
        if (cleanSelected != cleanVisible) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.ASSET_NOT_VERIFIED, "Asset mismatch: selected $selectedPairSymbol vs visible ${extractedData.recognizedSymbol}")
        }

        if (isSelectedOtc != extractedData.recognizedIsOtc) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.NO_TRADE_MARKET_MODE_MISMATCH, "Market mode mismatch.")
        }

        val tf = (extractedData.recognizedTimeframe ?: "").uppercase()
        if (tf !in listOf("1M", "01:00", "M1")) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.NO_TRADE_TIMEFRAME_MISMATCH, "Timeframe is $tf; strictly requires 1M.")
        }

        val cd = extractedData.countdownSecondsRemaining
        if (cd == null || cd !in 1..7) {
            return makeNoTrade(id, currentTimeMs, selectedPairSymbol, isSelectedOtc, SignalReason.NO_TRADE_TIMING_UNVERIFIED, "Awaiting final 7s candle window.")
        }

        val greenCount = extractedData.detectedCandles.takeLast(5).count { it.isBullish }
        val signal = when {
            greenCount >= 4 -> SignalType.UP
            greenCount <= 1 -> SignalType.DOWN
            else -> SignalType.NO_TRADE
        }

        return SignalResult(
            id = id,
            timestamp = currentTimeMs,
            pairSymbol = selectedPairSymbol,
            isOtc = isSelectedOtc,
            signal = signal,
            modelConfidenceScore = if (signal == SignalType.NO_TRADE) 40 else 82,
            reason = if (signal == SignalType.UP) SignalReason.VALIDATED_BULLISH_MOMENTUM else if (signal == SignalType.DOWN) SignalReason.VALIDATED_BEARISH_MOMENTUM else SignalReason.NO_TRADE_CONFLICTING_EVIDENCE,
            detailedMessage = if (signal != SignalType.NO_TRADE) "Validated directional consensus in 7s window" else "Conflicting candle patterns",
            validationChecklist = ValidationChecklist(true, true, true, true, true, true, true, true, signal != SignalType.NO_TRADE),
            allChecksPassed = signal != SignalType.NO_TRADE,
            countdownSeconds = cd,
            observedCandleCount = extractedData.detectedCandles.size
        )
    }

    private fun makeNoTrade(id: String, time: Long, pair: String, isOtc: Boolean, reason: SignalReason, msg: String): SignalResult {
        return SignalResult(
            id = id,
            timestamp = time,
            pairSymbol = pair,
            isOtc = isOtc,
            signal = SignalType.NO_TRADE,
            modelConfidenceScore = 0,
            reason = reason,
            detailedMessage = msg,
            validationChecklist = ValidationChecklist(false, false, false, false, false, false, false, false, false),
            allChecksPassed = false,
            countdownSeconds = null,
            observedCandleCount = 0
        )
    }
}