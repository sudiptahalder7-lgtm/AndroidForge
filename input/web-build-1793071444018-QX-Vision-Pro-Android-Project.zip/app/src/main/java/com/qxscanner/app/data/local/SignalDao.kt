package com.qxscanner.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalDao {
    @Query("SELECT * FROM signal_history ORDER BY timestamp DESC")
    fun getAllSignals(): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signal_history WHERE isOtc = :isOtc ORDER BY timestamp DESC")
    fun getSignalsByMarket(isOtc: Boolean): Flow<List<SignalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(signal: SignalEntity)

    @Query("UPDATE signal_history SET evaluatedOutcome = :outcome, outcomeNotes = :notes WHERE id = :id")
    suspend fun updateOutcome(id: String, outcome: String, notes: String?)

    @Query("DELETE FROM signal_history WHERE isOtc = :isOtc")
    suspend fun clearByMarket(isOtc: Boolean)
}