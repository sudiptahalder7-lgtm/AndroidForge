package com.qxscanner.app.engine

import android.graphics.Bitmap
import android.graphics.Color
import com.qxscanner.app.data.model.CandlePixelData

class CandleRecognitionEngine {
    fun recognizeCandles(chartCanvasBitmap: Bitmap): List<CandlePixelData> {
        val width = chartCanvasBitmap.width
        val height = chartCanvasBitmap.height
        if (width < 50 || height < 50) return emptyList()

        val stepX = (width / 50).coerceAtLeast(3)
        val candleCandidates = mutableListOf<CandlePixelData>()
        var index = 0
        var x = 0

        while (x < width - stepX) {
            val col = analyzeColumn(chartCanvasBitmap, x, height)
            if (col.hasCandle) {
                val isBull = col.greenCount > col.redCount
                val bodyHeight = (col.bodyBottom - col.bodyTop).coerceAtLeast(1f)
                val upperWick = (col.bodyTop - col.wickHigh).coerceAtLeast(0f)
                val lowerWick = (col.wickLow - col.bodyBottom).coerceAtLeast(0f)
                val total = (col.wickLow - col.wickHigh).coerceAtLeast(bodyHeight)

                candleCandidates.add(CandlePixelData(
                    index = index++,
                    isBullish = isBull,
                    bodyTop = col.bodyTop,
                    bodyBottom = col.bodyBottom,
                    wickHigh = col.wickHigh,
                    wickLow = col.wickLow,
                    bodyHeight = bodyHeight,
                    upperWickLength = upperWick,
                    lowerWickLength = lowerWick,
                    totalLength = total
                ))
                x += (width / 22).coerceAtLeast(6)
            }
            x += stepX
        }
        return candleCandidates.takeLast(12)
    }

    private data class ColData(val hasCandle: Boolean, val greenCount: Int, val redCount: Int, val bodyTop: Float, val bodyBottom: Float, val wickHigh: Float, val wickLow: Float)

    private fun analyzeColumn(bitmap: Bitmap, x: Int, height: Int): ColData {
        var gC = 0
        var rC = 0
        var firstY = -1
        var lastY = -1
        for (y in 0 until height step 2) {
            val p = bitmap.getPixel(x, y)
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            if (g > 110 && g > r * 1.3f && g > b) {
                gC++
                if (firstY == -1) firstY = y
                lastY = y
            } else if (r > 120 && r > g * 1.4f && r > b) {
                rC++
                if (firstY == -1) firstY = y
                lastY = y
            }
        }
        val has = (gC + rC) > 8
        val top = if (firstY != -1) firstY.toFloat() else 0f
        val btm = if (lastY != -1) lastY.toFloat() else height.toFloat()
        return ColData(has, gC, rC, top + 5f, btm - 5f, top, btm)
    }
}