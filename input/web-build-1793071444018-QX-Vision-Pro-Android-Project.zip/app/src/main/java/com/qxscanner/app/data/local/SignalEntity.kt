package com.qxscanner.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signal_history")
data class SignalEntity(
    @PrimaryKey
    val id: String,
    val timestamp: Long,
    val pairSymbol: String,
    val isOtc: Boolean,
    val timeframe: String,
    val signal: String,
    val modelConfidenceScore: Int,
    val reason: String,
    val detailedMessage: String,
    val observedCandleCount: Int,
    val countdownSeconds: Int?,
    val allChecksPassed: Boolean,
    val evaluatedOutcome: String = "UNOBSERVED",
    val outcomeNotes: String? = null
)