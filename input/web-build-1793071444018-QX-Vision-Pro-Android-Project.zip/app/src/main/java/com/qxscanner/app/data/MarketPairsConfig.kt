package com.qxscanner.app.data

data class MarketPair(
    val id: String,
    val symbol: String,
    val cleanSymbol: String,
    val isOtc: Boolean,
    val displayName: String,
    val baseCurrency: String,
    val quoteCurrency: String
)

object MarketPairsConfig {
    val BASE_REAL_SYMBOLS: List<String> = listOf(
        "GBP/USD", "USD/JPY", "USD/CHF", "AUD/USD", "USD/CAD",
        "NZD/USD", "EUR/GBP", "EUR/JPY", "EUR/AUD", "GBP/JPY"
    )

    val CONFIGURED_PAIRS: List<MarketPair> = buildList {
        BASE_REAL_SYMBOLS.forEach { symbol ->
            val parts = symbol.split("/")
            add(MarketPair(
                id = "REAL_${parts[0]}${parts[1]}",
                symbol = symbol,
                cleanSymbol = "${parts[0]}${parts[1]}",
                isOtc = false,
                displayName = symbol,
                baseCurrency = parts[0],
                quoteCurrency = parts[1]
            ))
        }
        BASE_REAL_SYMBOLS.forEach { symbol ->
            val parts = symbol.split("/")
            add(MarketPair(
                id = "OTC_${parts[0]}${parts[1]}",
                symbol = "$symbol (OTC)",
                cleanSymbol = "${parts[0]}${parts[1]}_OTC",
                isOtc = true,
                displayName = "$symbol (OTC)",
                baseCurrency = parts[0],
                quoteCurrency = parts[1]
            ))
        }
    }

    const val TOTAL_PAIRS = 20
    const val REAL_PAIRS_COUNT = 10
    const val OTC_PAIRS_COUNT = 10

    fun getRealPairs(): List<MarketPair> = CONFIGURED_PAIRS.filter { !it.isOtc }
    fun getOtcPairs(): List<MarketPair> = CONFIGURED_PAIRS.filter { it.isOtc }
}