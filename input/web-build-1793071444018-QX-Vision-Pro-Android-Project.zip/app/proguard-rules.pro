# ProGuard & R8 rules for QX Smart Scanner
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

-keepclassmembers class * extends androidx.room.RoomDatabase { public void <init>(); }
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

-keep class com.google.mlkit.vision.** { *; }
-keep class com.google.android.gms.vision.** { *; }
-dontwarn com.google.mlkit.**

-keep class com.qxscanner.app.data.local.** { *; }
-keep class com.qxscanner.app.data.model.** { *; }