# ProGuard & R8 optimization rules for QX Smart Scanner

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}

# Room Database
-keepclassmembers class * extends androidx.room.RoomDatabase {
    public void <init>();
}
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Google ML Kit Text Recognition
-keep class com.google.mlkit.vision.** { *; }
-keep class com.google.android.gms.vision.** { *; }
-dontwarn com.google.mlkit.**

# Jetpack Compose
-keepclassmembers class androidx.compose.runtime.Recomposer {
    <init>(...);
}
-dontwarn androidx.compose.**

# Keep models for Room & JSON
-keep class com.qxscanner.app.data.local.** { *; }
-keep class com.qxscanner.app.data.model.** { *; }
