package com.qxscanner.app.data

/**
 * Centralized Market Pair Configuration for QX Smart Scanner.
 * Strictly 10 REAL pairs and 10 corresponding OTC entries (Total: 20).
 * Never merges or confuses REAL and OTC data.
 */
data class MarketPair(
    val id: String,
    val symbol: String,         // e.g. "GBP/USD"
    val cleanSymbol: String,    // e.g. "GBPUSD"
    val isOtc: Boolean,
    val displayName: String,    // e.g. "GBP/USD" or "GBP/USD (OTC)"
    val baseCurrency: String,
    val quoteCurrency: String
)

object MarketPairsConfig {

    val BASE_REAL_SYMBOLS: List<String> = listOf(
        "GBP/USD",
        "USD/JPY",
        "USD/CHF",
        "AUD/USD",
        "USD/CAD",
        "NZD/USD",
        "EUR/GBP",
        "EUR/JPY",
        "EUR/AUD",
        "GBP/JPY"
    )

    val CONFIGURED_PAIRS: List<MarketPair> = buildList {
        // 10 REAL Pairs
        BASE_REAL_SYMBOLS.forEach { symbol ->
            val parts = symbol.split("/")
            val base = parts[0]
            val quote = parts[1]
            add(
                MarketPair(
                    id = "REAL_${base}${quote}",
                    symbol = symbol,
                    cleanSymbol = "${base}${quote}",
                    isOtc = false,
                    displayName = symbol,
                    baseCurrency = base,
                    quoteCurrency = quote
                )
            )
        }

        // 10 Corresponding OTC Pairs
        BASE_REAL_SYMBOLS.forEach { symbol ->
            val parts = symbol.split("/")
            val base = parts[0]
            val quote = parts[1]
            add(
                MarketPair(
                    id = "OTC_${base}${quote}",
                    symbol = "$symbol (OTC)",
                    cleanSymbol = "${base}${quote}_OTC",
                    isOtc = true,
                    displayName = "$symbol (OTC)",
                    baseCurrency = base,
                    quoteCurrency = quote
                )
            )
        }
    }

    const val TOTAL_PAIRS = 20
    const val REAL_PAIRS_COUNT = 10
    const val OTC_PAIRS_COUNT = 10

    fun getRealPairs(): List<MarketPair> = CONFIGURED_PAIRS.filter { !it.isOtc }

    fun getOtcPairs(): List<MarketPair> = CONFIGURED_PAIRS.filter { it.isOtc }

    fun findPairByDisplay(displayName: String): MarketPair? {
        val normalized = displayName.trim().uppercase()
        return CONFIGURED_PAIRS.find { it.displayName.uppercase() == normalized }
    }

    fun findPairBySymbolAndMode(symbol: String, isOtc: Boolean): MarketPair? {
        val clean = symbol.replace("(OTC)", "").replace("\\s+".toRegex(), "").uppercase()
        return CONFIGURED_PAIRS.find {
            val pClean = it.symbol.replace("(OTC)", "").replace("\\s+".toRegex(), "").uppercase()
            pClean == clean && it.isOtc == isOtc
        }
    }
}
