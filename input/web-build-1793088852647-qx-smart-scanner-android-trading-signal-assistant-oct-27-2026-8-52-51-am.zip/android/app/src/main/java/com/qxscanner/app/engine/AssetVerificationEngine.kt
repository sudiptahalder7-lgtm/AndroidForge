package com.qxscanner.app.engine

import com.qxscanner.app.data.model.MarketMode

/**
 * AssetVerificationEngine
 * Guarantees that signals are never generated for mismatched assets,
 * mismatched market modes, or wrong timeframes.
 */
class AssetVerificationEngine {

    data class AssetVerificationResult(
        val symbolMatched: Boolean,
        val modeMatched: Boolean,
        val timeframeVerified: Boolean,
        val overallVerified: Boolean,
        val failureReason: String?
    )

    fun verifyAsset(
        selectedPairSymbol: String,
        selectedMarketMode: MarketMode,
        recognizedSymbol: String?,
        recognizedIsOtc: Boolean,
        recognizedTimeframe: String?
    ): AssetVerificationResult {
        if (recognizedSymbol.isNullOrBlank()) {
            return AssetVerificationResult(
                symbolMatched = false,
                modeMatched = false,
                timeframeVerified = false,
                overallVerified = false,
                failureReason = "Asset symbol not detected on visible chart"
            )
        }

        // Clean strings for comparison
        val cleanSelected = selectedPairSymbol.replace("(OTC)", "").replace("\\s+".toRegex(), "").uppercase()
        val cleanRecognized = recognizedSymbol.replace("(OTC)", "").replace("\\s+".toRegex(), "").uppercase()

        val symbolMatched = cleanSelected == cleanRecognized
        val isSelectedOtc = selectedMarketMode == MarketMode.OTC
        val modeMatched = isSelectedOtc == recognizedIsOtc

        val cleanTf = (recognizedTimeframe ?: "").uppercase().trim()
        val timeframeVerified = cleanTf in listOf("1M", "01:00", "M1", "1 MIN")

        val failureReason = when {
            !symbolMatched -> "Asset mismatch: selected $selectedPairSymbol vs visible $recognizedSymbol"
            !modeMatched -> "Market mode mismatch: selected $selectedMarketMode vs visible ${if (recognizedIsOtc) "OTC" else "REAL"}"
            !timeframeVerified -> "Timeframe mismatch: visible $recognizedTimeframe (App requires 1-minute)"
            else -> null
        }

        return AssetVerificationResult(
            symbolMatched = symbolMatched,
            modeMatched = modeMatched,
            timeframeVerified = timeframeVerified,
            overallVerified = symbolMatched && modeMatched && timeframeVerified,
            failureReason = failureReason
        )
    }
}
