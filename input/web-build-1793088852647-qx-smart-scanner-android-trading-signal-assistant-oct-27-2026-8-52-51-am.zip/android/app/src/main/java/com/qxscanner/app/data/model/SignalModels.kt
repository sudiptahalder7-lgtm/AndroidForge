package com.qxscanner.app.data.model

enum class SignalType {
    UP,
    DOWN,
    NO_TRADE
}

enum class MarketMode {
    REAL,
    OTC
}

enum class ScanningMode {
    CURRENT_CHART,
    SEQUENTIAL_SCAN
}

enum class SignalReason {
    VALIDATED_BULLISH_MOMENTUM,
    VALIDATED_BEARISH_MOMENTUM,
    VALIDATED_BULLISH_REJECTION,
    VALIDATED_BEARISH_REJECTION,
    SCREEN_CAPTURE_STOPPED,
    ASSET_NOT_VERIFIED,
    NO_TRADE_INSUFFICIENT_DATA,
    NO_TRADE_TIMING_UNVERIFIED,
    NO_TRADE_CONFLICTING_EVIDENCE,
    NO_TRADE_LOW_IMAGE_QUALITY,
    NO_TRADE_TIMEFRAME_MISMATCH,
    NO_TRADE_MARKET_MODE_MISMATCH,
    NO_TRADE_STALE_FRAME
}

data class CandlePixelData(
    val index: Int,
    val isBullish: Boolean,
    val bodyTop: Float,
    val bodyBottom: Float,
    val wickHigh: Float,
    val wickLow: Float,
    val bodyHeight: Float,
    val upperWickLength: Float,
    val lowerWickLength: Float,
    val totalLength: Float
)

data class ExtractedChartData(
    val timestamp: Long,
    val frameAgeMs: Long,
    val imageClear: Boolean,
    val sharpnessScore: Int,
    val recognizedSymbol: String?,
    val recognizedIsOtc: Boolean,
    val recognizedTimeframe: String?,
    val countdownSecondsRemaining: Int?,
    val countdownConfidence: Int,
    val detectedCandles: List<CandlePixelData>
)

data class ValidationChecklist(
    val screenCaptureActive: Boolean,
    val imageSufficientlyClear: Boolean,
    val symbolMatched: Boolean,
    val marketModeMatched: Boolean,
    val timeframeVerified: Boolean,
    val timingReliable: Boolean,
    val sufficientCandlesVisible: Boolean,
    val frameRecent: Boolean,
    val internallyConsistent: Boolean
) {
    val allPassed: Boolean
        get() = screenCaptureActive &&
                imageSufficientlyClear &&
                symbolMatched &&
                marketModeMatched &&
                timeframeVerified &&
                timingReliable &&
                sufficientCandlesVisible &&
                frameRecent &&
                internallyConsistent
}

data class SignalResult(
    val id: String,
    val timestamp: Long,
    val pairSymbol: String,
    val isOtc: Boolean,
    val timeframe: String = "1 MIN",
    val signal: SignalType,
    val modelConfidenceScore: Int, // 0 to 100 heuristic model score
    val reason: SignalReason,
    val detailedMessage: String,
    val validationChecklist: ValidationChecklist,
    val allChecksPassed: Boolean,
    val countdownSeconds: Int?,
    val observedCandleCount: Int,
    val evaluatedOutcome: String? = "UNOBSERVED",
    val outcomeNotes: String? = null
)
