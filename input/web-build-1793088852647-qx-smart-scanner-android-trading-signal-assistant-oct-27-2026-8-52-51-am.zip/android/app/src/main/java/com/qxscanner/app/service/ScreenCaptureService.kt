package com.qxscanner.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.qxscanner.app.data.local.AppDatabase
import com.qxscanner.app.data.local.SignalEntity
import com.qxscanner.app.data.model.ExtractedChartData
import com.qxscanner.app.data.model.MarketMode
import com.qxscanner.app.engine.*
import com.qxscanner.app.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * ScreenCaptureService
 * Foreground service conforming to Android 14+ MEDIA_PROJECTION requirements.
 * Captures frames safely, passes through ML/OCR and candle recognition,
 * and feeds the SignalValidationEngine.
 */
class ScreenCaptureService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private val regionDetector = ChartRegionDetector()
    private val ocrProcessor = ChartOCRProcessor()
    private val candleEngine = CandleRecognitionEngine()
    private val validationEngine = SignalValidationEngine()

    private var selectedPair = "GBP/USD"
    private var marketMode = MarketMode.REAL
    private var captureIntervalMs = 1000L
    private var isCapturing = false

    companion object {
        const val CHANNEL_ID = "qx_capture_channel"
        const val NOTIFICATION_ID = 101

        const val ACTION_START = "ACTION_START_CAPTURE"
        const val ACTION_STOP = "ACTION_STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val EXTRA_PAIR = "EXTRA_PAIR"
        const val EXTRA_MARKET_MODE = "EXTRA_MARKET_MODE"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                selectedPair = intent.getStringExtra(EXTRA_PAIR) ?: "GBP/USD"
                marketMode = MarketMode.valueOf(intent.getStringExtra(EXTRA_MARKET_MODE) ?: "REAL")

                if (resultCode != 0 && resultData != null) {
                    startForeground(NOTIFICATION_ID, buildNotification("Scanning active: $selectedPair"))
                    _isServiceRunning.value = true
                    startMediaProjection(resultCode, resultData)
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startMediaProjection(resultCode: Int, resultData: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, resultData)

        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "QXScannerDisplay",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )

        isCapturing = true
        startProcessingLoop()
    }

    private fun startProcessingLoop() {
        serviceScope.launch {
            while (isActive && isCapturing) {
                val startTime = System.currentTimeMillis()
                processLatestFrame()
                val elapsed = System.currentTimeMillis() - startTime
                val delayTime = (captureIntervalMs - elapsed).coerceAtLeast(150L)
                delay(delayTime)
            }
        }
    }

    private suspend fun processLatestFrame() {
        val reader = imageReader ?: return
        var image: android.media.Image? = null
        var bitmap: Bitmap? = null

        try {
            image = reader.acquireLatestImage() ?: return
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * image.width

            bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val frameTimestamp = System.currentTimeMillis()
            val regions = regionDetector.detectRegions(bitmap)

            val headerBmp = regionDetector.cropRegion(bitmap, regions.headerRect)
            val countdownBmp = regionDetector.cropRegion(bitmap, regions.countdownRect)
            val chartBmp = regionDetector.cropRegion(bitmap, regions.chartCanvasRect)

            if (headerBmp != null && chartBmp != null) {
                val ocr = ocrProcessor.processHeaderAndTiming(headerBmp, countdownBmp)
                val candles = candleEngine.recognizeCandles(chartBmp)

                val extracted = ExtractedChartData(
                    timestamp = frameTimestamp,
                    frameAgeMs = System.currentTimeMillis() - frameTimestamp,
                    imageClear = true,
                    sharpnessScore = 85,
                    recognizedSymbol = ocr.recognizedSymbol,
                    recognizedIsOtc = ocr.isOtc,
                    recognizedTimeframe = ocr.timeframe,
                    countdownSecondsRemaining = ocr.countdownSeconds,
                    countdownConfidence = ocr.confidence,
                    detectedCandles = candles
                )

                val signal = validationEngine.validateAndGenerate(
                    screenCaptureActive = true,
                    selectedPairSymbol = selectedPair,
                    selectedMarketMode = marketMode,
                    extractedData = extracted
                )

                // Save to Room database if a new validated signal or state change occurs
                if (signal.signal != com.qxscanner.app.data.model.SignalType.NO_TRADE || signal.observedCandleCount >= 5) {
                    val entity = SignalEntity(
                        id = signal.id,
                        timestamp = signal.timestamp,
                        pairSymbol = signal.pairSymbol,
                        isOtc = signal.isOtc,
                        timeframe = signal.timeframe,
                        signal = signal.signal.name,
                        modelConfidenceScore = signal.modelConfidenceScore,
                        reason = signal.reason.name,
                        detailedMessage = signal.detailedMessage,
                        observedCandleCount = signal.observedCandleCount,
                        countdownSeconds = signal.countdownSeconds,
                        allChecksPassed = signal.allChecksPassed
                    )
                    AppDatabase.getInstance(applicationContext).signalDao().insertSignal(entity)
                }
            }
        } catch (e: Exception) {
            // Safe catch to ensure foreground service never crashes
        } finally {
            image?.close()
            bitmap?.recycle()
        }
    }

    private fun stopCapture() {
        isCapturing = false
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
        _isServiceRunning.value = false
    }

    override fun onDestroy() {
        stopCapture()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Screen Scanner Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors visible Quotex chart for candle timing and patterns"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("QX Vision Pro")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingOpen)
            .addAction(android.R.drawable.ic_media_pause, "Stop Scanning", pendingStop)
            .setOngoing(true)
            .build()
    }
}
