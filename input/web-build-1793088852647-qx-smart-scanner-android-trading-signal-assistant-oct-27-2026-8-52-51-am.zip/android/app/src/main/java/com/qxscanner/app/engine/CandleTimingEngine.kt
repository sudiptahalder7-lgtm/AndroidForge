package com.qxscanner.app.engine

/**
 * CandleTimingEngine
 * Focuses strictly on 1-minute candle transitions.
 * Target window: final 7 seconds of the candle (<= 7s and >= 1s).
 * Goal: emit validated signal ~1 second before candle closes.
 */
class CandleTimingEngine {

    data class TimingEvaluation(
        val isWindowActive: Boolean,
        val secondsRemaining: Int?,
        val confidenceScore: Int,
        val statusMessage: String
    )

    fun evaluateTiming(
        countdownSeconds: Int?,
        countdownConfidence: Int
    ): TimingEvaluation {
        if (countdownSeconds == null) {
            return TimingEvaluation(
                isWindowActive = false,
                secondsRemaining = null,
                confidenceScore = 0,
                statusMessage = "Countdown timer unreadable or missing from chart"
            )
        }

        if (countdownConfidence < 60) {
            return TimingEvaluation(
                isWindowActive = false,
                secondsRemaining = countdownSeconds,
                confidenceScore = countdownConfidence,
                statusMessage = "Countdown OCR confidence too low ($countdownConfidence%)"
            )
        }

        return when {
            countdownSeconds in 1..7 -> {
                TimingEvaluation(
                    isWindowActive = true,
                    secondsRemaining = countdownSeconds,
                    confidenceScore = countdownConfidence,
                    statusMessage = "Active 7-second pre-close window ($countdownSeconds s left)"
                )
            }
            countdownSeconds > 7 -> {
                TimingEvaluation(
                    isWindowActive = false,
                    secondsRemaining = countdownSeconds,
                    confidenceScore = countdownConfidence,
                    statusMessage = "Holding analysis until final 7s (Current: $countdownSeconds s)"
                )
            }
            else -> {
                TimingEvaluation(
                    isWindowActive = false,
                    secondsRemaining = countdownSeconds,
                    confidenceScore = countdownConfidence,
                    statusMessage = "Candle expired or transitioning"
                )
            }
        }
    }
}
