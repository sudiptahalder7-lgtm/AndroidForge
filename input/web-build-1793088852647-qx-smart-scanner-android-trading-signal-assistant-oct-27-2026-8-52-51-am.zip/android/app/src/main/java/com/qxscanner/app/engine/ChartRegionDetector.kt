package com.qxscanner.app.engine

import android.graphics.Bitmap
import android.graphics.Rect

/**
 * ChartRegionDetector
 * Identifies functional regions on a captured Quotex Android screen:
 * - Header region: Top area with asset selector, OTC badge, timeframe (1M)
 * - Candle countdown region: Typically near the current candle or top-right indicator
 * - Chart grid / candle canvas region: Main vertical and horizontal area where candles are drawn
 */
class ChartRegionDetector {

    data class DetectedRegions(
        val headerRect: Rect,
        val countdownRect: Rect,
        val chartCanvasRect: Rect,
        val isLandscape: Boolean
    )

    fun detectRegions(frame: Bitmap): DetectedRegions {
        val width = frame.width
        val height = frame.height
        val isLandscape = width > height

        return if (isLandscape) {
            // Quotex Landscape Trading UI layout
            val header = Rect(0, 0, (width * 0.45f).toInt(), (height * 0.16f).toInt())
            val countdown = Rect((width * 0.70f).toInt(), 0, width, (height * 0.18f).toInt())
            val chartCanvas = Rect(
                (width * 0.05f).toInt(),
                (height * 0.16f).toInt(),
                (width * 0.88f).toInt(),
                (height * 0.90f).toInt()
            )
            DetectedRegions(header, countdown, chartCanvas, isLandscape = true)
        } else {
            // Quotex Portrait Mobile Layout
            val header = Rect(0, (height * 0.04f).toInt(), width, (height * 0.14f).toInt())
            val countdown = Rect((width * 0.60f).toInt(), (height * 0.12f).toInt(), width, (height * 0.18f).toInt())
            val chartCanvas = Rect(
                0,
                (height * 0.18f).toInt(),
                width,
                (height * 0.65f).toInt()
            )
            DetectedRegions(header, countdown, chartCanvas, isLandscape = false)
        }
    }

    /**
     * Crop bitmap safely without throwing OutOfMemory or IllegalArgumentException
     */
    fun cropRegion(source: Bitmap, rect: Rect): Bitmap? {
        return try {
            val safeLeft = rect.left.coerceIn(0, source.width - 1)
            val safeTop = rect.top.coerceIn(0, source.height - 1)
            val safeWidth = rect.width().coerceAtMost(source.width - safeLeft).coerceAtLeast(1)
            val safeHeight = rect.height().coerceAtMost(source.height - safeTop).coerceAtLeast(1)

            Bitmap.createBitmap(source, safeLeft, safeTop, safeWidth, safeHeight)
        } catch (e: Exception) {
            null
        }
    }
}
