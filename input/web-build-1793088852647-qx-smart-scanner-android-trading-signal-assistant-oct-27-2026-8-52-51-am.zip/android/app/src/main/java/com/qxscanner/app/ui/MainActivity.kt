package com.qxscanner.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.qxscanner.app.data.MarketPairsConfig
import com.qxscanner.app.data.local.AppDatabase
import com.qxscanner.app.data.model.MarketMode
import com.qxscanner.app.service.FloatingOverlayService
import com.qxscanner.app.service.ScreenCaptureService
import com.qxscanner.app.ui.components.DashboardScreen
import com.qxscanner.app.ui.theme.CharcoalBackground
import com.qxscanner.app.ui.theme.QXSmartScannerTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val db by lazy { AppDatabase.getInstance(this) }

    private var pendingPair: String = "GBP/USD"
    private var pendingMarketMode: MarketMode = MarketMode.REAL

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenCaptureService.EXTRA_PAIR, pendingPair)
                putExtra(ScreenCaptureService.EXTRA_MARKET_MODE, pendingMarketMode.name)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Screen Capture Started for $pendingPair", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_LONG).show()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startFloatingOverlayService()
        } else {
            Toast.makeText(this, "Overlay permission denied. Floating button disabled.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            QXSmartScannerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CharcoalBackground
                ) {
                    DashboardScreen(
                        database = db,
                        onStartScan = { pair, mode ->
                            pendingPair = pair
                            pendingMarketMode = mode
                            requestScreenCapture()
                        },
                        onStopScan = {
                            val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
                                action = ScreenCaptureService.ACTION_STOP
                            }
                            startService(stopIntent)
                        },
                        onToggleOverlay = { enable ->
                            if (enable) {
                                requestOverlayPermission()
                            } else {
                                stopService(Intent(this, FloatingOverlayService::class.java))
                            }
                        }
                    )
                }
            }
        }
    }

    private fun requestScreenCapture() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            startFloatingOverlayService()
        }
    }

    private fun startFloatingOverlayService() {
        startService(Intent(this, FloatingOverlayService::class.java))
        Toast.makeText(this, "Floating assistant activated", Toast.LENGTH_SHORT).show()
    }
}
