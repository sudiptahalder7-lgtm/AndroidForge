package com.qxscanner.app.engine

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * ChartOCRProcessor
 * Uses Google ML Kit on-device Text Recognition (runs completely offline on-device,
 * no internet connection or cloud API calls).
 * Parses:
 * - Asset symbol (e.g. "GBP/USD", "EUR/JPY")
 * - OTC indicator badge ("OTC", "(OTC)")
 * - Timeframe (e.g. "1M", "01:00", "M1")
 * - Candle countdown timer (e.g. "00:06", "00:03")
 */
class ChartOCRProcessor {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    data class OcrResult(
        val rawText: String,
        val recognizedSymbol: String?,
        val isOtc: Boolean,
        val timeframe: String?,
        val countdownSeconds: Int?,
        val confidence: Int
    )

    suspend fun processHeaderAndTiming(headerBitmap: Bitmap, countdownBitmap: Bitmap?): OcrResult {
        val headerText = recognizeText(headerBitmap)
        val countdownText = countdownBitmap?.let { recognizeText(it) } ?: ""

        val combined = "$headerText\n$countdownText"
        val isOtc = combined.contains("OTC", ignoreCase = true)
        val symbol = extractSymbol(combined)
        val timeframe = extractTimeframe(combined)
        val countdownSeconds = extractCountdown(combined)

        val confidence = when {
            symbol != null && timeframe != null && countdownSeconds != null -> 95
            symbol != null && timeframe != null -> 80
            symbol != null -> 65
            else -> 30
        }

        return OcrResult(
            rawText = combined,
            recognizedSymbol = symbol,
            isOtc = isOtc,
            timeframe = timeframe,
            countdownSeconds = countdownSeconds,
            confidence = confidence
        )
    }

    private suspend fun recognizeText(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        try {
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    cont.resume(visionText.text)
                }
                .addOnFailureListener {
                    cont.resume("")
                }
        } catch (e: Exception) {
            cont.resume("")
        }
    }

    private fun extractSymbol(text: String): String? {
        // Look for currency pair pattern like GBP/USD, EURJPY, USD/CHF
        val slashRegex = Regex("([A-Z]{3}/[A-Z]{3})")
        slashRegex.find(text)?.let { return it.value }

        val sixLetterRegex = Regex("\\b([A-Z]{3})([A-Z]{3})\\b")
        sixLetterRegex.find(text)?.let {
            val match = it.groupValues
            return "${match[1]}/${match[2]}"
        }

        return null
    }

    private fun extractTimeframe(text: String): String? {
        val tfRegex = Regex("\\b(1M|01:00|M1|5M|15M|1H|30S)\\b", RegexOption.IGNORE_CASE)
        return tfRegex.find(text)?.value?.uppercase()
    }

    private fun extractCountdown(text: String): Int? {
        // e.g. "00:07", "0:05", ":04", "07s"
        val mmSsRegex = Regex("(?:00:0?|0:0?|:0?)([0-5]?[0-9])\\b")
        mmSsRegex.find(text)?.let {
            return it.groupValues[1].toIntOrNull()
        }

        val secRegex = Regex("\\b0?([1-9]|[1-5][0-9])s\\b", RegexOption.IGNORE_CASE)
        secRegex.find(text)?.let {
            return it.groupValues[1].toIntOrNull()
        }

        return null
    }
}
