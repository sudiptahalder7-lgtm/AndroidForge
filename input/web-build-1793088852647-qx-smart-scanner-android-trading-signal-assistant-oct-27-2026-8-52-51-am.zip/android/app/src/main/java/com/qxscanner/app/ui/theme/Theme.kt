package com.qxscanner.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CharcoalBackground = Color(0xFF0B0F14)
val CharcoalSurface = Color(0xFF131A22)
val CharcoalCard = Color(0xFF1B232D)
val CharcoalBorder = Color(0xFF26323E)

val NeonGreenAccent = Color(0xFF00E676)
val CrimsonDownAccent = Color(0xFFFF3366)
val NeutralGray = Color(0xFF8B949E)
val TextPrimary = Color(0xFFF0F6FC)
val TextMuted = Color(0xFF8B949E)

private val DarkColorScheme = darkColorScheme(
    primary = NeonGreenAccent,
    onPrimary = Color.Black,
    secondary = CrimsonDownAccent,
    onSecondary = Color.White,
    background = CharcoalBackground,
    onBackground = TextPrimary,
    surface = CharcoalSurface,
    onSurface = TextPrimary,
    surfaceVariant = CharcoalCard,
    onSurfaceVariant = TextMuted,
    outline = CharcoalBorder
)

@Composable
fun QXSmartScannerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
