package com.qxscanner.app.engine

import android.graphics.Bitmap
import android.graphics.Color
import com.qxscanner.app.data.model.CandlePixelData

/**
 * CandleRecognitionEngine
 * Analyzes raw chart pixel data on-device to isolate candles without external market APIs.
 *
 * Distinguishes Quotex chart palette:
 * - Bullish: Green hues (RGB: High G, low R)
 * - Bearish: Red/Crimson hues (RGB: High R, low G)
 * - Dark background / Grid lines (RGB < 40)
 */
class CandleRecognitionEngine {

    fun recognizeCandles(chartCanvasBitmap: Bitmap): List<CandlePixelData> {
        val width = chartCanvasBitmap.width
        val height = chartCanvasBitmap.height
        if (width < 50 || height < 50) return emptyList()

        // Sample vertical column profiles
        val stepX = (width / 60).coerceAtLeast(2)
        val candleCandidates = mutableListOf<CandlePixelData>()

        var currentCandleX = -1
        var candleIndex = 0

        var x = 0
        while (x < width - stepX) {
            val columnProfile = analyzeColumn(chartCanvasBitmap, x, height)
            if (columnProfile.hasCandlePixel) {
                // Candle column found
                val isBull = columnProfile.greenCount > columnProfile.redCount
                val bodyHeight = (columnProfile.bodyBottom - columnProfile.bodyTop).coerceAtLeast(1f)
                val upperWick = (columnProfile.bodyTop - columnProfile.wickHigh).coerceAtLeast(0f)
                val lowerWick = (columnProfile.wickLow - columnProfile.bodyBottom).coerceAtLeast(0f)
                val total = (columnProfile.wickLow - columnProfile.wickHigh).coerceAtLeast(bodyHeight)

                if (bodyHeight >= 3f) { // filter noise
                    candleCandidates.add(
                        CandlePixelData(
                            index = candleIndex++,
                            isBullish = isBull,
                            bodyTop = columnProfile.bodyTop,
                            bodyBottom = columnProfile.bodyBottom,
                            wickHigh = columnProfile.wickHigh,
                            wickLow = columnProfile.wickLow,
                            bodyHeight = bodyHeight,
                            upperWickLength = upperWick,
                            lowerWickLength = lowerWick,
                            totalLength = total
                        )
                    )
                    // Skip ahead past candle body width
                    x += (width / 25).coerceAtLeast(6)
                }
            }
            x += stepX
        }

        // Return latest candles (up to 15)
        return candleCandidates.takeLast(15)
    }

    private data class ColumnProfile(
        val hasCandlePixel: Boolean,
        val greenCount: Int,
        val redCount: Int,
        val bodyTop: Float,
        val bodyBottom: Float,
        val wickHigh: Float,
        val wickLow: Float
    )

    private fun analyzeColumn(bitmap: Bitmap, x: Int, height: Int): ColumnProfile {
        var greenCount = 0
        var redCount = 0
        var firstColoredY = -1
        var lastColoredY = -1

        var minBodyY = -1
        var maxBodyY = -1

        for (y in 0 until height step 2) {
            val pixel = bitmap.getPixel(x, y)
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)

            val isGreen = g > 110 && g > r * 1.3f && g > b
            val isRed = r > 120 && r > g * 1.4f && r > b * 1.2f

            if (isGreen || isRed) {
                if (firstColoredY == -1) firstColoredY = y
                lastColoredY = y

                if (isGreen) greenCount++ else redCount++

                // Body detection: check horizontal width at this Y
                val isThickBody = isThickPixel(bitmap, x, y)
                if (isThickBody) {
                    if (minBodyY == -1) minBodyY = y
                    maxBodyY = y
                }
            }
        }

        val hasCandle = (greenCount + redCount) > 8
        val wickHigh = if (firstColoredY != -1) firstColoredY.toFloat() else 0f
        val wickLow = if (lastColoredY != -1) lastColoredY.toFloat() else height.toFloat()
        val bodyTop = if (minBodyY != -1) minBodyY.toFloat() else wickHigh
        val bodyBottom = if (maxBodyY != -1) maxBodyY.toFloat() else wickLow

        return ColumnProfile(
            hasCandlePixel = hasCandle,
            greenCount = greenCount,
            redCount = redCount,
            bodyTop = bodyTop,
            bodyBottom = bodyBottom,
            wickHigh = wickHigh,
            wickLow = wickLow
        )
    }

    private fun isThickPixel(bitmap: Bitmap, x: Int, y: Int): Boolean {
        if (x <= 1 || x >= bitmap.width - 2) return false
        val pLeft = bitmap.getPixel(x - 2, y)
        val pRight = bitmap.getPixel(x + 2, y)

        val gL = Color.green(pLeft)
        val rL = Color.red(pLeft)
        val gR = Color.green(pRight)
        val rR = Color.red(pRight)

        val leftColored = (gL > 100 && gL > rL) || (rL > 100 && rL > gL)
        val rightColored = (gR > 100 && gR > rR) || (rR > 100 && rR > gR)

        return leftColored && rightColored
    }
}
