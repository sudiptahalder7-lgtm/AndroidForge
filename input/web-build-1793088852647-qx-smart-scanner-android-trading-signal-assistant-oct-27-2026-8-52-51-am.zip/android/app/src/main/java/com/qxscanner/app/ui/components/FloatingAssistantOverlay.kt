package com.qxscanner.app.ui.components

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qxscanner.app.ui.MainActivity
import com.qxscanner.app.ui.theme.*

@Composable
fun FloatingAssistantOverlay(
    onDragDelta: (Float, Float) -> Unit,
    onCloseOverlay: () -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }
    var isScanning by remember { mutableStateOf(true) }
    var currentSignal by remember { mutableStateOf("NO TRADE") }
    var currentPair by remember { mutableStateOf("GBP/USD") }
    var isOtc by remember { mutableStateOf(false) }
    var countdownSec by remember { mutableStateOf(5) }

    // Glow pulse animation for circular floating button
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    val signalColor = when (currentSignal) {
        "UP" -> NeonGreenAccent
        "DOWN" -> CrimsonDownAccent
        else -> NeutralGray
    }

    Box(
        modifier = Modifier
            .wrapContentSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        if (!isExpanded) {
            // Circular draggable button
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(CharcoalSurface)
                    .border(
                        2.dp,
                        if (isScanning) NeonGreenAccent.copy(alpha = pulseAlpha) else CharcoalBorder,
                        CircleShape
                    )
                    .clickable { isExpanded = true }
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (currentSignal) {
                        "UP" -> Icons.Default.TrendingUp
                        "DOWN" -> Icons.Default.TrendingDown
                        else -> Icons.Default.Radar
                    },
                    contentDescription = "Expand Scanner",
                    tint = signalColor,
                    modifier = Modifier.size(28.dp)
                )
            }
        } else {
            // Expanded floating scanner panel
            Card(
                modifier = Modifier
                    .width(300.dp)
                    .shadow(16.dp, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "QX SCANNER",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Surface(
                                color = if (isOtc) Color(0xFFE65100) else Color(0xFF1565C0),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (isOtc) "OTC" else "REAL",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }

                        Row {
                            IconButton(
                                onClick = { isExpanded = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Remove, "Minimize", tint = TextMuted)
                            }
                            Spacer(Modifier.width(8.dp))
                            IconButton(
                                onClick = onCloseOverlay,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, "Close", tint = TextMuted)
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Pair & Timeframe info
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CharcoalCard, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ACTIVE PAIR", fontSize = 10.sp, color = TextMuted)
                            Text(currentPair, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("TIMEFRAME", fontSize = 10.sp, color = TextMuted)
                            Text("1 MIN · ${countdownSec}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = NeonGreenAccent)
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Signal Display Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(signalColor.copy(alpha = 0.15f))
                            .border(1.dp, signalColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CURRENT SIGNAL", fontSize = 10.sp, color = TextMuted)
                            Text(
                                text = currentSignal,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = signalColor,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Control Buttons
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { isScanning = !isScanning },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isScanning) CrimsonDownAccent else NeonGreenAccent,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 6.dp)
                        ) {
                            Text(
                                if (isScanning) "STOP SCAN" else "START SCAN",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                val intent = Intent(context, MainActivity::class.java).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                                }
                                context.startActivity(intent)
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 6.dp)
                        ) {
                            Text("DASHBOARD", fontSize = 12.sp, color = TextPrimary)
                        }
                    }
                }
            }
        }
    }
}
