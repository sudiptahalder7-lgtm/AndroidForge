package com.qxscanner.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalDao {

    @Query("SELECT * FROM signal_history ORDER BY timestamp DESC")
    fun getAllSignals(): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signal_history WHERE isOtc = :isOtc ORDER BY timestamp DESC")
    fun getSignalsByMarket(isOtc: Boolean): Flow<List<SignalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(signal: SignalEntity)

    @Query("UPDATE signal_history SET evaluatedOutcome = :outcome, outcomeNotes = :notes WHERE id = :id")
    suspend fun updateOutcome(id: String, outcome: String, notes: String?)

    @Query("DELETE FROM signal_history")
    suspend fun clearAll()

    @Query("DELETE FROM signal_history WHERE isOtc = :isOtc")
    suspend fun clearByMarket(isOtc: Boolean)

    @Query("SELECT COUNT(*) FROM signal_history WHERE isOtc = :isOtc")
    suspend fun getCountByMarket(isOtc: Boolean): Int

    @Query("SELECT COUNT(*) FROM signal_history WHERE isOtc = :isOtc AND evaluatedOutcome = 'WIN'")
    suspend fun getWinCountByMarket(isOtc: Boolean): Int

    @Query("SELECT COUNT(*) FROM signal_history WHERE isOtc = :isOtc AND evaluatedOutcome = 'LOSS'")
    suspend fun getLossCountByMarket(isOtc: Boolean): Int
}
