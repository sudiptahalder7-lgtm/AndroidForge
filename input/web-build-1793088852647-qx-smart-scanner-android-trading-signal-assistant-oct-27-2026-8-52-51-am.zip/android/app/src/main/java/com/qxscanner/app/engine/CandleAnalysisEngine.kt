package com.qxscanner.app.engine

import com.qxscanner.app.data.model.CandlePixelData
import com.qxscanner.app.data.model.SignalType
import kotlin.math.abs

/**
 * CandleAnalysisEngine
 * Pure observable technical evaluation based on visible candle sequence.
 */
class CandleAnalysisEngine {

    data class AnalysisOutput(
        val candidateSignal: SignalType,
        val modelScore: Int,
        val isConsistent: Boolean,
        val bullishPoints: Int,
        val bearishPoints: Int,
        val summary: String
    )

    fun analyze(candles: List<CandlePixelData>): AnalysisOutput {
        if (candles.size < 5) {
            return AnalysisOutput(
                candidateSignal = SignalType.NO_TRADE,
                modelScore = 0,
                isConsistent = false,
                bullishPoints = 0,
                bearishPoints = 0,
                summary = "Insufficient candle history (< 5 candles)"
            )
        }

        val recent = candles.takeLast(5)
        val current = recent.last()
        val prior = recent[recent.size - 2]
        val third = recent[recent.size - 3]

        var bullishPoints = 0
        var bearishPoints = 0

        // 1. Color sequence bias
        val greenCount = recent.count { it.isBullish }
        val redCount = recent.count { !it.isBullish }

        if (greenCount >= 4) bullishPoints += 2
        else if (redCount >= 4) bearishPoints += 2

        // 2. Body momentum
        val avgBody = recent.map { it.bodyHeight }.average().toFloat()
        if (current.bodyHeight > avgBody * 1.15f) {
            if (current.isBullish) bullishPoints += 2 else bearishPoints += 2
        }

        // 3. Wick Rejection
        if (current.lowerWickLength > current.bodyHeight * 1.3f) {
            bullishPoints += 2 // buying rejection from bottom
        }
        if (current.upperWickLength > current.bodyHeight * 1.3f) {
            bearishPoints += 2 // selling rejection from top
        }

        // 4. Consecutive momentum
        if (current.isBullish && prior.isBullish && third.isBullish) {
            bullishPoints += 1
        } else if (!current.isBullish && !prior.isBullish && !third.isBullish) {
            bearishPoints += 1
        }

        // 5. Doji or conflicting wick
        val isDoji = current.bodyHeight < avgBody * 0.25f
        val hasConflictingWick = (current.isBullish && current.upperWickLength > current.bodyHeight * 1.5f) ||
                (!current.isBullish && current.lowerWickLength > current.bodyHeight * 1.5f)

        if (isDoji || hasConflictingWick) {
            return AnalysisOutput(
                candidateSignal = SignalType.NO_TRADE,
                modelScore = 35,
                isConsistent = false,
                bullishPoints = bullishPoints,
                bearishPoints = bearishPoints,
                summary = if (isDoji) "Doji indecision candle detected" else "Opposing wick pressure against body"
            )
        }

        // 6. Conflicting balance
        if (bullishPoints > 0 && bearishPoints > 0 && abs(bullishPoints - bearishPoints) < 2) {
            return AnalysisOutput(
                candidateSignal = SignalType.NO_TRADE,
                modelScore = 40,
                isConsistent = false,
                bullishPoints = bullishPoints,
                bearishPoints = bearishPoints,
                summary = "Conflicting bullish and bearish technical patterns"
            )
        }

        if (bullishPoints >= 3 && bearishPoints <= 1) {
            val score = (60 + bullishPoints * 7).coerceAtMost(88)
            return AnalysisOutput(
                candidateSignal = SignalType.UP,
                modelScore = score,
                isConsistent = true,
                bullishPoints = bullishPoints,
                bearishPoints = bearishPoints,
                summary = "Confirmed bullish momentum & lower wick support"
            )
        }

        if (bearishPoints >= 3 && bullishPoints <= 1) {
            val score = (60 + bearishPoints * 7).coerceAtMost(88)
            return AnalysisOutput(
                candidateSignal = SignalType.DOWN,
                modelScore = score,
                isConsistent = true,
                bullishPoints = bullishPoints,
                bearishPoints = bearishPoints,
                summary = "Confirmed bearish momentum & upper wick resistance"
            )
        }

        return AnalysisOutput(
            candidateSignal = SignalType.NO_TRADE,
            modelScore = 45,
            isConsistent = true,
            bullishPoints = bullishPoints,
            bearishPoints = bearishPoints,
            summary = "Insufficient directional conviction"
        )
    }
}
