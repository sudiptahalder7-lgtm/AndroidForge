package com.qxscanner.app.engine

import com.qxscanner.app.data.model.*
import java.util.UUID

/**
 * SignalValidationEngine
 * Gatekeeper enforcing the 9 essential criteria before any UP or DOWN signal is released.
 */
class SignalValidationEngine(
    private val candleAnalysisEngine: CandleAnalysisEngine = CandleAnalysisEngine(),
    private val assetVerificationEngine: AssetVerificationEngine = AssetVerificationEngine(),
    private val candleTimingEngine: CandleTimingEngine = CandleTimingEngine()
) {

    fun validateAndGenerate(
        screenCaptureActive: Boolean,
        selectedPairSymbol: String,
        selectedMarketMode: MarketMode,
        extractedData: ExtractedChartData?,
        currentTimeMs: Long = System.currentTimeMillis()
    ): SignalResult {
        val id = "sig_${currentTimeMs}_${UUID.randomUUID().toString().take(5)}"
        val isSelectedOtc = selectedMarketMode == MarketMode.OTC

        val baseChecklist = ValidationChecklist(
            screenCaptureActive = screenCaptureActive,
            imageSufficientlyClear = false,
            symbolMatched = false,
            marketModeMatched = false,
            timeframeVerified = false,
            timingReliable = false,
            sufficientCandlesVisible = false,
            frameRecent = false,
            internallyConsistent = false
        )

        // 1. Screen capture check
        if (!screenCaptureActive) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = SignalReason.SCREEN_CAPTURE_STOPPED,
                detailedMessage = "Screen capture permission not active or revoked.",
                validationChecklist = baseChecklist,
                allChecksPassed = false,
                countdownSeconds = null,
                observedCandleCount = 0
            )
        }

        if (extractedData == null) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = SignalReason.NO_TRADE_INSUFFICIENT_DATA,
                detailedMessage = "No chart frame data extracted.",
                validationChecklist = baseChecklist,
                allChecksPassed = false,
                countdownSeconds = null,
                observedCandleCount = 0
            )
        }

        // 2. Image clarity check
        val imageClear = extractedData.imageClear && extractedData.sharpnessScore >= 55
        val checklistWithImage = baseChecklist.copy(imageSufficientlyClear = imageClear)
        if (!imageClear) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = SignalReason.NO_TRADE_LOW_IMAGE_QUALITY,
                detailedMessage = "Frame blur or black screen detected (Sharpness: ${extractedData.sharpnessScore}/100)",
                validationChecklist = checklistWithImage,
                allChecksPassed = false,
                countdownSeconds = extractedData.countdownSecondsRemaining,
                observedCandleCount = extractedData.detectedCandles.size
            )
        }

        // 8. Stale frame check
        val frameAge = extractedData.frameAgeMs
        val isRecent = frameAge in 0..1999
        val checklistWithAge = checklistWithImage.copy(frameRecent = isRecent)
        if (!isRecent) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = SignalReason.NO_TRADE_STALE_FRAME,
                detailedMessage = "Frame is stale (${frameAge}ms old). Required < 2000ms.",
                validationChecklist = checklistWithAge,
                allChecksPassed = false,
                countdownSeconds = extractedData.countdownSecondsRemaining,
                observedCandleCount = extractedData.detectedCandles.size
            )
        }

        // 3, 4, 5. Asset, Market Mode, and Timeframe verification
        val assetVer = assetVerificationEngine.verifyAsset(
            selectedPairSymbol = selectedPairSymbol,
            selectedMarketMode = selectedMarketMode,
            recognizedSymbol = extractedData.recognizedSymbol,
            recognizedIsOtc = extractedData.recognizedIsOtc,
            recognizedTimeframe = extractedData.recognizedTimeframe
        )

        val checklistWithAsset = checklistWithAge.copy(
            symbolMatched = assetVer.symbolMatched,
            marketModeMatched = assetVer.modeMatched,
            timeframeVerified = assetVer.timeframeVerified
        )

        if (!assetVer.overallVerified) {
            val (reason, msg) = when {
                !assetVer.symbolMatched -> Pair(
                    SignalReason.ASSET_NOT_VERIFIED,
                    "Asset mismatch. Expected $selectedPairSymbol, found ${extractedData.recognizedSymbol ?: "None"}."
                )
                !assetVer.modeMatched -> Pair(
                    SignalReason.NO_TRADE_MARKET_MODE_MISMATCH,
                    "Mode mismatch. Selected $selectedMarketMode vs chart ${if (extractedData.recognizedIsOtc) "OTC" else "REAL"}."
                )
                else -> Pair(
                    SignalReason.NO_TRADE_TIMEFRAME_MISMATCH,
                    "Timeframe mismatch. Visible: ${extractedData.recognizedTimeframe}. Requires 1-minute."
                )
            }
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = reason,
                detailedMessage = msg,
                validationChecklist = checklistWithAsset,
                allChecksPassed = false,
                countdownSeconds = extractedData.countdownSecondsRemaining,
                observedCandleCount = extractedData.detectedCandles.size
            )
        }

        // 6. Candle timing check (final 7s)
        val timing = candleTimingEngine.evaluateTiming(
            extractedData.countdownSecondsRemaining,
            extractedData.countdownConfidence
        )
        val checklistWithTiming = checklistWithAsset.copy(timingReliable = timing.isWindowActive)
        if (!timing.isWindowActive) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = SignalReason.NO_TRADE_TIMING_UNVERIFIED,
                detailedMessage = timing.statusMessage,
                validationChecklist = checklistWithTiming,
                allChecksPassed = false,
                countdownSeconds = extractedData.countdownSecondsRemaining,
                observedCandleCount = extractedData.detectedCandles.size
            )
        }

        // 7. Sufficient candles check
        val candleCount = extractedData.detectedCandles.size
        val hasEnoughCandles = candleCount >= 5
        val checklistWithCandles = checklistWithTiming.copy(sufficientCandlesVisible = hasEnoughCandles)
        if (!hasEnoughCandles) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = 0,
                reason = SignalReason.NO_TRADE_INSUFFICIENT_DATA,
                detailedMessage = "Only $candleCount candles identified (minimum 5 required).",
                validationChecklist = checklistWithCandles,
                allChecksPassed = false,
                countdownSeconds = extractedData.countdownSecondsRemaining,
                observedCandleCount = candleCount
            )
        }

        // 9. Candle technical analysis & internal consistency
        val analysis = candleAnalysisEngine.analyze(extractedData.detectedCandles)
        val finalChecklist = checklistWithCandles.copy(internallyConsistent = analysis.isConsistent)

        if (!analysis.isConsistent) {
            return SignalResult(
                id = id,
                timestamp = currentTimeMs,
                pairSymbol = selectedPairSymbol,
                isOtc = isSelectedOtc,
                signal = SignalType.NO_TRADE,
                modelConfidenceScore = analysis.modelScore,
                reason = SignalReason.NO_TRADE_CONFLICTING_EVIDENCE,
                detailedMessage = analysis.summary,
                validationChecklist = finalChecklist,
                allChecksPassed = false,
                countdownSeconds = extractedData.countdownSecondsRemaining,
                observedCandleCount = candleCount
            )
        }

        val finalSignal = analysis.candidateSignal
        val reason = when (finalSignal) {
            SignalType.UP -> if (analysis.bullishPoints > 3) SignalReason.VALIDATED_BULLISH_MOMENTUM else SignalReason.VALIDATED_BULLISH_REJECTION
            SignalType.DOWN -> if (analysis.bearishPoints > 3) SignalReason.VALIDATED_BEARISH_MOMENTUM else SignalReason.VALIDATED_BEARISH_REJECTION
            SignalType.NO_TRADE -> SignalReason.NO_TRADE_INSUFFICIENT_DATA
        }

        return SignalResult(
            id = id,
            timestamp = currentTimeMs,
            pairSymbol = selectedPairSymbol,
            isOtc = isSelectedOtc,
            signal = finalSignal,
            modelConfidenceScore = analysis.modelScore,
            reason = reason,
            detailedMessage = analysis.summary,
            validationChecklist = finalChecklist,
            allChecksPassed = finalSignal != SignalType.NO_TRADE,
            countdownSeconds = extractedData.countdownSecondsRemaining,
            observedCandleCount = candleCount
        )
    }
}
