package com.qxscanner.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.qxscanner.app.data.MarketPairsConfig
import com.qxscanner.app.data.local.AppDatabase
import com.qxscanner.app.data.local.SignalEntity
import com.qxscanner.app.data.model.MarketMode
import com.qxscanner.app.service.ScreenCaptureService
import com.qxscanner.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(
    database: AppDatabase,
    onStartScan: (String, MarketMode) -> Unit,
    onStopScan: () -> Unit,
    onToggleOverlay: (Boolean) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val isCapturing by ScreenCaptureService.isServiceRunning.collectAsState()

    var selectedMode by remember { mutableStateOf(MarketMode.REAL) }
    var selectedPair by remember { mutableStateOf("GBP/USD") }
    var overlayEnabled by remember { mutableStateOf(false) }

    val signalList by database.signalDao().getSignalsByMarket(selectedMode == MarketMode.OTC).collectAsState(initial = emptyList())

    val currentPairs = if (selectedMode == MarketMode.REAL) {
        MarketPairsConfig.getRealPairs()
    } else {
        MarketPairsConfig.getOtcPairs()
    }

    LaunchedEffect(selectedMode) {
        selectedPair = currentPairs.first().displayName
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "QX SMART SCANNER",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Android Trading Signal Assistant · 1M Analysis",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isCapturing) NeonGreenAccent.copy(alpha = 0.2f) else CharcoalCard)
                        .border(1.dp, if (isCapturing) NeonGreenAccent else CharcoalBorder, CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isCapturing) "CAPTURING" else "IDLE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCapturing) NeonGreenAccent else NeutralGray
                    )
                }
            }
        }

        // Market Selector (REAL vs OTC)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalSurface, RoundedCornerShape(10.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    onClick = { selectedMode = MarketMode.REAL },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMode == MarketMode.REAL) CharcoalCard else Color.Transparent,
                        contentColor = if (selectedMode == MarketMode.REAL) NeonGreenAccent else TextMuted
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Text("REAL MARKETS (10)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = { selectedMode = MarketMode.OTC },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMode == MarketMode.OTC) CharcoalCard else Color.Transparent,
                        contentColor = if (selectedMode == MarketMode.OTC) Color(0xFFFF9800) else TextMuted
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    Text("OTC MARKETS (10)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Pair Selector Quick Grid
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("SELECT ASSET PAIR", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        currentPairs.chunked(2).forEach { rowPairs ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowPairs.forEach { pair ->
                                    val isSelected = selectedPair == pair.displayName
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) CharcoalCard else CharcoalBackground)
                                            .border(
                                                1.dp,
                                                if (isSelected) NeonGreenAccent else CharcoalBorder,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable { selectedPair = pair.displayName }
                                            .padding(vertical = 8.dp, horizontal = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = pair.displayName,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) TextPrimary else TextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Scanner Control Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TARGET: $selectedPair", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Screen Capture Engine · 1-Min Candle Focus", fontSize = 11.sp, color = TextMuted)
                        }
                        Switch(
                            checked = overlayEnabled,
                            onCheckedChange = {
                                overlayEnabled = it
                                onToggleOverlay(it)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NeonGreenAccent,
                                checkedTrackColor = CharcoalCard
                            )
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                if (isCapturing) {
                                    onStopScan()
                                } else {
                                    onStartScan(selectedPair, selectedMode)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCapturing) CrimsonDownAccent else NeonGreenAccent,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(vertical = 12.dp)
                        ) {
                            Text(
                                if (isCapturing) "STOP SCREEN CAPTURE" else "START SCREEN SCANNER",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Signal History Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SCAN & SIGNAL HISTORY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                TextButton(
                    onClick = {
                        coroutineScope.launch {
                            database.signalDao().clearByMarket(selectedMode == MarketMode.OTC)
                        }
                    }
                ) {
                    Text("Clear ${if (selectedMode == MarketMode.OTC) "OTC" else "REAL"}", fontSize = 11.sp, color = TextMuted)
                }
            }
        }

        if (signalList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No signals recorded for this market yet. Start scanning to begin.", fontSize = 12.sp, color = TextMuted)
                }
            }
        } else {
            items(signalList) { item ->
                SignalHistoryRow(item)
            }
        }

        item {
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun SignalHistoryRow(signal: SignalEntity) {
    val signalColor = when (signal.signal) {
        "UP" -> NeonGreenAccent
        "DOWN" -> CrimsonDownAccent
        else -> NeutralGray
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(signal.pairSymbol, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("1 MIN", fontSize = 10.sp, color = TextMuted)
                }
                Text(
                    text = signal.detailedMessage,
                    fontSize = 11.sp,
                    color = TextMuted,
                    maxLines = 1
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(signalColor.copy(alpha = 0.15f))
                    .border(1.dp, signalColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = signal.signal,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    color = signalColor
                )
            }
        }
    }
}
