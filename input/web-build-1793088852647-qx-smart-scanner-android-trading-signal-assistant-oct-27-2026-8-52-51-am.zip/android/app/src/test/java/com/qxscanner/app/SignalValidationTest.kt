package com.qxscanner.app

import com.qxscanner.app.data.MarketPairsConfig
import com.qxscanner.app.data.model.*
import com.qxscanner.app.engine.SignalValidationEngine
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class SignalValidationTest {

    private lateinit var validationEngine: SignalValidationEngine

    @Before
    fun setUp() {
        validationEngine = SignalValidationEngine()
    }

    private fun createCandles(direction: String, count: Int = 6): List<CandlePixelData> {
        return (0 until count).map { i ->
            val isBull = when (direction) {
                "bullish" -> true
                "bearish" -> false
                else -> i % 2 == 0
            }
            val bodyHeight = if (direction == "doji" && i == count - 1) 2f else 35f
            val upper = if (direction == "bearish" && i == count - 1) 40f else 6f
            val lower = if (direction == "bullish" && i == count - 1) 40f else 6f

            CandlePixelData(
                index = i,
                isBullish = isBull,
                bodyTop = 100f,
                bodyBottom = 100f + bodyHeight,
                wickHigh = 100f - upper,
                wickLow = 100f + bodyHeight + lower,
                bodyHeight = bodyHeight,
                upperWickLength = upper,
                lowerWickLength = lower,
                totalLength = bodyHeight + upper + lower
            )
        }
    }

    @Test
    fun testMarketPairsExact20Configuration() {
        assertEquals("Total pairs must be exactly 20", 20, MarketPairsConfig.TOTAL_PAIRS)
        assertEquals("Real pairs must be exactly 10", 10, MarketPairsConfig.REAL_PAIRS_COUNT)
        assertEquals("OTC pairs must be exactly 10", 10, MarketPairsConfig.OTC_PAIRS_COUNT)

        val allIds = MarketPairsConfig.CONFIGURED_PAIRS.map { it.id }.toSet()
        assertEquals("All IDs must be unique", 20, allIds.size)

        val allNames = MarketPairsConfig.CONFIGURED_PAIRS.map { it.displayName }.toSet()
        assertEquals("All display names must be unique", 20, allNames.size)
    }

    @Test
    fun testScreenCaptureRevocation() {
        val result = validationEngine.validateAndGenerate(
            screenCaptureActive = false,
            selectedPairSymbol = "GBP/USD",
            selectedMarketMode = MarketMode.REAL,
            extractedData = null
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertEquals(SignalReason.SCREEN_CAPTURE_STOPPED, result.reason)
        assertFalse(result.allChecksPassed)
    }

    @Test
    fun testAssetMismatch() {
        val data = ExtractedChartData(
            timestamp = System.currentTimeMillis(),
            frameAgeMs = 100,
            imageClear = true,
            sharpnessScore = 80,
            recognizedSymbol = "EUR/USD", // Visible on chart
            recognizedIsOtc = false,
            recognizedTimeframe = "1M",
            countdownSecondsRemaining = 4,
            countdownConfidence = 90,
            detectedCandles = createCandles("bullish")
        )

        val result = validationEngine.validateAndGenerate(
            screenCaptureActive = true,
            selectedPairSymbol = "GBP/USD", // Selected by user
            selectedMarketMode = MarketMode.REAL,
            extractedData = data
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertEquals(SignalReason.ASSET_NOT_VERIFIED, result.reason)
    }

    @Test
    fun testTimeframeMismatch() {
        val data = ExtractedChartData(
            timestamp = System.currentTimeMillis(),
            frameAgeMs = 100,
            imageClear = true,
            sharpnessScore = 80,
            recognizedSymbol = "USD/JPY",
            recognizedIsOtc = false,
            recognizedTimeframe = "5M", // Non 1-minute
            countdownSecondsRemaining = 4,
            countdownConfidence = 90,
            detectedCandles = createCandles("bullish")
        )

        val result = validationEngine.validateAndGenerate(
            screenCaptureActive = true,
            selectedPairSymbol = "USD/JPY",
            selectedMarketMode = MarketMode.REAL,
            extractedData = data
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertEquals(SignalReason.NO_TRADE_TIMEFRAME_MISMATCH, result.reason)
    }

    @Test
    fun testTimingOutsideFinal7Seconds() {
        val data = ExtractedChartData(
            timestamp = System.currentTimeMillis(),
            frameAgeMs = 100,
            imageClear = true,
            sharpnessScore = 80,
            recognizedSymbol = "USD/JPY",
            recognizedIsOtc = false,
            recognizedTimeframe = "1M",
            countdownSecondsRemaining = 28, // Held until final 7s
            countdownConfidence = 90,
            detectedCandles = createCandles("bullish")
        )

        val result = validationEngine.validateAndGenerate(
            screenCaptureActive = true,
            selectedPairSymbol = "USD/JPY",
            selectedMarketMode = MarketMode.REAL,
            extractedData = data
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertEquals(SignalReason.NO_TRADE_TIMING_UNVERIFIED, result.reason)
    }

    @Test
    fun testInsufficientCandles() {
        val data = ExtractedChartData(
            timestamp = System.currentTimeMillis(),
            frameAgeMs = 100,
            imageClear = true,
            sharpnessScore = 80,
            recognizedSymbol = "USD/JPY",
            recognizedIsOtc = false,
            recognizedTimeframe = "1M",
            countdownSecondsRemaining = 4,
            countdownConfidence = 90,
            detectedCandles = createCandles("bullish", 3) // Only 3 candles
        )

        val result = validationEngine.validateAndGenerate(
            screenCaptureActive = true,
            selectedPairSymbol = "USD/JPY",
            selectedMarketMode = MarketMode.REAL,
            extractedData = data
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertEquals(SignalReason.NO_TRADE_INSUFFICIENT_DATA, result.reason)
    }

    @Test
    fun testBullishSignalSuccessIn7sWindow() {
        val data = ExtractedChartData(
            timestamp = System.currentTimeMillis(),
            frameAgeMs = 100,
            imageClear = true,
            sharpnessScore = 85,
            recognizedSymbol = "USD/JPY",
            recognizedIsOtc = false,
            recognizedTimeframe = "1M",
            countdownSecondsRemaining = 3, // In 7s window
            countdownConfidence = 95,
            detectedCandles = createCandles("bullish", 6)
        )

        val result = validationEngine.validateAndGenerate(
            screenCaptureActive = true,
            selectedPairSymbol = "USD/JPY",
            selectedMarketMode = MarketMode.REAL,
            extractedData = data
        )

        assertEquals(SignalType.UP, result.signal)
        assertTrue(result.allChecksPassed)
        assertTrue(result.modelConfidenceScore in 60..100)
    }
}
