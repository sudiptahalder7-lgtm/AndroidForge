import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  LayoutDashboard,
  FolderGit2,
  BookOpen,
  Download,
  Shield,
  Layers,
} from 'lucide-react';
import {
  CONFIGURED_MARKET_PAIRS,
  MarketPair,
} from './core/marketConfig.ts';
import { MarketMode, SignalResult } from './core/types.ts';
import { PhoneSimulator } from './components/PhoneSimulator.tsx';
import { NativeComposeDashboard } from './components/NativeComposeDashboard.tsx';
import { AndroidProjectHub } from './components/AndroidProjectHub.tsx';
import { ArchitectureModal } from './components/ArchitectureModal.tsx';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from './data/androidFiles.ts';

export default function App() {
  // Navigation view
  const [currentView, setCurrentView] = useState<'simulator' | 'dashboard' | 'project'>(
    'simulator'
  );

  // Market & pair state
  const [selectedMarketMode, setSelectedMarketMode] = useState<MarketMode>('REAL');
  const [selectedPair, setSelectedPair] = useState<MarketPair>(CONFIGURED_MARKET_PAIRS[0]);
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [captureInterval, setCaptureInterval] = useState<number>(1000);

  // Current validated signal
  const [currentSignal, setCurrentSignal] = useState<SignalResult | null>(null);

  // Local Room history state (persisted to localStorage)
  const [signalHistory, setSignalHistory] = useState<SignalResult[]>(() => {
    try {
      const saved = localStorage.getItem('qx_scanner_room_history');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return [];
  });

  // Architecture modal state
  const [isArchModalOpen, setIsArchModalOpen] = useState<boolean>(false);

  // Persist history
  useEffect(() => {
    try {
      localStorage.setItem('qx_scanner_room_history', JSON.stringify(signalHistory));
    } catch (e) {
      // ignore
    }
  }, [signalHistory]);

  const handleSignalGenerated = (signal: SignalResult) => {
    setCurrentSignal(signal);

    // Record into history if signal is actionable or significant state update
    setSignalHistory((prev) => {
      // Avoid duplicate consecutive identical timestamps
      if (prev.length > 0 && Math.abs(prev[0].timestamp - signal.timestamp) < 1500) {
        return prev;
      }
      return [signal, ...prev.slice(0, 49)];
    });
  };

  const handleUpdateOutcome = (id: string, outcome: 'WIN' | 'LOSS' | 'TIE') => {
    setSignalHistory((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, evaluatedOutcome: outcome } : item
      )
    );
  };

  const handleClearHistory = (mode?: MarketMode) => {
    if (!mode) {
      setSignalHistory([]);
    } else {
      const isOtc = mode === 'OTC';
      setSignalHistory((prev) => prev.filter((item) => item.isOtc !== isOtc));
    }
  };

  const handleDownloadAllZip = async () => {
    try {
      const zip = new JSZip();
      for (const file of ANDROID_PROJECT_FILES) {
        zip.file(file.path, file.content);
      }
      const content = await zip.generateAsync({ type: 'blob' });
      const downloadUrl = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'QX-Vision-Pro-Android-Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F14] text-neutral-100 flex flex-col font-sans selection:bg-emerald-500/30">
      {/* 1. Universal Top Navigation Bar (Strict 3-Zone Contract) */}
      <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-neutral-800/80 bg-[#0E141C]/90 backdrop-blur-md sticky top-0 z-40">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <span className="font-black text-black text-sm font-mono">QX</span>
          </div>
          <span className="text-base font-bold tracking-tight text-neutral-100 whitespace-nowrap">
            QX Vision Pro
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-neutral-400">
          <button
            onClick={() => setCurrentView('simulator')}
            className={`flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              currentView === 'simulator'
                ? 'text-emerald-400 font-bold'
                : 'hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            Live Device Simulator
          </button>

          <button
            onClick={() => setCurrentView('dashboard')}
            className={`flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              currentView === 'dashboard'
                ? 'text-emerald-400 font-bold'
                : 'hover:text-neutral-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            Compose Dashboard & History
          </button>

          <button
            onClick={() => setCurrentView('project')}
            className={`flex items-center gap-1.5 transition-colors whitespace-nowrap ${
              currentView === 'project'
                ? 'text-emerald-400 font-bold'
                : 'hover:text-neutral-200'
            }`}
          >
            <FolderGit2 className="w-4 h-4" />
            Android Studio Project & Code
          </button>

          <button
            onClick={() => setIsArchModalOpen(true)}
            className="flex items-center gap-1.5 text-neutral-400 hover:text-neutral-200 transition-colors whitespace-nowrap"
          >
            <BookOpen className="w-4 h-4" />
            Architecture & Specs
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleDownloadAllZip}
            className="px-3.5 py-1.5 text-xs font-bold text-black bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-sm flex items-center gap-2 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Download Source (.ZIP)
          </button>
        </div>
      </header>

      {/* 2. Main Content Viewport */}
      <main className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full">
        {currentView === 'simulator' && (
          <div className="space-y-6">
            <div className="text-center max-w-2xl mx-auto space-y-1.5">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Live Interactive MediaProjection & Overlay Emulator
              </span>
              <h1 className="text-2xl font-black text-neutral-100 tracking-tight">
                Quotex Screen Capture & 1-Minute Signal Assistant
              </h1>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Test on-device candle recognition, 7-second pre-close timing gates, and the draggable
                circular assistant floating over Quotex charts.
              </p>
            </div>

            <PhoneSimulator
              selectedPair={selectedPair}
              isScanning={isScanning}
              onToggleScanning={setIsScanning}
              onSelectPair={setSelectedPair}
              currentSignal={currentSignal}
              onSignalGenerated={handleSignalGenerated}
            />
          </div>
        )}

        {currentView === 'dashboard' && (
          <div className="space-y-6">
            <div className="text-center max-w-2xl mx-auto space-y-1.5">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Jetpack Compose Material 3 Dashboard
              </span>
              <h1 className="text-2xl font-black text-neutral-100 tracking-tight">
                Trading Signal Hub & Room Database History
              </h1>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Configure the exact 20 pairs (10 Real, 10 OTC), inspect 9-point signal validation
                passes, and record observable next-candle outcomes.
              </p>
            </div>

            <NativeComposeDashboard
              selectedPair={selectedPair}
              onSelectPair={setSelectedPair}
              selectedMarketMode={selectedMarketMode}
              onSelectMarketMode={setSelectedMarketMode}
              isScanning={isScanning}
              onToggleScanning={setIsScanning}
              currentSignal={currentSignal}
              signalHistory={signalHistory}
              onUpdateOutcome={handleUpdateOutcome}
              onClearHistory={handleClearHistory}
              captureInterval={captureInterval}
              onChangeCaptureInterval={setCaptureInterval}
            />
          </div>
        )}

        {currentView === 'project' && (
          <div className="space-y-6">
            <div className="text-center max-w-2xl mx-auto space-y-1.5">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                Android Studio Project Hub
              </span>
              <h1 className="text-2xl font-black text-neutral-100 tracking-tight">
                Native Kotlin & Jetpack Compose Source Code
              </h1>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Browse every Android Studio source file or download the complete production project
                ZIP ready to open, build, and deploy.
              </p>
            </div>

            <AndroidProjectHub />
          </div>
        )}
      </main>

      {/* 3. Footer */}
      <footer className="border-t border-neutral-800/80 bg-[#0E141C] py-4 px-6 text-center text-xs text-neutral-400">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 max-w-7xl mx-auto">
          <div>
            QX Vision Pro · Android Trading Signal Assistant · On-Device Computer Vision
          </div>
          <div className="flex items-center gap-4 text-[11px] text-neutral-400">
            <span>Zero Market-Data API Dependency</span>
            <span>·</span>
            <span>Room SQLite Local Persistence</span>
            <span>·</span>
            <span>Informational Signals Only</span>
          </div>
        </div>
      </footer>

      {/* Architecture & Documentation Modal */}
      <ArchitectureModal
        isOpen={isArchModalOpen}
        onClose={() => setIsArchModalOpen(false)}
      />
    </div>
  );
}
