import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  Square,
  Clock,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Layers,
  ShieldCheck,
  RotateCcw,
  Sliders,
  Check,
} from 'lucide-react';
import {
  CONFIGURED_MARKET_PAIRS,
  MarketPair,
} from '../core/marketConfig.ts';
import { MarketMode, SignalResult, SignalType } from '../core/types.ts';

interface NativeComposeDashboardProps {
  selectedPair: MarketPair;
  onSelectPair: (pair: MarketPair) => void;
  selectedMarketMode: MarketMode;
  onSelectMarketMode: (mode: MarketMode) => void;
  isScanning: boolean;
  onToggleScanning: (scanning: boolean) => void;
  currentSignal: SignalResult | null;
  signalHistory: SignalResult[];
  onUpdateOutcome: (id: string, outcome: 'WIN' | 'LOSS' | 'TIE') => void;
  onClearHistory: (mode?: MarketMode) => void;
  captureInterval: number;
  onChangeCaptureInterval: (ms: number) => void;
}

export const NativeComposeDashboard: React.FC<NativeComposeDashboardProps> = ({
  selectedPair,
  onSelectPair,
  selectedMarketMode,
  onSelectMarketMode,
  isScanning,
  onToggleScanning,
  currentSignal,
  signalHistory,
  onUpdateOutcome,
  onClearHistory,
  captureInterval,
  onChangeCaptureInterval,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'scanner' | 'history' | 'settings'>('scanner');

  // Filter pairs according to market mode and search
  const visiblePairs = CONFIGURED_MARKET_PAIRS.filter((p) => {
    const isTargetMode = selectedMarketMode === 'OTC' ? p.isOtc : !p.isOtc;
    if (!isTargetMode) return false;
    if (!searchQuery.trim()) return true;
    return (
      p.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.cleanSymbol.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  // Calculate separated statistics
  const filteredHistory = signalHistory.filter(
    (s) => (selectedMarketMode === 'OTC' ? s.isOtc : !s.isOtc)
  );
  const totalScans = filteredHistory.length;
  const upCount = filteredHistory.filter((s) => s.signal === 'UP').length;
  const downCount = filteredHistory.filter((s) => s.signal === 'DOWN').length;
  const noTradeCount = filteredHistory.filter((s) => s.signal === 'NO_TRADE').length;

  const evaluated = filteredHistory.filter(
    (s) => s.evaluatedOutcome && s.evaluatedOutcome !== 'UNOBSERVED'
  );
  const winCount = evaluated.filter((s) => s.evaluatedOutcome === 'WIN').length;
  const lossCount = evaluated.filter((s) => s.evaluatedOutcome === 'LOSS').length;
  const winRate = evaluated.length > 0 ? Math.round((winCount / evaluated.length) * 100) : 0;

  const signalColor =
    currentSignal?.signal === 'UP'
      ? 'border-[#00E676] bg-[#00E676]/10 text-[#00E676]'
      : currentSignal?.signal === 'DOWN'
      ? 'border-[#FF3366] bg-[#FF3366]/10 text-[#FF3366]'
      : 'border-neutral-700 bg-neutral-800/40 text-neutral-300';

  return (
    <div className="w-full max-w-4xl mx-auto space-y-5">
      {/* Top Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-1 bg-[#121922] p-1 rounded-xl border border-neutral-800">
          <button
            onClick={() => setActiveTab('scanner')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'scanner'
                ? 'bg-neutral-800 text-neutral-100 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Dashboard & Scanner
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'history'
                ? 'bg-neutral-800 text-neutral-100 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Room History ({signalHistory.length})
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
              activeTab === 'settings'
                ? 'bg-neutral-800 text-neutral-100 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Settings & Permissions
          </button>
        </div>

        <div className="flex items-center gap-2">
          <div
            className={`px-3 py-1 rounded-full text-xs font-mono font-bold flex items-center gap-1.5 border ${
              isScanning
                ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400 animate-pulse'
                : 'border-neutral-700 bg-neutral-800 text-neutral-400'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-current" />
            {isScanning ? 'SCREEN CAPTURE ACTIVE' : 'ENGINE IDLE'}
          </div>
        </div>
      </div>

      {activeTab === 'scanner' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* LEFT 5 COLUMNS: Market & Pair Selector */}
          <div className="md:col-span-5 space-y-4">
            {/* Market Mode Tabs (Strict REAL vs OTC) */}
            <div className="bg-[#121922] p-1.5 rounded-2xl border border-neutral-800 grid grid-cols-2 gap-1.5">
              <button
                onClick={() => {
                  onSelectMarketMode('REAL');
                  const firstReal = CONFIGURED_MARKET_PAIRS.find((p) => !p.isOtc);
                  if (firstReal) onSelectPair(firstReal);
                }}
                className={`py-2 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
                  selectedMarketMode === 'REAL'
                    ? 'bg-[#1A2330] text-emerald-400 border border-emerald-500/30 shadow-md'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <span>REAL MARKETS</span>
                <span className="text-[10px] bg-neutral-800 px-1.5 py-0.2 rounded-full font-mono">
                  10
                </span>
              </button>

              <button
                onClick={() => {
                  onSelectMarketMode('OTC');
                  const firstOtc = CONFIGURED_MARKET_PAIRS.find((p) => p.isOtc);
                  if (firstOtc) onSelectPair(firstOtc);
                }}
                className={`py-2 px-3 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 ${
                  selectedMarketMode === 'OTC'
                    ? 'bg-[#1A2330] text-amber-400 border border-amber-500/30 shadow-md'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <span>OTC MARKETS</span>
                <span className="text-[10px] bg-neutral-800 px-1.5 py-0.2 rounded-full font-mono">
                  10
                </span>
              </button>
            </div>

            {/* Pair Search */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={`Search ${selectedMarketMode} pairs (e.g. GBP/USD)...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#121922] border border-neutral-800 rounded-xl pl-9 pr-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-neutral-600"
              />
            </div>

            {/* Exact Configured Pairs List */}
            <div className="bg-[#121922] rounded-2xl border border-neutral-800 p-2 space-y-1 max-h-[420px] overflow-y-auto">
              {visiblePairs.map((pair) => {
                const isSelected = selectedPair.id === pair.id;
                return (
                  <button
                    key={pair.id}
                    onClick={() => onSelectPair(pair)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left text-xs transition-all ${
                      isSelected
                        ? 'bg-[#1C2736] border border-emerald-500/40 text-neutral-100 font-bold'
                        : 'hover:bg-[#16202C] text-neutral-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-2 h-2 rounded-full ${
                          isSelected ? 'bg-emerald-400' : 'bg-neutral-600'
                        }`}
                      />
                      <span>{pair.displayName}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-neutral-500">1 MIN</span>
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
                          pair.isOtc
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {pair.isOtc ? 'OTC' : 'REAL'}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* RIGHT 7 COLUMNS: Scanner & Signal Engine */}
          <div className="md:col-span-7 space-y-4">
            {/* Primary Signal Display Card */}
            <div
              className={`p-5 rounded-2xl border transition-all ${signalColor} shadow-lg relative overflow-hidden`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-mono tracking-wider uppercase text-neutral-400">
                    CURRENT TIMEFRAME SIGNAL
                  </div>
                  <h2 className="text-2xl font-black tracking-tight mt-1">
                    {currentSignal?.signal === 'UP' && '▲ UP (CALL)'}
                    {currentSignal?.signal === 'DOWN' && '▼ DOWN (PUT)'}
                    {currentSignal?.signal === 'NO_TRADE' && '■ NO TRADE'}
                    {!currentSignal && '■ NO TRADE'}
                  </h2>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-mono text-neutral-400">MODEL SCORE</div>
                  <div className="text-xl font-mono font-black">
                    {currentSignal ? `${currentSignal.modelConfidenceScore}/100` : '--/100'}
                  </div>
                  <div className="text-[9px] text-neutral-400">Algorithm Heuristic</div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-current/20 flex items-center justify-between text-xs">
                <div>
                  <span className="text-neutral-400">Reason: </span>
                  <span className="font-bold text-neutral-200">
                    {currentSignal?.reason.replace(/_/g, ' ') || 'ENGINE IDLE'}
                  </span>
                </div>
                <div className="text-[11px] font-mono text-neutral-300">
                  Candles: {currentSignal?.observedCandleCount || 0} visible
                </div>
              </div>
              <p className="text-[11px] text-neutral-300/80 mt-1 leading-relaxed">
                {currentSignal?.detailedMessage ||
                  'Screen capture stopped. Start scanner to evaluate observable candles.'}
              </p>
            </div>

            {/* 9-Stage Validation Gate Checklist */}
            <div className="bg-[#121922] p-4 rounded-2xl border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 font-mono">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  9-POINT SIGNAL VALIDATION AUDIT
                </h3>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                    currentSignal?.allChecksPassed
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {currentSignal?.allChecksPassed ? 'ALL GATES PASSED' : 'STRICT GATES ENFORCED'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] font-mono">
                {[
                  {
                    name: '1. Screen Capture Active',
                    passed: currentSignal?.validationChecklist.screenCaptureActive,
                  },
                  {
                    name: '2. Image Sharp & Clear',
                    passed: currentSignal?.validationChecklist.imageSufficientlyClear,
                  },
                  {
                    name: '3. Asset Pair Verified',
                    passed: currentSignal?.validationChecklist.symbolMatched,
                  },
                  {
                    name: '4. REAL/OTC Mode Verified',
                    passed: currentSignal?.validationChecklist.marketModeMatched,
                  },
                  {
                    name: '5. 1-Minute Timeframe',
                    passed: currentSignal?.validationChecklist.timeframeVerified,
                  },
                  {
                    name: '6. 7s Pre-Close Timing',
                    passed: currentSignal?.validationChecklist.timingReliable,
                  },
                  {
                    name: '7. Sufficient Candles (>=5)',
                    passed: currentSignal?.validationChecklist.sufficientCandlesVisible,
                  },
                  {
                    name: '8. Frame Age < 2000ms',
                    passed: currentSignal?.validationChecklist.frameRecent,
                  },
                  {
                    name: '9. Patterns Consistent',
                    passed: currentSignal?.validationChecklist.internallyConsistent,
                  },
                ].map((gate, i) => (
                  <div
                    key={i}
                    className={`p-2 rounded-xl border flex items-center justify-between ${
                      gate.passed
                        ? 'border-emerald-500/30 bg-emerald-500/5 text-emerald-300'
                        : 'border-neutral-800 bg-[#0E141D] text-neutral-400'
                    }`}
                  >
                    <span className="truncate pr-1 text-[10px]">{gate.name}</span>
                    {gate.passed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-neutral-600 shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => onToggleScanning(!isScanning)}
                className={`flex-1 py-3 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all ${
                  isScanning
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg'
                    : 'bg-emerald-500 hover:bg-emerald-600 text-black shadow-lg shadow-emerald-500/20'
                }`}
              >
                {isScanning ? (
                  <>
                    <Square className="w-4 h-4 fill-current" /> STOP SCREEN CAPTURE
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" /> START SCREEN SCANNER
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* HISTORY & TESTING STATS TAB */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {/* Market Stats Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#121922] p-3 rounded-2xl border border-neutral-800">
              <div className="text-[10px] text-neutral-400 font-mono">TOTAL {selectedMarketMode} SCANS</div>
              <div className="text-xl font-bold font-mono text-neutral-100">{totalScans}</div>
              <div className="text-[9px] text-neutral-500">Recorded Room instances</div>
            </div>

            <div className="bg-[#121922] p-3 rounded-2xl border border-neutral-800">
              <div className="text-[10px] text-neutral-400 font-mono">UP / DOWN RATIO</div>
              <div className="text-xl font-bold font-mono text-neutral-100">
                <span className="text-emerald-400">{upCount}</span> /{' '}
                <span className="text-rose-400">{downCount}</span>
              </div>
              <div className="text-[9px] text-neutral-500">{noTradeCount} NO TRADE fallbacks</div>
            </div>

            <div className="bg-[#121922] p-3 rounded-2xl border border-neutral-800">
              <div className="text-[10px] text-neutral-400 font-mono">EVALUATED OUTCOMES</div>
              <div className="text-xl font-bold font-mono text-neutral-100">
                {evaluated.length} <span className="text-xs text-neutral-400 font-normal">samples</span>
              </div>
              <div className="text-[9px] text-neutral-500">
                {winCount} Wins · {lossCount} Losses
              </div>
            </div>

            <div className="bg-[#121922] p-3 rounded-2xl border border-neutral-800">
              <div className="text-[10px] text-neutral-400 font-mono">SAMPLE WIN RATE</div>
              <div className="text-xl font-bold font-mono text-emerald-400">
                {evaluated.length > 0 ? `${winRate}%` : 'N/A'}
              </div>
              <div className="text-[9px] text-neutral-500">Observable next-candle tests</div>
            </div>
          </div>

          {/* History Table */}
          <div className="bg-[#121922] rounded-2xl border border-neutral-800 overflow-hidden">
            <div className="p-3 border-b border-neutral-800 flex items-center justify-between text-xs">
              <span className="font-bold text-neutral-200">
                {selectedMarketMode} Signal History Log
              </span>
              <button
                onClick={() => onClearHistory(selectedMarketMode)}
                className="text-[11px] text-rose-400 hover:text-rose-300 font-mono"
              >
                Clear {selectedMarketMode} History
              </button>
            </div>

            {filteredHistory.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-400">
                No signals logged for {selectedMarketMode} market yet. Run the scanner to generate
                signals.
              </div>
            ) : (
              <div className="divide-y divide-neutral-800/80 max-h-[460px] overflow-y-auto">
                {filteredHistory.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 flex items-center justify-between text-xs hover:bg-[#16202C] transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-neutral-100">{item.pairSymbol}</span>
                        <span className="text-[10px] font-mono text-neutral-400">1 MIN</span>
                        <span className="text-[10px] font-mono text-neutral-500">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="text-[11px] text-neutral-400 mt-0.5 line-clamp-1">
                        {item.detailedMessage}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold font-mono ${
                          item.signal === 'UP'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : item.signal === 'DOWN'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {item.signal}
                      </span>

                      {/* Outcome Logger Buttons */}
                      <div className="flex items-center gap-1 bg-[#0E141D] p-1 rounded-lg border border-neutral-800">
                        <button
                          onClick={() => onUpdateOutcome(item.id, 'WIN')}
                          className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${
                            item.evaluatedOutcome === 'WIN'
                              ? 'bg-emerald-500 text-black'
                              : 'text-neutral-400 hover:text-emerald-400'
                          }`}
                          title="Mark observed as Win"
                        >
                          WIN
                        </button>
                        <button
                          onClick={() => onUpdateOutcome(item.id, 'LOSS')}
                          className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${
                            item.evaluatedOutcome === 'LOSS'
                              ? 'bg-rose-500 text-white'
                              : 'text-neutral-400 hover:text-rose-400'
                          }`}
                          title="Mark observed as Loss"
                        >
                          LOSS
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SETTINGS TAB */}
      {activeTab === 'settings' && (
        <div className="bg-[#121922] p-5 rounded-2xl border border-neutral-800 space-y-5 text-xs text-neutral-300">
          <div>
            <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              Engine Configuration & Permissions
            </h3>
            <p className="text-neutral-400 mt-1">
              Configure on-device screen sampling interval and inspect Android OS permission gates.
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div>
                <div className="font-bold text-neutral-200">Capture Sampling Interval</div>
                <div className="text-[11px] text-neutral-400">
                  Delay between frame buffer captures (Lower = faster response, higher = battery
                  savings)
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="250"
                  max="2000"
                  step="250"
                  value={captureInterval}
                  onChange={(e) => onChangeCaptureInterval(Number(e.target.value))}
                  className="w-32 accent-emerald-500"
                />
                <span className="font-mono font-bold w-14 text-right text-emerald-400">
                  {captureInterval}ms
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div>
                <div className="font-bold text-neutral-200">MediaProjection Permission</div>
                <div className="text-[11px] text-neutral-400">
                  Allows capturing raw video frames from the display
                </div>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                GRANTED
              </span>
            </div>

            <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div>
                <div className="font-bold text-neutral-200">SYSTEM_ALERT_WINDOW (Overlay)</div>
                <div className="text-[11px] text-neutral-400">
                  Enables draggable floating assistant button over Quotex
                </div>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">
                ENABLED
              </span>
            </div>

            <div className="flex items-center justify-between pb-2">
              <div>
                <div className="font-bold text-neutral-200">Reset Local History</div>
                <div className="text-[11px] text-neutral-400">
                  Wipes all recorded signal entries from Room SQLite database
                </div>
              </div>
              <button
                onClick={() => onClearHistory()}
                className="px-3 py-1 bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 rounded-lg text-xs font-bold"
              >
                Clear Database
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
