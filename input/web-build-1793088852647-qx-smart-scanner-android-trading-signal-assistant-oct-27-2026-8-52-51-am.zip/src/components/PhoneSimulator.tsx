import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Square,
  Maximize2,
  Minimize2,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Layers,
  Shield,
  HelpCircle,
  Upload,
  RefreshCw,
} from 'lucide-react';
import { MarketPair } from '../core/marketConfig.ts';
import { ExtractedChartData, SignalResult } from '../core/types.ts';
import { validateAndGenerateSignal } from '../core/signalValidation.ts';

interface PhoneSimulatorProps {
  selectedPair: MarketPair;
  isScanning: boolean;
  onToggleScanning: (scanning: boolean) => void;
  onSelectPair: (pair: MarketPair) => void;
  currentSignal: SignalResult | null;
  onSignalGenerated: (signal: SignalResult) => void;
}

export type ScenarioType =
  | 'bullish_7s'
  | 'bearish_7s'
  | 'outside_window'
  | 'asset_mismatch'
  | 'timeframe_5m'
  | 'doji_indecision'
  | 'capture_stopped';

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  selectedPair,
  isScanning,
  onToggleScanning,
  onSelectPair,
  currentSignal,
  onSignalGenerated,
}) => {
  // Scenario state
  const [scenario, setScenario] = useState<ScenarioType>('bullish_7s');
  const [countdown, setCountdown] = useState<number>(5);
  const [isOverlayExpanded, setIsOverlayExpanded] = useState<boolean>(true);

  // Floating button draggable position (relative to phone screen, in px)
  const [dragPos, setDragPos] = useState<{ x: number; y: number }>({ x: 260, y: 180 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ mouseX: number; mouseY: number; startX: number; startY: number }>({
    mouseX: 0,
    mouseY: 0,
    startX: 260,
    startY: 180,
  });

  // Laser scanner animation position (0 to 100%)
  const [scanLaserPos, setScanLaserPos] = useState<number>(10);
  const [laserDirection, setLaserDirection] = useState<'down' | 'up'>('down');

  // Custom uploaded image
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  // Drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: dragPos.x,
      startY: dragPos.y,
    };
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: touch.clientX,
      mouseY: touch.clientY,
      startX: dragPos.x,
      startY: dragPos.y,
    };
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - dragStartRef.current.mouseX;
      const dy = e.clientY - dragStartRef.current.mouseY;
      const newX = Math.max(10, Math.min(310, dragStartRef.current.startX + dx));
      const newY = Math.max(60, Math.min(620, dragStartRef.current.startY + dy));
      setDragPos({ x: newX, y: newY });
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging) return;
      const touch = e.touches[0];
      const dx = touch.clientX - dragStartRef.current.mouseX;
      const dy = touch.clientY - dragStartRef.current.mouseY;
      const newX = Math.max(10, Math.min(310, dragStartRef.current.startX + dx));
      const newY = Math.max(60, Math.min(620, dragStartRef.current.startY + dy));
      setDragPos({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      window.addEventListener('touchmove', handleTouchMove);
      window.addEventListener('touchend', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleMouseUp);
    };
  }, [isDragging]);

  // Laser scanner animation
  useEffect(() => {
    if (!isScanning) return;
    const interval = setInterval(() => {
      setScanLaserPos((prev) => {
        if (laserDirection === 'down') {
          if (prev >= 88) {
            setLaserDirection('up');
            return 88;
          }
          return prev + 1.8;
        } else {
          if (prev <= 12) {
            setLaserDirection('down');
            return 12;
          }
          return prev - 1.8;
        }
      });
    }, 30);
    return () => clearInterval(interval);
  }, [isScanning, laserDirection]);

  // 1-minute countdown timer decrement
  useEffect(() => {
    if (!isScanning) return;
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (scenario === 'outside_window') {
          return 28;
        }
        if (prev <= 1) {
          return 59; // Reset to 59s when candle closes
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isScanning, scenario]);

  // When scenario changes, adjust initial countdown
  useEffect(() => {
    if (scenario === 'outside_window') {
      setCountdown(28);
    } else if (scenario === 'bullish_7s' || scenario === 'bearish_7s') {
      setCountdown(5);
    }
  }, [scenario]);

  // Execute on-device recognition and validation loop
  useEffect(() => {
    if (!isScanning) return;

    const timeout = setTimeout(() => {
      // Determine simulated extracted chart data based on selected scenario
      let recognizedSymbol = selectedPair.displayName;
      let recognizedIsOtc = selectedPair.isOtc;
      let recognizedTimeframe = '1M';
      let countdownSec = countdown;
      let imageClear = true;
      let sharpness = 88;
      let captureActive = true;

      if (scenario === 'asset_mismatch') {
        recognizedSymbol = selectedPair.isOtc ? 'EUR/GBP (OTC)' : 'EUR/GBP';
        recognizedIsOtc = selectedPair.isOtc;
      } else if (scenario === 'timeframe_5m') {
        recognizedTimeframe = '5M';
      } else if (scenario === 'capture_stopped') {
        captureActive = false;
      }

      // Generate candle geometry
      const isBullScenario = scenario === 'bullish_7s';
      const isBearScenario = scenario === 'bearish_7s';
      const isDojiScenario = scenario === 'doji_indecision';

      const detectedCandles = [0, 1, 2, 3, 4, 5].map((idx) => {
        const isBull = isDojiScenario
          ? idx % 2 === 0
          : isBullScenario
          ? true
          : isBearScenario
          ? false
          : idx > 2;

        const bodyHeight = isDojiScenario && idx === 5 ? 3 : 32;
        const upper = isBearScenario && idx === 5 ? 42 : 6;
        const lower = isBullScenario && idx === 5 ? 42 : 6;

        return {
          index: idx,
          isBullish: isBull,
          bodyTop: 100,
          bodyBottom: 100 + bodyHeight,
          wickHigh: 100 - upper,
          wickLow: 100 + bodyHeight + lower,
          bodyHeight,
          upperWickLength: upper,
          lowerWickLength: lower,
          totalLength: bodyHeight + upper + lower,
        };
      });

      const extracted: ExtractedChartData = {
        timestamp: Date.now(),
        frameAgeMs: 120,
        imageClear,
        sharpnessScore: sharpness,
        recognizedSymbol,
        recognizedIsOtc,
        recognizedTimeframe,
        countdownSecondsRemaining: countdownSec,
        countdownConfidence: 94,
        detectedCandles,
      };

      const result = validateAndGenerateSignal({
        screenCaptureActive: captureActive,
        selectedPairSymbol: selectedPair.displayName,
        selectedMarketMode: selectedPair.isOtc ? 'OTC' : 'REAL',
        extractedData: extracted,
      });

      onSignalGenerated(result);
    }, 400);

    return () => clearTimeout(timeout);
  }, [isScanning, scenario, countdown, selectedPair]);

  // Image upload handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const signalColor =
    currentSignal?.signal === 'UP'
      ? 'text-emerald-400 border-emerald-500 bg-emerald-500/10'
      : currentSignal?.signal === 'DOWN'
      ? 'text-rose-400 border-rose-500 bg-rose-500/10'
      : 'text-neutral-300 border-neutral-700 bg-neutral-800/40';

  return (
    <div className="flex flex-col lg:flex-row gap-6 items-start justify-center w-full">
      {/* LEFT: Android Phone Emulation Frame */}
      <div className="relative mx-auto w-[360px] h-[720px] bg-[#090D12] rounded-[44px] p-3 shadow-2xl border-4 border-neutral-800 ring-1 ring-neutral-700/60 select-none overflow-hidden shrink-0">
        {/* Android Top Speaker & Camera Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-2xl z-50 flex items-center justify-center gap-2">
          <div className="w-12 h-1 bg-neutral-800 rounded-full" />
          <div className="w-2.5 h-2.5 bg-neutral-900 border border-neutral-700 rounded-full" />
        </div>

        {/* Screen Content */}
        <div className="relative w-full h-full bg-[#0D131A] rounded-[34px] overflow-hidden flex flex-col">
          {/* Android Status Bar */}
          <div className="h-7 w-full bg-[#090E14] px-5 flex items-center justify-between text-[11px] text-neutral-400 font-mono z-40">
            <span>09:41</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-emerald-400">● 5G</span>
              <span>100%</span>
            </div>
          </div>

          {/* Quotex App Header Mock */}
          <div className="h-12 bg-[#121922] border-b border-neutral-800/80 px-3 flex items-center justify-between z-30">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center font-bold text-[11px] text-white">
                Q
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-neutral-100">
                    {scenario === 'asset_mismatch' ? 'EUR/GBP' : selectedPair.displayName}
                  </span>
                  <span
                    className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                      selectedPair.isOtc
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-blue-500/20 text-blue-300'
                    }`}
                  >
                    {selectedPair.isOtc ? 'OTC' : 'REAL'}
                  </span>
                </div>
                <span className="text-[9px] text-emerald-400 font-mono">Payout 87%</span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-right">
              <div>
                <div className="text-[9px] text-neutral-400">Live Account</div>
                <div className="text-xs font-mono font-bold text-neutral-200">$4,850.00</div>
              </div>
              <div
                className={`px-1.5 py-0.5 rounded text-[10px] font-mono font-bold ${
                  scenario === 'timeframe_5m'
                    ? 'bg-purple-900/40 text-purple-300 border border-purple-500/30'
                    : 'bg-neutral-800 text-neutral-300'
                }`}
              >
                {scenario === 'timeframe_5m' ? '5M' : '1M'}
              </div>
            </div>
          </div>

          {/* Quotex Chart Area Canvas */}
          <div className="relative flex-1 bg-[#0B1017] overflow-hidden flex flex-col justify-between p-3">
            {/* Background Grid Lines */}
            <div className="absolute inset-0 grid grid-cols-6 grid-rows-8 pointer-events-none opacity-15">
              {Array.from({ length: 48 }).map((_, i) => (
                <div key={i} className="border-b border-r border-neutral-600" />
              ))}
            </div>

            {/* Custom Uploaded Screenshot Background (if user uploaded one) */}
            {uploadedImage && (
              <img
                src={uploadedImage}
                alt="Custom Chart Upload"
                className="absolute inset-0 w-full h-full object-cover opacity-75 z-0"
              />
            )}

            {/* Candle Countdown Badge on Chart */}
            <div className="relative z-10 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 bg-[#16202C]/90 backdrop-blur px-2.5 py-1 rounded-md border border-neutral-700/60 font-mono">
                <Clock className="w-3.5 h-3.5 text-neutral-400" />
                <span className="text-[11px] text-neutral-400">Countdown:</span>
                <span
                  className={`font-bold ${
                    countdown <= 7
                      ? 'text-emerald-400 animate-pulse'
                      : 'text-neutral-200'
                  }`}
                >
                  00:{countdown < 10 ? `0${countdown}` : countdown}
                </span>
                {countdown <= 7 && (
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1 py-0.2 rounded font-sans">
                    7s Window
                  </span>
                )}
              </div>

              <div className="text-[10px] font-mono text-neutral-500 bg-[#121820]/80 px-2 py-0.5 rounded">
                Quotex v4.2 Engine
              </div>
            </div>

            {/* Simulated Quotex Candlestick Visualizer */}
            {!uploadedImage && (
              <div className="relative z-10 my-auto h-52 flex items-center justify-around px-2">
                {/* 6 Candles sequence */}
                {[
                  { isBull: scenario !== 'bearish_7s', h: 50, uh: 12, lh: 8 },
                  { isBull: scenario !== 'bearish_7s', h: 65, uh: 10, lh: 14 },
                  { isBull: scenario === 'bearish_7s' ? false : true, h: 45, uh: 16, lh: 6 },
                  { isBull: scenario === 'bullish_7s' ? true : false, h: 70, uh: 8, lh: 18 },
                  { isBull: scenario === 'bullish_7s' ? true : false, h: 80, uh: 14, lh: 12 },
                  // Live Current Candle forming
                  {
                    isBull:
                      scenario === 'doji_indecision'
                        ? true
                        : scenario === 'bullish_7s'
                        ? true
                        : false,
                    h: scenario === 'doji_indecision' ? 6 : 95,
                    uh: scenario === 'bearish_7s' ? 36 : scenario === 'doji_indecision' ? 45 : 8,
                    lh: scenario === 'bullish_7s' ? 36 : scenario === 'doji_indecision' ? 45 : 8,
                    isCurrent: true,
                  },
                ].map((c, i) => (
                  <div key={i} className="flex flex-col items-center justify-center relative">
                    {/* Upper Wick */}
                    <div
                      style={{ height: `${c.uh}px` }}
                      className={`w-[2px] ${c.isBull ? 'bg-[#00E676]' : 'bg-[#FF3366]'}`}
                    />
                    {/* Candle Body */}
                    <div
                      style={{ height: `${c.h}px` }}
                      className={`w-4 rounded-xs ${
                        c.isBull ? 'bg-[#00E676]' : 'bg-[#FF3366]'
                      } ${c.isCurrent ? 'ring-1 ring-white/60' : ''}`}
                    />
                    {/* Lower Wick */}
                    <div
                      style={{ height: `${c.lh}px` }}
                      className={`w-[2px] ${c.isBull ? 'bg-[#00E676]' : 'bg-[#FF3366]'}`}
                    />
                    {c.isCurrent && (
                      <span className="absolute -bottom-5 text-[8px] font-mono text-neutral-400 whitespace-nowrap">
                        Current
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Bottom Chart Stats */}
            <div className="relative z-10 flex items-center justify-between text-[10px] text-neutral-500 font-mono border-t border-neutral-800/60 pt-2">
              <span>Time: {new Date().toLocaleTimeString()}</span>
              <span>Candle: 1m O/C</span>
            </div>

            {/* HIGH-TECH LASER SCANNING ANIMATION */}
            {isScanning && (
              <div
                className="absolute left-0 right-0 pointer-events-none transition-all duration-75 ease-linear z-20"
                style={{ top: `${scanLaserPos}%` }}
              >
                {/* Laser core line */}
                <div className="h-[2px] w-full bg-[#00E676] shadow-[0_0_12px_#00E676,0_0_24px_#00E676]" />
                {/* Laser scan gradient beam */}
                <div
                  className={`h-12 w-full bg-gradient-to-b ${
                    laserDirection === 'down'
                      ? 'from-transparent to-[#00E676]/15'
                      : 'from-[#00E676]/15 to-transparent'
                  }`}
                />
              </div>
            )}

            {/* DRAGGABLE CIRCULAR FLOATING ASSISTANT BUTTON & OVERLAY */}
            <div
              style={{
                left: `${dragPos.x}px`,
                top: `${dragPos.y}px`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute z-50 cursor-grab active:cursor-grabbing transition-transform"
              onMouseDown={handleMouseDown}
              onTouchStart={handleTouchStart}
            >
              {/* Circular Button */}
              {!isOverlayExpanded ? (
                <div
                  onClick={() => setIsOverlayExpanded(true)}
                  className={`w-14 h-14 rounded-full bg-[#111720]/95 backdrop-blur-md shadow-2xl flex flex-col items-center justify-center border-2 ${
                    isScanning
                      ? 'border-[#00E676] shadow-[0_0_15px_rgba(0,230,118,0.4)] animate-pulse'
                      : 'border-neutral-700'
                  }`}
                >
                  {currentSignal?.signal === 'UP' ? (
                    <TrendingUp className="w-6 h-6 text-[#00E676]" />
                  ) : currentSignal?.signal === 'DOWN' ? (
                    <TrendingDown className="w-6 h-6 text-[#FF3366]" />
                  ) : (
                    <Sparkles className="w-6 h-6 text-neutral-400" />
                  )}
                  <span className="text-[8px] font-black tracking-wider text-neutral-200 mt-0.5">
                    {currentSignal?.signal || 'SCAN'}
                  </span>
                </div>
              ) : (
                /* Expanded Floating Scanner Panel */
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="w-72 bg-[#121922]/95 backdrop-blur-xl rounded-2xl border border-neutral-700/80 shadow-[0_16px_36px_rgba(0,0,0,0.8)] p-3 text-neutral-100"
                >
                  {/* Floating Panel Header */}
                  <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-black tracking-wider font-mono text-emerald-400">
                        QX VISION PRO
                      </span>
                      <span
                        className={`text-[9px] px-1 py-0.2 rounded font-bold ${
                          selectedPair.isOtc
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {selectedPair.isOtc ? 'OTC' : 'REAL'}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setIsOverlayExpanded(false)}
                        className="p-1 text-neutral-400 hover:text-neutral-100 rounded"
                        title="Minimize"
                      >
                        <Minimize2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Active Pair & Timeframe */}
                  <div className="flex items-center justify-between bg-[#192330] rounded-lg p-2 my-2 text-xs">
                    <div>
                      <div className="text-[10px] text-neutral-400">TARGET PAIR</div>
                      <div className="font-bold text-neutral-100">{selectedPair.displayName}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-neutral-400">TIMEFRAME</div>
                      <div className="font-mono font-bold text-emerald-400">
                        1 MIN · {countdown}s
                      </div>
                    </div>
                  </div>

                  {/* Current Signal Card */}
                  <div className={`p-2.5 rounded-xl border text-center my-2 ${signalColor}`}>
                    <div className="text-[10px] tracking-wider text-neutral-400 uppercase font-mono">
                      SIGNAL OUTPUT
                    </div>
                    <div className="text-xl font-black tracking-wider mt-0.5">
                      {currentSignal?.signal === 'UP' && '▲ UP'}
                      {currentSignal?.signal === 'DOWN' && '▼ DOWN'}
                      {currentSignal?.signal === 'NO_TRADE' && '■ NO TRADE'}
                    </div>
                    <div className="text-[10px] text-neutral-300 mt-1 line-clamp-1">
                      {currentSignal?.detailedMessage}
                    </div>
                  </div>

                  {/* 9-Stage Validation Gates Preview */}
                  <div className="grid grid-cols-3 gap-1 text-[9px] font-mono my-2 text-neutral-400">
                    <div
                      className={`p-1 rounded text-center border ${
                        currentSignal?.validationChecklist.screenCaptureActive
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400'
                          : 'bg-rose-950/40 border-rose-500/40 text-rose-400'
                      }`}
                    >
                      Capture: {currentSignal?.validationChecklist.screenCaptureActive ? 'ON' : 'OFF'}
                    </div>
                    <div
                      className={`p-1 rounded text-center border ${
                        currentSignal?.validationChecklist.symbolMatched
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400'
                          : 'bg-rose-950/40 border-rose-500/40 text-rose-400'
                      }`}
                    >
                      Asset: {currentSignal?.validationChecklist.symbolMatched ? 'OK' : 'FAIL'}
                    </div>
                    <div
                      className={`p-1 rounded text-center border ${
                        currentSignal?.validationChecklist.timingReliable
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400'
                          : 'bg-rose-950/40 border-rose-500/40 text-rose-400'
                      }`}
                    >
                      7s Timing: {currentSignal?.validationChecklist.timingReliable ? 'ACTIVE' : 'WAIT'}
                    </div>
                  </div>

                  {/* Start/Stop Button */}
                  <div className="flex gap-2 mt-2">
                    <button
                      onClick={() => onToggleScanning(!isScanning)}
                      className={`flex-1 py-1.5 px-3 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors ${
                        isScanning
                          ? 'bg-rose-600 hover:bg-rose-700 text-white'
                          : 'bg-emerald-500 hover:bg-emerald-600 text-black'
                      }`}
                    >
                      {isScanning ? (
                        <>
                          <Square className="w-3.5 h-3.5 fill-current" /> Stop Scan
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 fill-current" /> Start Scan
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => setIsOverlayExpanded(false)}
                      className="py-1.5 px-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-xs"
                    >
                      Dock
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Android Bottom Navigation Pill */}
          <div className="h-5 bg-[#090E14] flex items-center justify-center">
            <div className="w-28 h-1 bg-neutral-700 rounded-full" />
          </div>
        </div>
      </div>

      {/* RIGHT: Test Scenario Injector & Chart Controls */}
      <div className="flex-1 max-w-xl space-y-4">
        {/* Scenario Selection Box */}
        <div className="bg-[#121922] p-4 rounded-2xl border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              Chart & Screen Scenario Injector
            </h3>
            <span className="text-[11px] text-neutral-400">Live Emulation Control</span>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Test how the on-device recognition and 9-rule validation engine respond to real
            candlestick patterns, countdown timing gates, and verification failures:
          </p>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => setScenario('bullish_7s')}
              className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all ${
                scenario === 'bullish_7s'
                  ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300'
                  : 'border-neutral-800 bg-[#0E141D] text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Bullish Rally (7s Window)</div>
                <div className="text-[10px] text-neutral-400">
                  Green momentum + 5s countdown &rarr; Validated UP
                </div>
              </div>
            </button>

            <button
              onClick={() => setScenario('bearish_7s')}
              className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all ${
                scenario === 'bearish_7s'
                  ? 'border-rose-500 bg-rose-500/10 text-rose-300'
                  : 'border-neutral-800 bg-[#0E141D] text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <TrendingDown className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Bearish Drop (7s Window)</div>
                <div className="text-[10px] text-neutral-400">
                  Red momentum + 4s countdown &rarr; Validated DOWN
                </div>
              </div>
            </button>

            <button
              onClick={() => setScenario('outside_window')}
              className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all ${
                scenario === 'outside_window'
                  ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                  : 'border-neutral-800 bg-[#0E141D] text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Outside 7s Window</div>
                <div className="text-[10px] text-neutral-400">
                  28s countdown remaining &rarr; Held as NO TRADE
                </div>
              </div>
            </button>

            <button
              onClick={() => setScenario('asset_mismatch')}
              className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all ${
                scenario === 'asset_mismatch'
                  ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                  : 'border-neutral-800 bg-[#0E141D] text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Asset Mismatch</div>
                <div className="text-[10px] text-neutral-400">
                  Visible is EUR/GBP vs selected &rarr; ASSET NOT VERIFIED
                </div>
              </div>
            </button>

            <button
              onClick={() => setScenario('timeframe_5m')}
              className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all ${
                scenario === 'timeframe_5m'
                  ? 'border-purple-500 bg-purple-500/10 text-purple-300'
                  : 'border-neutral-800 bg-[#0E141D] text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <Layers className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Wrong Timeframe (5M)</div>
                <div className="text-[10px] text-neutral-400">
                  Chart set to 5m &rarr; NO TRADE TIMEFRAME MISMATCH
                </div>
              </div>
            </button>

            <button
              onClick={() => setScenario('doji_indecision')}
              className={`p-2.5 rounded-xl border text-left flex items-start gap-2 transition-all ${
                scenario === 'doji_indecision'
                  ? 'border-blue-500 bg-blue-500/10 text-blue-300'
                  : 'border-neutral-800 bg-[#0E141D] text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <HelpCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold">Doji / Conflicting Wicks</div>
                <div className="text-[10px] text-neutral-400">
                  Large opposing wicks &rarr; NO TRADE CONFLICTING
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Custom Screenshot Upload Box */}
        <div className="bg-[#121922] p-4 rounded-2xl border border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-2">
              <Upload className="w-4 h-4 text-blue-400" />
              Test With Your Quotex Screenshot
            </h3>
            {uploadedImage && (
              <button
                onClick={() => setUploadedImage(null)}
                className="text-xs text-rose-400 hover:underline"
              >
                Clear Upload
              </button>
            )}
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Upload an actual screenshot of the Quotex trading interface from your mobile device to
            test real on-device recognition and boundary extraction:
          </p>
          <label className="flex items-center justify-center border border-dashed border-neutral-700 hover:border-neutral-500 rounded-xl p-3 cursor-pointer bg-[#0D1219] transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <span className="text-xs text-neutral-300 flex items-center gap-2">
              <Upload className="w-4 h-4 text-neutral-400" />
              {uploadedImage ? 'Replace uploaded screenshot' : 'Select Screenshot (PNG/JPG)'}
            </span>
          </label>
        </div>

        {/* Floating Assistant Draggable Instructions */}
        <div className="bg-[#121922] p-4 rounded-2xl border border-neutral-800 text-xs text-neutral-400 space-y-2">
          <div className="font-bold text-neutral-200">Interactive Floating Assistant Tip:</div>
          <p>
            You can <strong>drag the circular floating button</strong> with your mouse or finger to
            any coordinate on the phone screen! Click it to toggle the overlay panel open or
            docked.
          </p>
        </div>
      </div>
    </div>
  );
};
