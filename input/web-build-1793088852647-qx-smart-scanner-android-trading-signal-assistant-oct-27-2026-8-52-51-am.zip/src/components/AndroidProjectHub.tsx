import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  Download,
  FileCode,
  Folder,
  Copy,
  Check,
  Terminal,
  BookOpen,
  Info,
  Layers,
  ShieldAlert,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES, AndroidProjectFile } from '../data/androidFiles.ts';

export const AndroidProjectHub: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(ANDROID_PROJECT_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const filteredFiles = ANDROID_PROJECT_FILES.filter((f) =>
    activeCategory === 'all' ? true : f.category === activeCategory
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // Add all project files into zip with correct directory structure
      for (const file of ANDROID_PROJECT_FILES) {
        zip.file(file.path, file.content);
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const downloadUrl = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = 'QXSmartScanner-Android-Project.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error('Failed to create zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner & 1-Click ZIP Download */}
      <div className="bg-gradient-to-r from-[#141B24] via-[#16212E] to-[#141B24] p-6 rounded-3xl border border-neutral-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono font-bold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">
              PRODUCTION-GRADE KOTLIN
            </span>
            <span className="text-xs text-neutral-400">Jetpack Compose · Material 3 · Room</span>
          </div>
          <h2 className="text-xl font-black text-neutral-100 mt-1">
            Complete Android Studio Project Source Code
          </h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-xl leading-relaxed">
            Ready to import into Android Studio. Contains full build scripts, AndroidManifest.xml,
            MediaProjection foreground service, WindowManager floating overlay, ML Kit on-device
            OCR, and JUnit tests.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-black font-black text-xs flex items-center gap-2.5 shadow-lg shadow-emerald-500/20 transition-all shrink-0 active:scale-95 disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          {isZipping ? 'PACKAGING ZIP...' : 'DOWNLOAD FULL PROJECT (.ZIP)'}
        </button>
      </div>

      {/* Main Grid: File Tree + Code Viewer */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        {/* LEFT 4 COLUMNS: File Explorer */}
        <div className="md:col-span-4 bg-[#121922] rounded-2xl border border-neutral-800 p-3 space-y-3">
          <div className="flex items-center justify-between px-2 pt-1">
            <span className="text-xs font-bold text-neutral-200 flex items-center gap-1.5 font-mono">
              <Folder className="w-4 h-4 text-emerald-400" />
              PROJECT FILES ({ANDROID_PROJECT_FILES.length})
            </span>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-1 text-[10px] font-mono px-1">
            {[
              { id: 'all', label: 'All' },
              { id: 'kotlin', label: 'Kotlin' },
              { id: 'room', label: 'Room' },
              { id: 'gradle', label: 'Gradle' },
              { id: 'test', label: 'Tests' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-2 py-1 rounded-md transition-colors ${
                  activeCategory === cat.id
                    ? 'bg-neutral-800 text-neutral-100 font-bold'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* File List */}
          <div className="space-y-1 max-h-[500px] overflow-y-auto pr-1">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                    isSelected
                      ? 'bg-[#1C2736] text-emerald-300 font-bold border border-emerald-500/30'
                      : 'text-neutral-300 hover:bg-[#16202C]'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-3.5 h-3.5 shrink-0 text-neutral-400" />
                    <span className="truncate text-[11px] font-mono">{file.name}</span>
                  </div>
                  <span className="text-[9px] uppercase px-1 rounded bg-neutral-800 text-neutral-500 shrink-0 font-mono">
                    {file.category}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT 8 COLUMNS: Code Inspector */}
        <div className="md:col-span-8 bg-[#121922] rounded-2xl border border-neutral-800 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="p-3 bg-[#16202C] border-b border-neutral-800 flex items-center justify-between text-xs">
            <div>
              <div className="font-mono font-bold text-neutral-200">{selectedFile.path}</div>
              <div className="text-[10px] text-neutral-400 mt-0.5">{selectedFile.description}</div>
            </div>

            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-mono text-[11px] flex items-center gap-1.5 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" /> Copy Code
                </>
              )}
            </button>
          </div>

          {/* Code Body */}
          <div className="p-4 bg-[#0A0E13] overflow-x-auto max-h-[500px] flex-1 font-mono text-xs leading-relaxed text-neutral-300 selection:bg-emerald-500/30">
            <pre>
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>

      {/* Build & Run Instructions Accordion */}
      <div className="bg-[#121922] p-6 rounded-3xl border border-neutral-800 space-y-4">
        <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          Android Studio Build & Installation Instructions
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-neutral-400">
          <div className="bg-[#0E141D] p-4 rounded-xl border border-neutral-800 space-y-2">
            <div className="font-bold text-neutral-200">1. Setup Android Studio</div>
            <p className="leading-relaxed">
              Open Android Studio (Hedgehog or newer). Click <strong>Open</strong> and choose the
              extracted folder. Ensure Gradle JDK is set to <strong>Java 17</strong>.
            </p>
          </div>

          <div className="bg-[#0E141D] p-4 rounded-xl border border-neutral-800 space-y-2">
            <div className="font-bold text-neutral-200">2. Build APK</div>
            <p className="leading-relaxed">
              Run Gradle build in terminal:
              <br />
              <code className="text-emerald-400 font-mono">./gradlew assembleDebug</code>
              <br />
              Generated APK location:
              <br />
              <code className="text-neutral-300 font-mono text-[10px]">
                app/build/outputs/apk/debug/app-debug.apk
              </code>
            </p>
          </div>

          <div className="bg-[#0E141D] p-4 rounded-xl border border-neutral-800 space-y-2">
            <div className="font-bold text-neutral-200">3. Install & Permissions</div>
            <p className="leading-relaxed">
              Install to physical Android phone via USB:
              <br />
              <code className="text-emerald-400 font-mono">adb install -r app-debug.apk</code>
              <br />
              Grant <strong>Display over other apps</strong> and{' '}
              <strong>Start recording/casting</strong> when prompted.
            </p>
          </div>
        </div>

        {/* Mandatory Ethical & Technical Disclaimer */}
        <div className="p-3.5 bg-neutral-900/80 rounded-xl border border-neutral-800 flex items-start gap-3 text-xs text-neutral-400 leading-relaxed">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-neutral-200">Strict Operating Boundary & Notice:</strong>
            <p className="mt-0.5">
              QX Smart Scanner provides purely informational on-device chart recognition. It does
              not execute trades, does not connect to private broker APIs, and makes no claims of
              guaranteed winning probabilities. When visual evidence or timing is insufficient, the
              engine defaults strictly to <code className="text-neutral-200">NO TRADE</code>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
