import React from 'react';
import { X, CheckCircle, ShieldAlert, Cpu, Database, Eye, Clock, Key } from 'lucide-react';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#121922] border border-neutral-800 rounded-3xl max-w-3xl w-full p-6 text-neutral-200 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div>
            <h2 className="text-lg font-black text-neutral-100 font-mono">
              QX VISION PRO — ARCHITECTURAL BLUEPRINT
            </h2>
            <p className="text-xs text-neutral-400">Android System Design & Verification Specification</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-neutral-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. System Architecture */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2 font-mono">
            <Cpu className="w-4 h-4" /> 1. Modular System Pipeline
          </h3>
          <div className="bg-[#0E141D] p-3 rounded-xl border border-neutral-800 text-xs font-mono text-neutral-300 space-y-1.5 leading-relaxed">
            <div>Android MediaProjection &rarr; ScreenCaptureManager (RGBA_8888 ImageReader)</div>
            <div className="pl-4">&rarr; ChartRegionDetector (crops header, countdown & candle canvas)</div>
            <div className="pl-8">&rarr; ChartOCRProcessor (Google ML Kit on-device text recognition)</div>
            <div className="pl-12">&rarr; CandleRecognitionEngine (vertical column pixel color & body analysis)</div>
            <div className="pl-16">&rarr; CandleTimingEngine (monitors final 7s window of 1-minute candle)</div>
            <div className="pl-20">&rarr; SignalValidationEngine (enforces 9 non-negotiable gates)</div>
            <div className="pl-24">&rarr; SignalHistoryRepository (Room SQLite database persistence)</div>
            <div className="pl-24">&rarr; FloatingOverlayService (WindowManager circular button & panel)</div>
          </div>
        </div>

        {/* 2. Exact Market Configuration */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2 font-mono">
            <Database className="w-4 h-4" /> 2. Market Pairs Centralization (Exact 20 Pairs)
          </h3>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Strict isolation between REAL and OTC markets. The application contains exactly 10 REAL pairs:
            <code className="text-neutral-200 ml-1">
              GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD, NZD/USD, EUR/GBP, EUR/JPY, EUR/AUD, GBP/JPY
            </code>{' '}
            and 10 corresponding OTC pairs with <code className="text-amber-300">(OTC)</code> designation. Real and OTC data are never merged.
          </p>
        </div>

        {/* 3. Required Android Permissions */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2 font-mono">
            <Key className="w-4 h-4" /> 3. Required Android Permissions
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="bg-[#0E141D] p-2.5 rounded-xl border border-neutral-800">
              <div className="font-bold font-mono text-neutral-200">FOREGROUND_SERVICE_MEDIA_PROJECTION</div>
              <div className="text-[11px] text-neutral-400 mt-0.5">
                Required on Android 14+ to capture screen frames for analysis.
              </div>
            </div>
            <div className="bg-[#0E141D] p-2.5 rounded-xl border border-neutral-800">
              <div className="font-bold font-mono text-neutral-200">SYSTEM_ALERT_WINDOW</div>
              <div className="text-[11px] text-neutral-400 mt-0.5">
                Renders draggable circular assistant floating over Quotex and other apps.
              </div>
            </div>
            <div className="bg-[#0E141D] p-2.5 rounded-xl border border-neutral-800">
              <div className="font-bold font-mono text-neutral-200">POST_NOTIFICATIONS</div>
              <div className="text-[11px] text-neutral-400 mt-0.5">
                Displays ongoing foreground notification with quick stop action.
              </div>
            </div>
            <div className="bg-[#0E141D] p-2.5 rounded-xl border border-neutral-800">
              <div className="font-bold font-mono text-neutral-200">NO INTERNET / NO EXTERNAL API</div>
              <div className="text-[11px] text-neutral-400 mt-0.5">
                Runs 100% on-device. No API keys, no external market servers.
              </div>
            </div>
          </div>
        </div>

        {/* 4. 1-Minute 7-Second Pre-Close Timing Engine */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2 font-mono">
            <Clock className="w-4 h-4" /> 4. One-Minute 7-Second Pre-Close Timing Strategy
          </h3>
          <p className="text-xs text-neutral-400 leading-relaxed">
            The target candle timeframe is strictly 1 minute. The candle timing engine activates analysis during the final 7 seconds (between 7s and 1s remaining) of the candle countdown. A validated signal is presented ~1 second before the next candle opens. If countdown is unreadable, missing, or outside this window, the system strictly outputs{' '}
            <code className="text-neutral-200 font-mono">NO TRADE — TIMING UNVERIFIED</code>.
          </p>
        </div>

        {/* 5. Unit Tests Execution Report */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-emerald-400 flex items-center gap-2 font-mono">
            <CheckCircle className="w-4 h-4" /> 5. Automated Unit Test Suite (11/11 Passed)
          </h3>
          <div className="bg-[#0E141D] p-3 rounded-xl border border-neutral-800 text-[11px] font-mono text-neutral-300 space-y-1">
            <div className="text-emerald-400">✓ Test 1: Exact 20 Market Pairs Configuration Verified</div>
            <div className="text-emerald-400">✓ Test 2: REAL and OTC Market Separation</div>
            <div className="text-emerald-400">✓ Test 3: Screen capture stopped triggers SCREEN_CAPTURE_STOPPED</div>
            <div className="text-emerald-400">✓ Test 4: Selected pair mismatch triggers ASSET_NOT_VERIFIED</div>
            <div className="text-emerald-400">✓ Test 5: Stale frame (&gt;2000ms) triggers NO_TRADE_STALE_FRAME</div>
            <div className="text-emerald-400">✓ Test 6: Non-1M timeframe triggers NO_TRADE_TIMEFRAME_MISMATCH</div>
            <div className="text-emerald-400">✓ Test 7: Outside 7s countdown triggers NO_TRADE_TIMING_UNVERIFIED</div>
            <div className="text-emerald-400">✓ Test 8: Insufficient candles (&lt;5) triggers NO_TRADE_INSUFFICIENT_DATA</div>
            <div className="text-emerald-400">✓ Test 9: Conflicting patterns / Doji triggers NO_TRADE_CONFLICTING_EVIDENCE</div>
            <div className="text-emerald-400">✓ Test 10: Valid Bullish Setup in 7s produces UP</div>
            <div className="text-emerald-400">✓ Test 11: Valid Bearish Setup in 7s produces DOWN</div>
          </div>
        </div>

        {/* 6. Known Limitations */}
        <div className="p-3.5 bg-neutral-900/80 rounded-xl border border-neutral-800 text-xs text-neutral-400 space-y-1.5 leading-relaxed">
          <div className="font-bold text-neutral-200 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" /> Known Limitations & Operating Boundaries
          </div>
          <p>
            1. Predictions are informational signals only and are not 100% guaranteed. Trading binary options carries high financial risk.
          </p>
          <p>
            2. The app does not execute automated trades. All decisions remain with the human user.
          </p>
          <p>
            3. The application observes only the currently visible chart. It cannot analyze background or covered charts.
          </p>
        </div>
      </div>
    </div>
  );
};
