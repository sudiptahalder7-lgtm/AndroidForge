/**
 * Centralized Market Pair Configuration
 * Exactly 10 REAL pairs and exactly 10 corresponding OTC pairs (Total: 20).
 * Real and OTC markets are strictly segregated.
 */

export interface MarketPair {
  id: string;
  symbol: string;         // e.g. "GBP/USD"
  cleanSymbol: string;    // e.g. "GBPUSD"
  isOtc: boolean;
  displayName: string;    // e.g. "GBP/USD" or "GBP/USD (OTC)"
  baseCurrency: string;
  quoteCurrency: string;
}

export const REAL_PAIRS_SYMBOLS: readonly string[] = [
  'GBP/USD',
  'USD/JPY',
  'USD/CHF',
  'AUD/USD',
  'USD/CAD',
  'NZD/USD',
  'EUR/GBP',
  'EUR/JPY',
  'EUR/AUD',
  'GBP/JPY',
] as const;

export const CONFIGURED_MARKET_PAIRS: readonly MarketPair[] = [
  // 10 REAL PAIRS
  ...REAL_PAIRS_SYMBOLS.map((symbol) => {
    const [base, quote] = symbol.split('/');
    return {
      id: `REAL_${base}${quote}`,
      symbol,
      cleanSymbol: `${base}${quote}`,
      isOtc: false,
      displayName: symbol,
      baseCurrency: base,
      quoteCurrency: quote,
    };
  }),

  // 10 CORRESPONDING OTC PAIRS
  ...REAL_PAIRS_SYMBOLS.map((symbol) => {
    const [base, quote] = symbol.split('/');
    return {
      id: `OTC_${base}${quote}`,
      symbol: `${symbol} (OTC)`,
      cleanSymbol: `${base}${quote}_OTC`,
      isOtc: true,
      displayName: `${symbol} (OTC)`,
      baseCurrency: base,
      quoteCurrency: quote,
    };
  }),
] as const;

/**
 * Total configured pairs must be exactly 20.
 */
export const TOTAL_PAIRS_COUNT = CONFIGURED_MARKET_PAIRS.length; // 20
export const REAL_PAIRS_COUNT = CONFIGURED_MARKET_PAIRS.filter((p) => !p.isOtc).length; // 10
export const OTC_PAIRS_COUNT = CONFIGURED_MARKET_PAIRS.filter((p) => p.isOtc).length; // 10

/**
 * Validate that pair configuration contains no duplicates and strictly adheres to specifications.
 */
export function validateMarketConfiguration(): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const idSet = new Set<string>();
  const displaySet = new Set<string>();

  if (CONFIGURED_MARKET_PAIRS.length !== 20) {
    errors.push(`Expected exactly 20 pairs, found ${CONFIGURED_MARKET_PAIRS.length}`);
  }

  const realCount = CONFIGURED_MARKET_PAIRS.filter((p) => !p.isOtc).length;
  if (realCount !== 10) {
    errors.push(`Expected exactly 10 REAL pairs, found ${realCount}`);
  }

  const otcCount = CONFIGURED_MARKET_PAIRS.filter((p) => p.isOtc).length;
  if (otcCount !== 10) {
    errors.push(`Expected exactly 10 OTC pairs, found ${otcCount}`);
  }

  for (const pair of CONFIGURED_MARKET_PAIRS) {
    if (idSet.has(pair.id)) {
      errors.push(`Duplicate pair id found: ${pair.id}`);
    }
    idSet.add(pair.id);

    if (displaySet.has(pair.displayName)) {
      errors.push(`Duplicate displayName found: ${pair.displayName}`);
    }
    displaySet.add(pair.displayName);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Centralized pair search/lookup
 */
export function findPairByDisplay(displayName: string): MarketPair | undefined {
  const normalized = displayName.trim().toUpperCase();
  return CONFIGURED_MARKET_PAIRS.find(
    (p) => p.displayName.toUpperCase() === normalized
  );
}

export function findPairBySymbolAndMode(symbol: string, isOtc: boolean): MarketPair | undefined {
  const normalized = symbol.replace(/\s+/g, '').replace('(OTC)', '').toUpperCase();
  return CONFIGURED_MARKET_PAIRS.find((p) => {
    const pClean = p.symbol.replace(/\s+/g, '').replace('(OTC)', '').toUpperCase();
    return pClean === normalized && p.isOtc === isOtc;
  });
}
