import {
  ExtractedChartData,
  MarketMode,
  SignalReason,
  SignalResult,
  ValidationChecklist,
} from './types.ts';
import { analyzeCandles } from './candleAnalysis.ts';

export interface ValidationInput {
  screenCaptureActive: boolean;
  selectedPairSymbol: string;   // e.g. "GBP/USD" or "GBP/USD (OTC)"
  selectedMarketMode: MarketMode; // "REAL" or "OTC"
  extractedData: ExtractedChartData | null;
  currentTimeMs?: number;
}

/**
 * SignalValidationEngine
 * Enforces all 9 non-negotiable verification gates.
 * Never outputs UP or DOWN if any check fails.
 * Always clears prior state and assigns deterministic reasons.
 */
export function validateAndGenerateSignal(input: ValidationInput): SignalResult {
  const now = input.currentTimeMs || Date.now();
  const id = `sig_${now}_${Math.random().toString(36).substring(2, 7)}`;
  const isSelectedOtc = input.selectedMarketMode === 'OTC';

  // Base checklist
  const checklist: ValidationChecklist = {
    screenCaptureActive: input.screenCaptureActive,
    imageSufficientlyClear: false,
    symbolMatched: false,
    marketModeMatched: false,
    timeframeVerified: false,
    timingReliable: false,
    sufficientCandlesVisible: false,
    frameRecent: false,
    internallyConsistent: false,
  };

  // Check 1: Screen capture active
  if (!input.screenCaptureActive) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'SCREEN_CAPTURE_STOPPED',
      detailedMessage: 'Screen capture permission not active or revoked by Android OS.',
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: 0,
    };
  }

  // Extracted data existence check
  const data = input.extractedData;
  if (!data) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_INSUFFICIENT_DATA',
      detailedMessage: 'No valid chart data extracted from current video projection frame.',
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: 0,
    };
  }

  // Check 2: Image sufficiently clear
  checklist.imageSufficientlyClear = data.imageClear && data.sharpnessScore >= 55;
  if (!checklist.imageSufficientlyClear) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_LOW_IMAGE_QUALITY',
      detailedMessage: `Image quality below verification threshold (Score: ${data.sharpnessScore}/100).`,
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: data.detectedCandles?.length || 0,
    };
  }

  // Check 8: Frame is recent (< 2000ms old)
  const frameAge = data.frameAgeMs !== undefined ? data.frameAgeMs : (now - data.timestamp);
  checklist.frameRecent = frameAge >= 0 && frameAge < 2000;
  if (!checklist.frameRecent) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_STALE_FRAME',
      detailedMessage: `Captured frame is stale (${frameAge}ms old). Required < 2000ms.`,
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: data.detectedCandles?.length || 0,
    };
  }

  // Check 3: Selected pair matches visible pair (Asset verification)
  const normSelected = input.selectedPairSymbol
    .replace('(OTC)', '')
    .replace(/\s+/g, '')
    .toUpperCase();
  const normRecognized = (data.recognizedSymbol || '')
    .replace('(OTC)', '')
    .replace(/\s+/g, '')
    .toUpperCase();

  checklist.symbolMatched = Boolean(
    data.recognizedSymbol && normSelected === normRecognized
  );
  if (!checklist.symbolMatched) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'ASSET_NOT_VERIFIED',
      detailedMessage: `Asset not verified. Expected ${input.selectedPairSymbol}, visible: ${data.recognizedSymbol || 'Unknown'}.`,
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: data.detectedCandles?.length || 0,
    };
  }

  // Check 4: REAL/OTC mode is verified
  checklist.marketModeMatched = data.recognizedIsOtc === isSelectedOtc;
  if (!checklist.marketModeMatched) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_MARKET_MODE_MISMATCH',
      detailedMessage: `Market mode mismatch. Selected: ${input.selectedMarketMode}, Detected: ${data.recognizedIsOtc ? 'OTC' : 'REAL'}.`,
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: data.detectedCandles?.length || 0,
    };
  }

  // Check 5: One-minute timeframe verified
  const normTf = (data.recognizedTimeframe || '').toUpperCase().trim();
  checklist.timeframeVerified = normTf === '1M' || normTf === '01:00' || normTf === 'M1' || normTf === '1 MIN';
  if (!checklist.timeframeVerified) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_TIMEFRAME_MISMATCH',
      detailedMessage: `Visible timeframe is '${data.recognizedTimeframe || 'Unverified'}'. App strictly requires 1-minute (1M).`,
      validationChecklist: checklist,
      allChecksPassed: false,
      observedCandleCount: data.detectedCandles?.length || 0,
    };
  }

  // Check 6: Candle timing is sufficiently reliable (Target: final 7 seconds: <= 7s and >= 1s)
  const cd = data.countdownSecondsRemaining;
  const timingIsReliable =
    cd !== undefined &&
    data.countdownConfidence >= 65 &&
    cd <= 7 &&
    cd >= 1;
  checklist.timingReliable = Boolean(timingIsReliable);

  if (!checklist.timingReliable) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_TIMING_UNVERIFIED',
      detailedMessage:
        cd === undefined
          ? 'Countdown timer unreadable or missing from visible chart.'
          : cd > 7
          ? `Analysis held until final 7s window (Current countdown: ${cd}s remaining).`
          : 'Candle timing expired or confidence below required threshold.',
      validationChecklist: checklist,
      allChecksPassed: false,
      countdownSeconds: cd,
      observedCandleCount: data.detectedCandles?.length || 0,
    };
  }

  // Check 7: Enough recent candles visible (>= 5 candles)
  const candleCount = data.detectedCandles?.length || 0;
  checklist.sufficientCandlesVisible = candleCount >= 5;
  if (!checklist.sufficientCandlesVisible) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: 0,
      reason: 'NO_TRADE_INSUFFICIENT_DATA',
      detailedMessage: `Insufficient candles recognized (${candleCount} detected, min 5 required).`,
      validationChecklist: checklist,
      allChecksPassed: false,
      countdownSeconds: cd,
      observedCandleCount: candleCount,
    };
  }

  // Run Candle Analysis
  const analysis = analyzeCandles(data.detectedCandles);
  checklist.internallyConsistent = analysis.isConsistent;

  // Check 9: Analysis result is internally consistent
  if (!checklist.internallyConsistent) {
    return {
      id,
      timestamp: now,
      pairSymbol: input.selectedPairSymbol,
      isOtc: isSelectedOtc,
      timeframe: '1 MIN',
      signal: 'NO_TRADE',
      modelConfidenceScore: analysis.modelScore,
      reason: 'NO_TRADE_CONFLICTING_EVIDENCE',
      detailedMessage: `Signal suppressed: ${analysis.summary}`,
      validationChecklist: checklist,
      allChecksPassed: false,
      countdownSeconds: cd,
      observedCandleCount: candleCount,
    };
  }

  // All 9 checks passed!
  const finalSignal = analysis.candidateSignal;
  let reason: SignalReason = 'VALIDATED_BULLISH_MOMENTUM';
  if (finalSignal === 'UP') {
    reason = analysis.bullishEvidenceCount > 3 ? 'VALIDATED_BULLISH_MOMENTUM' : 'VALIDATED_BULLISH_REJECTION';
  } else if (finalSignal === 'DOWN') {
    reason = analysis.bearishEvidenceCount > 3 ? 'VALIDATED_BEARISH_MOMENTUM' : 'VALIDATED_BEARISH_REJECTION';
  } else {
    reason = 'NO_TRADE_INSUFFICIENT_DATA';
  }

  return {
    id,
    timestamp: now,
    pairSymbol: input.selectedPairSymbol,
    isOtc: isSelectedOtc,
    timeframe: '1 MIN',
    signal: finalSignal,
    modelConfidenceScore: analysis.modelScore,
    reason,
    detailedMessage: analysis.summary,
    validationChecklist: checklist,
    allChecksPassed: finalSignal !== 'NO_TRADE',
    countdownSeconds: cd,
    observedCandleCount: candleCount,
  };
}
