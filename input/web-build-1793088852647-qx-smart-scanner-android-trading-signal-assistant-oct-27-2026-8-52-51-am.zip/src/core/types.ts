/**
 * Core Domain Models and Enums for QX Smart Scanner
 */

export type SignalType = 'UP' | 'DOWN' | 'NO_TRADE';

export type SignalReason =
  | 'VALIDATED_BULLISH_MOMENTUM'
  | 'VALIDATED_BEARISH_MOMENTUM'
  | 'VALIDATED_BULLISH_REJECTION'
  | 'VALIDATED_BEARISH_REJECTION'
  | 'SCREEN_CAPTURE_STOPPED'
  | 'ASSET_NOT_VERIFIED'
  | 'NO_TRADE_INSUFFICIENT_DATA'
  | 'NO_TRADE_TIMING_UNVERIFIED'
  | 'NO_TRADE_CONFLICTING_EVIDENCE'
  | 'NO_TRADE_LOW_IMAGE_QUALITY'
  | 'NO_TRADE_TIMEFRAME_MISMATCH'
  | 'NO_TRADE_MARKET_MODE_MISMATCH'
  | 'NO_TRADE_STALE_FRAME';

export type MarketMode = 'REAL' | 'OTC';

export type ScanningMode = 'CURRENT_CHART' | 'SEQUENTIAL_SCAN';

export interface CandlePixelData {
  index: number;
  isBullish: boolean;       // Green/Up
  bodyTop: number;          // y coordinate (pixels)
  bodyBottom: number;       // y coordinate (pixels)
  wickHigh: number;         // highest point (lowest y)
  wickLow: number;          // lowest point (highest y)
  bodyHeight: number;       // bodyBottom - bodyTop
  upperWickLength: number;  // bodyTop - wickHigh
  lowerWickLength: number;  // wickLow - bodyBottom
  totalLength: number;      // wickLow - wickHigh
}

export interface ExtractedChartData {
  timestamp: number;
  frameAgeMs: number;
  imageClear: boolean;
  sharpnessScore: number;     // 0 to 100
  recognizedSymbol?: string;  // e.g. "GBP/USD"
  recognizedIsOtc: boolean;
  recognizedTimeframe?: string; // e.g. "1M", "01:00"
  countdownSecondsRemaining?: number; // e.g. 7
  countdownConfidence: number; // 0 to 100
  detectedCandles: CandlePixelData[];
}

export interface ValidationChecklist {
  // 1. Screen capture is active
  screenCaptureActive: boolean;
  // 2. Image is sufficiently clear
  imageSufficientlyClear: boolean;
  // 3. Selected pair matches visible pair
  symbolMatched: boolean;
  // 4. REAL/OTC mode is verified
  marketModeMatched: boolean;
  // 5. One-minute timeframe is verified
  timeframeVerified: boolean;
  // 6. Candle timing is sufficiently reliable (final 7s window)
  timingReliable: boolean;
  // 7. Enough recent candles are visible (>= 5 candles)
  sufficientCandlesVisible: boolean;
  // 8. Captured frame is recent (< 2000 ms old)
  frameRecent: boolean;
  // 9. Analysis result is internally consistent
  internallyConsistent: boolean;
}

export interface SignalResult {
  id: string;
  timestamp: number;
  pairSymbol: string;
  isOtc: boolean;
  timeframe: '1 MIN';
  signal: SignalType;
  modelConfidenceScore: number; // 0 to 100. Strictly documented as model heuristic, not win probability!
  reason: SignalReason;
  detailedMessage: string;
  validationChecklist: ValidationChecklist;
  allChecksPassed: boolean;
  countdownSeconds?: number;
  observedCandleCount: number;
  evaluatedOutcome?: 'WIN' | 'LOSS' | 'TIE' | 'UNOBSERVED';
  outcomeNotes?: string;
}

export interface ScannerState {
  isScanning: boolean;
  scanningMode: ScanningMode;
  selectedPairSymbol: string;
  selectedMarketMode: MarketMode;
  screenCaptureActive: boolean;
  overlayPermissionGranted: boolean;
  captureIntervalMs: number;
  latestFrameTimestamp: number;
  lastAnalysisTimestamp: number;
  currentSignal: SignalResult | null;
  errorMessage: string | null;
}
