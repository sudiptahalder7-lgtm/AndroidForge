import { CandlePixelData, SignalType } from './types.ts';

export interface CandleAnalysisOutput {
  candidateSignal: SignalType;
  modelScore: number; // 0 to 100 heuristic
  isConsistent: boolean;
  bullishEvidenceCount: number;
  bearishEvidenceCount: number;
  summary: string;
}

/**
 * CandleAnalysisEngine
 * Pure logic engine that analyzes observable candle geometry and color sequence.
 * 
 * Rules:
 * - Does not invent OHLC numbers.
 * - Minimum 5 candles required for baseline context.
 * - Analyzes recent 3-5 candles for momentum, exhaustion wicks, and rejection.
 * - Detects conflicting evidence (e.g. green candle with enormous upper wick + prior red candles).
 * - Defaults to NO_TRADE when evidence is balanced or conflicting.
 */
export function analyzeCandles(candles: CandlePixelData[]): CandleAnalysisOutput {
  if (!candles || candles.length < 5) {
    return {
      candidateSignal: 'NO_TRADE',
      modelScore: 0,
      isConsistent: false,
      bullishEvidenceCount: 0,
      bearishEvidenceCount: 0,
      summary: 'Insufficient visible candles (< 5 detected)',
    };
  }

  // Take the last 5 candles
  const recent = candles.slice(-5);
  const currentCandle = recent[recent.length - 1];
  const priorCandle = recent[recent.length - 2];
  const thirdCandle = recent[recent.length - 3];

  let bullishEvidence = 0;
  let bearishEvidence = 0;

  // 1. Recent directional bias
  const greenCount = recent.filter((c) => c.isBullish).length;
  const redCount = recent.filter((c) => !c.isBullish).length;

  if (greenCount >= 4) {
    bullishEvidence += 2;
  } else if (redCount >= 4) {
    bearishEvidence += 2;
  }

  // 2. Body momentum (relative size)
  const avgBodyHeight =
    recent.reduce((acc, c) => acc + c.bodyHeight, 0) / recent.length;

  // Check if current candle has a strong directional body (> average)
  if (currentCandle.bodyHeight > avgBodyHeight * 1.1) {
    if (currentCandle.isBullish) {
      bullishEvidence += 2;
    } else {
      bearishEvidence += 2;
    }
  }

  // 3. Wick Rejection Analysis
  // Long lower wick (buying pressure from below): lowerWick > bodyHeight * 1.4
  if (currentCandle.lowerWickLength > currentCandle.bodyHeight * 1.3) {
    bullishEvidence += 2;
  }

  // Long upper wick (selling pressure from above): upperWick > bodyHeight * 1.4
  if (currentCandle.upperWickLength > currentCandle.bodyHeight * 1.3) {
    bearishEvidence += 2;
  }

  // 4. Consecutive confirmation: 2 consecutive candles in same direction
  if (currentCandle.isBullish && priorCandle.isBullish && thirdCandle.isBullish) {
    bullishEvidence += 1;
  } else if (!currentCandle.isBullish && !priorCandle.isBullish && !thirdCandle.isBullish) {
    bearishEvidence += 1;
  }

  // 5. Check for Indecision / Doji / Extreme Wicks
  const isDoji = currentCandle.bodyHeight < avgBodyHeight * 0.25;
  const hasOpposingLargeWick =
    (currentCandle.isBullish && currentCandle.upperWickLength > currentCandle.bodyHeight * 1.5) ||
    (!currentCandle.isBullish && currentCandle.lowerWickLength > currentCandle.bodyHeight * 1.5);

  if (isDoji || hasOpposingLargeWick) {
    return {
      candidateSignal: 'NO_TRADE',
      modelScore: 35,
      isConsistent: false,
      bullishEvidenceCount: bullishEvidence,
      bearishEvidenceCount: bearishEvidence,
      summary: isDoji
        ? 'Doji indecision detected on current candle'
        : 'Conflicting opposing wick pressure against candle body',
    };
  }

  // 6. Conflicting evidence check
  const evidenceDiff = Math.abs(bullishEvidence - bearishEvidence);
  if (bullishEvidence > 0 && bearishEvidence > 0 && evidenceDiff < 2) {
    return {
      candidateSignal: 'NO_TRADE',
      modelScore: 40,
      isConsistent: false,
      bullishEvidenceCount: bullishEvidence,
      bearishEvidenceCount: bearishEvidence,
      summary: 'Conflicting bullish and bearish technical patterns detected',
    };
  }

  // Clear directional consensus required
  if (bullishEvidence >= 3 && bearishEvidence <= 1) {
    const score = Math.min(88, 60 + bullishEvidence * 7);
    return {
      candidateSignal: 'UP',
      modelScore: score,
      isConsistent: true,
      bullishEvidenceCount: bullishEvidence,
      bearishEvidenceCount: bearishEvidence,
      summary: 'Strong bullish momentum and bottom rejection structure',
    };
  }

  if (bearishEvidence >= 3 && bullishEvidence <= 1) {
    const score = Math.min(88, 60 + bearishEvidence * 7);
    return {
      candidateSignal: 'DOWN',
      modelScore: score,
      isConsistent: true,
      bullishEvidenceCount: bullishEvidence,
      bearishEvidenceCount: bearishEvidence,
      summary: 'Strong bearish momentum and upper resistance rejection',
    };
  }

  return {
    candidateSignal: 'NO_TRADE',
    modelScore: 45,
    isConsistent: true,
    bullishEvidenceCount: bullishEvidence,
    bearishEvidenceCount: bearishEvidence,
    summary: 'Evidence insufficient for directional conviction',
  };
}
