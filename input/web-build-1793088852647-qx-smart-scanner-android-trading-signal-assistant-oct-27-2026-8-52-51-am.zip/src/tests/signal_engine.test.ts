import test from 'node:test';
import assert from 'node:assert/strict';
import {
  CONFIGURED_MARKET_PAIRS,
  REAL_PAIRS_COUNT,
  OTC_PAIRS_COUNT,
  TOTAL_PAIRS_COUNT,
  validateMarketConfiguration,
  findPairByDisplay,
} from '../core/marketConfig.ts';
import { validateAndGenerateSignal } from '../core/signalValidation.ts';
import { CandlePixelData, ExtractedChartData } from '../core/types.ts';

// Helper to generate mock candle sequence
function generateMockCandles(direction: 'bullish' | 'bearish' | 'conflicting' | 'doji', count = 6): CandlePixelData[] {
  const candles: CandlePixelData[] = [];
  for (let i = 0; i < count; i++) {
    const isBull = direction === 'bullish' ? true : direction === 'bearish' ? false : (i % 2 === 0);
    const bodyHeight = direction === 'doji' && i === count - 1 ? 2 : 30;
    const upperWick = direction === 'bearish' && i === count - 1 ? 45 : 8;
    const lowerWick = direction === 'bullish' && i === count - 1 ? 45 : 8;

    candles.push({
      index: i,
      isBullish: isBull,
      bodyTop: 100,
      bodyBottom: 100 + bodyHeight,
      wickHigh: 100 - upperWick,
      wickLow: 100 + bodyHeight + lowerWick,
      bodyHeight,
      upperWickLength: upperWick,
      lowerWickLength: lowerWick,
      totalLength: bodyHeight + upperWick + lowerWick,
    });
  }
  return candles;
}

test('1. Exact 20 Market Pairs Configuration Verification', () => {
  assert.equal(TOTAL_PAIRS_COUNT, 20, 'Total pairs must be exactly 20');
  assert.equal(REAL_PAIRS_COUNT, 10, 'REAL pairs must be exactly 10');
  assert.equal(OTC_PAIRS_COUNT, 10, 'OTC pairs must be exactly 10');

  const validation = validateMarketConfiguration();
  assert.equal(validation.valid, true, `Configuration must be valid: ${validation.errors.join(', ')}`);
  assert.equal(validation.errors.length, 0);

  // Check no duplicates in names and ids
  const ids = new Set(CONFIGURED_MARKET_PAIRS.map((p) => p.id));
  assert.equal(ids.size, 20, 'All 20 IDs must be strictly unique');

  const names = new Set(CONFIGURED_MARKET_PAIRS.map((p) => p.displayName));
  assert.equal(names.size, 20, 'All 20 display names must be strictly unique');
});

test('2. REAL and OTC Market Separation', () => {
  const gbpReal = findPairByDisplay('GBP/USD');
  const gbpOtc = findPairByDisplay('GBP/USD (OTC)');

  assert.ok(gbpReal, 'GBP/USD REAL must exist');
  assert.ok(gbpOtc, 'GBP/USD (OTC) must exist');
  assert.equal(gbpReal.isOtc, false);
  assert.equal(gbpOtc.isOtc, true);
  assert.notEqual(gbpReal.id, gbpOtc.id);
});

test('3. Screen capture stopped triggers SCREEN_CAPTURE_STOPPED and NO_TRADE', () => {
  const result = validateAndGenerateSignal({
    screenCaptureActive: false,
    selectedPairSymbol: 'GBP/USD',
    selectedMarketMode: 'REAL',
    extractedData: null,
  });

  assert.equal(result.signal, 'NO_TRADE');
  assert.equal(result.reason, 'SCREEN_CAPTURE_STOPPED');
  assert.equal(result.allChecksPassed, false);
  assert.equal(result.validationChecklist.screenCaptureActive, false);
});

test('4. Selected pair mismatch triggers ASSET_NOT_VERIFIED', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 200,
    imageClear: true,
    sharpnessScore: 85,
    recognizedSymbol: 'EUR/USD', // Visible chart is EUR/USD, but user selected GBP/USD
    recognizedIsOtc: false,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 5,
    countdownConfidence: 90,
    detectedCandles: generateMockCandles('bullish', 6),
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'GBP/USD',
    selectedMarketMode: 'REAL',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'NO_TRADE');
  assert.equal(result.reason, 'ASSET_NOT_VERIFIED');
  assert.equal(result.validationChecklist.symbolMatched, false);
});

test('5. Stale frame (> 2000ms) triggers NO_TRADE_STALE_FRAME', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now() - 4000,
    frameAgeMs: 4000, // 4 seconds old
    imageClear: true,
    sharpnessScore: 85,
    recognizedSymbol: 'GBP/USD',
    recognizedIsOtc: false,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 4,
    countdownConfidence: 90,
    detectedCandles: generateMockCandles('bullish', 6),
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'GBP/USD',
    selectedMarketMode: 'REAL',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'NO_TRADE');
  assert.equal(result.reason, 'NO_TRADE_STALE_FRAME');
  assert.equal(result.validationChecklist.frameRecent, false);
});

test('6. Non-1M timeframe triggers NO_TRADE_TIMEFRAME_MISMATCH', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 150,
    imageClear: true,
    sharpnessScore: 80,
    recognizedSymbol: 'USD/JPY',
    recognizedIsOtc: false,
    recognizedTimeframe: '5M', // Visible chart is 5 minutes instead of 1 minute!
    countdownSecondsRemaining: 5,
    countdownConfidence: 90,
    detectedCandles: generateMockCandles('bullish', 6),
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'USD/JPY',
    selectedMarketMode: 'REAL',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'NO_TRADE');
  assert.equal(result.reason, 'NO_TRADE_TIMEFRAME_MISMATCH');
  assert.equal(result.validationChecklist.timeframeVerified, false);
});

test('7. Missing or outside 7-second countdown window triggers NO_TRADE_TIMING_UNVERIFIED', () => {
  // Case A: 25 seconds remaining (too early)
  const extractedEarly: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 150,
    imageClear: true,
    sharpnessScore: 85,
    recognizedSymbol: 'USD/JPY',
    recognizedIsOtc: false,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 25,
    countdownConfidence: 90,
    detectedCandles: generateMockCandles('bullish', 6),
  };

  const resultEarly = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'USD/JPY',
    selectedMarketMode: 'REAL',
    extractedData: extractedEarly,
  });

  assert.equal(resultEarly.signal, 'NO_TRADE');
  assert.equal(resultEarly.reason, 'NO_TRADE_TIMING_UNVERIFIED');
  assert.equal(resultEarly.validationChecklist.timingReliable, false);

  // Case B: countdown unreadable / undefined
  const extractedMissing: ExtractedChartData = {
    ...extractedEarly,
    countdownSecondsRemaining: undefined,
  };

  const resultMissing = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'USD/JPY',
    selectedMarketMode: 'REAL',
    extractedData: extractedMissing,
  });

  assert.equal(resultMissing.signal, 'NO_TRADE');
  assert.equal(resultMissing.reason, 'NO_TRADE_TIMING_UNVERIFIED');
});

test('8. Insufficient candles (< 5) triggers NO_TRADE_INSUFFICIENT_DATA', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 150,
    imageClear: true,
    sharpnessScore: 85,
    recognizedSymbol: 'USD/JPY',
    recognizedIsOtc: false,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 5,
    countdownConfidence: 90,
    detectedCandles: generateMockCandles('bullish', 3), // Only 3 candles
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'USD/JPY',
    selectedMarketMode: 'REAL',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'NO_TRADE');
  assert.equal(result.reason, 'NO_TRADE_INSUFFICIENT_DATA');
  assert.equal(result.validationChecklist.sufficientCandlesVisible, false);
});

test('9. Conflicting signals / Doji indecision triggers NO_TRADE_CONFLICTING_EVIDENCE', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 150,
    imageClear: true,
    sharpnessScore: 85,
    recognizedSymbol: 'USD/JPY',
    recognizedIsOtc: false,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 4,
    countdownConfidence: 90,
    detectedCandles: generateMockCandles('doji', 6), // Indecision / Doji
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'USD/JPY',
    selectedMarketMode: 'REAL',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'NO_TRADE');
  assert.equal(result.reason, 'NO_TRADE_CONFLICTING_EVIDENCE');
  assert.equal(result.validationChecklist.internallyConsistent, false);
});

test('10. Valid Bullish Setup in 7s window produces UP signal and all 9 checks pass', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 250,
    imageClear: true,
    sharpnessScore: 88,
    recognizedSymbol: 'USD/JPY',
    recognizedIsOtc: false,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 4, // Inside final 7-second window!
    countdownConfidence: 95,
    detectedCandles: generateMockCandles('bullish', 6),
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'USD/JPY',
    selectedMarketMode: 'REAL',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'UP');
  assert.equal(result.allChecksPassed, true);
  assert.ok(result.modelConfidenceScore >= 60, 'Model score must reflect evidence');
  assert.equal(result.validationChecklist.screenCaptureActive, true);
  assert.equal(result.validationChecklist.imageSufficientlyClear, true);
  assert.equal(result.validationChecklist.symbolMatched, true);
  assert.equal(result.validationChecklist.marketModeMatched, true);
  assert.equal(result.validationChecklist.timeframeVerified, true);
  assert.equal(result.validationChecklist.timingReliable, true);
  assert.equal(result.validationChecklist.sufficientCandlesVisible, true);
  assert.equal(result.validationChecklist.frameRecent, true);
  assert.equal(result.validationChecklist.internallyConsistent, true);
});

test('11. Valid Bearish Setup in 7s window produces DOWN signal', () => {
  const extracted: ExtractedChartData = {
    timestamp: Date.now(),
    frameAgeMs: 200,
    imageClear: true,
    sharpnessScore: 92,
    recognizedSymbol: 'GBP/USD (OTC)',
    recognizedIsOtc: true,
    recognizedTimeframe: '1M',
    countdownSecondsRemaining: 3,
    countdownConfidence: 95,
    detectedCandles: generateMockCandles('bearish', 6),
  };

  const result = validateAndGenerateSignal({
    screenCaptureActive: true,
    selectedPairSymbol: 'GBP/USD (OTC)',
    selectedMarketMode: 'OTC',
    extractedData: extracted,
  });

  assert.equal(result.signal, 'DOWN');
  assert.equal(result.allChecksPassed, true);
  assert.equal(result.isOtc, true);
});
