# QA and build status

Date: 2026-10-27

## Checks completed in the authoring environment

- Parsed the Android manifest and all XML resources successfully.
- Compiled the pure Kotlin domain, pair-configuration, data-provider contract, candle-validation, analysis, timing, signal-validation, and lifecycle-policy modules with `kotlinc`.
- Ran a core smoke check for the exact 10 REAL / 10 OTC lists, distinct REAL/OTC IDs, fresh/stale candle checks, mock data labeling, and the default unconfigured provider.
- Ran 22 pure-logic test methods with a temporary local harness: 22 passed, 0 failed. The harness uses temporary minimal JUnit/Room-annotation shims and is not the Android Gradle/JUnit test runner.
- Checked the Unix bootstrap script syntax with `bash -n`.

## Not verified here

- No full `assembleDebug` or `testDebugUnitTest` Gradle run. Android SDK Platform 36 / `android.jar` and downloadable Gradle/Maven dependencies were not available from this authoring environment.
- No APK was produced or tested on an Android device/emulator.
- No authorized live market-data client is bundled. `AuthorizedApiProvider` intentionally defaults to `DATA SOURCE NOT CONFIGURED`; real/OTC live analysis must remain unavailable until a permitted adapter is implemented and independently checked.
- MediaProjection captures frames only. OCR, chart identity and candle parsing are not implemented; screen capture does not produce an analysis signal.

Build with Android Studio / JDK 17, Android SDK Platform 36, and network access, then run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` (Windows: `gradlew.bat`). Treat this source package as unverified until those checks pass and device QA is completed.
