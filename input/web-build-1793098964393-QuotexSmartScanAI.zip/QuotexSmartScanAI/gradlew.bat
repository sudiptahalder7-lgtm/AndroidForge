@echo off
setlocal EnableExtensions EnableDelayedExpansion
set GRADLE_VERSION=8.13
set PROJECT_DIR=%~dp0
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME_LOCAL=%GRADLE_USER_HOME%\smartscan-distributions\gradle-%GRADLE_VERSION%

where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle --version | findstr /C:"Gradle 8.13" >nul
  if not errorlevel 1 (
    gradle -p "%PROJECT_DIR%" %*
    exit /b !errorlevel!
  )
)

if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
  echo Gradle %GRADLE_VERSION% is not cached. Downloading the official distribution...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $version='%GRADLE_VERSION%'; $base='%GRADLE_USER_HOME%\smartscan-distributions'; New-Item -ItemType Directory -Force -Path $base | Out-Null; $zip=Join-Path $env:TEMP ('gradle-'+$version+'-bin.zip'); Invoke-WebRequest -Uri ('https://services.gradle.org/distributions/gradle-'+$version+'-bin.zip') -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $base -Force; Remove-Item $zip -Force; if (Test-Path '%GRADLE_HOME_LOCAL%') { Remove-Item '%GRADLE_HOME_LOCAL%' -Recurse -Force }; Move-Item (Join-Path $base ('gradle-'+$version)) '%GRADLE_HOME_LOCAL%'"
  if errorlevel 1 exit /b 1
)

call "%GRADLE_HOME_LOCAL%\bin\gradle.bat" -p "%PROJECT_DIR%" %*
exit /b !errorlevel!
