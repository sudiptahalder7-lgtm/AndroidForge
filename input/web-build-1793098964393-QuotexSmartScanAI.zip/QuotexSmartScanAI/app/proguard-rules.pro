# Keep Room entity and DAO metadata intact if release minification is enabled.
-keep class androidx.room.** { *; }
-keep @androidx.room.Entity class * { *; }
