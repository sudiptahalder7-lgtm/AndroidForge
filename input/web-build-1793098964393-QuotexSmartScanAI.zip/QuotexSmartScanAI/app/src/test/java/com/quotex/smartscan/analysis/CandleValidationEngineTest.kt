package com.quotex.smartscan.analysis

import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.CandleValidationStatus
import com.quotex.smartscan.model.DataSourceKind
import com.quotex.smartscan.model.MarketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CandleValidationEngineTest {
    private val engine = CandleValidationEngine()
    private val instrument = ConfiguredPairs.realPairs.first()

    private fun candles(now: Long = System.currentTimeMillis()): List<Candle> {
        val lastOpen = (now / 60_000L) * 60_000L
        return (0 until 10).map { index ->
            val open = 1.1000 + index * 0.0001
            Candle(
                instrumentId = instrument.id,
                marketMode = MarketMode.REAL,
                timeframeSeconds = 60,
                timestampMillis = lastOpen - (9 - index) * 60_000L,
                open = open,
                high = open + 0.0005,
                low = open - 0.0005,
                close = open + 0.0001,
                dataSource = DataSourceKind.AUTHORIZED_API,
                receivedAtMillis = now,
                isClosed = index < 9
            )
        }
    }

    @Test fun acceptsWellFormedFreshData() {
        val now = System.currentTimeMillis()
        assertTrue(engine.validate(instrument, candles(now), now) is CandleValidationResult.Valid)
    }

    @Test fun missingDataReturnsNoDirectionalInput() {
        val result = engine.validate(instrument, emptyList()) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.DATA_MISSING, result.status)
    }

    @Test fun insufficientDataIsRejected() {
        val data = candles().take(9)
        val result = engine.validate(instrument, data) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.INSUFFICIENT_DATA, result.status)
    }

    @Test fun staleReceiveTimestampIsRejected() {
        val now = System.currentTimeMillis()
        val stale = candles(now - 6_000L).map { it.copy(receivedAtMillis = now - 6_000L) }
        val result = engine.validate(instrument, stale, now) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.STALE_DATA, result.status)
    }

    @Test fun invalidOhlcIsRejected() {
        val now = System.currentTimeMillis()
        val data = candles(now).toMutableList()
        data[data.lastIndex] = data.last().copy(high = data.last().close - 0.01)
        val result = engine.validate(instrument, data, now) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.INVALID_OHLC, result.status)
    }

    @Test fun mismatchedOtcIdentityIsRejected() {
        val now = System.currentTimeMillis()
        val data = candles(now).map { it.copy(marketMode = MarketMode.OTC) }
        val result = engine.validate(instrument, data, now) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.INSTRUMENT_MISMATCH, result.status)
    }


    @Test fun oneMinuteTimestampGapIsRejected() {
        val now = System.currentTimeMillis()
        val data = candles(now).toMutableList()
        data[5] = data[5].copy(timestampMillis = data[5].timestampMillis + 60_000L)
        val result = engine.validate(instrument, data, now) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.TIMESTAMP_ERROR, result.status)
    }

    @Test fun futureReceiveTimestampIsRejected() {
        val now = System.currentTimeMillis()
        val data = candles(now).mapIndexed { index, candle ->
            if (index == 0) candle.copy(timestampMillis = now + 10_000L) else candle
        }.sortedBy { it.timestampMillis }
        val result = engine.validate(instrument, data, now) as CandleValidationResult.Invalid
        assertEquals(CandleValidationStatus.TIMESTAMP_ERROR, result.status)
    }
}
