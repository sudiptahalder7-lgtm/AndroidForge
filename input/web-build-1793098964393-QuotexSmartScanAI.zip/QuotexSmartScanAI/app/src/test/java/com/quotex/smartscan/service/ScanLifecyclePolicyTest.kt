package com.quotex.smartscan.service

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanLifecyclePolicyTest {
    @Test fun serviceInterruptionAlwaysClearsActiveFlag() {
        val decision = ScanLifecyclePolicy.stopped(ScanStopReason.SERVICE_INTERRUPTED)
        assertFalse(decision.scanningActive)
        assertTrue(decision.status.contains("INTERRUPTED"))
        assertTrue(decision.clearPreviousSignal)
    }

    @Test fun permissionRevocationCannotLeaveScanningActive() {
        val decision = ScanLifecyclePolicy.stopped(ScanStopReason.PERMISSION_REVOKED)
        assertFalse(decision.scanningActive)
        assertTrue(decision.status.contains("PERMISSION"))
    }

    @Test fun networkLossClearsPreviousSignal() {
        val decision = ScanLifecyclePolicy.stopped(ScanStopReason.NETWORK_LOST)
        assertFalse(decision.scanningActive)
        assertTrue(decision.clearPreviousSignal)
    }
}
