package com.quotex.smartscan.history

import com.quotex.smartscan.analysis.PerformanceEvaluator
import com.quotex.smartscan.model.MarketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PerformanceEvaluatorTest {
    private fun row(mode: String, signal: String, outcome: Boolean?, verified: Boolean) = SignalHistoryEntity(
        instrumentId = if (mode == "OTC") "OTC_GBP_USD" else "REAL_GBP_USD",
        symbol = "GBP/USD",
        marketMode = mode,
        timestampMillis = 1L,
        candleTimestampMillis = 60_000L + if (mode == "OTC") 1L else 0L,
        signal = signal,
        dataSource = "AUTHORIZED_API",
        validationStatus = "VALIDATED",
        reason = "test",
        verifiedOutcome = outcome,
        outcomeVerified = verified
    )

    @Test fun unresolvedPredictionsAreExcludedFromHitRate() {
        val data = listOf(
            row("REAL", "UP", true, true),
            row("REAL", "DOWN", null, false),
            row("REAL", "UP", false, true),
            row("REAL", "NO_TRADE", true, true)
        )
        val stats = PerformanceEvaluator.evaluate(data, MarketMode.REAL)
        assertEquals(2, stats.evaluatedPredictions)
        assertEquals(1, stats.correctPredictions)
        assertEquals(50.0, stats.hitRatePercent!!, 0.001)
    }

    @Test fun realAndOtcResultsRemainSeparate() {
        val data = listOf(row("REAL", "UP", true, true), row("OTC", "DOWN", false, true))
        assertEquals(1, PerformanceEvaluator.evaluate(data, MarketMode.REAL).evaluatedPredictions)
        assertEquals(1, PerformanceEvaluator.evaluate(data, MarketMode.OTC).evaluatedPredictions)
        assertEquals(0, PerformanceEvaluator.evaluate(data, MarketMode.OTC).correctPredictions)
    }

    @Test fun noCompletedPredictionsHasNoRate() {
        val stats = PerformanceEvaluator.evaluate(listOf(row("REAL", "UP", null, false)), MarketMode.REAL)
        assertEquals(0, stats.evaluatedPredictions)
        assertNull(stats.hitRatePercent)
    }
}
