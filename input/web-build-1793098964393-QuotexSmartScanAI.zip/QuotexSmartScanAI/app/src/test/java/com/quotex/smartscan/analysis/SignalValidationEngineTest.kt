package com.quotex.smartscan.analysis

import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.model.AnalysisCandidate
import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.DataSourceKind
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.model.SignalDirection
import com.quotex.smartscan.model.TimingAssessment
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SignalValidationEngineTest {
    private val engine = SignalValidationEngine()
    private val instrument = ConfiguredPairs.realPairs.first()

    // Fixed, minute-aligned timestamps make these tests deterministic and independent of wall-clock jitter.
    private val minuteBase = 1_800_000_000_000L / 60_000L * 60_000L

    private fun validCandles(now: Long): CandleValidationResult.Valid {
        val latestOpen = (now / 60_000L) * 60_000L
        val data = (0 until 10).map { index ->
            val open = 1.1 + index * 0.0001
            Candle(
                instrumentId = instrument.id,
                marketMode = MarketMode.REAL,
                timeframeSeconds = 60,
                timestampMillis = latestOpen - (9 - index) * 60_000L,
                open = open,
                high = open + 0.0005,
                low = open - 0.0005,
                close = open + 0.0001,
                dataSource = DataSourceKind.AUTHORIZED_API,
                receivedAtMillis = now,
                isClosed = index < 9
            )
        }
        return CandleValidationResult.Valid(data)
    }

    private fun timing(open: Long, now: Long) = TimingAssessment(
        trusted = true,
        candleOpenMillis = open,
        candleCloseMillis = open + 60_000L,
        displayTargetMillis = open + 59_000L,
        remainingMillis = open + 60_000L - now,
        reason = "verified"
    )

    @Test fun missingProviderAvailabilityAlwaysReturnsNoTrade() {
        val now = minuteBase + 59_000L
        val result = engine.validate(
            instrument,
            AnalysisCandidate(SignalDirection.UP, "candidate", 80),
            validCandles(now), timing(minuteBase, now), now, false
        )
        assertEquals(SignalDirection.NO_TRADE, result.direction)
        assertEquals("PAIR UNAVAILABLE", result.status)
    }

    @Test fun lateSignalIsNoTrade() {
        val now = minuteBase + 59_800L
        val result = engine.validate(
            instrument,
            AnalysisCandidate(SignalDirection.UP, "candidate", 80),
            validCandles(now), timing(minuteBase, now), now, true
        )
        assertEquals(SignalDirection.NO_TRADE, result.direction)
        assertTrue(result.status.contains("SIGNAL LATE"))
    }

    @Test fun noTradeCandidateStaysNoTrade() {
        val now = minuteBase + 59_000L
        val result = engine.validate(
            instrument,
            AnalysisCandidate(SignalDirection.NO_TRADE, "conflicting indicators"),
            validCandles(now), timing(minuteBase, now), now, true
        )
        assertEquals(SignalDirection.NO_TRADE, result.direction)
        assertEquals("NO TRADE", result.status)
        assertEquals("conflicting indicators", result.reason)
    }

    @Test fun timingMismatchCannotProduceDirectionalSignal() {
        val now = minuteBase + 59_000L
        val result = engine.validate(
            instrument,
            AnalysisCandidate(SignalDirection.UP, "candidate", 80),
            validCandles(now), timing(minuteBase - 60_000L, now), now, true
        )
        assertEquals(SignalDirection.NO_TRADE, result.direction)
        assertEquals("DATA MISMATCH", result.status)
    }
}
