package com.quotex.smartscan.config

import com.quotex.smartscan.model.MarketMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ConfiguredPairsTest {
    @Test fun exactlyTenRealPairsAreConfigured() {
        ConfiguredPairs.validateConfiguration()
        assertEquals(10, ConfiguredPairs.realPairs.size)
        assertTrue(ConfiguredPairs.realPairs.all { it.mode == MarketMode.REAL })
    }

    @Test fun exactlyTenOtcPairsAreConfigured() {
        ConfiguredPairs.validateConfiguration()
        assertEquals(10, ConfiguredPairs.otcPairs.size)
        assertTrue(ConfiguredPairs.otcPairs.all { it.mode == MarketMode.OTC })
    }

    @Test fun pairsHaveUniqueIdsAndRealOtcStorageIsSeparate() {
        assertEquals(10, ConfiguredPairs.realPairs.map { it.id }.distinct().size)
        assertEquals(10, ConfiguredPairs.otcPairs.map { it.id }.distinct().size)
        val real = ConfiguredPairs.find("GBP/USD", MarketMode.REAL)!!
        val otc = ConfiguredPairs.find("GBP/USD", MarketMode.OTC)!!
        assertNotEquals(real.id, otc.id)
        assertNotEquals(real.mode, otc.mode)
    }

    @Test fun defaultsContainOnlyRequestedSymbols() {
        val expected = setOf("GBP/USD", "USD/JPY", "USD/CHF", "AUD/USD", "USD/CAD", "NZD/USD", "EUR/GBP", "EUR/JPY", "EUR/AUD", "GBP/JPY")
        assertEquals(expected, ConfiguredPairs.realPairs.map { it.symbol }.toSet())
        assertEquals(expected, ConfiguredPairs.otcPairs.map { it.symbol }.toSet())
    }
}
