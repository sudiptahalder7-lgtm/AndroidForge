package com.quotex.smartscan.service

import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketMode

object ScanConfiguration {
    @Volatile var marketMode: MarketMode = MarketMode.REAL
        private set
    @Volatile var selectedInstrumentId: String = ConfiguredPairs.realPairs.first().id
        private set
    @Volatile var autoMode: Boolean = false

    fun selectedInstrument(): Instrument =
        ConfiguredPairs.find(selectedInstrumentId) ?: ConfiguredPairs.forMode(marketMode).first()

    @Synchronized
    fun selectMode(mode: MarketMode) {
        val currentSymbol = selectedInstrument().symbol
        marketMode = mode
        selectedInstrumentId = ConfiguredPairs.find(currentSymbol, mode)?.id
            ?: ConfiguredPairs.forMode(mode).first().id
    }

    @Synchronized
    fun selectInstrument(instrument: Instrument) {
        require(ConfiguredPairs.find(instrument.id) == instrument) { "Only configured instruments can be selected." }
        marketMode = instrument.mode
        selectedInstrumentId = instrument.id
    }
}
