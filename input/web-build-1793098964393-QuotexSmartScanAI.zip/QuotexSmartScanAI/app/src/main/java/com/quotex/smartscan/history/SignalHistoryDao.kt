package com.quotex.smartscan.history

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SignalHistoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(record: SignalHistoryEntity): Long

    @Query("SELECT * FROM signal_history WHERE marketMode = :marketMode ORDER BY timestampMillis DESC LIMIT :limit")
    fun listByMode(marketMode: String, limit: Int): List<SignalHistoryEntity>

    @Query("SELECT * FROM signal_history ORDER BY timestampMillis DESC LIMIT :limit")
    fun listRecent(limit: Int): List<SignalHistoryEntity>

    @Query("SELECT * FROM signal_history WHERE outcomeVerified = 1 AND verifiedOutcome IS NOT NULL AND marketMode = :marketMode")
    fun completedByMode(marketMode: String): List<SignalHistoryEntity>

    @Query("SELECT * FROM signal_history WHERE instrumentId = :instrumentId AND marketMode = :marketMode AND outcomeVerified = 0 AND verifiedOutcome IS NULL AND signal IN ('UP', 'DOWN') ORDER BY candleTimestampMillis ASC")
    fun pendingForInstrument(instrumentId: String, marketMode: String): List<SignalHistoryEntity>

    @Query("UPDATE signal_history SET verifiedOutcome = :correct, outcomeVerified = 1 WHERE id = :recordId AND outcomeVerified = 0")
    fun updateVerifiedOutcome(recordId: Long, correct: Boolean): Int

    @Query("DELETE FROM signal_history")
    fun deleteAll()

    @Query("SELECT COUNT(*) FROM signal_history")
    fun countAll(): Int
}
