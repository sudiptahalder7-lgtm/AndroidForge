package com.quotex.smartscan.analysis

import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.CandleValidationStatus
import com.quotex.smartscan.model.Instrument

class CandleValidationEngine(
    private val minimumCandles: Int = 10,
    private val maximumReceiveAgeMillis: Long = 5_000L,
    private val futureTimestampToleranceMillis: Long = 2_000L
) {
    fun validate(
        instrument: Instrument,
        candles: List<Candle>?,
        nowMillis: Long = System.currentTimeMillis()
    ): CandleValidationResult {
        if (candles.isNullOrEmpty()) {
            return invalid(CandleValidationStatus.DATA_MISSING, "No candle data was received.")
        }
        if (candles.size < minimumCandles) {
            return invalid(
                CandleValidationStatus.INSUFFICIENT_DATA,
                "Need at least $minimumCandles candles; received ${candles.size}."
            )
        }

        val ordered = candles.sortedBy { it.timestampMillis }
        if (ordered != candles) {
            return invalid(CandleValidationStatus.TIMESTAMP_ERROR, "Candles are not in increasing timestamp order.")
        }
        for (index in 1 until candles.size) {
            val delta = candles[index].timestampMillis - candles[index - 1].timestampMillis
            if (delta != 60_000L) {
                return invalid(CandleValidationStatus.TIMESTAMP_ERROR, "One-minute candle timestamps are not contiguous.")
            }
        }

        for (candle in candles) {
            if (candle.instrumentId != instrument.id || candle.marketMode != instrument.mode) {
                return invalid(
                    CandleValidationStatus.INSTRUMENT_MISMATCH,
                    "Candle identity or REAL/OTC mode does not match the selected pair."
                )
            }
            if (candle.timeframeSeconds != 60) {
                return invalid(CandleValidationStatus.TIMEFRAME_MISMATCH, "Only 1-minute candles are accepted.")
            }
            if (candle.timestampMillis <= 0L || candle.timestampMillis > nowMillis + futureTimestampToleranceMillis) {
                return invalid(CandleValidationStatus.TIMESTAMP_ERROR, "Candle timestamp is invalid or in the future.")
            }
            if (!candle.open.isFinite() || !candle.high.isFinite() || !candle.low.isFinite() || !candle.close.isFinite()) {
                return invalid(CandleValidationStatus.INVALID_OHLC, "OHLC values must be finite numbers.")
            }
            if (candle.open <= 0.0 || candle.close <= 0.0 || candle.low <= 0.0 ||
                candle.high < maxOf(candle.open, candle.close) ||
                candle.low > minOf(candle.open, candle.close) || candle.high < candle.low ||
                (candle.volume != null && (!candle.volume.isFinite() || candle.volume < 0.0))
            ) {
                return invalid(CandleValidationStatus.INVALID_OHLC, "OHLC or volume values violate candle bounds.")
            }
            if (candle.receivedAtMillis <= 0L || candle.receivedAtMillis > nowMillis + futureTimestampToleranceMillis) {
                return invalid(CandleValidationStatus.TIMESTAMP_ERROR, "Data receive timestamp is invalid.")
            }
        }

        val latest = candles.last()
        val candleAge = nowMillis - latest.timestampMillis
        if (candleAge > latest.timeframeSeconds * 1_000L + futureTimestampToleranceMillis) {
            return invalid(CandleValidationStatus.STALE_DATA, "The latest candle timestamp is no longer current enough for one-minute analysis.")
        }
        val receiveAge = nowMillis - latest.receivedAtMillis
        if (receiveAge < -futureTimestampToleranceMillis || receiveAge > maximumReceiveAgeMillis) {
            return invalid(CandleValidationStatus.STALE_DATA, "Market data is stale. Fresh data is required.")
        }

        return CandleValidationResult.Valid(candles.toList())
    }

    private fun invalid(status: CandleValidationStatus, reason: String) =
        CandleValidationResult.Invalid(status, reason)
}
