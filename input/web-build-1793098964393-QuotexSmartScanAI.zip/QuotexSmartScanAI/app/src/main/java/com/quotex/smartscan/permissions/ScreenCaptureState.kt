package com.quotex.smartscan.permissions

object ScreenCaptureState {
    @Volatile var isActive: Boolean = false
        private set
    @Volatile var lastFrameAtMillis: Long? = null
        private set

    fun markFrameReceived(timestampMillis: Long = System.currentTimeMillis()) {
        isActive = true
        lastFrameAtMillis = timestampMillis
    }

    fun markStopped() {
        isActive = false
        lastFrameAtMillis = null
    }
}
