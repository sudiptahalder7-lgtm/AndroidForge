package com.quotex.smartscan.model

/** REAL and OTC are intentionally different identities, even when their display symbols match. */
enum class MarketMode { REAL, OTC }

enum class SignalDirection { UP, DOWN, NO_TRADE }

enum class DataSourceKind { AUTHORIZED_API, SCREEN_CAPTURE, MOCK }

enum class DataFreshness { FRESH, STALE, UNKNOWN }

enum class CandleValidationStatus {
    VALID,
    DATA_MISSING,
    INSUFFICIENT_DATA,
    STALE_DATA,
    INVALID_OHLC,
    TIMESTAMP_ERROR,
    INSTRUMENT_MISMATCH,
    TIMEFRAME_MISMATCH
}

data class Instrument(
    val id: String,
    val symbol: String,
    val mode: MarketMode
) {
    val displayName: String
        get() = if (mode == MarketMode.OTC) "$symbol (OTC)" else symbol
}

data class Candle(
    val instrumentId: String,
    val marketMode: MarketMode,
    val timeframeSeconds: Int,
    /** Candle open timestamp in UTC epoch milliseconds, as reported by the provider. */
    val timestampMillis: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double? = null,
    val dataSource: DataSourceKind,
    /** Local receive timestamp, assigned at ingestion. Never inferred from the candle timestamp. */
    val receivedAtMillis: Long,
    val isClosed: Boolean = false
) {
    val closeTimeMillis: Long
        get() = timestampMillis + timeframeSeconds * 1_000L
}

data class AnalysisMetrics(
    val bodyToRangeRatio: Double,
    val upperWickRatio: Double,
    val lowerWickRatio: Double,
    val momentumScore: Double,
    val trendScore: Double,
    val averageRange: Double,
    val supportEstimate: Double,
    val resistanceEstimate: Double,
    val volatilityRatio: Double
)

data class AnalysisCandidate(
    val direction: SignalDirection,
    val reason: String,
    /** A deterministic heuristic score, not a probability or measured accuracy. */
    val heuristicStrength: Int = 0,
    val metrics: AnalysisMetrics? = null
)

data class ValidatedSignal(
    val instrument: Instrument,
    val direction: SignalDirection,
    val timestampMillis: Long,
    val status: String,
    val reason: String,
    val dataSource: DataSourceKind? = null,
    val heuristicStrength: Int = 0
)

data class TimingAssessment(
    val trusted: Boolean,
    val candleOpenMillis: Long,
    val candleCloseMillis: Long,
    val displayTargetMillis: Long,
    val remainingMillis: Long,
    val reason: String
)

sealed class CandleValidationResult {
    data class Valid(val candles: List<Candle>) : CandleValidationResult()
    data class Invalid(val status: CandleValidationStatus, val reason: String) : CandleValidationResult()
}

sealed class MarketDataResult {
    data class Success(val candles: List<Candle>, val source: DataSourceKind) : MarketDataResult()
    data class Unavailable(val reason: String) : MarketDataResult()
    data class Failure(val reason: String) : MarketDataResult()
}

data class PerformanceStats(
    val mode: MarketMode,
    val evaluatedPredictions: Int,
    val correctPredictions: Int,
    val hitRatePercent: Double?
)
