package com.quotex.smartscan.data

import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode

/** No endpoint or secret is assumed. A concrete authorized client must be supplied explicitly. */
class AuthorizedApiProvider(
    private val client: AuthorizedMarketDataClient? = null
) : MarketDataProvider {
    override val name: String = "AUTHORIZED_API"

    override fun isConfigured(): Boolean = client != null

    override fun isModeSupported(mode: MarketMode): Boolean = client?.supportsMode(mode) == true

    override fun isAuthoritativeForMode(mode: MarketMode): Boolean = client?.isAuthoritativeForMode(mode) == true

    override fun isInstrumentAvailable(instrument: Instrument): Boolean =
        client?.isInstrumentAvailable(instrument) == true

    override fun fetchCandles(
        instrument: Instrument,
        timeframeSeconds: Int,
        limit: Int
    ): MarketDataResult {
        val authorizedClient = client ?: return MarketDataResult.Unavailable("DATA SOURCE NOT CONFIGURED")
        if (!authorizedClient.supportsMode(instrument.mode)) {
            return MarketDataResult.Unavailable("MARKET MODE NOT SUPPORTED BY PROVIDER")
        }
        if (!authorizedClient.isInstrumentAvailable(instrument)) {
            return MarketDataResult.Unavailable("PAIR UNAVAILABLE")
        }
        if (timeframeSeconds != 60) {
            return MarketDataResult.Unavailable("Only the configured 1-minute timeframe is enabled.")
        }
        return authorizedClient.fetchCandles(instrument, timeframeSeconds, limit)
    }
}
