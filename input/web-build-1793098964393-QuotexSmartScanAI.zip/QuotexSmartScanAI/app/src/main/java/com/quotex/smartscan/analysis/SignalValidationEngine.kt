package com.quotex.smartscan.analysis

import com.quotex.smartscan.model.AnalysisCandidate
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.SignalDirection
import com.quotex.smartscan.model.ValidatedSignal

class SignalValidationEngine {
    fun validate(
        instrument: Instrument,
        candidate: AnalysisCandidate,
        candleValidation: CandleValidationResult,
        timing: com.quotex.smartscan.model.TimingAssessment,
        nowMillis: Long,
        instrumentAvailable: Boolean
    ): ValidatedSignal {
        fun noTrade(status: String, reason: String) = ValidatedSignal(
            instrument = instrument,
            direction = SignalDirection.NO_TRADE,
            timestampMillis = nowMillis,
            status = status,
            reason = reason,
            heuristicStrength = 0
        )

        if (!instrumentAvailable) return noTrade("PAIR UNAVAILABLE", "The provider has not confirmed this instrument is available.")
        if (candleValidation !is CandleValidationResult.Valid) {
            val reason = (candleValidation as? CandleValidationResult.Invalid)?.reason ?: "Candle data is missing."
            val status = when (candleValidation) {
                is CandleValidationResult.Invalid -> candleValidation.status.name.replace('_', ' ')
                else -> "DATA MISSING"
            }
            return noTrade(status, reason)
        }
        if (!timing.trusted) return noTrade("CHART NOT VERIFIED", timing.reason)
        val latestCandle = candleValidation.candles.lastOrNull()
            ?: return noTrade("DATA MISSING", "No latest candle is available.")
        if (timing.candleOpenMillis != latestCandle.timestampMillis ||
            timing.candleCloseMillis != latestCandle.closeTimeMillis
        ) {
            return noTrade("DATA MISMATCH", "The timing boundary does not match the validated latest candle.")
        }

        // The signal may only be shown in a narrow window immediately before the next minute.
        if (nowMillis < timing.displayTargetMillis) {
            return noTrade("ANALYZING", "Waiting for the verified signal display window.")
        }
        if (nowMillis >= timing.candleCloseMillis || nowMillis - timing.displayTargetMillis > 750L) {
            return noTrade("SIGNAL LATE — NO TRADE", "The validated display window was missed.")
        }

        if (candidate.direction == SignalDirection.NO_TRADE) {
            return noTrade("NO TRADE", candidate.reason)
        }

        val latest = candleValidation.candles.lastOrNull()
            ?: return noTrade("DATA MISSING", "No latest candle is available.")
        if (nowMillis - latest.receivedAtMillis > 5_000L) {
            return noTrade("STALE DATA", "Data became stale before signal display.")
        }

        return ValidatedSignal(
            instrument = instrument,
            direction = candidate.direction,
            timestampMillis = nowMillis,
            status = "VALIDATED",
            reason = candidate.reason,
            dataSource = latest.dataSource,
            heuristicStrength = candidate.heuristicStrength
        )
    }
}
