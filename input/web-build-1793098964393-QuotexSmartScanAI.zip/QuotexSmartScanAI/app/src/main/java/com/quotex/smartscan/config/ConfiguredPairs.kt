package com.quotex.smartscan.config

import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketMode

object ConfiguredPairs {
    private val symbols = listOf(
        "GBP/USD",
        "USD/JPY",
        "USD/CHF",
        "AUD/USD",
        "USD/CAD",
        "NZD/USD",
        "EUR/GBP",
        "EUR/JPY",
        "EUR/AUD",
        "GBP/JPY"
    )

    val realPairs: List<Instrument> = symbols.map { symbol ->
        Instrument(id = "REAL_${symbol.replace('/', '_')}", symbol = symbol, mode = MarketMode.REAL)
    }

    val otcPairs: List<Instrument> = symbols.map { symbol ->
        Instrument(id = "OTC_${symbol.replace('/', '_')}", symbol = symbol, mode = MarketMode.OTC)
    }

    fun forMode(mode: MarketMode): List<Instrument> = when (mode) {
        MarketMode.REAL -> realPairs
        MarketMode.OTC -> otcPairs
    }

    fun allConfigured(): List<Instrument> = realPairs + otcPairs

    fun find(id: String): Instrument? = allConfigured().firstOrNull { it.id == id }

    fun find(symbol: String, mode: MarketMode): Instrument? =
        forMode(mode).firstOrNull { it.symbol.equals(symbol, ignoreCase = true) }

    /** Throws early in development/tests if a future edit introduces invalid defaults. */
    fun validateConfiguration() {
        require(realPairs.size == 10) { "Exactly 10 REAL pairs must be configured." }
        require(otcPairs.size == 10) { "Exactly 10 OTC pairs must be configured." }
        require(realPairs.all { it.mode == MarketMode.REAL }) { "REAL list contains a non-REAL pair." }
        require(otcPairs.all { it.mode == MarketMode.OTC }) { "OTC list contains a non-OTC pair." }
        require(realPairs.map { it.id }.distinct().size == 10) { "Duplicate REAL pair IDs." }
        require(otcPairs.map { it.id }.distinct().size == 10) { "Duplicate OTC pair IDs." }
        require(realPairs.map { it.symbol }.toSet() == symbols.toSet()) { "REAL defaults changed unexpectedly." }
        require(otcPairs.map { it.symbol }.toSet() == symbols.toSet()) { "OTC defaults changed unexpectedly." }
        require(realPairs.map { it.id }.intersect(otcPairs.map { it.id }.toSet()).isEmpty()) {
            "REAL and OTC storage identifiers must not overlap."
        }
    }
}
