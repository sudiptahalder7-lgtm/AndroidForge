package com.quotex.smartscan.data

import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.DataSourceKind
import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode
import kotlin.math.sin

/** Explicit test-only source. Never register this as the production provider. */
class MockMarketDataProvider : MarketDataProvider {
    override val name: String = "MOCK_TEST_DATA"

    override fun isConfigured(): Boolean = true

    override fun isModeSupported(mode: MarketMode): Boolean = true

    override fun isInstrumentAvailable(instrument: Instrument): Boolean =
        ConfiguredPairs.find(instrument.id) != null

    override fun fetchCandles(
        instrument: Instrument,
        timeframeSeconds: Int,
        limit: Int
    ): MarketDataResult {
        if (timeframeSeconds != 60 || limit < 2 || !isInstrumentAvailable(instrument)) {
            return MarketDataResult.Unavailable("Unsupported mock request")
        }

        val now = System.currentTimeMillis()
        val currentMinute = (now / 60_000L) * 60_000L
        val normalizedLimit = limit.coerceAtMost(120)
        val start = currentMinute - (normalizedLimit - 1) * 60_000L
        var close = if (instrument.symbol.contains("JPY")) 150.0 else 1.08
        val result = ArrayList<Candle>(normalizedLimit)
        for (index in 0 until normalizedLimit) {
            val open = close
            val wave = sin(index * 0.63 + instrument.id.length) * (if (instrument.symbol.contains("JPY")) 0.025 else 0.00025)
            val drift = (if (index % 6 < 3) 1.0 else -1.0) * (if (instrument.symbol.contains("JPY")) 0.008 else 0.00008)
            close = (open + wave + drift).coerceAtLeast(0.0001)
            val spread = (if (instrument.symbol.contains("JPY")) 0.018 else 0.00018) + kotlin.math.abs(wave) * 0.25
            val high = maxOf(open, close) + spread
            val low = (minOf(open, close) - spread).coerceAtLeast(0.00001)
            result += Candle(
                instrumentId = instrument.id,
                marketMode = instrument.mode,
                timeframeSeconds = timeframeSeconds,
                timestampMillis = start + index * 60_000L,
                open = open,
                high = high,
                low = low,
                close = close,
                volume = null,
                dataSource = DataSourceKind.MOCK,
                receivedAtMillis = now,
                isClosed = index < normalizedLimit - 1
            )
        }
        return MarketDataResult.Success(result, DataSourceKind.MOCK)
    }
}
