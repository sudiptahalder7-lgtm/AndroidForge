package com.quotex.smartscan.service

import android.os.Handler
import android.os.Looper
import com.quotex.smartscan.model.ValidatedSignal
import java.util.concurrent.CopyOnWriteArraySet

 data class ScanStateSnapshot(
    val scanning: Boolean,
    val status: String,
    val detail: String,
    val latestSignal: ValidatedSignal?
)

object ScanSessionState {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<(ScanStateSnapshot) -> Unit>()

    @Volatile private var current = ScanStateSnapshot(
        scanning = false,
        status = "DATA SOURCE NOT CONFIGURED",
        detail = "Connect an authorized provider before starting live analysis.",
        latestSignal = null
    )

    fun snapshot(): ScanStateSnapshot = current

    fun addListener(listener: (ScanStateSnapshot) -> Unit) {
        listeners += listener
        mainHandler.post { listener(current) }
    }

    fun removeListener(listener: (ScanStateSnapshot) -> Unit) {
        listeners -= listener
    }

    fun update(
        scanning: Boolean = current.scanning,
        status: String = current.status,
        detail: String = current.detail,
        latestSignal: ValidatedSignal? = current.latestSignal
    ) {
        current = ScanStateSnapshot(scanning, status, detail, latestSignal)
        val snapshot = current
        mainHandler.post { listeners.forEach { listener -> runCatching { listener(snapshot) } } }
    }

    fun beginAnalysis(instrumentName: String) {
        update(status = "ANALYZING", detail = "Validating fresh one-minute data for $instrumentName.", latestSignal = null)
    }
}
