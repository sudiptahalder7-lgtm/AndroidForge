package com.quotex.smartscan.analysis

import com.quotex.smartscan.data.MarketDataProvider
import com.quotex.smartscan.model.AnalysisCandidate
import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.model.SignalDirection
import com.quotex.smartscan.model.TimingAssessment
import com.quotex.smartscan.model.ValidatedSignal

class PreparedScan internal constructor(
    val instrument: Instrument,
    val candles: List<Candle>,
    val candidate: AnalysisCandidate,
    val validation: CandleValidationResult,
    val timing: TimingAssessment,
    val available: Boolean
)

class ChartScanningEngine(
    private val candleValidationEngine: CandleValidationEngine = CandleValidationEngine(),
    private val candleAnalysisEngine: CandleAnalysisEngine = CandleAnalysisEngine(),
    private val timingEngine: CandleTimingEngine = CandleTimingEngine(),
    private val signalValidationEngine: SignalValidationEngine = SignalValidationEngine()
) {
    fun prepare(
        provider: MarketDataProvider,
        instrument: Instrument,
        nowMillis: Long = System.currentTimeMillis(),
        testMode: Boolean = false
    ): PreparedScan? {
        if (!provider.isConfigured() || !provider.isModeSupported(instrument.mode)) return null
        if (!provider.isInstrumentAvailable(instrument)) return null
        // OTC requires a provider that explicitly asserts it is authoritative for OTC prices.
        // Mock data is permitted only through the explicit testMode path.
        if (!provider.isAuthoritativeForMode(instrument.mode) && !testMode) return null
        val data = provider.fetchCandles(instrument, timeframeSeconds = 60, limit = 30)
        if (data !is MarketDataResult.Success) return null
        if (data.source.name == "MOCK" && !testMode) return null
        val validation = candleValidationEngine.validate(instrument, data.candles, nowMillis)
        val candidate = when (validation) {
            is CandleValidationResult.Valid -> candleAnalysisEngine.analyze(validation.candles)
            is CandleValidationResult.Invalid -> AnalysisCandidate(SignalDirection.NO_TRADE, validation.reason)
        }
        val latest = data.candles.lastOrNull() ?: return null
        return PreparedScan(
            instrument = instrument,
            candles = data.candles,
            candidate = candidate,
            validation = validation,
            timing = timingEngine.assess(latest, nowMillis),
            available = true
        )
    }

    fun finish(prepared: PreparedScan, nowMillis: Long = System.currentTimeMillis()): ValidatedSignal =
        signalValidationEngine.validate(
            instrument = prepared.instrument,
            candidate = prepared.candidate,
            candleValidation = candleValidationEngine.validate(prepared.instrument, prepared.candles, nowMillis),
            timing = timingEngine.assess(prepared.candles.last(), nowMillis),
            nowMillis = nowMillis,
            instrumentAvailable = prepared.available
        )
}
