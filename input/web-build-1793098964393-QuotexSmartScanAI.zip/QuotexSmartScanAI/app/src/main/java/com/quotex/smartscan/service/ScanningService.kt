package com.quotex.smartscan.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.quotex.smartscan.R
import com.quotex.smartscan.analysis.CandleAnalysisEngine
import com.quotex.smartscan.analysis.CandleTimingEngine
import com.quotex.smartscan.analysis.CandleValidationEngine
import com.quotex.smartscan.analysis.SignalValidationEngine
import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.data.MarketDataRegistry
import com.quotex.smartscan.history.SignalDatabase
import com.quotex.smartscan.history.SignalHistoryEntity
import com.quotex.smartscan.history.SignalHistoryRepository
import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.model.SignalDirection
import com.quotex.smartscan.model.ValidatedSignal
import com.quotex.smartscan.ui.MainActivity
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** A user-started service. Live scanning remains disabled until an authorized client is installed. */
class ScanningService : Service() {
    private var executor: ScheduledExecutorService? = null
    private var cycleCount = 0L
    private var lastInstrumentSwitchMillis = 0L
    private var currentAutoInstrumentId: String? = null
    private val lastFetchAt = ConcurrentHashMap<String, Long>()
    private val cachedCandles = ConcurrentHashMap<String, List<Candle>>()
    private val scheduledKeys = ConcurrentHashMap.newKeySet<String>()

    private val validationEngine = CandleValidationEngine()
    private val analysisEngine = CandleAnalysisEngine()
    private val timingEngine = CandleTimingEngine()
    private val signalValidationEngine = SignalValidationEngine()
    private lateinit var historyRepository: SignalHistoryRepository

    override fun onCreate() {
        super.onCreate()
        historyRepository = SignalHistoryRepository(SignalDatabase.get(this).signalHistoryDao())
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopScanning("SCANNING STOPPED", "Scanning was stopped by the user.")
            return START_NOT_STICKY
        }

        val provider = MarketDataRegistry.provider
        if (!provider.isConfigured()) {
            ScanSessionState.update(
                scanning = false,
                status = "DATA SOURCE NOT CONFIGURED",
                detail = "No authorized market-data client is installed. No live signals are generated.",
                latestSignal = null
            )
            stopSelf(startId)
            return START_NOT_STICKY
        }

        startForegroundCompat()
        ScanSessionState.update(
            scanning = true,
            status = "CONNECTING",
            detail = "Checking configured instruments and provider support.",
            latestSignal = null
        )
        if (executor == null || executor?.isShutdown == true) {
            executor = Executors.newSingleThreadScheduledExecutor()
            executor?.scheduleWithFixedDelay(::scanCycle, 0L, 1L, TimeUnit.SECONDS)
        }
        return START_STICKY
    }

    private fun scanCycle() {
        try {
            val provider = MarketDataRegistry.provider
            if (!provider.isConfigured()) {
                stopScanning("DATA SOURCE NOT CONFIGURED", "Provider configuration was removed.")
                return
            }

            val now = System.currentTimeMillis()
            val instrument = chooseInstrument(now)
            if (!provider.isModeSupported(instrument.mode) ||
                !provider.isAuthoritativeForMode(instrument.mode) ||
                !provider.isInstrumentAvailable(instrument)
            ) {
                val noTrade = ValidatedSignal(
                    instrument, SignalDirection.NO_TRADE, now, "PAIR UNAVAILABLE",
                    "The provider has not verified this instrument and market mode."
                )
                ScanSessionState.update(true, "PAIR UNAVAILABLE", noTrade.reason, noTrade)
                return
            }

            val lastFetch = lastFetchAt[instrument.id] ?: 0L
            if (now - lastFetch >= MIN_FETCH_INTERVAL_MS || !cachedCandles.containsKey(instrument.id)) {
                ScanSessionState.beginAnalysis(instrument.displayName)
                when (val response = provider.fetchCandles(instrument, timeframeSeconds = 60, limit = 30)) {
                    is MarketDataResult.Success -> {
                        if (response.source.name == "MOCK") {
                            ScanSessionState.update(true, "TEST DATA REJECTED", "Mock data cannot be used by the live scanning service.", null)
                            cachedCandles.remove(instrument.id)
                            return
                        }
                        if (instrument.mode == MarketMode.OTC && !provider.isAuthoritativeForMode(MarketMode.OTC)) {
                            ScanSessionState.update(true, "PAIR UNAVAILABLE", "Ordinary forex prices are not authoritative for Quotex OTC.", null)
                            return
                        }
                        cachedCandles[instrument.id] = response.candles
                        lastFetchAt[instrument.id] = now
                        if (provider.isAuthoritativeForMode(instrument.mode)) {
                            evaluatePendingOutcomes(instrument, response.candles, now)
                        }
                    }
                    is MarketDataResult.Unavailable -> {
                        cachedCandles.remove(instrument.id)
                        lastFetchAt[instrument.id] = now
                        ScanSessionState.update(true, "PAIR UNAVAILABLE", response.reason, null)
                        return
                    }
                    is MarketDataResult.Failure -> {
                        cachedCandles.remove(instrument.id)
                        lastFetchAt[instrument.id] = now
                        ScanSessionState.update(true, "CONNECTION ERROR", response.reason, null)
                        return
                    }
                }
            }

            val candles = cachedCandles[instrument.id] ?: return
            val validation = validationEngine.validate(instrument, candles, now)
            if (validation !is CandleValidationResult.Valid) {
                val invalid = validation as CandleValidationResult.Invalid
                val result = ValidatedSignal(instrument, SignalDirection.NO_TRADE, now, invalid.status.name.replace('_', ' '), invalid.reason)
                ScanSessionState.update(true, result.status, result.reason, result)
                return
            }

            val candidate = analysisEngine.analyze(validation.candles)
            val latest = validation.candles.last()
            val timing = timingEngine.assess(latest, now)
            if (!timing.trusted) {
                val result = ValidatedSignal(instrument, SignalDirection.NO_TRADE, now, "CHART NOT VERIFIED", timing.reason)
                ScanSessionState.update(true, result.status, result.reason, result)
                return
            }

            val remaining = timing.remainingMillis
            if (remaining > SIGNAL_WINDOW_MS) {
                ScanSessionState.update(true, "SCANNING", "Waiting for the final seven seconds of the verified candle.", null)
                return
            }
            if (remaining <= 0L) {
                val result = ValidatedSignal(instrument, SignalDirection.NO_TRADE, now, "SIGNAL LATE — NO TRADE", "The candle boundary has already passed.")
                ScanSessionState.update(true, result.status, result.reason, result)
                return
            }

            val key = "${instrument.id}:${latest.timestampMillis}"
            if (scheduledKeys.add(key)) {
                val delay = (timing.displayTargetMillis - now).coerceAtLeast(0L)
                executor?.schedule({
                    try {
                        finishAtDisplayTime(instrument, candidate, latest, timing.candleCloseMillis, key)
                    } catch (_: Throwable) {
                        scheduledKeys.remove(key)
                        ScanSessionState.update(true, "NO TRADE", "Signal validation failed safely.", null)
                    }
                }, delay, TimeUnit.MILLISECONDS)
            }
            ScanSessionState.update(true, "ANALYZING", "Candidate held until the verified display window.", null)
        } catch (error: Throwable) {
            ScanSessionState.update(true, "CONNECTION ERROR", error.message ?: "Unexpected scan error.", null)
        }
    }

    private fun finishAtDisplayTime(
        instrument: com.quotex.smartscan.model.Instrument,
        candidate: com.quotex.smartscan.model.AnalysisCandidate,
        latest: Candle,
        candleCloseMillis: Long,
        key: String
    ) {
        try {
            val now = System.currentTimeMillis()
            val latestCandles = cachedCandles[instrument.id].orEmpty()
            val validation = validationEngine.validate(instrument, latestCandles, now)
            val timing = timingEngine.assess(latest, now)
            val available = MarketDataRegistry.provider.isInstrumentAvailable(instrument) &&
                MarketDataRegistry.provider.isAuthoritativeForMode(instrument.mode)
            val signal = if (now >= candleCloseMillis || now - timing.displayTargetMillis > DISPLAY_WINDOW_TOLERANCE_MS) {
                ValidatedSignal(instrument, SignalDirection.NO_TRADE, now, "SIGNAL LATE — NO TRADE", "The target display time was missed.")
            } else {
                signalValidationEngine.validate(instrument, candidate, validation, timing, now, available)
            }
            ScanSessionState.update(true, signal.status, signal.reason, signal)
            historyRepository.save(
                SignalHistoryEntity(
                    instrumentId = instrument.id,
                    symbol = instrument.symbol,
                    marketMode = instrument.mode.name,
                    timestampMillis = signal.timestampMillis,
                    candleTimestampMillis = latest.timestampMillis,
                    signal = signal.direction.name,
                    dataSource = latest.dataSource.name,
                    validationStatus = signal.status,
                    reason = signal.reason,
                    verifiedOutcome = null,
                    outcomeVerified = false
                )
            )
        } finally {
            scheduledKeys.remove(key)
        }
    }

    private fun evaluatePendingOutcomes(
        instrument: com.quotex.smartscan.model.Instrument,
        candles: List<Candle>,
        nowMillis: Long
    ) {
        val trustedCandles = candles.filter {
            it.instrumentId == instrument.id && it.marketMode == instrument.mode &&
                it.dataSource.name != "MOCK" && it.isClosed &&
                nowMillis - it.receivedAtMillis in 0L..5_000L
        }
        if (trustedCandles.isEmpty()) return
        historyRepository.pendingForInstrument(instrument.id, instrument.mode.name) { pending ->
            pending.forEach { record ->
                val nextCandleTime = record.candleTimestampMillis + 60_000L
                val next = trustedCandles.firstOrNull { it.timestampMillis == nextCandleTime } ?: return@forEach
                val correct = when (record.signal) {
                    "UP" -> next.close > next.open
                    "DOWN" -> next.close < next.open
                    else -> return@forEach
                }
                if (next.close != next.open) historyRepository.updateVerifiedOutcome(record.id, correct)
            }
        }
    }

    private fun chooseInstrument(now: Long): com.quotex.smartscan.model.Instrument {
        if (!ScanConfiguration.autoMode) return ScanConfiguration.selectedInstrument()
        val modePairs = ConfiguredPairs.forMode(ScanConfiguration.marketMode)
        if (now - lastInstrumentSwitchMillis >= AUTO_PAIR_INTERVAL_MS || currentAutoInstrumentId == null) {
            currentAutoInstrumentId = modePairs[(cycleCount++ % modePairs.size).toInt()].id
            lastInstrumentSwitchMillis = now
        }
        return ConfiguredPairs.find(currentAutoInstrumentId.orEmpty()) ?: modePairs.first()
    }

    private fun stopScanning(status: String, detail: String) {
        executor?.shutdownNow()
        executor = null
        scheduledKeys.clear()
        val reason = when {
            status.contains("NETWORK") || status.contains("CONNECTION LOST") -> ScanStopReason.NETWORK_LOST
            status.contains("PERMISSION") -> ScanStopReason.PERMISSION_REVOKED
            status.contains("DATA SOURCE") -> ScanStopReason.PROVIDER_MISSING
            else -> ScanStopReason.USER_REQUEST
        }
        val decision = ScanLifecyclePolicy.stopped(reason)
        ScanSessionState.update(false, decision.status.ifBlank { status }, decision.detail.ifBlank { detail }, null)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, ScanningService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Quotex SmartScan AI")
            .setContentText("User-started market scanning service")
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                    description = getString(R.string.notification_channel_description)
                }
            )
        }
    }

    /** Android 15+ applies a time budget to dataSync foreground services. Stop cleanly on timeout. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        executor?.shutdownNow()
        executor = null
        scheduledKeys.clear()
        ScanSessionState.update(
            scanning = false,
            status = "SERVICE TIME LIMIT",
            detail = "Android ended the foreground-service time budget. Restart from the app when permitted.",
            latestSignal = null
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf(startId)
    }

    override fun onDestroy() {
        executor?.shutdownNow()
        executor = null
        scheduledKeys.clear()
        if (ScanSessionState.snapshot().scanning) {
            val decision = ScanLifecyclePolicy.stopped(ScanStopReason.SERVICE_INTERRUPTED)
            ScanSessionState.update(false, decision.status, decision.detail, null)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.quotex.smartscan.action.START"
        const val ACTION_STOP = "com.quotex.smartscan.action.STOP"
        const val CHANNEL_ID = "smartscan_status"
        const val NOTIFICATION_ID = 2471
        const val MIN_FETCH_INTERVAL_MS = 5_000L
        const val AUTO_PAIR_INTERVAL_MS = 5_000L
        const val SIGNAL_WINDOW_MS = 7_000L
        const val DISPLAY_WINDOW_TOLERANCE_MS = 750L
    }
}
