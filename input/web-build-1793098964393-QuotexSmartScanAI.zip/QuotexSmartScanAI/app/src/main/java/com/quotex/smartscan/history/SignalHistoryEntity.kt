package com.quotex.smartscan.history

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "signal_history",
    indices = [Index(value = ["instrumentId", "marketMode", "candleTimestampMillis"], unique = true)]
)
data class SignalHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val instrumentId: String,
    val symbol: String,
    val marketMode: String,
    val timestampMillis: Long,
    val candleTimestampMillis: Long,
    val signal: String,
    val dataSource: String,
    val validationStatus: String,
    val reason: String,
    /** null until a next-candle outcome has been verified against authoritative data. */
    val verifiedOutcome: Boolean? = null,
    val outcomeVerified: Boolean = false
)
