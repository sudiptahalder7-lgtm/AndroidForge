package com.quotex.smartscan.data

import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.permissions.ScreenCaptureState

/**
 * Capture lifecycle is implemented separately with MediaProjection. This provider deliberately
 * does not manufacture candles from pixels. Until an OCR/vision adapter verifies symbol, mode,
 * timeframe, timestamp and OHLC extraction, it must return CHART NOT VERIFIED.
 */
class ScreenChartCaptureProvider : MarketDataProvider {
    override val name: String = "SCREEN_CAPTURE"

    override fun isConfigured(): Boolean = ScreenCaptureState.isActive

    override fun isModeSupported(mode: MarketMode): Boolean = ScreenCaptureState.isActive

    override fun isInstrumentAvailable(instrument: Instrument): Boolean = false

    override fun fetchCandles(
        instrument: Instrument,
        timeframeSeconds: Int,
        limit: Int
    ): MarketDataResult = MarketDataResult.Unavailable(
        if (ScreenCaptureState.isActive) "CHART NOT VERIFIED" else "SCREEN CAPTURE STOPPED"
    )
}
