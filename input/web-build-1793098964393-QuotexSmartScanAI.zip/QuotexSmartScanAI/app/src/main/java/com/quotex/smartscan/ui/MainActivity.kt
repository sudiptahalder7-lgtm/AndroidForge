package com.quotex.smartscan.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.quotex.smartscan.analysis.CandleAnalysisEngine
import com.quotex.smartscan.analysis.CandleValidationEngine
import com.quotex.smartscan.analysis.PerformanceEvaluator
import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.data.MarketDataRegistry
import com.quotex.smartscan.data.MockMarketDataProvider
import com.quotex.smartscan.history.SignalDatabase
import com.quotex.smartscan.history.SignalHistoryEntity
import com.quotex.smartscan.history.SignalHistoryRepository
import com.quotex.smartscan.model.CandleValidationResult
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.model.SignalDirection
import com.quotex.smartscan.permissions.ScreenCaptureService
import com.quotex.smartscan.permissions.ScreenCaptureState
import com.quotex.smartscan.overlay.FloatingOverlayService
import com.quotex.smartscan.service.ScanConfiguration
import com.quotex.smartscan.service.ScanSessionState
import com.quotex.smartscan.service.ScanStateSnapshot
import com.quotex.smartscan.service.ScanningService
import com.quotex.smartscan.ui.components.ConfidenceIndicator
import com.quotex.smartscan.ui.components.ConnectionStatus
import com.quotex.smartscan.ui.components.EmptyState
import com.quotex.smartscan.ui.components.ErrorState
import com.quotex.smartscan.ui.components.FloatingPanel
import com.quotex.smartscan.ui.components.HistoryRow
import com.quotex.smartscan.ui.components.LoadingState
import com.quotex.smartscan.ui.components.MarketModeSelector
import com.quotex.smartscan.ui.components.PairSelector
import com.quotex.smartscan.ui.components.PrimaryButton
import com.quotex.smartscan.ui.components.ScanningIndicator
import com.quotex.smartscan.ui.components.SecondaryButton
import com.quotex.smartscan.ui.components.SignalCard
import com.quotex.smartscan.ui.components.StatusChip
import com.quotex.smartscan.ui.design.AppColorTokens
import com.quotex.smartscan.ui.design.AppShapes
import com.quotex.smartscan.ui.design.AppSpacing
import com.quotex.smartscan.ui.design.AppTheme
import com.quotex.smartscan.ui.design.AppTypography
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private enum class Screen(val label: String) {
        DASHBOARD("HOME"), PAIRS("PAIRS"), LIVE("LIVE ANALYSIS"), OVERLAY("FLOATING"),
        HISTORY("HISTORY"), STATS("STATS"), PROVIDER("DATA SOURCE"),
        PERMISSIONS("PERMISSIONS"), SETTINGS("SETTINGS"), TEST("TEST MODE")
    }

    private var currentScreen = Screen.DASHBOARD
    private var historyMode = MarketMode.REAL
    private var root: LinearLayout? = null
    private var content: LinearLayout? = null
    private var screenScroll: ScrollView? = null
    private var currentSignalCard: SignalCard? = null
    private var currentStatusChip: StatusChip? = null
    private var currentScanningIndicator: ScanningIndicator? = null
    private var currentConfidenceIndicator: ConfidenceIndicator? = null
    private var dashboardScanStatus: TextView? = null
    private var historyContainer: LinearLayout? = null
    private val navButtons = mutableMapOf<Screen, Button>()
    private val historyCache = mutableMapOf<String, List<SignalHistoryEntity>>()
    private val testCache = mutableMapOf<String, String>()
    private var testCandidate: com.quotex.smartscan.model.AnalysisCandidate? = null
    private var testOutput: TextView? = null
    private var testEvidence: ConfidenceIndicator? = null
    private lateinit var historyRepository: SignalHistoryRepository

    private val scanListener: (ScanStateSnapshot) -> Unit = { state ->
        runOnUiThread {
            currentSignalCard?.show(state.latestSignal, state.status, state.detail)
            currentStatusChip?.updateLabel(state.status, statusTone(state.status, state.scanning))
            currentScanningIndicator?.setScanning(state.scanning)
            currentConfidenceIndicator?.update(state.latestSignal?.heuristicStrength ?: 0)
            dashboardScanStatus?.text = if (state.scanning) "SCANNING ACTIVE" else "SCANNING INACTIVE"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppTheme.apply(this)
        ConfiguredPairs.validateConfiguration()
        historyRepository = com.quotex.smartscan.history.SignalHistoryRepository(
            SignalDatabase.get(this).signalHistoryDao()
        )
        buildShell()
        ScanSessionState.addListener(scanListener)
        renderScreen()
    }

    override fun onDestroy() {
        ScanSessionState.removeListener(scanListener)
        super.onDestroy()
    }

    private fun buildShell() {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(AppColorTokens.Background)
        }
        root = shell
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(AppSpacing.Lg), dp(14), dp(AppSpacing.Lg), dp(12))
        }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "QS"
            textSize = 18f
            typeface = AppTypography.Bold
            gravity = Gravity.CENTER
            setTextColor(AppColorTokens.Background)
            background = AppShapes.rounded(AppColorTokens.Green, dp(12).toFloat())
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(43), dp(43)))
        val titleBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, 0, 0)
        }
        titleBlock.addView(TextView(this).apply {
            text = "QUOTEX SMARTSCAN AI"
            textSize = 16f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        titleBlock.addView(TextView(this).apply {
            text = "ONE-MINUTE MARKET ANALYSIS"
            textSize = 10.5f
            typeface = AppTypography.Medium
            setTextColor(AppColorTokens.TextSecondary)
            letterSpacing = 0.08f
        })
        brandRow.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        brandRow.addView(TextView(this).apply {
            text = "v1.0"
            textSize = 11f
            setTextColor(AppColorTokens.TextSecondary)
            background = AppShapes.rounded(AppColorTokens.SurfaceRaised, dp(100).toFloat())
            setPadding(dp(9), dp(6), dp(9), dp(6))
        })
        header.addView(brandRow)
        shell.addView(header)

        val navScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(AppSpacing.Lg), 0, dp(AppSpacing.Lg), dp(12))
        }
        val navRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Screen.entries.forEach { screen ->
            val button = SecondaryButton(this, screen.label) { navigate(screen) }
            button.textSize = 10.5f
            button.minHeight = dp(37)
            button.setPadding(dp(12), dp(5), dp(12), dp(5))
            if (screen == currentScreen) {
                button.setTextColor(AppColorTokens.Green)
                button.background = AppShapes.rounded(AppColorTokens.SurfaceRaised, dp(12).toFloat(), AppColorTokens.Green, dp(1))
            }
            navButtons[screen] = button
            navRow.addView(button, LinearLayout.LayoutParams(-2, dp(38)).apply { marginEnd = dp(7) })
        }
        navScroll.addView(navRow)
        shell.addView(navScroll)
        val line = View(this).apply { setBackgroundColor(AppColorTokens.Border) }
        shell.addView(line, LinearLayout.LayoutParams(-1, dp(1)))

        val scrolling = ScrollView(this).apply {
            fillViewport = true
            clipToPadding = false
            isVerticalScrollBarEnabled = false
        }
        screenScroll = scrolling
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(AppSpacing.Lg), dp(AppSpacing.Lg), dp(AppSpacing.Lg), dp(32))
        }
        content = body
        scrolling.addView(body)
        shell.addView(scrolling, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "INFORMATIONAL ANALYSIS ONLY · NO ORDERS · NO PROFIT GUARANTEE"
            textSize = 9.5f
            gravity = Gravity.CENTER
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(dp(12), dp(9), dp(12), dp(10))
            background = AppShapes.rounded(AppColorTokens.Surface, dp(10).toFloat())
        }
        shell.addView(footer, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(9)) })
        setContentView(shell)
    }

    private fun navigate(screen: Screen) {
        currentScreen = screen
        refreshNavigationButtons()
        currentSignalCard = null
        currentStatusChip = null
        currentScanningIndicator = null
        currentConfidenceIndicator = null
        dashboardScanStatus = null
        renderScreen()
    }

    private fun refreshNavigationButtons() {
        navButtons.forEach { (screen, button) ->
            val selected = screen == currentScreen
            button.setTextColor(if (selected) AppColorTokens.Green else AppColorTokens.TextPrimary)
            button.background = AppShapes.rounded(
                AppColorTokens.SurfaceRaised,
                dp(12).toFloat(),
                if (selected) AppColorTokens.Green else AppColorTokens.Border,
                dp(1)
            )
        }
    }

    private fun renderScreen() {
        val body = content ?: return
        body.removeAllViews()
        when (currentScreen) {
            Screen.DASHBOARD -> showDashboard(body)
            Screen.PAIRS -> showPairs(body)
            Screen.LIVE -> showLiveAnalysis(body)
            Screen.OVERLAY -> showOverlaySettings(body)
            Screen.HISTORY -> showHistory(body)
            Screen.STATS -> showStatistics(body)
            Screen.PROVIDER -> showProviderSettings(body)
            Screen.PERMISSIONS -> showPermissions(body)
            Screen.SETTINGS -> showSettings(body)
            Screen.TEST -> showTestMode(body)
        }
    }

    private fun showDashboard(body: LinearLayout) {
        heading(body, "Market overview", "A clean status view for your configured one-minute instruments.")
        val provider = MarketDataRegistry.provider
        val connected = provider.isConfigured()
        val connectionCard = card(body)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val statusText = columnText("DATA CONNECTION", if (connected) "Authorized provider configured" else "No live provider configured")
        row.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
        val connection = ConnectionStatus(this, if (connected) "CONFIGURED" else "DISCONNECTED", connected)
        row.addView(connection)
        connectionCard.addView(row)

        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metricTile(metrics, "20", "CONFIGURED PAIRS", "10 REAL + 10 OTC")
        metricTile(metrics, "1m", "TIMEFRAME", "Fixed interval")
        metricTile(metrics, ScanConfiguration.marketMode.name, "MODE", "Mode-separated")
        body.addView(metrics, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(14) })

        sectionTitle(body, "CURRENT SELECTION")
        val selectedCard = card(body)
        selectedCard.addView(TextView(this).apply {
            text = ScanConfiguration.selectedInstrument().displayName
            textSize = 22f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        selectedCard.addView(TextView(this).apply {
            text = "1-minute candles · ${if (ScanConfiguration.autoMode) "AUTO" else "MANUAL"} mode"
            textSize = 12f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(5), 0, dp(10))
        })
        selectedCard.addView(MarketModeSelector(this, ScanConfiguration.marketMode) { mode ->
            ScanConfiguration.selectMode(mode)
            renderScreen()
        })
        selectedCard.addView(SecondaryButton(this, "CHOOSE MARKET PAIR") { navigate(Screen.PAIRS) },
            LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })

        sectionTitle(body, "LATEST VALIDATED RESULT")
        val state = ScanSessionState.snapshot()
        val visibleStatusChip = StatusChip(this, state.status, statusTone(state.status, state.scanning))
        currentStatusChip = visibleStatusChip
        body.addView(visibleStatusChip, matchWidth().apply { bottomMargin = dp(10) })
        val signal = SignalCard(this).also { it.show(state.latestSignal, state.status, state.detail) }
        currentSignalCard = signal
        body.addView(signal, matchWidth())
        val evidence = ConfidenceIndicator(this).apply { update(state.latestSignal?.heuristicStrength ?: 0) }
        currentConfidenceIndicator = evidence
        body.addView(evidence, matchWidth().apply { topMargin = dp(12) })

        val animationCard = card(body)
        val labelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        labelRow.addView(TextView(this).apply {
            text = "SCANNER ACTIVITY"
            textSize = 12f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        dashboardScanStatus = TextView(this).apply {
            text = if (state.scanning) "SCANNING ACTIVE" else "SCANNING INACTIVE"
            textSize = 10.5f
            setTextColor(if (state.scanning) AppColorTokens.Green else AppColorTokens.TextSecondary)
        }
        labelRow.addView(dashboardScanStatus)
        animationCard.addView(labelRow)
        val scanningIndicator = ScanningIndicator(this).apply { setScanning(state.scanning) }
        currentScanningIndicator = scanningIndicator
        animationCard.addView(scanningIndicator, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(12) })
        animationCard.addView(TextView(this).apply {
            text = "Animation is visual only. It does not confirm that live candles were received or analyzed."
            textSize = 11f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(9), 0, 0)
        })

        body.addView(PrimaryButton(this, "START SCANNING") { startScanning() }, matchWidth().apply { topMargin = dp(14) })
        body.addView(SecondaryButton(this, "OPEN LIVE ANALYSIS") { navigate(Screen.LIVE) }, matchWidth().apply { topMargin = dp(8) })
        body.addView(SecondaryButton(this, "FLOATING SCANNER SETTINGS") { navigate(Screen.OVERLAY) }, matchWidth().apply { topMargin = dp(8) })
        body.addView(EmptyState("IMPORTANT", "NO REAL OR OTC PRICE FEED IS CURRENTLY CONFIGURED", "Signals remain NO TRADE until an authorized provider verifies the selected instrument and current candle."), matchWidth().apply { topMargin = dp(14) })
    }

    private fun showPairs(body: LinearLayout) {
        heading(body, "Market pair selector", "REAL and OTC instruments have independent IDs, histories and statistics.")
        body.addView(MarketModeSelector(this, ScanConfiguration.marketMode) { mode ->
            ScanConfiguration.selectMode(mode)
            renderScreen()
        }, matchWidth().apply { bottomMargin = dp(12) })
        val mode = ScanConfiguration.marketMode
        val provider = MarketDataRegistry.provider
        val availableCount = ConfiguredPairs.forMode(mode).count { provider.isInstrumentAvailable(it) && provider.isModeSupported(mode) && provider.isAuthoritativeForMode(mode) }
        body.addView(StatusChip(this, "$availableCount / 10 PAIRS VERIFIED AVAILABLE", if (availableCount > 0) StatusChip.Tone.GREEN else StatusChip.Tone.AMBER),
            matchWidth().apply { bottomMargin = dp(12) })
        body.addView(PairSelector(
            context = this,
            instruments = ConfiguredPairs.forMode(mode),
            selectedId = ScanConfiguration.selectedInstrumentId,
            availability = { instrument -> if (provider.isConfigured() && provider.isModeSupported(mode) && provider.isAuthoritativeForMode(mode) && provider.isInstrumentAvailable(instrument)) "AVAILABLE" else "PAIR UNAVAILABLE" },
            onSelect = { instrument ->
                ScanConfiguration.selectInstrument(instrument)
                Toast.makeText(this, "Selected ${instrument.displayName}", Toast.LENGTH_SHORT).show()
                navigate(Screen.LIVE)
            }
        ), matchWidth())
        body.addView(TextView(this).apply {
            text = "These 20 entries are configuration defaults, not confirmation that Quotex or a provider offers every instrument. No pair is substituted silently."
            textSize = 12f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(10), 0, 0)
        })
    }

    private fun showLiveAnalysis(body: LinearLayout) {
        heading(body, "Live analysis", "Signals are shown only after data, pair identity and timing checks pass.")
        val selected = ScanConfiguration.selectedInstrument()
        card(body).apply {
            addView(TextView(this@MainActivity).apply {
                text = selected.displayName
                textSize = 23f
                typeface = AppTypography.Bold
                setTextColor(AppColorTokens.TextPrimary)
            })
            addView(TextView(this@MainActivity).apply {
                text = "TIMEFRAME  1 MINUTE     MODE  ${selected.mode.name}"
                textSize = 11f
                setTextColor(AppColorTokens.TextSecondary)
                setPadding(0, dp(6), 0, dp(8))
            })
            addView(StatusChip(this@MainActivity, if (MarketDataRegistry.provider.isInstrumentAvailable(selected)) "PAIR SUPPORTED BY PROVIDER" else "PAIR UNAVAILABLE", if (MarketDataRegistry.provider.isInstrumentAvailable(selected)) StatusChip.Tone.GREEN else StatusChip.Tone.AMBER))
        }
        val state = ScanSessionState.snapshot()
        val visibleStatusChip = StatusChip(this, state.status, statusTone(state.status, state.scanning))
        currentStatusChip = visibleStatusChip
        body.addView(visibleStatusChip, matchWidth().apply { bottomMargin = dp(10) })
        val signalCard = SignalCard(this).also { it.show(state.latestSignal, state.status, state.detail) }
        currentSignalCard = signalCard
        body.addView(signalCard, matchWidth().apply { topMargin = dp(12) })
        val confidence = ConfidenceIndicator(this).apply { update(state.latestSignal?.heuristicStrength ?: 0) }
        currentConfidenceIndicator = confidence
        body.addView(confidence, matchWidth().apply { topMargin = dp(10) })
        val indicator = ScanningIndicator(this).apply { setScanning(state.scanning) }
        currentScanningIndicator = indicator
        body.addView(indicator, matchWidth().apply { height = dp(34); topMargin = dp(12) })
        body.addView(PrimaryButton(this, if (state.scanning) "SCANNING ACTIVE · OPEN STATUS" else "START MANUAL ANALYSIS") { startScanning() }, matchWidth().apply { topMargin = dp(12) })
        body.addView(SecondaryButton(this, "STOP SCANNING") { stopScanning() }, matchWidth().apply { topMargin = dp(8) })
        body.addView(SecondaryButton(this, "CHANGE PAIR") { navigate(Screen.PAIRS) }, matchWidth().apply { topMargin = dp(8) })
        body.addView(SecondaryButton(this, if (ScanConfiguration.autoMode) "SWITCH TO MANUAL MODE" else "SWITCH TO AUTO MODE") {
            ScanConfiguration.autoMode = !ScanConfiguration.autoMode
            renderScreen()
        }, matchWidth().apply { topMargin = dp(8) })
        body.addView(TextView(this).apply {
            text = "Candle timing: ${if (state.latestSignal == null) "not verified" else "${state.latestSignal.timestampMillis} (local display timestamp)"}. No countdown is shown unless a timestamped boundary can be validated."
            textSize = 11f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(12), 0, 0)
        })
    }

    private fun showOverlaySettings(body: LinearLayout) {
        heading(body, "Floating scanner", "Draggable launcher and compact panel. Android can revoke overlay access at any time.")
        val granted = Settings.canDrawOverlays(this)
        val panel = FloatingPanel(this)
        panel.addView(TextView(this).apply {
            text = "OVERLAY PERMISSION"
            textSize = 12f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        panel.addView(StatusChip(this, if (granted) "GRANTED" else "NOT GRANTED", if (granted) StatusChip.Tone.GREEN else StatusChip.Tone.AMBER),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        panel.addView(TextView(this).apply {
            text = "The overlay remains independent of the data feed. It must say DATA SOURCE NOT CONFIGURED when a live provider is missing."
            textSize = 12f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(10), 0, dp(4))
        })
        body.addView(panel, matchWidth())
        body.addView(PrimaryButton(this, if (granted) "OPEN FLOATING PANEL" else "ALLOW DISPLAY OVER OTHER APPS") {
            if (Settings.canDrawOverlays(this)) startOverlayService()
            else {
                val settingsIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivityForResult(settingsIntent, REQUEST_OVERLAY_PERMISSION)
            }
        }, matchWidth().apply { topMargin = dp(12) })
        body.addView(SecondaryButton(this, "CLOSE FLOATING PANEL") {
            startService(Intent(this, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_CLOSE))
        }, matchWidth().apply { topMargin = dp(8) })
        body.addView(EmptyState("OVERLAY LIMITATION", "ONE VISIBLE CHART AT A TIME", "A floating panel does not scan 20 charts simultaneously. Screen capture itself does not verify chart identity or OCR."), matchWidth().apply { topMargin = dp(14) })
    }

    private fun showHistory(body: LinearLayout) {
        heading(body, "Signal history", "Only validated analysis events are stored. Unresolved outcomes are excluded from performance calculations.")
        body.addView(MarketModeSelector(this, historyMode) { mode ->
            historyMode = mode
            renderScreen()
        }, matchWidth().apply { bottomMargin = dp(12) })
        val filter = TextView(this).apply {
            text = "Showing ${historyMode.name} records only"
            textSize = 12f
            setTextColor(AppColorTokens.TextSecondary)
        }
        body.addView(filter)
        body.addView(SecondaryButton(this, "REFRESH HISTORY") {
            historyCache.remove(historyMode.name)
            renderScreen()
        }, matchWidth().apply { topMargin = dp(8) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyContainer = list
        body.addView(list, matchWidth().apply { topMargin = dp(10) })
        val cached = historyCache[historyMode.name]
        if (cached != null) {
            populateHistory(list, cached)
        } else {
            list.addView(LoadingState(this, "Reading local Room history…"))
            val requestedMode = historyMode
            historyRepository.byMode(requestedMode.name, 200) { records ->
                historyCache[requestedMode.name] = records
                runOnUiThread {
                    if (currentScreen == Screen.HISTORY && historyMode == requestedMode) {
                        list.removeAllViews()
                        populateHistory(list, records)
                    }
                }
            }
        }
    }

    private fun populateHistory(container: LinearLayout, records: List<SignalHistoryEntity>) {
        container.removeAllViews()
        if (records.isEmpty()) {
            container.addView(EmptyState("NO HISTORY YET", "No ${historyMode.name} signals stored", "History appears only after a validated provider-backed analysis. Test Mode data is not written here."), matchWidth())
            return
        }
        val verified = records.count { it.outcomeVerified && it.verifiedOutcome != null }
        container.addView(TextView(this).apply {
            text = "${records.size} records · $verified verified outcomes"
            textSize = 11f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, 0, 0, dp(8))
        })
        records.forEach { record ->
            container.addView(HistoryRow(this, record), matchWidth().apply { bottomMargin = dp(8) })
        }
    }

    private fun showStatistics(body: LinearLayout) {
        heading(body, "Performance statistics", "Hit rate uses completed, verified next-candle outcomes only. Sample size is always shown.")
        val realCard = card(body)
        realCard.addView(TextView(this).apply {
            text = "REAL MARKET"
            textSize = 15f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        val realStats = TextView(this).apply {
            text = "Loading verified outcomes…"
            textSize = 13f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(8), 0, 0)
        }
        realCard.addView(realStats)
        val otcCard = card(body)
        otcCard.addView(TextView(this).apply {
            text = "OTC MARKET"
            textSize = 15f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        val otcStats = TextView(this).apply {
            text = "Loading verified outcomes…"
            textSize = 13f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(8), 0, 0)
        }
        otcCard.addView(otcStats)
        MarketMode.entries.forEach { mode ->
            historyRepository.completedByMode(mode.name) { completed ->
                val stats = PerformanceEvaluator.evaluate(completed, mode)
                runOnUiThread {
                    val label = when {
                        stats.evaluatedPredictions == 0 -> "No verified completed outcomes yet.\nEvaluated predictions: 0\nHit rate: not available"
                        else -> "Evaluated predictions: ${stats.evaluatedPredictions}\nCorrect: ${stats.correctPredictions}\nHit rate: ${"%.1f".format(Locale.US, stats.hitRatePercent)}%"
                    }
                    if (mode == MarketMode.REAL) realStats.text = label else otcStats.text = label
                }
            }
        }
        body.addView(EmptyState("NO FABRICATED ACCURACY", "Heuristic score is not a win rate", "The app does not convert its internal heuristic score into a claimed prediction accuracy."), matchWidth().apply { topMargin = dp(14) })
    }

    private fun showProviderSettings(body: LinearLayout) {
        heading(body, "Data provider settings", "The live adapter is deliberately unconfigured until a documented, authorized market-data client is supplied.")
        val provider = MarketDataRegistry.provider
        val info = card(body)
        info.addView(TextView(this).apply {
            text = provider.name
            textSize = 18f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        info.addView(StatusChip(this, if (provider.isConfigured()) "CONFIGURED" else "DATA SOURCE NOT CONFIGURED", if (provider.isConfigured()) StatusChip.Tone.GREEN else StatusChip.Tone.AMBER),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(9) })
        info.addView(TextView(this).apply {
            text = "No endpoint, private key, password or session token is bundled. Implement AuthorizedMarketDataClient using your provider's documented API and keep private credentials on a trusted backend."
            textSize = 13f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(12), 0, 0)
        })
        body.addView(info, matchWidth())
        sectionTitle(body, "OTC SAFETY")
        body.addView(EmptyState("OTC DATA REQUIRES SEPARATE AUTHORITY", "Ordinary forex prices are not Quotex OTC prices", "OTC is marked unavailable unless the authorized provider explicitly confirms OTC support for that instrument."), matchWidth())
        body.addView(SecondaryButton(this, "RECHECK PROVIDER STATUS") {
            renderScreen()
            Toast.makeText(this, if (MarketDataRegistry.provider.isConfigured()) "Provider client present" else "No provider configured", Toast.LENGTH_SHORT).show()
        }, matchWidth().apply { topMargin = dp(12) })
    }

    private fun showPermissions(body: LinearLayout) {
        heading(body, "Permissions and service status", "Only permissions needed for a visible feature are requested, and Android may interrupt services.")
        val overlayGranted = Settings.canDrawOverlays(this)
        permissionRow(body, "Display over other apps", if (overlayGranted) "GRANTED" else "NOT GRANTED", overlayGranted) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), REQUEST_OVERLAY_PERMISSION)
        }
        val captureActive = ScreenCaptureState.isActive
        permissionRow(body, "Screen capture", if (captureActive) "CAPTURING" else "STOPPED", captureActive) {
            if (!ScreenCaptureState.isActive) requestScreenCapture() else stopScreenCapture()
        }
        val notificationGranted = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        permissionRow(body, "Notifications", if (notificationGranted) "AVAILABLE" else "NOT GRANTED", notificationGranted) {
            if (Build.VERSION.SDK_INT >= 33 && !notificationGranted) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            else Toast.makeText(this, "Notification permission is available", Toast.LENGTH_SHORT).show()
        }
        val state = ScanSessionState.snapshot()
        permissionRow(body, "Background service", if (state.scanning) "ACTIVE" else "INACTIVE", state.scanning) {
            if (state.scanning) stopScanning() else startScanning()
        }
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryUnrestricted = powerManager.isIgnoringBatteryOptimizations(packageName)
        permissionRow(
            body,
            "Battery optimization",
            if (batteryUnrestricted) "UNRESTRICTED" else "MAY BE RESTRICTED",
            batteryUnrestricted
        ) {
            runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                .onFailure { Toast.makeText(this, "Open battery settings manually for this app", Toast.LENGTH_SHORT).show() }
        }
        body.addView(EmptyState("CAPTURE STATUS", if (captureActive) "SCREEN CAPTURE IS ACTIVE" else "SCREEN CAPTURE IS STOPPED", if (captureActive) "Frames are being captured, but chart OCR and instrument identity are not verified. Results remain CHART NOT VERIFIED." else "Starting capture requires the Android system consent dialog. It does not enable live chart analysis by itself."), matchWidth().apply { topMargin = dp(12) })
    }

    private fun showSettings(body: LinearLayout) {
        heading(body, "App settings", "Small set of explicit controls. REAL and OTC data remain separate regardless of scan mode.")
        val current = if (ScanConfiguration.autoMode) "AUTO" else "MANUAL"
        card(body).apply {
            addView(TextView(this@MainActivity).apply {
                text = "Scanning mode"
                textSize = 15f
                typeface = AppTypography.Bold
                setTextColor(AppColorTokens.TextPrimary)
            })
            addView(TextView(this@MainActivity).apply {
                text = "Current: $current"
                textSize = 12f
                setTextColor(AppColorTokens.TextSecondary)
                setPadding(0, dp(6), 0, dp(10))
            })
            addView(SecondaryButton(this@MainActivity, "SWITCH TO ${if (ScanConfiguration.autoMode) "MANUAL" else "AUTO"}") {
                ScanConfiguration.autoMode = !ScanConfiguration.autoMode
                renderScreen()
            }, matchWidth())
        }
        body.addView(SecondaryButton(this, "CLEAR LOCAL SIGNAL HISTORY") {
            AlertDialog.Builder(this)
                .setTitle("Clear local history?")
                .setMessage("This deletes stored signal-history rows from this device. It cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    historyRepository.clear {
                        historyCache.clear()
                        runOnUiThread {
                            Toast.makeText(this, "Local history cleared", Toast.LENGTH_SHORT).show()
                            renderScreen()
                        }
                    }
                }
                .show()
        }, matchWidth().apply { topMargin = dp(14) })
        body.addView(TextView(this).apply {
            text = "Build profile: min SDK 26 · target SDK 35 · 1-minute analysis only. No order placement is implemented."
            textSize = 12f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(14), 0, 0)
        })
    }

    private fun showTestMode(body: LinearLayout) {
        heading(body, "Test mode", "This screen uses deterministic synthetic candles only. The output is never labelled as a live signal and is not stored in normal history.")
        val selected = ScanConfiguration.selectedInstrument()
        val panel = FloatingPanel(this)
        panel.addView(TextView(this).apply {
            text = "SIMULATED TEST DATA"
            textSize = 14f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.Amber)
        })
        panel.addView(TextView(this).apply {
            text = "Selected test instrument: ${selected.displayName}"
            textSize = 13f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(7), 0, dp(9))
        })
        panel.addView(PrimaryButton(this, "RUN SYNTHETIC CANDLE TEST") {
            runSyntheticTest()
        }, matchWidth())
        testOutput = TextView(this).apply {
            text = testCache[selected.id] ?: "No test run yet."
            textSize = 13f
            setTextColor(AppColorTokens.TextPrimary)
            setPadding(0, dp(12), 0, dp(4))
        }
        panel.addView(testOutput)
        testEvidence = ConfidenceIndicator(this).apply { update(testCandidate?.heuristicStrength ?: 0) }
        panel.addView(testEvidence, matchWidth().apply { topMargin = dp(8) })
        body.addView(panel, matchWidth())
        body.addView(EmptyState("TEST DATA ONLY", "Never use this result as live evidence", "Test-mode candles are synthetic, do not reflect Quotex prices, and cannot be used to calculate hit rate."), matchWidth().apply { topMargin = dp(14) })
    }

    private fun runSyntheticTest() {
        val instrument = ScanConfiguration.selectedInstrument()
        val provider = MockMarketDataProvider()
        val result = provider.fetchCandles(instrument, 60, 30)
        val output = when (result) {
            is MarketDataResult.Success -> {
                when (val validation = CandleValidationEngine().validate(instrument, result.candles)) {
                    is CandleValidationResult.Invalid -> "SIMULATED TEST DATA\nValidation: ${validation.status}\nResult: NO TRADE\nReason: ${validation.reason}"
                    is CandleValidationResult.Valid -> {
                        testCandidate = CandleAnalysisEngine().analyze(validation.candles)
                        "SIMULATED TEST DATA\nValidation: PASS (synthetic candles)\nResult: ${testCandidate?.direction}\nReason: ${testCandidate?.reason}\nCandles: ${validation.candles.size}"
                    }
                }
            }
            is MarketDataResult.Unavailable -> "SIMULATED TEST DATA\nUnavailable: ${result.reason}"
            is MarketDataResult.Failure -> "SIMULATED TEST DATA\nFailure: ${result.reason}"
        }
        testCache[instrument.id] = output
        testOutput?.text = output
        testEvidence?.update(testCandidate?.heuristicStrength ?: 0)
        Toast.makeText(this, "Synthetic test completed. Not live data.", Toast.LENGTH_SHORT).show()
    }

    private fun startScanning() {
        val provider = MarketDataRegistry.provider
        val instrument = ScanConfiguration.selectedInstrument()
        if (!provider.isConfigured()) {
            ScanSessionState.update(false, "DATA SOURCE NOT CONFIGURED", "No authorized market-data client is installed. Live scanning was not started.", null)
            Toast.makeText(this, "Authorized market data is not configured", Toast.LENGTH_SHORT).show()
            navigate(Screen.LIVE)
            return
        }
        if (!provider.isModeSupported(instrument.mode) || !provider.isAuthoritativeForMode(instrument.mode) || !provider.isInstrumentAvailable(instrument)) {
            ScanSessionState.update(false, "PAIR UNAVAILABLE", "The provider has not verified ${instrument.displayName}.", null)
            navigate(Screen.LIVE)
            return
        }
        val intent = Intent(this, ScanningService::class.java).setAction(ScanningService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        ScanSessionState.update(true, "CONNECTING", "Starting authorized provider checks.", null)
        navigate(Screen.LIVE)
    }

    private fun stopScanning() {
        if (ScanSessionState.snapshot().scanning) {
            startService(Intent(this, ScanningService::class.java).setAction(ScanningService.ACTION_STOP))
        } else {
            ScanSessionState.update(false, "SCANNING STOPPED", "No active scan service was reported.", null)
        }
        renderScreen()
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission is required", Toast.LENGTH_SHORT).show()
            return
        }
        startService(Intent(this, FloatingOverlayService::class.java).setAction(FloatingOverlayService.ACTION_SHOW))
        Toast.makeText(this, "Floating panel requested", Toast.LENGTH_SHORT).show()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
    }

    private fun stopScreenCapture() {
        startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
        ScreenCaptureState.markStopped()
        Toast.makeText(this, "Screen capture stop requested", Toast.LENGTH_SHORT).show()
        renderScreen()
    }

    @Deprecated("Activity Result API would normally be used in new code; legacy result handling keeps this project dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_OVERLAY_PERMISSION -> {
                if (Settings.canDrawOverlays(this)) startOverlayService()
                else Toast.makeText(this, "Overlay permission was not granted", Toast.LENGTH_SHORT).show()
                renderScreen()
            }
            REQUEST_SCREEN_CAPTURE -> {
                if (resultCode == RESULT_OK && data != null) {
                    val serviceIntent = Intent(this, ScreenCaptureService::class.java)
                        .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                        .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                    Toast.makeText(this, "Screen capture permission granted", Toast.LENGTH_SHORT).show()
                } else {
                    ScreenCaptureState.markStopped()
                    Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
                }
                renderScreen()
            }
        }
    }

    private fun permissionRow(
        body: LinearLayout,
        title: String,
        status: String,
        granted: Boolean,
        action: () -> Unit
    ) {
        val box = card(body)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val label = TextView(this).apply {
            text = title
            textSize = 14f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        }
        row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(StatusChip(this, status, if (granted) StatusChip.Tone.GREEN else StatusChip.Tone.AMBER))
        box.addView(row)
        box.addView(SecondaryButton(this, if (granted) "OPEN / MANAGE" else "GRANT / START") { action() },
            LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(9) })
    }

    private fun heading(body: LinearLayout, title: String, subtitle: String) {
        body.addView(TextView(this).apply {
            text = title
            textSize = AppTypography.TitleSp
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        })
        body.addView(TextView(this).apply {
            text = subtitle
            textSize = AppTypography.BodySp
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(6), 0, dp(16))
        })
    }

    private fun sectionTitle(body: LinearLayout, title: String) {
        body.addView(TextView(this).apply {
            text = title
            textSize = 11f
            typeface = AppTypography.Bold
            letterSpacing = 0.07f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(14), 0, dp(8))
        })
    }

    private fun card(body: LinearLayout): LinearLayout {
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = AppShapes.rounded(AppColorTokens.Surface, dp(18).toFloat(), AppColorTokens.Border, dp(1))
        }
        body.addView(view, matchWidth().apply { bottomMargin = dp(10) })
        return view
    }

    private fun metricTile(parent: LinearLayout, big: String, title: String, subtitle: String) {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(12), dp(10), dp(12))
            background = AppShapes.rounded(AppColorTokens.Surface, dp(14).toFloat(), AppColorTokens.Border, dp(1))
        }
        tile.addView(TextView(this).apply {
            text = big
            textSize = 18f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.Green)
        })
        tile.addView(TextView(this).apply {
            text = title
            textSize = 9.5f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
            setPadding(0, dp(5), 0, 0)
        })
        tile.addView(TextView(this).apply {
            text = subtitle
            textSize = 9f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, dp(3), 0, 0)
        })
        parent.addView(tile, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
    }

    private fun columnText(label: String, value: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@MainActivity).apply {
            text = label
            textSize = 10f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextSecondary)
        })
        addView(TextView(this@MainActivity).apply {
            text = value
            textSize = 13f
            typeface = AppTypography.Medium
            setTextColor(AppColorTokens.TextPrimary)
            setPadding(0, dp(5), 0, 0)
        })
    }

    private fun statusTone(status: String, scanning: Boolean): StatusChip.Tone = when {
        status.contains("VALIDATED") -> StatusChip.Tone.GREEN
        status.contains("UP") -> StatusChip.Tone.GREEN
        status.contains("DOWN") -> StatusChip.Tone.RED
        status.contains("ERROR") || status.contains("LATE") || status.contains("UNAVAILABLE") || status.contains("NOT CONFIGURED") || status.contains("REVOKED") -> StatusChip.Tone.AMBER
        scanning -> StatusChip.Tone.GREEN
        else -> StatusChip.Tone.NEUTRAL
    }

    private fun matchWidth(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    companion object {
        private const val REQUEST_OVERLAY_PERMISSION = 7101
        private const val REQUEST_SCREEN_CAPTURE = 7102
        private const val REQUEST_NOTIFICATIONS = 7103
    }
}
