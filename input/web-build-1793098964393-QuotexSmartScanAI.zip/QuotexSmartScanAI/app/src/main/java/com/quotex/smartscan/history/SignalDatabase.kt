package com.quotex.smartscan.history

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SignalHistoryEntity::class], version = 1, exportSchema = false)
abstract class SignalDatabase : RoomDatabase() {
    abstract fun signalHistoryDao(): SignalHistoryDao

    companion object {
        @Volatile private var instance: SignalDatabase? = null

        fun get(context: Context): SignalDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                SignalDatabase::class.java,
                "smartscan_history.db"
            ).build().also { instance = it }
        }
    }
}
