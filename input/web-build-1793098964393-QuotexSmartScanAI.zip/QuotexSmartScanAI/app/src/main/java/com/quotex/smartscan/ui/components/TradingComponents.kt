package com.quotex.smartscan.ui.components

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.quotex.smartscan.history.SignalHistoryEntity
import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.model.SignalDirection
import com.quotex.smartscan.model.ValidatedSignal
import com.quotex.smartscan.ui.design.AppColorTokens
import com.quotex.smartscan.ui.design.AppShapes
import com.quotex.smartscan.ui.design.AppSpacing
import com.quotex.smartscan.ui.design.AppTypography
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

class PrimaryButton(context: Context, label: String, action: (View) -> Unit) : Button(context) {
    init {
        text = label
        isAllCaps = false
        textSize = AppTypography.ButtonSp
        typeface = AppTypography.Bold
        setTextColor(AppColorTokens.Background)
        background = AppShapes.rounded(AppColorTokens.Green, context.dp(13).toFloat())
        minHeight = context.dp(48)
        setPadding(context.dp(18), context.dp(10), context.dp(18), context.dp(10))
        setOnClickListener { action(it) }
    }
}

class SecondaryButton(context: Context, label: String, action: (View) -> Unit) : Button(context) {
    init {
        text = label
        isAllCaps = false
        textSize = AppTypography.ButtonSp
        typeface = AppTypography.Medium
        setTextColor(AppColorTokens.TextPrimary)
        background = AppShapes.rounded(AppColorTokens.SurfaceRaised, context.dp(13).toFloat(), AppColorTokens.Border, context.dp(1))
        minHeight = context.dp(44)
        setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
        setOnClickListener { action(it) }
    }
}

open class StatusChip(context: Context, label: String, tone: Tone = Tone.NEUTRAL) : TextView(context) {
    enum class Tone { GREEN, RED, AMBER, NEUTRAL }

    init {
        text = label
        textSize = AppTypography.CaptionSp
        typeface = AppTypography.Bold
        gravity = Gravity.CENTER
        setPadding(context.dp(10), context.dp(7), context.dp(10), context.dp(7))
        updateTone(tone)
    }

    fun updateLabel(label: String, tone: Tone = Tone.NEUTRAL) {
        text = label
        updateTone(tone)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    private fun updateTone(tone: Tone) {
        val foreground = when (tone) {
            Tone.GREEN -> AppColorTokens.Green
            Tone.RED -> AppColorTokens.Red
            Tone.AMBER -> AppColorTokens.Amber
            Tone.NEUTRAL -> AppColorTokens.TextSecondary
        }
        val background = when (tone) {
            Tone.GREEN -> 0x222BE6A2
            Tone.RED -> 0x22FF6576
            Tone.AMBER -> 0x22FFC66D
            Tone.NEUTRAL -> 0x229AA8B2
        }
        setTextColor(foreground)
        this.background = AppShapes.rounded(background, dp(100).toFloat())
    }
}

class ConnectionStatus(context: Context, label: String, connected: Boolean) : StatusChip(
    context, label, if (connected) StatusChip.Tone.GREEN else StatusChip.Tone.AMBER
)

class MarketModeSelector(
    context: Context,
    selected: MarketMode,
    onSelect: (MarketMode) -> Unit
) : LinearLayout(context) {
    init {
        orientation = HORIZONTAL
        val real = SecondaryButton(context, if (selected == MarketMode.REAL) "✓ REAL" else "REAL") { onSelect(MarketMode.REAL) }
        val otc = SecondaryButton(context, if (selected == MarketMode.OTC) "✓ OTC" else "OTC") { onSelect(MarketMode.OTC) }
        addView(real, LayoutParams(0, context.dp(44), 1f).apply { marginEnd = context.dp(AppSpacing.Sm) })
        addView(otc, LayoutParams(0, context.dp(44), 1f).apply { marginStart = context.dp(AppSpacing.Sm) })
    }
}

class PairSelector(
    context: Context,
    instruments: List<Instrument>,
    selectedId: String,
    availability: (Instrument) -> String,
    onSelect: (Instrument) -> Unit
) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        instruments.forEach { instrument ->
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(context.dp(12), context.dp(8), context.dp(8), context.dp(8))
                background = AppShapes.rounded(
                    if (instrument.id == selectedId) AppColorTokens.SurfaceRaised else AppColorTokens.Surface,
                    context.dp(13).toFloat(),
                    if (instrument.id == selectedId) AppColorTokens.Green else AppColorTokens.Border,
                    context.dp(1)
                )
            }
            val label = TextView(context).apply {
                text = instrument.displayName
                textSize = 14f
                typeface = AppTypography.Bold
                setTextColor(AppColorTokens.TextPrimary)
            }
            row.addView(label, LayoutParams(0, context.dp(34), 1f))
            val availabilityLabel = TextView(context).apply {
                text = availability(instrument)
                textSize = 10.5f
                typeface = AppTypography.Medium
                setTextColor(if (availability(instrument) == "AVAILABLE") AppColorTokens.Green else AppColorTokens.Amber)
                gravity = Gravity.CENTER
                setPadding(context.dp(7), context.dp(5), context.dp(7), context.dp(5))
                background = AppShapes.rounded(AppColorTokens.SurfaceRaised, context.dp(100).toFloat())
            }
            row.addView(availabilityLabel)
            row.setOnClickListener { onSelect(instrument) }
            addView(row, LayoutParams(-1, context.dp(52)).apply { bottomMargin = context.dp(7) })
        }
    }
}

class SignalCard(context: Context) : LinearLayout(context) {
    private val directionView = TextView(context)
    private val pairView = TextView(context)
    private val reasonView = TextView(context)
    private val statusView = StatusChip(context, "NO TRADE")

    init {
        orientation = VERTICAL
        setPadding(context.dp(16), context.dp(16), context.dp(16), context.dp(16))
        background = AppShapes.rounded(AppColorTokens.Surface, context.dp(18).toFloat(), AppColorTokens.Border, context.dp(1))
        val topRow = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        directionView.text = "NO TRADE"
        directionView.textSize = 24f
        directionView.typeface = AppTypography.Bold
        directionView.setTextColor(AppColorTokens.Neutral)
        topRow.addView(directionView, LayoutParams(0, -2, 1f))
        topRow.addView(statusView)
        addView(topRow)
        pairView.textSize = 13f
        pairView.setTextColor(AppColorTokens.TextSecondary)
        pairView.setPadding(0, context.dp(8), 0, context.dp(6))
        addView(pairView)
        reasonView.textSize = 13f
        reasonView.setTextColor(AppColorTokens.TextSecondary)
        addView(reasonView)
        show(null, "DATA SOURCE NOT CONFIGURED", "No validated signal is available.")
    }

    fun show(signal: ValidatedSignal?, status: String, reason: String) {
        val direction = signal?.direction ?: SignalDirection.NO_TRADE
        directionView.text = direction.name.replace('_', ' ')
        directionView.setTextColor(when (direction) {
            SignalDirection.UP -> AppColorTokens.Green
            SignalDirection.DOWN -> AppColorTokens.Red
            SignalDirection.NO_TRADE -> AppColorTokens.Neutral
        })
        pairView.text = signal?.let { "${it.instrument.displayName}  ·  ${formatTime(it.timestampMillis)}" } ?: "Pair and signal timestamp not verified"
        reasonView.text = reason
        val tone = when {
            direction == SignalDirection.UP -> StatusChip.Tone.GREEN
            direction == SignalDirection.DOWN -> StatusChip.Tone.RED
            status.contains("LATE") || status.contains("ERROR") || status.contains("UNAVAILABLE") -> StatusChip.Tone.AMBER
            else -> StatusChip.Tone.NEUTRAL
        }
        statusView.updateLabel(status, tone)
    }

    private fun formatTime(time: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(time))
}

class ConfidenceIndicator(context: Context) : LinearLayout(context) {
    private val labelView = TextView(context)
    private val progress = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal)

    init {
        orientation = VERTICAL
        labelView.textSize = 12f
        labelView.setTextColor(AppColorTokens.TextSecondary)
        addView(labelView, LayoutParams(-1, -2))
        progress.max = 100
        progress.progressTintList = android.content.res.ColorStateList.valueOf(AppColorTokens.Green)
        progress.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(AppColorTokens.Border)
        addView(progress, LayoutParams(-1, context.dp(6)).apply { topMargin = context.dp(7) })
        update(0)
    }

    fun update(heuristicStrength: Int) {
        val clamped = heuristicStrength.coerceIn(0, 100)
        val evidence = when {
            clamped >= 70 -> "Strong heuristic evidence"
            clamped >= 40 -> "Moderate heuristic evidence"
            clamped > 0 -> "Limited heuristic evidence"
            else -> "No directional evidence"
        }
        labelView.text = "$evidence · score $clamped/100 (not accuracy)"
        progress.progress = clamped
    }
}

class ScanningIndicator(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AppColorTokens.Green
        strokeWidth = context.dp(2).toFloat()
        style = Paint.Style.STROKE
        setShadowLayer(context.dp(7).toFloat(), 0f, 0f, AppColorTokens.Green)
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x332BE6A2
        style = Paint.Style.FILL
    }
    @Volatile private var scanning = false

    fun setScanning(active: Boolean) {
        scanning = active
        invalidate()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        canvas.drawRoundRect(0f, h * 0.35f, w, h * 0.65f, h * 0.15f, h * 0.15f, glowPaint)
        if (!scanning) {
            paint.clearShadowLayer()
            paint.color = AppColorTokens.Border
            canvas.drawLine(0f, h / 2f, w, h / 2f, paint)
            return
        }
        paint.color = AppColorTokens.Green
        paint.setShadowLayer(dp(7).toFloat(), 0f, 0f, AppColorTokens.Green)
        val phase = (SystemClock.uptimeMillis() % 1_600L) / 1_600f
        val triangle = if (phase < 0.5f) phase * 2f else (1f - phase) * 2f
        val y = h * (0.08f + 0.84f * triangle)
        canvas.drawLine(0f, y, w, y, paint)
        postInvalidateDelayed(16L)
    }
}

class FloatingPanel(context: Context) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        setPadding(context.dp(16), context.dp(16), context.dp(16), context.dp(16))
        background = AppShapes.rounded(AppColorTokens.SurfaceRaised, context.dp(20).toFloat(), AppColorTokens.Border, context.dp(1))
    }
}

class HistoryRow(context: Context, record: SignalHistoryEntity) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        setPadding(context.dp(12), context.dp(11), context.dp(12), context.dp(11))
        background = AppShapes.rounded(AppColorTokens.Surface, context.dp(13).toFloat(), AppColorTokens.Border, context.dp(1))
        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val pair = TextView(context).apply {
            text = record.symbol + if (record.marketMode == "OTC") " (OTC)" else ""
            textSize = 14f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
        }
        head.addView(pair, LayoutParams(0, -2, 1f))
        val signal = TextView(context).apply {
            text = record.signal
            textSize = 12f
            typeface = AppTypography.Bold
            setTextColor(when (record.signal) {
                "UP" -> AppColorTokens.Green
                "DOWN" -> AppColorTokens.Red
                else -> AppColorTokens.Neutral
            })
        }
        head.addView(signal)
        addView(head)
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(record.timestampMillis))
        addView(TextView(context).apply {
            text = "$date  ·  ${record.validationStatus}"
            textSize = 11f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, context.dp(5), 0, 0)
        })
        addView(TextView(context).apply {
            text = when {
                record.outcomeVerified && record.verifiedOutcome == true -> "Outcome: verified correct"
                record.outcomeVerified && record.verifiedOutcome == false -> "Outcome: verified incorrect"
                else -> "Outcome: unresolved (excluded from hit rate)"
            }
            textSize = 11f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(0, context.dp(4), 0, 0)
        })
    }
}

open class EmptyState(context: Context, title: String, description: String) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(context.dp(20), context.dp(24), context.dp(20), context.dp(24))
        background = AppShapes.rounded(AppColorTokens.Surface, context.dp(16).toFloat(), AppColorTokens.Border, context.dp(1))
        addView(TextView(context).apply {
            text = title
            textSize = 16f
            typeface = AppTypography.Bold
            setTextColor(AppColorTokens.TextPrimary)
            gravity = Gravity.CENTER
        })
        addView(TextView(context).apply {
            text = description
            textSize = 13f
            setTextColor(AppColorTokens.TextSecondary)
            gravity = Gravity.CENTER
            setPadding(0, context.dp(8), 0, 0)
        })
    }
}

class ErrorState(context: Context, title: String, description: String) : EmptyState(context, title, description)

class LoadingState(context: Context, label: String = "Loading…") : LinearLayout(context) {
    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(context.dp(12), context.dp(12), context.dp(12), context.dp(12))
        val spinner = ProgressBar(context)
        addView(spinner, LayoutParams(context.dp(28), context.dp(28)))
        addView(TextView(context).apply {
            text = label
            textSize = 13f
            setTextColor(AppColorTokens.TextSecondary)
            setPadding(context.dp(10), 0, 0, 0)
        })
    }
}
