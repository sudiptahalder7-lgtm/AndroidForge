package com.quotex.smartscan.ui.design

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Window

object AppColorTokens {
    const val Background = 0xFF080D12.toInt()
    const val Surface = 0xFF101820.toInt()
    const val SurfaceRaised = 0xFF16212B.toInt()
    const val Border = 0xFF293946.toInt()
    const val TextPrimary = 0xFFF1F6F8.toInt()
    const val TextSecondary = 0xFFA6B5BE.toInt()
    const val Green = 0xFF2BE6A2.toInt()
    const val Red = 0xFFFF6576.toInt()
    const val Neutral = 0xFF9AA8B2.toInt()
    const val Amber = 0xFFFFC66D.toInt()
}

object AppTypography {
    const val TitleSp = 24f
    const val HeadingSp = 18f
    const val BodySp = 14f
    const val CaptionSp = 12f
    const val ButtonSp = 13f
    val Bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
    val Medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    val Regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
}

object AppSpacing {
    const val Xs = 4
    const val Sm = 8
    const val Md = 12
    const val Lg = 16
    const val Xl = 22
    const val Xxl = 28
}

object AppShapes {
    const val CardRadiusDp = 18f
    const val ButtonRadiusDp = 13f
    const val ChipRadiusDp = 100f

    fun rounded(
        color: Int,
        radiusPx: Float,
        strokeColor: Int? = null,
        strokeWidthPx: Int = 0
    ): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokeColor != null && strokeWidthPx > 0) setStroke(strokeWidthPx, strokeColor)
    }
}

object AppTheme {
    fun apply(activity: Activity) {
        activity.window.statusBarColor = AppColorTokens.Background
        activity.window.navigationBarColor = AppColorTokens.Background
        activity.window.decorView.setBackgroundColor(AppColorTokens.Background)
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            activity.window.isNavigationBarContrastEnforced = false
            activity.window.isStatusBarContrastEnforced = false
        }
    }
}
