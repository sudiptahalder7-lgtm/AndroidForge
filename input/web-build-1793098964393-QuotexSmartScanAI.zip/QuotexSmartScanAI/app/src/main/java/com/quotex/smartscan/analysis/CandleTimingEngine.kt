package com.quotex.smartscan.analysis

import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.TimingAssessment

class CandleTimingEngine(
    private val targetLeadMillis: Long = 1_000L,
    private val maximumClockSkewMillis: Long = 2_000L
) {
    fun assess(candle: Candle, nowMillis: Long = System.currentTimeMillis()): TimingAssessment {
        val closeTime = candle.closeTimeMillis
        val target = closeTime - targetLeadMillis
        val minuteAligned = candle.timestampMillis % 60_000L == 0L
        val timestampPlausible = candle.timestampMillis > 0L &&
            nowMillis >= candle.timestampMillis - maximumClockSkewMillis
        val timeframeValid = candle.timeframeSeconds == 60
        val trusted = minuteAligned && timestampPlausible && timeframeValid
        val reason = when {
            !timeframeValid -> "Candle timeframe is not one minute."
            !minuteAligned -> "Candle boundary is not aligned to a verified UTC minute."
            !timestampPlausible -> "Candle timestamp is in the future or cannot be verified."
            else -> "Candle boundary is derived from a timestamped one-minute candle."
        }
        return TimingAssessment(
            trusted = trusted,
            candleOpenMillis = candle.timestampMillis,
            candleCloseMillis = closeTime,
            displayTargetMillis = target,
            remainingMillis = closeTime - nowMillis,
            reason = reason
        )
    }
}
