package com.quotex.smartscan.history

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class SignalHistoryRepository(private val dao: SignalHistoryDao) {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    fun save(record: SignalHistoryEntity, onComplete: ((Long) -> Unit)? = null) {
        executor.execute {
            val insertedId = dao.insert(record)
            onComplete?.invoke(insertedId)
        }
    }

    fun recent(limit: Int = 200, callback: (List<SignalHistoryEntity>) -> Unit) {
        executor.execute { callback(dao.listRecent(limit)) }
    }

    fun byMode(mode: String, limit: Int = 200, callback: (List<SignalHistoryEntity>) -> Unit) {
        executor.execute { callback(dao.listByMode(mode, limit)) }
    }

    fun completedByMode(mode: String, callback: (List<SignalHistoryEntity>) -> Unit) {
        executor.execute { callback(dao.completedByMode(mode)) }
    }

    fun pendingForInstrument(instrumentId: String, marketMode: String, callback: (List<SignalHistoryEntity>) -> Unit) {
        executor.execute { callback(dao.pendingForInstrument(instrumentId, marketMode)) }
    }

    fun updateVerifiedOutcome(recordId: Long, correct: Boolean) {
        executor.execute { dao.updateVerifiedOutcome(recordId, correct) }
    }

    fun clear(onComplete: (() -> Unit)? = null) {
        executor.execute {
            dao.deleteAll()
            onComplete?.invoke()
        }
    }
}
