package com.quotex.smartscan.service

/** Pure lifecycle decisions so an unexpected service exit cannot leave an in-app ACTIVE flag. */
enum class ScanStopReason { USER_REQUEST, SERVICE_INTERRUPTED, PROVIDER_MISSING, NETWORK_LOST, PERMISSION_REVOKED }

data class ScanLifecycleDecision(
    val scanningActive: Boolean,
    val status: String,
    val detail: String,
    val clearPreviousSignal: Boolean = true
)

object ScanLifecyclePolicy {
    fun stopped(reason: ScanStopReason): ScanLifecycleDecision = when (reason) {
        ScanStopReason.USER_REQUEST -> ScanLifecycleDecision(false, "SCANNING STOPPED", "Scanning was stopped by the user.")
        ScanStopReason.SERVICE_INTERRUPTED -> ScanLifecycleDecision(false, "SERVICE INTERRUPTED", "Android or the operating system stopped the scanning service. Restart is required.")
        ScanStopReason.PROVIDER_MISSING -> ScanLifecycleDecision(false, "DATA SOURCE NOT CONFIGURED", "No authorized market-data client is available.")
        ScanStopReason.NETWORK_LOST -> ScanLifecycleDecision(false, "CONNECTION LOST", "Network connectivity was lost. No directional signal is retained.")
        ScanStopReason.PERMISSION_REVOKED -> ScanLifecycleDecision(false, "PERMISSION REVOKED", "A required Android permission was revoked. Scanning is inactive.")
    }
}
