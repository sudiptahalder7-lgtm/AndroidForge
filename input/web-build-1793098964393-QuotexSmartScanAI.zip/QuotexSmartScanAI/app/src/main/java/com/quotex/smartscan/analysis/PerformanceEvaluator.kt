package com.quotex.smartscan.analysis

import com.quotex.smartscan.history.SignalHistoryEntity
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.model.PerformanceStats

object PerformanceEvaluator {
    fun evaluate(records: Collection<SignalHistoryEntity>, mode: MarketMode): PerformanceStats {
        val completed = records.filter {
            it.marketMode == mode.name && it.outcomeVerified && it.verifiedOutcome != null &&
                (it.signal == "UP" || it.signal == "DOWN")
        }
        val correct = completed.count { it.verifiedOutcome == true }
        val rate = if (completed.isEmpty()) null else correct * 100.0 / completed.size
        return PerformanceStats(
            mode = mode,
            evaluatedPredictions = completed.size,
            correctPredictions = correct,
            hitRatePercent = rate
        )
    }
}
