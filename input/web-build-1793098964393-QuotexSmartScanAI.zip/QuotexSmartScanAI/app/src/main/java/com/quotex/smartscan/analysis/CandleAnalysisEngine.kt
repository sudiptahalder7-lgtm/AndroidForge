package com.quotex.smartscan.analysis

import com.quotex.smartscan.model.AnalysisCandidate
import com.quotex.smartscan.model.AnalysisMetrics
import com.quotex.smartscan.model.Candle
import com.quotex.smartscan.model.SignalDirection
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Transparent, deterministic heuristics only. This is not a trained ML model and does not predict
 * an outcome with calibrated probability. The engine prefers NO TRADE when indicators conflict.
 */
class CandleAnalysisEngine(private val minimumCandles: Int = 10) {
    fun analyze(candles: List<Candle>): AnalysisCandidate {
        if (candles.size < minimumCandles) {
            return noTrade("Insufficient candles for analysis.")
        }

        val sample = candles.takeLast(20)
        val ranges = sample.map { it.high - it.low }
        val averageRange = ranges.average()
        if (!averageRange.isFinite() || averageRange <= 0.0) {
            return noTrade("Volatility cannot be estimated from the available candles.")
        }

        val last = sample.last()
        val lastRange = (last.high - last.low).coerceAtLeast(1e-12)
        val body = abs(last.close - last.open)
        val bodyRatio = (body / lastRange).coerceIn(0.0, 1.0)
        val upperWick = (last.high - maxOf(last.open, last.close)).coerceAtLeast(0.0) / lastRange
        val lowerWick = (minOf(last.open, last.close) - last.low).coerceAtLeast(0.0) / lastRange

        val half = sample.size / 2
        val olderAverage = sample.take(half).map { it.close }.average()
        val recentAverage = sample.drop(half).map { it.close }.average()
        val trendScore = (recentAverage - olderAverage) / averageRange
        val momentumReferenceIndex = (sample.lastIndex - 3).coerceAtLeast(0)
        val momentumScore = (last.close - sample[momentumReferenceIndex].close) / averageRange
        val meanPrice = sample.map { it.close }.average().coerceAtLeast(1e-12)
        val volatilityRatio = averageRange / meanPrice
        val metrics = AnalysisMetrics(
            bodyToRangeRatio = bodyRatio,
            upperWickRatio = upperWick.coerceIn(0.0, 1.0),
            lowerWickRatio = lowerWick.coerceIn(0.0, 1.0),
            momentumScore = momentumScore,
            trendScore = trendScore,
            averageRange = averageRange,
            supportEstimate = sample.minOf { it.low },
            resistanceEstimate = sample.maxOf { it.high },
            volatilityRatio = volatilityRatio
        )

        if (!volatilityRatio.isFinite() || volatilityRatio <= 0.0) {
            return AnalysisCandidate(SignalDirection.NO_TRADE, "Volatility reading is invalid.", 0, metrics)
        }
        if (abs(trendScore) < 0.20 && abs(momentumScore) < 0.45) {
            return AnalysisCandidate(SignalDirection.NO_TRADE, "Momentum and trend are too weak.", 0, metrics)
        }
        if (trendScore * momentumScore < 0.0 && abs(trendScore) > 0.15 && abs(momentumScore) > 0.25) {
            return AnalysisCandidate(SignalDirection.NO_TRADE, "Short-term momentum conflicts with the trend.", 0, metrics)
        }

        val directionValue = trendScore * 0.55 + momentumScore * 0.45
        val opposingWick = if (directionValue >= 0) upperWick else lowerWick
        val bodyContribution = if (last.close >= last.open) 1.0 else -1.0
        val score = directionValue + (bodyContribution * bodyRatio * 0.12) - (opposingWick * 0.18)

        if (abs(score) < 0.48) {
            return AnalysisCandidate(SignalDirection.NO_TRADE, "The directional evidence is not strong enough.", 0, metrics)
        }

        val strength = (abs(score) * 35.0).roundToInt().coerceIn(1, 100)
        return if (score > 0.0) {
            AnalysisCandidate(SignalDirection.UP, "Heuristic trend and momentum lean upward.", strength, metrics)
        } else {
            AnalysisCandidate(SignalDirection.DOWN, "Heuristic trend and momentum lean downward.", strength, metrics)
        }
    }

    private fun noTrade(reason: String) = AnalysisCandidate(SignalDirection.NO_TRADE, reason)
}
