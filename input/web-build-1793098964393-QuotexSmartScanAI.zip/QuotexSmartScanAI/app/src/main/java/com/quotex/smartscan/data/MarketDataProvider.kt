package com.quotex.smartscan.data

import com.quotex.smartscan.model.Instrument
import com.quotex.smartscan.model.MarketDataResult
import com.quotex.smartscan.model.MarketMode

/**
 * Adapter boundary for a documented and authorized provider. Implementations must normalize
 * timestamps to UTC epoch milliseconds and stamp receivedAtMillis at ingestion time.
 */
interface MarketDataProvider {
    val name: String
    fun isConfigured(): Boolean
    fun isModeSupported(mode: MarketMode): Boolean
    /** True only when this provider has explicitly confirmed the data is authoritative for this mode. */
    fun isAuthoritativeForMode(mode: MarketMode): Boolean = false
    fun isInstrumentAvailable(instrument: Instrument): Boolean
    fun fetchCandles(instrument: Instrument, timeframeSeconds: Int, limit: Int): MarketDataResult
}

/**
 * This interface is implemented by a licensed/authorized provider adapter in a deployment.
 * Keep private credentials on a trusted backend, not in this Android APK.
 */
interface AuthorizedMarketDataClient {
    fun supportsMode(mode: MarketMode): Boolean
    /** Must explicitly confirm source authority for this market mode. OTC must never inherit REAL authority. */
    fun isAuthoritativeForMode(mode: MarketMode): Boolean
    fun isInstrumentAvailable(instrument: Instrument): Boolean
    fun fetchCandles(instrument: Instrument, timeframeSeconds: Int, limit: Int): MarketDataResult
}

object MarketDataRegistry {
    @Volatile
    var provider: MarketDataProvider = AuthorizedApiProvider()
        private set

    fun installAuthorizedClient(client: AuthorizedMarketDataClient) {
        provider = AuthorizedApiProvider(client)
    }

    fun resetToUnconfigured() {
        provider = AuthorizedApiProvider()
    }
}
