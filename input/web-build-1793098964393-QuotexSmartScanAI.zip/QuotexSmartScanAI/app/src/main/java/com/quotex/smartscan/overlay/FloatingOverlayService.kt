package com.quotex.smartscan.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.quotex.smartscan.config.ConfiguredPairs
import com.quotex.smartscan.data.MarketDataRegistry
import com.quotex.smartscan.model.MarketMode
import com.quotex.smartscan.service.ScanConfiguration
import com.quotex.smartscan.service.ScanSessionState
import com.quotex.smartscan.service.ScanningService
import com.quotex.smartscan.ui.MainActivity

/** Small, draggable overlay. It never implies live scanning if the provider is not configured. */
class FloatingOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var launcher: TextView? = null
    private var panel: LinearLayout? = null
    private var launcherParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isExpanded = false
    private var statusText: TextView? = null

    private val permissionMonitor = object : Runnable {
        override fun run() {
            if (!Settings.canDrawOverlays(this@FloatingOverlayService)) {
                removeOverlayViews()
                ScanSessionState.update(false, "OVERLAY PERMISSION REVOKED", "Android overlay permission is no longer granted.", null)
                stopSelf()
                return
            }
            handler.postDelayed(this, 2_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CLOSE -> {
                removeOverlayViews()
                ScanSessionState.update(false, "OVERLAY INACTIVE", "Floating scanner was closed.", null)
                stopSelf(startId)
            }
            ACTION_SHOW, null -> {
                if (!Settings.canDrawOverlays(this)) {
                    ScanSessionState.update(false, "OVERLAY PERMISSION REQUIRED", "Grant Display over other apps permission in Android Settings.", null)
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                createOverlayViews()
                ScanSessionState.update(
                    scanning = ScanSessionState.snapshot().scanning,
                    status = if (MarketDataRegistry.provider.isConfigured()) ScanSessionState.snapshot().status else "DATA SOURCE NOT CONFIGURED",
                    detail = if (MarketDataRegistry.provider.isConfigured()) "Floating panel is open." else "Overlay is ready; live scanning is disabled until an authorized provider is configured.",
                    latestSignal = null
                )
                handler.removeCallbacks(permissionMonitor)
                handler.postDelayed(permissionMonitor, 2_000L)
            }
        }
        return START_NOT_STICKY
    }

    private fun createOverlayViews() {
        if (launcher != null) return
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val startX = dp(18)
        val startY = dp(180)
        launcherParams = WindowManager.LayoutParams(
            dp(58), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
        }
        val badge = TextView(this).apply {
            text = "QS"
            textSize = 17f
            setTextColor(Color.rgb(7, 18, 20))
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(43, 230, 162), 100f)
            elevation = dp(8).toFloat()
            contentDescription = "Open SmartScan floating panel"
        }
        installDragAndTap(badge)
        launcher = badge
        val launcherAdded = runCatching { windowManager.addView(badge, launcherParams); true }.getOrDefault(false)
        if (!launcherAdded) {
            launcher = null
            ScanSessionState.update(false, "OVERLAY ERROR", "Android could not create the floating launcher.", null)
            stopSelf()
            return
        }
        createPanel(type)
    }

    private fun createPanel(type: Int) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(12, 20, 27), 20f, Color.rgb(48, 67, 74), dp(1))
            elevation = dp(10).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SMARTSCAN AI"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(32), 1f))
        val close = smallButton("×") {
            isExpanded = false
            panel?.visibility = View.GONE
            launcher?.visibility = View.VISIBLE
        }
        header.addView(close, LinearLayout.LayoutParams(dp(34), dp(32)))
        root.addView(header)

        val pairLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(192, 205, 212))
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(pairLabel)
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        modeRow.addView(smallButton("REAL / OTC") {
            val next = if (ScanConfiguration.marketMode == MarketMode.REAL) MarketMode.OTC else MarketMode.REAL
            ScanConfiguration.selectMode(next)
            pairLabel.text = "${ScanConfiguration.selectedInstrument().displayName} · 1 MIN"
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
        modeRow.addView(smallButton("NEXT PAIR") {
            val pairs = ConfiguredPairs.forMode(ScanConfiguration.marketMode)
            val currentIndex = pairs.indexOfFirst { it.id == ScanConfiguration.selectedInstrumentId }.coerceAtLeast(0)
            ScanConfiguration.selectInstrument(pairs[(currentIndex + 1) % pairs.size])
            pairLabel.text = "${ScanConfiguration.selectedInstrument().displayName} · 1 MIN"
        }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
        root.addView(modeRow)
        pairLabel.text = "${ScanConfiguration.selectedInstrument().displayName} · 1 MIN"

        root.addView(smallButton(if (ScanConfiguration.autoMode) "MODE: AUTO" else "MODE: MANUAL") {
            ScanConfiguration.autoMode = !ScanConfiguration.autoMode
            (it as Button).text = if (ScanConfiguration.autoMode) "MODE: AUTO" else "MODE: MANUAL"
        }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(7) })

        root.addView(smallButton("START SCANNING") { startScanning() }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(8) })
        root.addView(smallButton("STOP SCANNING") { stopScanning() }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(6) })

        statusText = TextView(this).apply {
            text = "NO TRADE · DATA SOURCE NOT CONFIGURED"
            textSize = 12f
            setTextColor(Color.rgb(185, 197, 204))
            setPadding(0, dp(9), 0, dp(4))
        }
        root.addView(statusText)

        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        footer.addView(smallButton("MINIMIZE") {
            isExpanded = false
            panel?.visibility = View.GONE
            launcher?.visibility = View.VISIBLE
        }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginEnd = dp(4) })
        footer.addView(smallButton("CLOSE OVERLAY") {
            removeOverlayViews()
            handler.removeCallbacks(permissionMonitor)
            ScanSessionState.update(false, "OVERLAY INACTIVE", "Floating panel was closed by the user.", null)
            stopSelf()
        }, LinearLayout.LayoutParams(0, dp(34), 1f).apply { marginStart = dp(4) })
        root.addView(footer)

        panelParams = WindowManager.LayoutParams(
            dp(278), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(82)
            y = dp(180)
        }
        root.visibility = View.GONE
        panel = root
        runCatching { windowManager.addView(root, panelParams) }.onFailure {
            panel = null
            ScanSessionState.update(false, "OVERLAY ERROR", "Android could not create the floating panel.", null)
        }
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (statusText == null) return
                val state = ScanSessionState.snapshot()
                statusText?.text = "${state.status}\n${state.detail}"
                if (launcher != null) handler.postDelayed(this, 1_000L)
            }
        }, 1_000L)
    }

    private fun installDragAndTap(view: View) {
        var downX = 0f
        var downY = 0f
        var initialX = 0
        var initialY = 0
        var moved = false
        view.setOnTouchListener { _, event ->
            val params = launcherParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    initialX = params.x
                    initialY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    params.x = (initialX + dx).coerceAtLeast(0)
                    params.y = (initialY + dy).coerceAtLeast(0)
                    runCatching { windowManager.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> true
            }
        }
    }

    private fun togglePanel() {
        isExpanded = !isExpanded
        panel?.visibility = if (isExpanded) View.VISIBLE else View.GONE
        launcher?.visibility = if (isExpanded) View.GONE else View.VISIBLE
    }

    private fun startScanning() {
        if (!MarketDataRegistry.provider.isConfigured()) {
            ScanSessionState.update(false, "DATA SOURCE NOT CONFIGURED", "Live scanning is disabled. Add an authorized provider adapter first.", null)
            Toast.makeText(this, "Authorized market data is not configured", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, ScanningService::class.java).setAction(ScanningService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    private fun stopScanning() {
        if (ScanSessionState.snapshot().scanning) {
            runCatching { startService(Intent(this, ScanningService::class.java).setAction(ScanningService.ACTION_STOP)) }
        } else {
            ScanSessionState.update(false, "SCANNING STOPPED", "No active scan service was reported.", null)
        }
    }

    private fun smallButton(textValue: String, click: (View) -> Unit): Button = Button(this).apply {
        text = textValue
        textSize = 11f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(28, 43, 51), 12f, Color.rgb(57, 81, 89), dp(1))
        setOnClickListener { click(it) }
    }

    private fun rounded(color: Int, radiusDp: Float, strokeColor: Int? = null, strokeWidth: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp.toInt()).toFloat()
            if (strokeColor != null && strokeWidth > 0) setStroke(strokeWidth, strokeColor)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    private fun removeOverlayViews() {
        launcher?.let { runCatching { windowManager.removeView(it) } }
        panel?.let { runCatching { windowManager.removeView(it) } }
        launcher = null
        panel = null
        statusText = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(permissionMonitor)
        removeOverlayViews()
        if (ScanSessionState.snapshot().status.startsWith("OVERLAY")) {
            ScanSessionState.update(false, "OVERLAY INACTIVE", "Floating panel service is no longer running.", null)
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_SHOW = "com.quotex.smartscan.overlay.SHOW"
        const val ACTION_CLOSE = "com.quotex.smartscan.overlay.CLOSE"
    }
}
