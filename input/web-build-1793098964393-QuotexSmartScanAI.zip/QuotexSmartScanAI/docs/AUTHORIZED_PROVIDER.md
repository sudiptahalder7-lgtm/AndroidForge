# Adding an authorized market-data adapter

The app intentionally ships without a live endpoint. Implement `AuthorizedMarketDataClient` only for a source you are permitted to use, and follow that source's official API documentation and terms. Do not scrape protected Quotex endpoints or put credentials in the APK.

## Contract checklist

1. `supportsMode(mode)` must describe actual provider support.
2. `isAuthoritativeForMode(mode)` must return true only when the provider's data is authoritative for that specific mode. Never return true for OTC just because REAL forex data exists.
3. `isInstrumentAvailable(instrument)` must check the exact requested instrument and mode. Never silently substitute a symbol.
4. `fetchCandles` must return normalized one-minute candles with UTC epoch milliseconds, positive valid OHLC values, and `receivedAtMillis` set when the response enters the app. Include `volume` only if provided by the source.
5. Use `DataSourceKind.AUTHORIZED_API` only for actual authorized-provider responses. Never label mocked or screen-captured data as an API response.
6. Bound request timeouts and rate limits in the adapter. Handle authentication on a trusted backend where practical. Never log API secrets, passwords, cookies, or session tokens.
7. Confirm how the provider timestamps candle opens/closes and what clock it uses. If this cannot be trusted, leave timing untrusted and return no directional signal.

## Adapter skeleton

```kotlin
class MyAuthorizedMarketDataClient : AuthorizedMarketDataClient {
    override fun supportsMode(mode: MarketMode): Boolean = when (mode) {
        MarketMode.REAL -> /* confirmed by official provider docs */ false
        MarketMode.OTC -> /* separate explicit OTC support check */ false
    }

    override fun isAuthoritativeForMode(mode: MarketMode): Boolean = when (mode) {
        MarketMode.REAL -> /* confirmed REAL authority */ false
        MarketMode.OTC -> /* confirmed OTC authority; do not inherit REAL authority */ false
    }

    override fun isInstrumentAvailable(instrument: Instrument): Boolean {
        // Verify this exact symbol and market mode through the authorized provider.
        return false
    }

    override fun fetchCandles(
        instrument: Instrument,
        timeframeSeconds: Int,
        limit: Int
    ): MarketDataResult {
        // Implement documented HTTP/API access, normalized parsing, rate limits, and errors.
        // Return Unavailable until the exact pair and market mode are verified.
        return MarketDataResult.Unavailable("Provider adapter not implemented")
    }
}
```

Install the verified client at application startup with `MarketDataRegistry.installAuthorizedClient(client)`. The default registry remains intentionally unconfigured. This sample skeleton does not make the app live-ready; it must be implemented and audited against the actual provider contract.
