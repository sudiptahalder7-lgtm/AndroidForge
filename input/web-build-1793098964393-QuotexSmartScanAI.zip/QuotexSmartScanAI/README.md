# Quotex SmartScan AI (Android/Kotlin)

A dark, Android-first market-analysis application scaffold built around strict data validation and a fail-closed `NO TRADE` policy. It does **not** place orders.

## Current implementation status

### Implemented in source

- Native Android UI with reusable dark design tokens, cards, status chips, navigation, responsive scroll layouts, pair selector, live-analysis view, floating scanner controls, history, statistics, provider settings, permission status, app settings and explicit test mode.
- Exactly 10 configured REAL pairs and exactly 10 configured OTC pairs. REAL/OTC use separate instrument IDs and mode-specific storage/reporting.
- `MarketDataProvider`, `AuthorizedApiProvider`, `ScreenChartCaptureProvider`, and a test-only `MockMarketDataProvider`.
- OHLC, identity, timeframe, receive-time freshness and timestamp validation.
- Transparent heuristic analysis for candle body/range, wick ratios, short-term momentum/trend, support/resistance estimates and volatility. It is not a trained ML model or calibrated probability.
- Timing gate that schedules a potential signal for approximately one second before a timestamp-derived candle boundary and rejects missed windows.
- Room-backed local signal history and statistics that exclude unresolved outcomes. Verified outcomes are resolved only from later closed candles in the matching instrument/mode, when the provider asserts authority for that market mode.
- User-consented Android MediaProjection frame capture and a draggable floating overlay. Screen pixels are captured, but chart OCR/instrument identity extraction is not implemented; capture alone always remains unverified.
- Foreground scanning service with visible notification, stop action, data-source checks, per-instrument fetch interval, AUTO pair rotation, conservative fallback statuses, and an Android 15+ `dataSync` timeout callback. Permission status includes overlay, MediaProjection, notifications, service state, and battery optimization settings.
- Unit tests for pair counts/separation, OHLC and freshness validation, timestamp faults, late/no-trade validation and performance calculations.

### Not live-ready until an authorized adapter is added

No concrete live market-data endpoint is bundled. The API provider is deliberately unconfigured, because this project does not assume an API URL or scrape protected Quotex endpoints. Until an implementation of `AuthorizedMarketDataClient` is installed, live scanning will remain disabled and the UI will report `DATA SOURCE NOT CONFIGURED` / `PAIR UNAVAILABLE` instead of inventing prices or signals.

OTC prices are especially strict: an ordinary forex feed is not accepted as authoritative OTC data. The authorized client must explicitly assert support and authority for each market mode and pair; the OTC authority check is a separate method from REAL-mode support. The configured lists are not confirmation that Quotex or a third-party provider offers those instruments.

Other integration work still required for production use:

- Implement and audit an authorized data client against its official API documentation.
- Supply a reliable source/server clock and verify provider candle-boundary semantics. The app refuses late or unverifiable timing.
- Implement OCR/chart parsing if screen-capture analysis is needed. Until then, the capture service only captures frames and reports that chart identity is unverified.
- Test foreground-service behavior, Android 15+ timeout, battery optimization, and overlay permission revocation on target devices. Android may stop services or restrict their run time.
- Run a full Android Studio build, tests and on-device QA before distributing an APK.

## Configured instruments

REAL:

`GBP/USD`, `USD/JPY`, `USD/CHF`, `AUD/USD`, `USD/CAD`, `NZD/USD`, `EUR/GBP`, `EUR/JPY`, `EUR/AUD`, `GBP/JPY`

OTC: the same 10 display symbols marked `(OTC)`, with independent OTC IDs.

No other instruments are added to the default lists.

## Build requirements

- Android Studio with Android SDK Platform 36 installed
- JDK 17
- Internet access on the build machine for Maven/Gradle dependency downloads
- Android device/emulator with API 26 or higher for installation

This project uses Android Gradle Plugin `8.13.2`, Gradle `8.13`, Kotlin `2.2.21`, Room `2.8.5`, `compileSdk 36`, `targetSdk 35`, and `minSdk 26`.

### Build a debug APK

From the project root:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

Output path after a successful build:

```text
app/build/outputs/apk/debug/app-debug.apk
```

### Run unit tests

```bash
./gradlew testDebugUnitTest
```

The `gradlew` / `gradlew.bat` bootstrap scripts use the official Gradle 8.13 distribution when it is not already present in the local Gradle cache. They do not bundle a Gradle wrapper JAR.

## Android permissions

- **Draw over other apps:** required only for the floating overlay.
- **MediaProjection consent:** required for screen capture. The user must approve each capture session.
- **Notifications / foreground service:** used to show user-visible status while scanning or capturing.
- **Internet:** declared for a future authorized provider integration.

Do not embed private API secrets, passwords, cookies or account tokens into this APK. Prefer a backend that holds provider secrets and returns only permitted market data.

## Test mode

The in-app Test Mode uses deterministic synthetic candles and labels all results `SIMULATED TEST DATA`. It does not write test signals to normal history, is not connected to Quotex, and must not be used to infer live accuracy.

## Quality note

The pure Kotlin market-model, pair-configuration and signal-analysis modules were compiled with the Kotlin compiler in the authoring environment. A local harness ran 22 pure-logic test methods successfully (pair configuration, OHLC and freshness validation, timing/signal fail-closed rules, REAL/OTC performance separation, and lifecycle decisions). This harness does not replace the real Gradle/JUnit run. A full Android Gradle build and Android unit-test run were **not** performed here because this environment does not contain an Android SDK/`android.jar` and cannot download Gradle/dependencies. Treat the Android project as source-complete for review, not as a verified APK. Build and test it in Android Studio before use.
