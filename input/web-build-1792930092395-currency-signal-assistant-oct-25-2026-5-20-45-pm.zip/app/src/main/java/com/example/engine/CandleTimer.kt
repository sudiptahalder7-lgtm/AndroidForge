package com.example.engine

import android.os.SystemClock
import com.example.cv.FrameAnalysisResult
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

interface CandleTimerListener {
    fun onSecondsRemainingChanged(secondsRemaining: Int, isFinalSevenSeconds: Boolean, timingQuality: String)
    fun onFinalSevenSecondsWindowStarted(candleTimestampMs: Long)
    fun onTriggerSignalGeneration(candleTimestampMs: Long, secondsRemaining: Int)
    fun onCandleClosed(candleTimestampMs: Long)
}

class CandleTimer(
    var timingToleranceSeconds: Float = 1.5f,
    private val listener: CandleTimerListener
) {
    @Volatile var isRunning: Boolean = false
        private set

    // Monotonic clock anchors
    private val anchorRealtimeMs = AtomicLong(0L)
    private val anchorSecondsRemaining = AtomicLong(60L)
    private val lastObservedSyncMs = AtomicLong(0L)
    private val timingDriftMs = AtomicLong(0L)

    private val signalTriggeredForCandle = AtomicBoolean(false)
    private val finalWindowTriggeredForCandle = AtomicBoolean(false)
    private var lastEmittedCandleMinute: Long = 0L

    private fun getElapsedRealtime(): Long {
        return try {
            SystemClock.elapsedRealtime()
        } catch (e: Throwable) {
            System.currentTimeMillis()
        }
    }

    fun start() {
        isRunning = true
        resetSync()
    }

    fun stop() {
        isRunning = false
    }

    fun resetSync() {
        val now = System.currentTimeMillis()
        val secondOfMinute = ((now / 1000L) % 60).toInt()
        val remaining = 60 - secondOfMinute

        anchorRealtimeMs.set(getElapsedRealtime())
        anchorSecondsRemaining.set(remaining.toLong())
        lastObservedSyncMs.set(now)
        timingDriftMs.set(0L)
        signalTriggeredForCandle.set(false)
        finalWindowTriggeredForCandle.set(false)
    }

    /**
     * Called whenever a frame is processed from screen capture or when a timer tick occurs.
     */
    fun onFrameAnalyzed(frameResult: FrameAnalysisResult) {
        if (!isRunning) return

        val nowRealtime = getElapsedRealtime()
        val wallNow = System.currentTimeMillis()

        // 1. If screen detected an on-screen timer countdown, calibrate monotonic anchor
        val detected = frameResult.detectedSecondsRemaining
        if (detected != null && detected in 0..59) {
            val prevEstimated = calculateSecondsRemaining(nowRealtime)
            val diff = abs(prevEstimated - detected)

            // If drift detected, smoothly re-anchor
            anchorRealtimeMs.set(nowRealtime)
            anchorSecondsRemaining.set(detected.toLong())
            lastObservedSyncMs.set(wallNow)
            timingDriftMs.set((diff * 1000L).toLong())
        }

        val secondsRemaining = calculateSecondsRemaining(nowRealtime)
        val currentCandleMinute = (wallNow / 60000L) * 60000L

        // Check if candle boundary rolled over
        if (currentCandleMinute != lastEmittedCandleMinute) {
            if (lastEmittedCandleMinute != 0L) {
                listener.onCandleClosed(lastEmittedCandleMinute)
            }
            lastEmittedCandleMinute = currentCandleMinute
            signalTriggeredForCandle.set(false)
            finalWindowTriggeredForCandle.set(false)
        }

        val isFinalSevenSeconds = secondsRemaining in 1..7

        // Evaluate timing quality
        val timeSinceSync = wallNow - lastObservedSyncMs.get()
        val driftSeconds = timingDriftMs.get() / 1000f
        val timingQuality = when {
            driftSeconds > timingToleranceSeconds -> "Drift Detected (${String.format("%.1fs", driftSeconds)})"
            timeSinceSync > 120000L -> "Searching Countdown (Clock Synced)"
            frameResult.isScreenObscured -> "Screen Obscured"
            else -> "Synced"
        }

        listener.onSecondsRemainingChanged(secondsRemaining, isFinalSevenSeconds, timingQuality)

        // 2. Begin analysis during final 7 seconds (T-7s to T-1s)
        if (isFinalSevenSeconds && !finalWindowTriggeredForCandle.getAndSet(true)) {
            listener.onFinalSevenSecondsWindowStarted(currentCandleMinute)
        }

        // 3. Target displaying the signal approximately one second before next candle begins (T-1s)
        if (secondsRemaining <= 1 && !signalTriggeredForCandle.getAndSet(true)) {
            listener.onTriggerSignalGeneration(currentCandleMinute, secondsRemaining)
        }
    }

    /**
     * Monotonic countdown calculation to eliminate phone clock changes/jitter.
     */
    fun calculateSecondsRemaining(nowRealtime: Long = getElapsedRealtime()): Int {
        val elapsedMs = nowRealtime - anchorRealtimeMs.get()
        val elapsedSeconds = (elapsedMs / 1000L).toInt()
        val remaining = (anchorSecondsRemaining.get() - elapsedSeconds).toInt()

        return if (remaining <= 0) {
            // Rolled over to new 60s candle
            val modulus = ((-remaining) % 60)
            60 - modulus
        } else {
            remaining % 61
        }
    }

    /**
     * Checks if timing is within acceptable tolerance for generating trading signals.
     */
    fun isTimingReliable(): Boolean {
        val driftSeconds = timingDriftMs.get() / 1000f
        return driftSeconds <= timingToleranceSeconds
    }
}
