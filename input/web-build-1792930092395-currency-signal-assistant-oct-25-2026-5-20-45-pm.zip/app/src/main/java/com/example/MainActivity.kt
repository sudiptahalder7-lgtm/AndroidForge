package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.service.FloatingOverlayService
import com.example.service.ScreenCaptureService
import com.example.ui.MainViewModel
import com.example.ui.screens.CurrencySelectorScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SignalHistoryScreen
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

enum class NavDestination {
    DASHBOARD,
    CURRENCIES,
    HISTORY,
    PERMISSIONS,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val context = LocalContext.current
    val app = context.applicationContext as CurrencySignalApp
    val stateManager = app.stateManager

    var currentScreen by remember { mutableStateOf(NavDestination.DASHBOARD) }

    // Dynamic states
    val instrument by viewModel.selectedInstrument.collectAsState()
    val observationState by viewModel.observationState.collectAsState()
    val latestSignal by viewModel.latestSignal.collectAsState()
    val latestFrame by viewModel.latestFrameBitmap.collectAsState()

    val filteredInstruments by viewModel.filteredInstruments.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()

    val signalHistory by viewModel.signalHistory.collectAsState()
    val paperTestSummary by viewModel.paperTestSummary.collectAsState()

    val samplingFps by viewModel.samplingFps.collectAsState()
    val timingTolerance by viewModel.timingTolerance.collectAsState()
    val isPaperTestingEnabled by viewModel.isPaperTestingEnabled.collectAsState()

    var isOverlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var isNotificationGranted by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    // Refresh permission states on resume
    LaunchedEffect(currentScreen) {
        isOverlayGranted = Settings.canDrawOverlays(context)
        isNotificationGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    // MediaProjection Activity Result Launcher
    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val data = result.data!!
            stateManager.mediaProjectionResultCode = result.resultCode
            stateManager.mediaProjectionData = data
            ScreenCaptureService.startService(context, result.resultCode, data)

            // If overlay permitted, launch floating overlay as well
            if (Settings.canDrawOverlays(context)) {
                FloatingOverlayService.start(context)
            }
            Toast.makeText(context, "Quotex screen observation started", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "MediaProjection permission was cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    // Notification Permission Launcher (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isNotificationGranted = granted
    }

    // Function to trigger MediaProjection prompt
    val startMediaProjectionFlow = {
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    // Custom back handler
    if (currentScreen != NavDestination.DASHBOARD) {
        BackHandler {
            currentScreen = NavDestination.DASHBOARD
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                contentColor = AccentCyan
            ) {
                NavigationBarItem(
                    selected = currentScreen == NavDestination.DASHBOARD,
                    onClick = { currentScreen = NavDestination.DASHBOARD },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentCyan,
                        selectedTextColor = AccentCyan,
                        indicatorColor = DarkBackground,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == NavDestination.CURRENCIES,
                    onClick = { currentScreen = NavDestination.CURRENCIES },
                    icon = { Icon(Icons.Default.CurrencyExchange, contentDescription = "Pairs") },
                    label = { Text("Pairs", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentCyan,
                        selectedTextColor = AccentCyan,
                        indicatorColor = DarkBackground,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == NavDestination.HISTORY,
                    onClick = { currentScreen = NavDestination.HISTORY },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("Signals", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentCyan,
                        selectedTextColor = AccentCyan,
                        indicatorColor = DarkBackground,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == NavDestination.PERMISSIONS,
                    onClick = { currentScreen = NavDestination.PERMISSIONS },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Health") },
                    label = { Text("Health", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentCyan,
                        selectedTextColor = AccentCyan,
                        indicatorColor = DarkBackground,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentScreen == NavDestination.SETTINGS,
                    onClick = { currentScreen = NavDestination.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AccentCyan,
                        selectedTextColor = AccentCyan,
                        indicatorColor = DarkBackground,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                NavDestination.DASHBOARD -> {
                    DashboardScreen(
                        instrument = instrument,
                        observationState = observationState,
                        latestSignal = latestSignal,
                        latestFrame = latestFrame,
                        onStartScanningClicked = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !isNotificationGranted) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            startMediaProjectionFlow()
                        },
                        onStopScanningClicked = {
                            ScreenCaptureService.stopService(context)
                            FloatingOverlayService.stop(context)
                        },
                        onToggleOverlayClicked = {
                            if (!Settings.canDrawOverlays(context)) {
                                Toast.makeText(context, "Grant Overlay permission first", Toast.LENGTH_LONG).show()
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            } else {
                                if (observationState.isOverlayShowing) {
                                    FloatingOverlayService.stop(context)
                                } else {
                                    FloatingOverlayService.start(context)
                                }
                            }
                        },
                        onOpenPairSelector = {
                            currentScreen = NavDestination.CURRENCIES
                        }
                    )
                }

                NavDestination.CURRENCIES -> {
                    CurrencySelectorScreen(
                        instruments = filteredInstruments,
                        selectedInstrument = instrument,
                        searchQuery = searchQuery,
                        selectedTab = selectedTab,
                        onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                        onTabSelected = { viewModel.setSelectedTab(it) },
                        onInstrumentSelected = {
                            viewModel.selectInstrument(it)
                            currentScreen = NavDestination.DASHBOARD
                        },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onImportAssetList = { csv -> viewModel.importCustomPairs(csv) }
                    )
                }

                NavDestination.HISTORY -> {
                    SignalHistoryScreen(
                        signals = signalHistory,
                        summary = paperTestSummary,
                        onClearHistory = { viewModel.clearSignalHistory() }
                    )
                }

                NavDestination.PERMISSIONS -> {
                    PermissionsScreen(
                        isOverlayGranted = isOverlayGranted,
                        isNotificationGranted = isNotificationGranted,
                        isMediaProjectionActive = observationState.isCapturing,
                        onRequestMediaProjection = { startMediaProjectionFlow() },
                        onRequestNotificationPermission = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                    )
                }

                NavDestination.SETTINGS -> {
                    SettingsScreen(
                        samplingFps = samplingFps,
                        timingTolerance = timingTolerance,
                        isPaperTestingEnabled = isPaperTestingEnabled,
                        latestFrame = latestFrame,
                        onSamplingFpsChanged = { viewModel.setSamplingRate(it) },
                        onTimingToleranceChanged = { viewModel.setTimingToleranceSeconds(it) },
                        onPaperTestingToggled = { viewModel.setPaperTesting(it) }
                    )
                }
            }
        }
    }
}
