package com.example.data.market

import com.example.data.model.CandleData
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import java.util.concurrent.CopyOnWriteArrayList

class ScreenOnlyMarketAdapter : MarketDataProvider {

    override val providerId: String = "SCREEN_VISION_OBSERVATION"
    override val providerName: String = "Screen Vision (Local Pixel Analysis)"
    override val isOtcSupported: Boolean = true // Observes whichever chart is displayed on screen

    private val observedCandles = CopyOnWriteArrayList<CandleData>()
    @Volatile private var latestQuoteTimestamp: Long = 0L
    @Volatile private var latestCalculatedPrice: Double = 1.0

    fun updateObservedFrame(priceEstimate: Double, isBullish: Boolean, timestampMs: Long) {
        latestQuoteTimestamp = timestampMs
        latestCalculatedPrice = priceEstimate

        // Group into 1-minute candle boundaries
        val candleMinute = (timestampMs / 60000L) * 60000L
        val existingIndex = observedCandles.indexOfFirst { it.timestampMs == candleMinute }

        if (existingIndex >= 0) {
            val existing = observedCandles[existingIndex]
            val high = kotlin.math.max(existing.high, priceEstimate)
            val low = kotlin.math.min(existing.low, priceEstimate)
            observedCandles[existingIndex] = existing.copy(
                high = high,
                low = low,
                close = priceEstimate,
                isComplete = false
            )
        } else {
            // New candle start
            val newCandle = CandleData(
                timestampMs = candleMinute,
                open = priceEstimate,
                high = priceEstimate,
                low = priceEstimate,
                close = priceEstimate,
                volume = 1.0,
                isComplete = false,
                source = "SCREEN-ONLY"
            )
            observedCandles.add(newCandle)
            // Keep buffer reasonable
            while (observedCandles.size > 30) {
                observedCandles.removeAt(0)
            }
        }
    }

    override suspend fun getCandles(
        symbol: String,
        marketType: MarketType,
        timeframe: String,
        count: Int
    ): Result<List<CandleData>> {
        val now = System.currentTimeMillis()
        if (now - latestQuoteTimestamp > 15000L) {
            return Result.failure(IllegalStateException("Screen observation feed is stale (> 15s since last frame)"))
        }

        val list = observedCandles.takeLast(count)
        if (list.isEmpty()) {
            return Result.failure(IllegalStateException("No observed candle data available yet"))
        }
        return Result.success(list)
    }

    override suspend fun getLatestQuote(
        symbol: String,
        marketType: MarketType
    ): Result<QuoteData> {
        val now = System.currentTimeMillis()
        val freshness = checkFreshness(latestQuoteTimestamp)
        if (freshness == DataSourceStatus.STALE || freshness == DataSourceStatus.UNAVAILABLE) {
            return Result.failure(IllegalStateException("Screen frame stream unavailable or stale"))
        }

        return Result.success(
            QuoteData(
                symbol = symbol,
                marketType = marketType,
                bid = latestCalculatedPrice,
                ask = latestCalculatedPrice,
                lastPrice = latestCalculatedPrice,
                timestampMs = latestQuoteTimestamp,
                provider = providerName,
                status = DataSourceStatus.SCREEN_ONLY
            )
        )
    }

    override fun checkFreshness(lastUpdateTimestampMs: Long): DataSourceStatus {
        if (lastUpdateTimestampMs == 0L) return DataSourceStatus.UNAVAILABLE
        val elapsed = System.currentTimeMillis() - lastUpdateTimestampMs
        return when {
            elapsed < 8000L -> DataSourceStatus.SCREEN_ONLY
            elapsed < 20000L -> DataSourceStatus.STALE
            else -> DataSourceStatus.UNAVAILABLE
        }
    }
}
