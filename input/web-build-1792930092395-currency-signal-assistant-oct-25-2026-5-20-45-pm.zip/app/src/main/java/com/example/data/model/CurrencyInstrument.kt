package com.example.data.model

data class CurrencyInstrument(
    val symbol: String,                    // e.g. "EUR/USD" or "USD/DZD"
    val canonicalSymbol: String,           // e.g. "EURUSD"
    val displayName: String,               // e.g. "Euro / US Dollar"
    val marketType: MarketType,            // REAL or OTC (Strictly separated)
    val sourceProvider: String,            // e.g. "SCREEN_CAPTURE", "LIVE_FEED", "USER_IMPORT"
    val isAvailable: Boolean = true,
    val isFavorite: Boolean = false,
    val lastUpdatedMs: Long = System.currentTimeMillis(),
    val supportedTimeframes: List<String> = listOf("M1"),
    val validationStatus: String = "Verified" // "Verified", "Screenshot-derived OTC (Unverified)", "Imported"
)
