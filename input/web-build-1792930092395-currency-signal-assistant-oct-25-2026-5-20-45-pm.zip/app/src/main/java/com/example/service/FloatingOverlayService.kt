package com.example.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.CurrencySignalApp
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import com.example.data.model.SignalResult
import com.example.data.model.SignalType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class FloatingOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var stateManager: AppStateManager? = null

    private var windowManager: WindowManager? = null
    private var overlayContainer: FrameLayout? = null
    private var windowParams: WindowManager.LayoutParams? = null

    // UI elements inside overlay
    private var expandedLayout: LinearLayout? = null
    private var minimizedLayout: LinearLayout? = null

    private var tvPair: TextView? = null
    private var tvMarketBadge: TextView? = null
    private var tvTimeframe: TextView? = null
    private var tvSignal: TextView? = null
    private var signalCard: LinearLayout? = null
    private var tvCountdown: TextView? = null
    private var tvDataStatus: TextView? = null
    private var tvLastScan: TextView? = null
    private var btnScanToggle: TextView? = null
    private var btnMinimize: ImageView? = null
    private var btnClose: ImageView? = null

    // Minimized views
    private var tvMinPair: TextView? = null
    private var tvMinSignal: TextView? = null
    private var tvMinCountdown: TextView? = null

    private var isMinimized = false
    private var stateCollectorJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        stateManager = (application as CurrencySignalApp).stateManager

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        initOverlayViews()
        observeAppState()
        stateManager?.updateOverlayState(true)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initOverlayViews() {
        val wm = windowManager ?: return

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 160
        }
        windowParams = params

        val density = resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val root = FrameLayout(this)
        overlayContainer = root

        // Drag mechanics
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (kotlin.math.abs(dx) > 10 || kotlin.math.abs(dy) > 10) {
                        isDragging = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        try {
                            wm.updateViewLayout(root, params)
                        } catch (e: Exception) {
                            // Layout update safeguard
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging && isMinimized) {
                        // Click on minimized bubble restores expanded panel
                        toggleMinimize(false)
                    }
                    true
                }
                else -> false
            }
        }

        // ================= BUILD EXPANDED VIEW =================
        val expanded = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#121929"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.parseColor("#1F2D4A"))
            }
            setPadding(dp(12), dp(10), dp(12), dp(10))
            elevation = dp(8).toFloat()
        }
        expandedLayout = expanded

        // 1. Header Bar: Drag Handle + Pair + Market Type + Close/Minimize
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val pairText = TextView(this).apply {
            text = "EUR/USD"
            setTextColor(Color.WHITE)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        tvPair = pairText

        val marketBadge = TextView(this).apply {
            text = "OTC"
            textSize = 10f
            setTextColor(Color.parseColor("#FFB74D"))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FFB74D"))
                cornerRadius = dp(4).toFloat()
            }
            setPadding(dp(6), dp(2), dp(6), dp(2))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(6) }
            layoutParams = lp
        }
        tvMarketBadge = marketBadge

        val tfBadge = TextView(this).apply {
            text = "M1"
            textSize = 10f
            setTextColor(Color.parseColor("#64B5F6"))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2664B5F6"))
                cornerRadius = dp(4).toFloat()
            }
            setPadding(dp(6), dp(2), dp(6), dp(2))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(4) }
            layoutParams = lp
        }
        tvTimeframe = tfBadge

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
        }

        val minBtn = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_sort_by_size)
            setColorFilter(Color.parseColor("#90A4AE"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setOnClickListener { toggleMinimize(true) }
        }
        btnMinimize = minBtn

        val closeBtn = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setColorFilter(Color.parseColor("#EF5350"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setOnClickListener { stopSelf() }
        }
        btnClose = closeBtn

        header.addView(pairText)
        header.addView(marketBadge)
        header.addView(tfBadge)
        header.addView(spacer)
        header.addView(minBtn)
        header.addView(closeBtn)
        expanded.addView(header)

        // 2. Signal Display Card
        val sigCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1B273E"))
                cornerRadius = dp(10).toFloat()
            }
            val lp = LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        signalCard = sigCard

        val sigText = TextView(this).apply {
            text = "OBSERVING..."
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        tvSignal = sigText
        sigCard.addView(sigText)

        val countdownText = TextView(this).apply {
            text = "Candle: --s"
            textSize = 12f
            setTextColor(Color.parseColor("#B0BEC5"))
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4) }
            layoutParams = lp
        }
        tvCountdown = countdownText
        sigCard.addView(countdownText)
        expanded.addView(sigCard)

        // 3. Status and Timestamp Row
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = lp
        }

        val statusText = TextView(this).apply {
            text = "STATUS: SCREEN-ONLY"
            textSize = 9f
            setTextColor(Color.parseColor("#78909C"))
        }
        tvDataStatus = statusText

        val statusSpacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
        }

        val lastScanText = TextView(this).apply {
            text = "Last: --"
            textSize = 9f
            setTextColor(Color.parseColor("#78909C"))
        }
        tvLastScan = lastScanText

        statusRow.addView(statusText)
        statusRow.addView(statusSpacer)
        statusRow.addView(lastScanText)
        expanded.addView(statusRow)

        // 4. Quick Action Controls: START / STOP
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            layoutParams = lp
        }

        val scanToggle = TextView(this).apply {
            text = "STOP SCANNING"
            textSize = 11f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#D32F2F"))
                cornerRadius = dp(6).toFloat()
            }
            setPadding(dp(12), dp(6), dp(12), dp(6))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            layoutParams = lp
            setOnClickListener {
                val sm = stateManager ?: return@setOnClickListener
                val isCapturing = sm.observationState.value.isCapturing
                if (isCapturing) {
                    ScreenCaptureService.stopService(this@FloatingOverlayService)
                }
            }
        }
        btnScanToggle = scanToggle
        actionRow.addView(scanToggle)
        expanded.addView(actionRow)

        // ================= BUILD MINIMIZED VIEW =================
        val minimized = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1B273E"))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.parseColor("#00E5FF"))
            }
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
            elevation = dp(8).toFloat()
        }
        minimizedLayout = minimized

        val minPair = TextView(this).apply {
            text = "EUR/USD"
            textSize = 11f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        tvMinPair = minPair

        val minSig = TextView(this).apply {
            text = "●"
            textSize = 12f
            setTextColor(Color.GRAY)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(6) }
            layoutParams = lp
        }
        tvMinSignal = minSig

        val minCd = TextView(this).apply {
            text = "59s"
            textSize = 11f
            setTextColor(Color.parseColor("#00E5FF"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(6) }
            layoutParams = lp
        }
        tvMinCountdown = minCd

        minimized.addView(minPair)
        minimized.addView(minSig)
        minimized.addView(minCd)

        root.addView(expanded)
        root.addView(minimized)

        wm.addView(root, params)
    }

    private fun toggleMinimize(minimize: Boolean) {
        isMinimized = minimize
        if (minimize) {
            expandedLayout?.visibility = View.GONE
            minimizedLayout?.visibility = View.VISIBLE
        } else {
            expandedLayout?.visibility = View.VISIBLE
            minimizedLayout?.visibility = View.GONE
        }
        try {
            val wm = windowManager
            val root = overlayContainer
            val params = windowParams
            if (wm != null && root != null && params != null) {
                wm.updateViewLayout(root, params)
            }
        } catch (e: Exception) {
            // Safe layout update
        }
    }

    private fun observeAppState() {
        val sm = stateManager ?: return
        stateCollectorJob?.cancel()

        stateCollectorJob = serviceScope.launch {
            combine(
                sm.selectedInstrument,
                sm.observationState,
                sm.latestSignal
            ) { instrument, obs, signal ->
                Triple(instrument, obs, signal)
            }.collect { (instrument, obs, signal) ->
                updateUI(instrument, obs, signal)
            }
        }
    }

    private fun updateUI(
        instrument: com.example.data.model.CurrencyInstrument,
        obs: com.example.data.model.ScreenObservationState,
        signal: SignalResult?
    ) {
        val density = resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density).toInt()

        // 1. Pair & Market
        tvPair?.text = instrument.symbol
        tvMinPair?.text = instrument.symbol.split(" ").firstOrNull() ?: instrument.symbol

        if (instrument.marketType == MarketType.OTC) {
            tvMarketBadge?.text = "OTC"
            tvMarketBadge?.setTextColor(Color.parseColor("#FFA726"))
            (tvMarketBadge?.background as? GradientDrawable)?.setColor(Color.parseColor("#33FFA726"))
        } else {
            tvMarketBadge?.text = "REAL"
            tvMarketBadge?.setTextColor(Color.parseColor("#42A5F5"))
            (tvMarketBadge?.background as? GradientDrawable)?.setColor(Color.parseColor("#2642A5F5"))
        }

        // 2. Countdown & Final Window Highlight
        val seconds = obs.candleSecondsRemaining
        val cdText = if (seconds in 0..59) String.format("00:%02d", seconds) else "--s"
        tvCountdown?.text = "Candle: $cdText (${obs.timingQuality})"
        tvMinCountdown?.text = "${seconds}s"

        if (obs.isFinalAnalysisWindow) {
            tvCountdown?.setTextColor(Color.parseColor("#FFD54F")) // Pulsing amber in final 7s
        } else {
            tvCountdown?.setTextColor(Color.parseColor("#B0BEC5"))
        }

        // 3. Signal Card
        if (signal != null && !obs.isFinalAnalysisWindow && seconds in 1..55) {
            val isUp = signal.signal == SignalType.UP
            val isDown = signal.signal == SignalType.DOWN

            when {
                isUp -> {
                    tvSignal?.text = "CALL (UP) ▲"
                    tvSignal?.setTextColor(Color.parseColor("#00E676"))
                    (signalCard?.background as? GradientDrawable)?.setColor(Color.parseColor("#1A00E676"))
                    tvMinSignal?.text = "▲"
                    tvMinSignal?.setTextColor(Color.parseColor("#00E676"))
                }
                isDown -> {
                    tvSignal?.text = "PUT (DOWN) ▼"
                    tvSignal?.setTextColor(Color.parseColor("#FF3366"))
                    (signalCard?.background as? GradientDrawable)?.setColor(Color.parseColor("#1AFF3366"))
                    tvMinSignal?.text = "▼"
                    tvMinSignal?.setTextColor(Color.parseColor("#FF3366"))
                }
                else -> {
                    tvSignal?.text = "NO TRADE ━"
                    tvSignal?.setTextColor(Color.parseColor("#FFB300"))
                    (signalCard?.background as? GradientDrawable)?.setColor(Color.parseColor("#1AFFB300"))
                    tvMinSignal?.text = "━"
                    tvMinSignal?.setTextColor(Color.parseColor("#FFB300"))
                }
            }
        } else if (obs.isFinalAnalysisWindow) {
            tvSignal?.text = "ANALYZING (T-${seconds}s)..."
            tvSignal?.setTextColor(Color.parseColor("#00E5FF"))
            (signalCard?.background as? GradientDrawable)?.setColor(Color.parseColor("#1A00E5FF"))
            tvMinSignal?.text = "⏳"
            tvMinSignal?.setTextColor(Color.parseColor("#00E5FF"))
        } else {
            tvSignal?.text = "OBSERVING CANDLE"
            tvSignal?.setTextColor(Color.WHITE)
            (signalCard?.background as? GradientDrawable)?.setColor(Color.parseColor("#1B273E"))
            tvMinSignal?.text = "●"
            tvMinSignal?.setTextColor(Color.GRAY)
        }

        // 4. Data Status & Last Scan
        val statusLabel = if (instrument.marketType == MarketType.OTC) {
            "SCREEN-ONLY (OTC)"
        } else {
            "LIVE FEED (REAL)"
        }
        tvDataStatus?.text = "DATA: $statusLabel"

        val timeDiff = (System.currentTimeMillis() - obs.lastScanTimeMs) / 1000
        tvLastScan?.text = if (obs.lastScanTimeMs > 0) "${timeDiff}s ago" else "--"

        // 5. Button toggle
        if (obs.isCapturing) {
            btnScanToggle?.text = "STOP SCANNING"
            (btnScanToggle?.background as? GradientDrawable)?.setColor(Color.parseColor("#D32F2F"))
        } else {
            btnScanToggle?.text = "CAPTURE STOPPED"
            (btnScanToggle?.background as? GradientDrawable)?.setColor(Color.parseColor("#455A64"))
        }
    }

    override fun onDestroy() {
        stateCollectorJob?.cancel()
        serviceScope.cancel()

        try {
            overlayContainer?.let { windowManager?.removeView(it) }
        } catch (e: Exception) {
            // View removal safeguard
        }

        stateManager?.updateOverlayState(false)
        super.onDestroy()
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java)
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java)
            context.stopService(intent)
        }
    }
}
