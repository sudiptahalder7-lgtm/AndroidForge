package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface InstrumentDao {
    @Query("SELECT * FROM instruments ORDER BY symbol ASC")
    fun getAllInstruments(): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments WHERE marketType = :marketType ORDER BY symbol ASC")
    fun getInstrumentsByMarketType(marketType: String): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments WHERE isFavorite = 1 ORDER BY symbol ASC")
    fun getFavoriteInstruments(): Flow<List<InstrumentEntity>>

    @Query("SELECT * FROM instruments WHERE symbol = :symbol LIMIT 1")
    suspend fun getInstrumentBySymbol(symbol: String): InstrumentEntity?

    @Query("SELECT COUNT(*) FROM instruments")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(instruments: List<InstrumentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(instrument: InstrumentEntity)

    @Update
    suspend fun update(instrument: InstrumentEntity)

    @Query("UPDATE instruments SET isFavorite = :isFavorite WHERE symbol = :symbol")
    suspend fun updateFavorite(symbol: String, isFavorite: Boolean)

    @Query("DELETE FROM instruments WHERE symbol = :symbol")
    suspend fun delete(symbol: String)
}
