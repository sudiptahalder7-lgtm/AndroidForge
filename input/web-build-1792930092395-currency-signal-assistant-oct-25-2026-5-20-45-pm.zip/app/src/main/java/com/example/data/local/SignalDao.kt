package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalDao {
    @Query("SELECT * FROM signals ORDER BY candleTimeMs DESC")
    fun getAllSignals(): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE instrumentSymbol = :symbol ORDER BY candleTimeMs DESC")
    fun getSignalsByInstrument(symbol: String): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE marketType = :marketType ORDER BY candleTimeMs DESC")
    fun getSignalsByMarketType(marketType: String): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE outcome = 'PENDING' ORDER BY candleTimeMs ASC")
    suspend fun getPendingSignals(): List<SignalEntity>

    @Query("SELECT * FROM signals ORDER BY candleTimeMs DESC LIMIT 1")
    fun getLatestSignal(): Flow<SignalEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignal(signal: SignalEntity): Long

    @Update
    suspend fun updateSignal(signal: SignalEntity)

    @Query("DELETE FROM signals")
    suspend fun clearAllSignals()

    @Query("DELETE FROM signals WHERE id = :id")
    suspend fun deleteSignalById(id: Long)
}
