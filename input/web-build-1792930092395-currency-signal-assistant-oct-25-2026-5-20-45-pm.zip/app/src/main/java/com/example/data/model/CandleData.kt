package com.example.data.model

data class CandleData(
    val timestampMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
    val isComplete: Boolean = true,
    val source: String = "SCREEN_VISION"
) {
    val isBullish: Boolean
        get() = close > open

    val isBearish: Boolean
        get() = close < open

    val isDoji: Boolean
        get() {
            val totalRange = high - low
            if (totalRange <= 0.000001) return true
            val bodySize = kotlin.math.abs(close - open)
            return (bodySize / totalRange) < 0.15 // Body is less than 15% of range
        }

    val bodySize: Double
        get() = kotlin.math.abs(close - open)

    val upperWick: Double
        get() = high - kotlin.math.max(open, close)

    val lowerWick: Double
        get() = kotlin.math.min(open, close) - low

    val totalRange: Double
        get() = high - low
}
