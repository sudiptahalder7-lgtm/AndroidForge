package com.example.data.model

import android.graphics.Rect

data class ScreenObservationState(
    val isCapturing: Boolean = false,
    val isOverlayShowing: Boolean = false,
    val lastScanTimeMs: Long = 0L,
    val candleSecondsRemaining: Int = 60,
    val isFinalAnalysisWindow: Boolean = false, // true during final 7 seconds (T-7s to T-1s)
    val timingQuality: String = "Searching Countdown", // "Synced", "Drift Detected", "Searching Countdown", "Unreliable"
    val timingUncertaintyMs: Long = 0L,
    val cropRect: Rect? = null,
    val lastObservedCandleColor: String = "NONE", // "BULLISH_GREEN", "BEARISH_RED", "DOJI", "NONE"
    val fps: Float = 0.0f,
    val errorMessage: String? = null
)
