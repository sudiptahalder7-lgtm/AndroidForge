package com.example.data.model

enum class SignalType {
    UP,
    DOWN,
    NO_TRADE;

    val displayLabel: String
        get() = when (this) {
            UP -> "CALL (UP) ▲"
            DOWN -> "PUT (DOWN) ▼"
            NO_TRADE -> "NO TRADE ━"
        }
}

enum class DataSourceStatus {
    LIVE,
    STALE,
    UNAVAILABLE,
    SCREEN_ONLY;

    val displayLabel: String
        get() = when (this) {
            LIVE -> "LIVE FEED"
            STALE -> "STALE DATA"
            UNAVAILABLE -> "UNAVAILABLE"
            SCREEN_ONLY -> "SCREEN-ONLY"
        }
}

enum class Outcome {
    PENDING,
    WIN,
    LOSS,
    PUSH,
    SKIPPED
}

data class SignalResult(
    val id: Long = 0,
    val instrumentSymbol: String,
    val marketType: MarketType,
    val signal: SignalType,
    val confidence: Float,               // Heuristic confidence 0.0f - 1.0f
    val isCalibrated: Boolean = false,   // True only if backed by validated statistical model
    val dataStatus: DataSourceStatus,
    val reason: String,
    val candleTimeMs: Long,              // Minute timestamp of observed candle
    val analysisTimeMs: Long,            // Precise analysis timestamp (approx T-1s)
    val outcome: Outcome = Outcome.PENDING,
    val entryPrice: Double? = null,
    val exitPrice: Double? = null,
    val detectedCountdownSeconds: Int = 0,
    val indicatorsSummary: String = ""
)
