package com.example.data.model

enum class MarketType {
    REAL,
    OTC;

    val label: String
        get() = when (this) {
            REAL -> "REAL MARKET"
            OTC -> "OTC MARKET"
        }

    val shortLabel: String
        get() = when (this) {
            REAL -> "REAL"
            OTC -> "OTC"
        }
}
