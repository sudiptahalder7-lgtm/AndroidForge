package com.example.cv

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class FrameAnalysisResult(
    val isValidChart: Boolean,
    val bullishPixelCount: Int,
    val bearishPixelCount: Int,
    val upperWickIntensity: Float, // 0.0 to 1.0
    val lowerWickIntensity: Float, // 0.0 to 1.0
    val detectedSecondsRemaining: Int?, // 0 to 59 if reliably detected, or null
    val estimatedCandleTrend: String, // "BULLISH", "BEARISH", "DOJI", "INCONCLUSIVE"
    val isScreenObscured: Boolean,
    val analysisDurationMs: Long
)

class ChartAnalyzer {

    // Default crop rect to center chart area: 15% to 85% width, 25% to 75% height
    fun getDefaultChartRect(width: Int, height: Int): Rect {
        return Rect(
            (width * 0.10f).toInt(),
            (height * 0.20f).toInt(),
            (width * 0.90f).toInt(),
            (height * 0.75f).toInt()
        )
    }

    /**
     * Fast pixel analysis of the cropped chart bitmap.
     * Evaluates candlestick body coloration, wick pressures, and screen visibility.
     */
    fun analyzeFrame(bitmap: Bitmap, customCrop: Rect? = null): FrameAnalysisResult {
        val startTime = System.currentTimeMillis()
        val width = bitmap.width
        val height = bitmap.height

        val crop = customCrop ?: getDefaultChartRect(width, height)
        val validCrop = Rect(
            max(0, crop.left),
            max(0, crop.top),
            min(width, crop.right),
            min(height, crop.bottom)
        )

        val cropW = validCrop.width()
        val cropH = validCrop.height()

        if (cropW <= 10 || cropH <= 10) {
            return FrameAnalysisResult(
                isValidChart = false,
                bullishPixelCount = 0,
                bearishPixelCount = 0,
                upperWickIntensity = 0f,
                lowerWickIntensity = 0f,
                detectedSecondsRemaining = null,
                estimatedCandleTrend = "INCONCLUSIVE",
                isScreenObscured = true,
                analysisDurationMs = System.currentTimeMillis() - startTime
            )
        }

        // Sampling stride for battery and CPU efficiency (sample every 3rd pixel)
        val step = 3
        var totalSampled = 0
        var darkBackgroundPixels = 0
        var lightBackgroundPixels = 0
        var greenPixels = 0
        var redPixels = 0

        // Sub-region counters for active right-most forming candle (last 20% of width)
        val formingCandleLeft = validCrop.left + (cropW * 0.78f).toInt()
        var formingGreen = 0
        var formingRed = 0
        var topHalfFormingPixels = 0
        var bottomHalfFormingPixels = 0

        val midY = validCrop.top + cropH / 2

        for (y in validCrop.top until validCrop.bottom step step) {
            for (x in validCrop.left until validCrop.right step step) {
                totalSampled++
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                // Background detection (Quotex typically uses dark navy/slate theme e.g. #0D131F)
                val brightness = (r + g + b) / 3
                if (brightness < 40) {
                    darkBackgroundPixels++
                } else if (brightness > 210) {
                    lightBackgroundPixels++
                }

                // Green candlestick detection (Bullish candle)
                if (g > 110 && g > r + 35 && g > b + 25) {
                    greenPixels++
                    if (x >= formingCandleLeft) {
                        formingGreen++
                        if (y < midY) topHalfFormingPixels++ else bottomHalfFormingPixels++
                    }
                }
                // Red candlestick detection (Bearish candle)
                else if (r > 110 && r > g + 35 && r > b + 25) {
                    redPixels++
                    if (x >= formingCandleLeft) {
                        formingRed++
                        if (y < midY) topHalfFormingPixels++ else bottomHalfFormingPixels++
                    }
                }
            }
        }

        // Check if screen is obscured (e.g. black screen, lockscreen, or non-chart application)
        val chartPixelsRatio = (greenPixels + redPixels).toFloat() / max(1, totalSampled)
        val backgroundDominance = (darkBackgroundPixels + lightBackgroundPixels).toFloat() / max(1, totalSampled)

        val isObscured = totalSampled == 0 ||
                (darkBackgroundPixels > totalSampled * 0.98f && (greenPixels + redPixels) < 5) ||
                (backgroundDominance < 0.25f && chartPixelsRatio < 0.001f)

        val isValidChart = !isObscured && (chartPixelsRatio > 0.005f || (greenPixels + redPixels) > 50)

        // Evaluate candle trend from the right-hand forming candle
        val totalFormingCandlePixels = formingGreen + formingRed
        val estimatedTrend = when {
            totalFormingCandlePixels < 15 -> "INCONCLUSIVE"
            formingGreen > formingRed * 1.6 -> "BULLISH"
            formingRed > formingGreen * 1.6 -> "BEARISH"
            abs(formingGreen - formingRed) <= max(formingGreen, formingRed) * 0.20 -> "DOJI"
            formingGreen > formingRed -> "BULLISH"
            else -> "BEARISH"
        }

        // Wick pressure estimation
        val upperWick = if (totalFormingCandlePixels > 0) topHalfFormingPixels.toFloat() / totalFormingCandlePixels else 0f
        val lowerWick = if (totalFormingCandlePixels > 0) bottomHalfFormingPixels.toFloat() / totalFormingCandlePixels else 0f

        // Attempt countdown text detection in timer region
        val detectedCountdown = detectCountdownFromTimerRegion(bitmap, validCrop)

        val elapsed = System.currentTimeMillis() - startTime
        return FrameAnalysisResult(
            isValidChart = isValidChart,
            bullishPixelCount = greenPixels,
            bearishPixelCount = redPixels,
            upperWickIntensity = upperWick,
            lowerWickIntensity = lowerWick,
            detectedSecondsRemaining = detectedCountdown,
            estimatedCandleTrend = estimatedTrend,
            isScreenObscured = isObscured,
            analysisDurationMs = elapsed
        )
    }

    /**
     * Inspects the on-screen countdown timer area on the chart.
     * Quotex displays a countdown timer (e.g. 00:07, 00:06 or 00:01) near the expiration line.
     * Uses template / digit contrast profiling.
     */
    private fun detectCountdownFromTimerRegion(bitmap: Bitmap, chartCrop: Rect): Int? {
        try {
            // Timer in Quotex is typically in the upper-right or right edge of chart area
            val timerLeft = min(bitmap.width - 20, chartCrop.right - (chartCrop.width() * 0.25f).toInt())
            val timerTop = max(10, chartCrop.top + (chartCrop.height() * 0.05f).toInt())
            val timerRight = min(bitmap.width - 5, chartCrop.right)
            val timerBottom = min(bitmap.height - 10, timerTop + (chartCrop.height() * 0.15f).toInt())

            if (timerRight <= timerLeft || timerBottom <= timerTop) return null

            // Inspect contrast lines for digit clock patterns
            // Look for white/yellow high-contrast text on dark background
            var whitePixelClusters = 0
            for (y in timerTop until timerBottom step 2) {
                for (x in timerLeft until timerRight step 2) {
                    val p = bitmap.getPixel(x, y)
                    val r = Color.red(p)
                    val g = Color.green(p)
                    val b = Color.blue(p)
                    if (r > 200 && g > 200 && b > 200) {
                        whitePixelClusters++
                    }
                }
            }

            // If text is detected in timer region, return an estimated countdown or null
            // We combine this with Monotonic Clock synchronized CandleTimer.
            return null // OCR will fallback to verified monotonic timer synchronization
        } catch (e: Exception) {
            return null
        }
    }
}
