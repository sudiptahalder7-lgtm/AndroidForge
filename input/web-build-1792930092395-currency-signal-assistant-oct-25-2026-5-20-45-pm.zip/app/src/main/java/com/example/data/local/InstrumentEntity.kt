package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.CurrencyInstrument
import com.example.data.model.MarketType

@Entity(tableName = "instruments")
data class InstrumentEntity(
    @PrimaryKey
    val symbol: String,                 // Primary key: e.g. "USD/DZD"
    val canonicalSymbol: String,
    val displayName: String,
    val marketType: String,             // "REAL" or "OTC"
    val sourceProvider: String,
    val isAvailable: Boolean,
    val isFavorite: Boolean,
    val lastUpdatedMs: Long,
    val supportedTimeframes: String,    // Comma separated e.g. "M1"
    val validationStatus: String
) {
    fun toDomain(): CurrencyInstrument = CurrencyInstrument(
        symbol = symbol,
        canonicalSymbol = canonicalSymbol,
        displayName = displayName,
        marketType = try { MarketType.valueOf(marketType) } catch (e: Exception) { MarketType.OTC },
        sourceProvider = sourceProvider,
        isAvailable = isAvailable,
        isFavorite = isFavorite,
        lastUpdatedMs = lastUpdatedMs,
        supportedTimeframes = supportedTimeframes.split(",").map { it.trim() }.filter { it.isNotEmpty() },
        validationStatus = validationStatus
    )

    companion object {
        fun fromDomain(instrument: CurrencyInstrument): InstrumentEntity = InstrumentEntity(
            symbol = instrument.symbol,
            canonicalSymbol = instrument.canonicalSymbol,
            displayName = instrument.displayName,
            marketType = instrument.marketType.name,
            sourceProvider = instrument.sourceProvider,
            isAvailable = instrument.isAvailable,
            isFavorite = instrument.isFavorite,
            lastUpdatedMs = instrument.lastUpdatedMs,
            supportedTimeframes = instrument.supportedTimeframes.joinToString(","),
            validationStatus = instrument.validationStatus
        )
    }
}
