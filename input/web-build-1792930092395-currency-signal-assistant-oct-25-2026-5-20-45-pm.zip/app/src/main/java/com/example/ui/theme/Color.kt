package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF131C2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkCardBorder = Color(0xFF283652)

val AccentCyan = Color(0xFF00E5FF)
val SignalGreen = Color(0xFF00E676)
val SignalGreenBg = Color(0x2600E676)
val SignalRed = Color(0xFFFF3366)
val SignalRedBg = Color(0x26FF3366)
val SignalAmber = Color(0xFFFFB300)
val SignalAmberBg = Color(0x26FFB300)

val OtcBadgeColor = Color(0xFFFFA726)
val OtcBadgeBg = Color(0x2EFFA726)
val RealBadgeColor = Color(0xFF42A5F5)
val RealBadgeBg = Color(0x2E42A5F5)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
