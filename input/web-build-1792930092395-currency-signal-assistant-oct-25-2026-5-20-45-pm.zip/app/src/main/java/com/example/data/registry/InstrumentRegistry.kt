package com.example.data.registry

import com.example.data.local.InstrumentDao
import com.example.data.local.InstrumentEntity
import com.example.data.model.CurrencyInstrument
import com.example.data.model.MarketType

object InstrumentRegistry {

    /**
     * Exact OTC screenshot-derived currency pair list (41 pairs).
     * Marked strictly as OTC and labeled as "Screenshot-derived OTC (Unverified Quotex feed)".
     */
    val OTC_SEED_SYMBOLS: List<Pair<String, String>> = listOf(
        "USD/DZD" to "US Dollar / Algerian Dinar",
        "USD/INR" to "US Dollar / Indian Rupee",
        "AUD/JPY" to "Australian Dollar / Japanese Yen",
        "NZD/CHF" to "New Zealand Dollar / Swiss Franc",
        "EUR/JPY" to "Euro / Japanese Yen",
        "USD/CHF" to "US Dollar / Swiss Franc",
        "AUD/CAD" to "Australian Dollar / Canadian Dollar",
        "USD/MXN" to "US Dollar / Mexican Peso",
        "EUR/CHF" to "Euro / Swiss Franc",
        "EUR/GBP" to "Euro / British Pound",
        "GBP/USD" to "British Pound / US Dollar",
        "USD/BRL" to "US Dollar / Brazilian Real",
        "EUR/USD" to "Euro / US Dollar",
        "USD/BDT" to "US Dollar / Bangladeshi Taka",
        "EUR/AUD" to "Euro / Australian Dollar",
        "USD/IDR" to "US Dollar / Indonesian Rupiah",
        "AUD/USD" to "Australian Dollar / US Dollar",
        "USD/COP" to "US Dollar / Colombian Peso",
        "GBP/AUD" to "British Pound / Australian Dollar",
        "GBP/CAD" to "British Pound / Canadian Dollar",
        "AUD/CHF" to "Australian Dollar / Swiss Franc",
        "AUD/NZD" to "Australian Dollar / New Zealand Dollar",
        "NZD/JPY" to "New Zealand Dollar / Japanese Yen",
        "EUR/CAD" to "Euro / Canadian Dollar",
        "GBP/JPY" to "British Pound / Japanese Yen",
        "NZD/USD" to "New Zealand Dollar / US Dollar",
        "CHF/JPY" to "Swiss Franc / Japanese Yen",
        "USD/EGP" to "US Dollar / Egyptian Pound",
        "USD/JPY" to "US Dollar / Japanese Yen",
        "USD/NGN" to "US Dollar / Nigerian Naira",
        "NZD/CAD" to "New Zealand Dollar / Canadian Dollar",
        "USD/ARS" to "US Dollar / Argentine Peso",
        "USD/CAD" to "US Dollar / Canadian Dollar",
        "USD/PHP" to "US Dollar / Philippine Peso",
        "USD/PKR" to "US Dollar / Pakistani Rupee",
        "CAD/CHF" to "Canadian Dollar / Swiss Franc",
        "CAD/JPY" to "Canadian Dollar / Japanese Yen",
        "USD/ZAR" to "US Dollar / South African Rand",
        "GBP/CHF" to "British Pound / Swiss Franc",
        "GBP/NZD" to "British Pound / New Zealand Dollar",
        "EUR/NZD" to "Euro / New Zealand Dollar"
    )

    /**
     * Verified REAL market currency pairs. Kept strictly separate from OTC pairs.
     * Real instruments represent standard interbank forex pairs.
     */
    val REAL_SEED_SYMBOLS: List<Pair<String, String>> = listOf(
        "EUR/USD" to "Euro / US Dollar",
        "GBP/USD" to "British Pound / US Dollar",
        "USD/JPY" to "US Dollar / Japanese Yen",
        "USD/CHF" to "US Dollar / Swiss Franc",
        "AUD/USD" to "Australian Dollar / US Dollar",
        "USD/CAD" to "US Dollar / Canadian Dollar",
        "NZD/USD" to "New Zealand Dollar / US Dollar",
        "EUR/GBP" to "Euro / British Pound",
        "EUR/JPY" to "Euro / Japanese Yen",
        "GBP/JPY" to "British Pound / Japanese Yen",
        "AUD/JPY" to "Australian Dollar / Japanese Yen",
        "CAD/JPY" to "Canadian Dollar / Japanese Yen",
        "CHF/JPY" to "Swiss Franc / Japanese Yen",
        "NZD/JPY" to "New Zealand Dollar / Japanese Yen",
        "EUR/CAD" to "Euro / Canadian Dollar",
        "AUD/CAD" to "Australian Dollar / Canadian Dollar",
        "CAD/CHF" to "Canadian Dollar / Swiss Franc",
        "GBP/CHF" to "British Pound / Swiss Franc",
        "EUR/CHF" to "Euro / Swiss Franc",
        "GBP/AUD" to "British Pound / Australian Dollar",
        "EUR/AUD" to "Euro / Australian Dollar"
    )

    fun createInitialEntities(): List<InstrumentEntity> {
        val now = System.currentTimeMillis()
        val list = mutableListOf<InstrumentEntity>()

        // 1. Add OTC pairs (marked as Screenshot-derived OTC)
        OTC_SEED_SYMBOLS.forEach { (symbol, name) ->
            val canonical = symbol.replace("/", "").trim().uppercase()
            list.add(
                InstrumentEntity(
                    symbol = "$symbol (OTC)",
                    canonicalSymbol = canonical,
                    displayName = "$name (OTC)",
                    marketType = MarketType.OTC.name,
                    sourceProvider = "SCREEN_CAPTURE",
                    isAvailable = true,
                    isFavorite = (symbol == "EUR/USD" || symbol == "GBP/USD" || symbol == "USD/INR"),
                    lastUpdatedMs = now,
                    supportedTimeframes = "M1",
                    validationStatus = "Screenshot-derived OTC (Unverified Quotex feed)"
                )
            )
        }

        // 2. Add REAL pairs (strictly separate)
        REAL_SEED_SYMBOLS.forEach { (symbol, name) ->
            val canonical = symbol.replace("/", "").trim().uppercase()
            list.add(
                InstrumentEntity(
                    symbol = symbol,
                    canonicalSymbol = canonical,
                    displayName = name,
                    marketType = MarketType.REAL.name,
                    sourceProvider = "INTERBANK_SPOT",
                    isAvailable = true,
                    isFavorite = (symbol == "EUR/USD" || symbol == "GBP/USD"),
                    lastUpdatedMs = now,
                    supportedTimeframes = "M1",
                    validationStatus = "Verified Real Market"
                )
            )
        }

        return list
    }

    suspend fun seedDatabaseIfEmpty(dao: InstrumentDao) {
        if (dao.getCount() == 0) {
            dao.insertAll(createInitialEntities())
        }
    }

    /**
     * Parses custom asset list imported by the user in CSV format:
     * Line format: SYMBOL,MARKET_TYPE[,DISPLAY_NAME]
     * e.g.:
     * USD/TRY,OTC,US Dollar / Turkish Lira
     * EUR/PLN,REAL,Euro / Polish Zloty
     */
    fun parseCustomAssetList(csvContent: String): List<CurrencyInstrument> {
        val result = mutableListOf<CurrencyInstrument>()
        val lines = csvContent.lines()
        val now = System.currentTimeMillis()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue
            val parts = trimmed.split(",").map { it.trim() }
            if (parts.size >= 2) {
                val symbol = parts[0].uppercase()
                val marketTypeStr = parts[1].uppercase()
                val marketType = if (marketTypeStr.contains("OTC")) MarketType.OTC else MarketType.REAL
                val displayName = if (parts.size >= 3 && parts[2].isNotEmpty()) parts[2] else symbol
                val canonical = symbol.replace("/", "").replace("(OTC)", "").trim()

                result.add(
                    CurrencyInstrument(
                        symbol = if (marketType == MarketType.OTC && !symbol.contains("OTC")) "$symbol (OTC)" else symbol,
                        canonicalSymbol = canonical,
                        displayName = displayName,
                        marketType = marketType,
                        sourceProvider = "USER_IMPORT",
                        isAvailable = true,
                        isFavorite = false,
                        lastUpdatedMs = now,
                        supportedTimeframes = listOf("M1"),
                        validationStatus = "User-Imported Asset"
                    )
                )
            }
        }
        return result
    }
}
