package com.example.engine

import com.example.data.local.SignalDao
import com.example.data.local.SignalEntity
import com.example.data.model.Outcome
import com.example.data.model.SignalResult
import com.example.data.model.SignalType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PaperTestSummary(
    val totalSignals: Int,
    val winCount: Int,
    val lossCount: Int,
    val pushCount: Int,
    val skippedCount: Int,
    val pendingCount: Int,
    val winRatePercent: Float, // Calculated on evaluated signals (Wins / (Wins + Losses))
    val sampleSize: Int,
    val methodologyNote: String
)

class PaperTestingManager(
    private val signalDao: SignalDao
) {

    /**
     * Called when a 1-minute candle closes to evaluate any pending signals from the previous candle.
     */
    suspend fun evaluatePendingSignals(currentPrice: Double) = withContext(Dispatchers.IO) {
        val pending = signalDao.getPendingSignals()
        val now = System.currentTimeMillis()

        for (entity in pending) {
            // Only evaluate if at least 55 seconds have elapsed since signal analysis
            val elapsed = now - entity.analysisTimeMs
            if (elapsed >= 55000L) {
                val entry = entity.entryPrice ?: currentPrice
                val exit = currentPrice

                val outcome = when (entity.signalType) {
                    SignalType.UP.name -> {
                        when {
                            exit > entry -> Outcome.WIN
                            exit < entry -> Outcome.LOSS
                            else -> Outcome.PUSH
                        }
                    }
                    SignalType.DOWN.name -> {
                        when {
                            exit < entry -> Outcome.WIN
                            exit > entry -> Outcome.LOSS
                            else -> Outcome.PUSH
                        }
                    }
                    else -> Outcome.SKIPPED
                }

                signalDao.updateSignal(
                    entity.copy(
                        outcome = outcome.name,
                        exitPrice = exit
                    )
                )
            }
        }
    }

    /**
     * Compiles a statistical summary across all historical signals.
     */
    fun calculateSummary(signals: List<SignalResult>): PaperTestSummary {
        val evaluated = signals.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS }
        val wins = signals.count { it.outcome == Outcome.WIN }
        val losses = signals.count { it.outcome == Outcome.LOSS }
        val pushes = signals.count { it.outcome == Outcome.PUSH }
        val skipped = signals.count { it.outcome == Outcome.SKIPPED || it.signal == SignalType.NO_TRADE }
        val pending = signals.count { it.outcome == Outcome.PENDING }

        val evaluatedCount = wins + losses
        val winRate = if (evaluatedCount > 0) {
            (wins.toFloat() / evaluatedCount.toFloat()) * 100f
        } else {
            0.0f
        }

        return PaperTestSummary(
            totalSignals = signals.size,
            winCount = wins,
            lossCount = losses,
            pushCount = pushes,
            skippedCount = skipped,
            pendingCount = pending,
            winRatePercent = winRate,
            sampleSize = evaluatedCount,
            methodologyNote = "Win rate calculated as Wins / (Wins + Losses) on closed 1-minute candles. NO TRADE and tie outcomes are excluded from win-rate calculation. Paper-testing does not simulate broker slippage or execution latency."
        )
    }
}
