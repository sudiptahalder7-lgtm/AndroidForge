package com.example.engine

import com.example.cv.FrameAnalysisResult
import com.example.data.model.CandleData
import com.example.data.model.CurrencyInstrument
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import com.example.data.model.Outcome
import com.example.data.model.SignalResult
import com.example.data.model.SignalType
import kotlin.math.abs

data class SignalEngineConfig(
    val minConfidenceThreshold: Float = 0.65f,
    val maxTimingDriftSeconds: Float = 2.0f,
    val dojiThresholdPercent: Float = 0.15f,
    val isStrictConfirmationRequired: Boolean = true
)

class SignalEngine(
    private val config: SignalEngineConfig = SignalEngineConfig()
) {

    /**
     * Evaluates all gathered inputs and produces a SignalResult.
     * Guaranteed safe fallback to NO_TRADE whenever conditions are not met.
     */
    fun evaluateSignal(
        instrument: CurrencyInstrument,
        latestCandles: List<CandleData>,
        frameResult: FrameAnalysisResult?,
        dataStatus: DataSourceStatus,
        timingQuality: String,
        secondsRemaining: Int,
        isTimingReliable: Boolean
    ): SignalResult {
        val now = System.currentTimeMillis()
        val currentCandleMinute = (now / 60000L) * 60000L

        // Safety Rule 1: Data Status check
        if (dataStatus == DataSourceStatus.UNAVAILABLE) {
            return SignalResult(
                instrumentSymbol = instrument.symbol,
                marketType = instrument.marketType,
                signal = SignalType.NO_TRADE,
                confidence = 0.0f,
                isCalibrated = false,
                dataStatus = dataStatus,
                reason = "Market data feed unavailable. Signal generation aborted for safety.",
                candleTimeMs = currentCandleMinute,
                analysisTimeMs = now,
                outcome = Outcome.SKIPPED,
                detectedCountdownSeconds = secondsRemaining
            )
        }

        if (dataStatus == DataSourceStatus.STALE) {
            return SignalResult(
                instrumentSymbol = instrument.symbol,
                marketType = instrument.marketType,
                signal = SignalType.NO_TRADE,
                confidence = 0.0f,
                isCalibrated = false,
                dataStatus = dataStatus,
                reason = "Feed quotes are stale (> 15s delay). Waiting for fresh market data.",
                candleTimeMs = currentCandleMinute,
                analysisTimeMs = now,
                outcome = Outcome.SKIPPED,
                detectedCountdownSeconds = secondsRemaining
            )
        }

        // Safety Rule 2: Screen observation validation
        if (frameResult != null && frameResult.isScreenObscured) {
            return SignalResult(
                instrumentSymbol = instrument.symbol,
                marketType = instrument.marketType,
                signal = SignalType.NO_TRADE,
                confidence = 0.0f,
                isCalibrated = false,
                dataStatus = dataStatus,
                reason = "Screen obscured or Quotex chart not visible in observation area.",
                candleTimeMs = currentCandleMinute,
                analysisTimeMs = now,
                outcome = Outcome.SKIPPED,
                detectedCountdownSeconds = secondsRemaining
            )
        }

        // Safety Rule 3: Timing validation
        if (!isTimingReliable) {
            return SignalResult(
                instrumentSymbol = instrument.symbol,
                marketType = instrument.marketType,
                signal = SignalType.NO_TRADE,
                confidence = 0.0f,
                isCalibrated = false,
                dataStatus = dataStatus,
                reason = "Candle boundary timing uncertainty exceeded tolerance ($timingQuality).",
                candleTimeMs = currentCandleMinute,
                analysisTimeMs = now,
                outcome = Outcome.SKIPPED,
                detectedCountdownSeconds = secondsRemaining
            )
        }

        // Safety Rule 4: Data insufficiency check
        if (latestCandles.isEmpty() && frameResult == null) {
            return SignalResult(
                instrumentSymbol = instrument.symbol,
                marketType = instrument.marketType,
                signal = SignalType.NO_TRADE,
                confidence = 0.0f,
                isCalibrated = false,
                dataStatus = dataStatus,
                reason = "Insufficient candle history to evaluate price action patterns.",
                candleTimeMs = currentCandleMinute,
                analysisTimeMs = now,
                outcome = Outcome.SKIPPED,
                detectedCountdownSeconds = secondsRemaining
            )
        }

        // Core Strategy Evaluation: Multi-factor momentum, body/wick proportions, and pixel trend
        var bullishScore = 0f
        var bearishScore = 0f
        val factors = mutableListOf<String>()

        // Factor A: Screen-observed candle pixel momentum
        if (frameResult != null && frameResult.isValidChart) {
            when (frameResult.estimatedCandleTrend) {
                "BULLISH" -> {
                    bullishScore += 0.40f
                    factors.add("Screen: Bullish green dominance (+0.40)")
                }
                "BEARISH" -> {
                    bearishScore += 0.40f
                    factors.add("Screen: Bearish red dominance (+0.40)")
                }
                "DOJI" -> {
                    factors.add("Screen: Doji/flat candle body - high indecision")
                }
                else -> {
                    factors.add("Screen: Inconclusive candle distribution")
                }
            }

            // Wick rejection analysis
            if (frameResult.lowerWickIntensity > 0.45f && frameResult.upperWickIntensity < 0.20f) {
                bullishScore += 0.25f
                factors.add("Lower wick rejection (Bullish buying pressure +0.25)")
            } else if (frameResult.upperWickIntensity > 0.45f && frameResult.lowerWickIntensity < 0.20f) {
                bearishScore += 0.25f
                factors.add("Upper wick rejection (Bearish selling pressure +0.25)")
            }
        }

        // Factor B: OHLC Candle sequence price action (if candles available)
        if (latestCandles.isNotEmpty()) {
            val lastCandle = latestCandles.last()

            // Doji filter: candle body < 15% total range
            if (lastCandle.isDoji) {
                factors.add("Previous candle is a Doji; market direction indecisive")
            } else if (lastCandle.isBullish) {
                bullishScore += 0.35f
                factors.add("Recent 1M close was Bullish (+0.35)")
            } else if (lastCandle.isBearish) {
                bearishScore += 0.35f
                factors.add("Recent 1M close was Bearish (+0.35)")
            }

            // Rejection pin bars in OHLC
            if (lastCandle.lowerWick > lastCandle.bodySize * 2.0 && lastCandle.bodySize > 0) {
                bullishScore += 0.20f
                factors.add("Bullish hammer / pin bar formed (+0.20)")
            } else if (lastCandle.upperWick > lastCandle.bodySize * 2.0 && lastCandle.bodySize > 0) {
                bearishScore += 0.20f
                factors.add("Bearish shooting star formed (+0.20)")
            }
        }

        // Factor C: Conflict resolution
        val scoreDiff = abs(bullishScore - bearishScore)
        val maxScore = kotlin.math.max(bullishScore, bearishScore)

        if (bullishScore > 0.25f && bearishScore > 0.25f && scoreDiff < 0.20f) {
            return SignalResult(
                instrumentSymbol = instrument.symbol,
                marketType = instrument.marketType,
                signal = SignalType.NO_TRADE,
                confidence = 0.35f,
                isCalibrated = false,
                dataStatus = dataStatus,
                reason = "Conflicting indicators detected (Bullish $bullishScore vs Bearish $bearishScore). Filtered to NO TRADE.",
                candleTimeMs = currentCandleMinute,
                analysisTimeMs = now,
                outcome = Outcome.SKIPPED,
                detectedCountdownSeconds = secondsRemaining,
                indicatorsSummary = factors.joinToString("; ")
            )
        }

        // Determine output
        val selectedSignal: SignalType
        val finalConfidence: Float
        val reason: String

        if (bullishScore >= config.minConfidenceThreshold && bullishScore > bearishScore) {
            selectedSignal = SignalType.UP
            finalConfidence = minOf(bullishScore, 0.88f)
            reason = "Bullish momentum aligned across candle body and wick pressures."
        } else if (bearishScore >= config.minConfidenceThreshold && bearishScore > bullishScore) {
            selectedSignal = SignalType.DOWN
            finalConfidence = minOf(bearishScore, 0.88f)
            reason = "Bearish continuation aligned across candle body and selling pressure."
        } else {
            selectedSignal = SignalType.NO_TRADE
            finalConfidence = maxScore
            reason = "Confidence threshold (${(config.minConfidenceThreshold * 100).toInt()}%) not met (Score: ${(maxScore * 100).toInt()}%). Neutral stance."
        }

        val entryPrice = latestCandles.lastOrNull()?.close

        return SignalResult(
            instrumentSymbol = instrument.symbol,
            marketType = instrument.marketType,
            signal = selectedSignal,
            confidence = finalConfidence,
            isCalibrated = false, // Heuristic score, not statistically calibrated probability
            dataStatus = dataStatus,
            reason = reason,
            candleTimeMs = currentCandleMinute,
            analysisTimeMs = now,
            outcome = if (selectedSignal == SignalType.NO_TRADE) Outcome.SKIPPED else Outcome.PENDING,
            entryPrice = entryPrice,
            detectedCountdownSeconds = secondsRemaining,
            indicatorsSummary = factors.joinToString("; ")
        )
    }
}
