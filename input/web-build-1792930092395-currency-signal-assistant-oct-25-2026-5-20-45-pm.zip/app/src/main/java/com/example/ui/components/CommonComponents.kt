package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import com.example.data.model.SignalType
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.OtcBadgeBg
import com.example.ui.theme.OtcBadgeColor
import com.example.ui.theme.RealBadgeBg
import com.example.ui.theme.RealBadgeColor
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalAmberBg
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalGreenBg
import com.example.ui.theme.SignalRed
import com.example.ui.theme.SignalRedBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MarketBadge(marketType: MarketType, modifier: Modifier = Modifier) {
    val (bgColor, textColor, label) = when (marketType) {
        MarketType.REAL -> Triple(RealBadgeBg, RealBadgeColor, "REAL")
        MarketType.OTC -> Triple(OtcBadgeBg, OtcBadgeColor, "OTC")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun SignalBadge(signal: SignalType, modifier: Modifier = Modifier) {
    val (bgColor, textColor, label) = when (signal) {
        SignalType.UP -> Triple(SignalGreenBg, SignalGreen, "CALL (UP) ▲")
        SignalType.DOWN -> Triple(SignalRedBg, SignalRed, "PUT (DOWN) ▼")
        SignalType.NO_TRADE -> Triple(SignalAmberBg, SignalAmber, "NO TRADE ━")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun StatusPill(status: DataSourceStatus, modifier: Modifier = Modifier) {
    val (dotColor, text) = when (status) {
        DataSourceStatus.LIVE -> Pair(SignalGreen, "LIVE FEED")
        DataSourceStatus.SCREEN_ONLY -> Pair(Color(0xFF00E5FF), "SCREEN-ONLY")
        DataSourceStatus.STALE -> Pair(SignalAmber, "STALE")
        DataSourceStatus.UNAVAILABLE -> Pair(SignalRed, "UNAVAILABLE")
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceVariant)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = text,
            color = TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun EducationalDisclaimerCard(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161F33)),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Educational Disclaimer",
                tint = Color(0xFF00E5FF),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Educational market observation only. This application never places trades automatically, never connects to trading accounts, and does not request passwords or cookies.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    }
}
