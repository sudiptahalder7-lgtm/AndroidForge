package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.local.AppDatabase
import com.example.data.registry.InstrumentRegistry
import com.example.service.AppStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CurrencySignalApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { AppDatabase.getDatabase(this) }
    val stateManager by lazy { AppStateManager.getInstance(this, database) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()

        // Seed initial OTC and REAL registry in background
        applicationScope.launch {
            InstrumentRegistry.seedDatabaseIfEmpty(database.instrumentDao())
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val observationChannel = NotificationChannel(
                CHANNEL_SCREEN_OBSERVATION,
                "Screen Observation Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifies when background screen observation for candle analysis is active"
                setShowBadge(false)
            }

            val signalChannel = NotificationChannel(
                CHANNEL_SIGNAL_ALERTS,
                "Candle Signal Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High priority notifications when new trading signals are generated"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(observationChannel)
            notificationManager.createNotificationChannel(signalChannel)
        }
    }

    companion object {
        const val CHANNEL_SCREEN_OBSERVATION = "screen_observation_channel"
        const val CHANNEL_SIGNAL_ALERTS = "candle_signal_alerts_channel"

        private var instance: CurrencySignalApp? = null
        fun getInstance(): CurrencySignalApp = instance
            ?: throw IllegalStateException("Application not initialized")
    }
}
