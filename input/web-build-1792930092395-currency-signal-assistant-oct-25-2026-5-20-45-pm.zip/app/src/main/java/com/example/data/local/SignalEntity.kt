package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import com.example.data.model.Outcome
import com.example.data.model.SignalResult
import com.example.data.model.SignalType

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val instrumentSymbol: String,
    val marketType: String,             // "REAL" or "OTC"
    val signalType: String,             // "UP", "DOWN", "NO_TRADE"
    val confidence: Float,
    val isCalibrated: Boolean,
    val dataStatus: String,             // "LIVE", "STALE", "UNAVAILABLE", "SCREEN_ONLY"
    val reason: String,
    val candleTimeMs: Long,
    val analysisTimeMs: Long,
    val outcome: String,                // "PENDING", "WIN", "LOSS", "PUSH", "SKIPPED"
    val entryPrice: Double?,
    val exitPrice: Double?,
    val detectedCountdownSeconds: Int,
    val indicatorsSummary: String
) {
    fun toDomain(): SignalResult = SignalResult(
        id = id,
        instrumentSymbol = instrumentSymbol,
        marketType = try { MarketType.valueOf(marketType) } catch (e: Exception) { MarketType.OTC },
        signal = try { SignalType.valueOf(signalType) } catch (e: Exception) { SignalType.NO_TRADE },
        confidence = confidence,
        isCalibrated = isCalibrated,
        dataStatus = try { DataSourceStatus.valueOf(dataStatus) } catch (e: Exception) { DataSourceStatus.SCREEN_ONLY },
        reason = reason,
        candleTimeMs = candleTimeMs,
        analysisTimeMs = analysisTimeMs,
        outcome = try { Outcome.valueOf(outcome) } catch (e: Exception) { Outcome.PENDING },
        entryPrice = entryPrice,
        exitPrice = exitPrice,
        detectedCountdownSeconds = detectedCountdownSeconds,
        indicatorsSummary = indicatorsSummary
    )

    companion object {
        fun fromDomain(domain: SignalResult): SignalEntity = SignalEntity(
            id = domain.id,
            instrumentSymbol = domain.instrumentSymbol,
            marketType = domain.marketType.name,
            signalType = domain.signal.name,
            confidence = domain.confidence,
            isCalibrated = domain.isCalibrated,
            dataStatus = domain.dataStatus.name,
            reason = domain.reason,
            candleTimeMs = domain.candleTimeMs,
            analysisTimeMs = domain.analysisTimeMs,
            outcome = domain.outcome.name,
            entryPrice = domain.entryPrice,
            exitPrice = domain.exitPrice,
            detectedCountdownSeconds = domain.detectedCountdownSeconds,
            indicatorsSummary = domain.indicatorsSummary
        )
    }
}
