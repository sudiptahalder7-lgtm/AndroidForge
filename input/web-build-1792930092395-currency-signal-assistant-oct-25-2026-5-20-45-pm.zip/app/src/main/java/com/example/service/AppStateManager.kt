package com.example.service

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import com.example.cv.ChartAnalyzer
import com.example.cv.FrameAnalysisResult
import com.example.data.local.AppDatabase
import com.example.data.local.SignalEntity
import com.example.data.market.LiveForexMarketAdapter
import com.example.data.market.ScreenOnlyMarketAdapter
import com.example.data.model.CurrencyInstrument
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import com.example.data.model.ScreenObservationState
import com.example.data.model.SignalResult
import com.example.data.model.SignalType
import com.example.engine.CandleTimer
import com.example.engine.CandleTimerListener
import com.example.engine.PaperTestingManager
import com.example.engine.SignalEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicReference

class AppStateManager private constructor(
    private val context: Context,
    private val database: AppDatabase
) : CandleTimerListener {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Components
    val chartAnalyzer = ChartAnalyzer()
    val screenOnlyAdapter = ScreenOnlyMarketAdapter()
    val liveForexAdapter = LiveForexMarketAdapter()
    val signalEngine = SignalEngine()
    val paperTestingManager = PaperTestingManager(database.signalDao())

    val candleTimer = CandleTimer(
        timingToleranceSeconds = 1.5f,
        listener = this
    )

    // StateFlows
    private val _selectedInstrument = MutableStateFlow(
        CurrencyInstrument(
            symbol = "EUR/USD",
            canonicalSymbol = "EURUSD",
            displayName = "Euro / US Dollar",
            marketType = MarketType.REAL,
            sourceProvider = "INTERBANK_SPOT",
            isAvailable = true,
            isFavorite = true,
            lastUpdatedMs = System.currentTimeMillis(),
            validationStatus = "Verified Real Market"
        )
    )
    val selectedInstrument: StateFlow<CurrencyInstrument> = _selectedInstrument.asStateFlow()

    private val _observationState = MutableStateFlow(ScreenObservationState())
    val observationState: StateFlow<ScreenObservationState> = _observationState.asStateFlow()

    private val _latestSignal = MutableStateFlow<SignalResult?>(null)
    val latestSignal: StateFlow<SignalResult?> = _latestSignal.asStateFlow()

    private val _isPaperTestingEnabled = MutableStateFlow(true)
    val isPaperTestingEnabled: StateFlow<Boolean> = _isPaperTestingEnabled.asStateFlow()

    private val _samplingFps = MutableStateFlow(2.0f)
    val samplingFps: StateFlow<Float> = _samplingFps.asStateFlow()

    private val _timingTolerance = MutableStateFlow(1.5f)
    val timingTolerance: StateFlow<Float> = _timingTolerance.asStateFlow()

    private val _customCropRect = MutableStateFlow<Rect?>(null)
    val customCropRect: StateFlow<Rect?> = _customCropRect.asStateFlow()

    private val _latestFrameBitmap = MutableStateFlow<Bitmap?>(null)
    val latestFrameBitmap: StateFlow<Bitmap?> = _latestFrameBitmap.asStateFlow()

    // Cached MediaProjection intent from system prompt
    var mediaProjectionResultCode: Int = 0
    var mediaProjectionData: Intent? = null

    private val lastFrameResult = AtomicReference<FrameAnalysisResult?>(null)

    fun setSelectedInstrument(instrument: CurrencyInstrument) {
        _selectedInstrument.value = instrument
    }

    fun setPaperTestingEnabled(enabled: Boolean) {
        _isPaperTestingEnabled.value = enabled
    }

    fun setSamplingFps(fps: Float) {
        _samplingFps.value = fps
    }

    fun setTimingTolerance(tolerance: Float) {
        _timingTolerance.value = tolerance
        candleTimer.timingToleranceSeconds = tolerance
    }

    fun setCustomCropRect(rect: Rect?) {
        _customCropRect.value = rect
    }

    fun updateCapturingState(isCapturing: Boolean, errorMessage: String? = null) {
        _observationState.value = _observationState.value.copy(
            isCapturing = isCapturing,
            errorMessage = errorMessage
        )
        if (isCapturing) {
            candleTimer.start()
        } else {
            candleTimer.stop()
        }
    }

    fun updateOverlayState(isShowing: Boolean) {
        _observationState.value = _observationState.value.copy(isOverlayShowing = isShowing)
    }

    /**
     * Ingests a new frame captured by MediaProjection ImageReader.
     */
    fun processCapturedBitmap(bitmap: Bitmap) {
        val analysis = chartAnalyzer.analyzeFrame(bitmap, _customCropRect.value)
        lastFrameResult.set(analysis)
        _latestFrameBitmap.value = bitmap

        // Feed to screen only adapter
        val estimatedPrice = if (analysis.bullishPixelCount > analysis.bearishPixelCount) 1.0001 else 0.9999
        val isBullish = analysis.bullishPixelCount >= analysis.bearishPixelCount
        screenOnlyAdapter.updateObservedFrame(estimatedPrice, isBullish, System.currentTimeMillis())

        val now = System.currentTimeMillis()
        _observationState.value = _observationState.value.copy(
            lastScanTimeMs = now,
            lastObservedCandleColor = when (analysis.estimatedCandleTrend) {
                "BULLISH" -> "BULLISH_GREEN"
                "BEARISH" -> "BEARISH_RED"
                "DOJI" -> "DOJI"
                else -> "NONE"
            },
            fps = _samplingFps.value,
            errorMessage = if (analysis.isScreenObscured) "Screen Obscured / Chart not visible" else null
        )

        candleTimer.onFrameAnalyzed(analysis)
    }

    // --- CandleTimerListener callbacks ---

    override fun onSecondsRemainingChanged(
        secondsRemaining: Int,
        isFinalSevenSeconds: Boolean,
        timingQuality: String
    ) {
        _observationState.value = _observationState.value.copy(
            candleSecondsRemaining = secondsRemaining,
            isFinalAnalysisWindow = isFinalSevenSeconds,
            timingQuality = timingQuality
        )
    }

    override fun onFinalSevenSecondsWindowStarted(candleTimestampMs: Long) {
        // Boost sampling rate temporarily during the final 7 seconds
        // Handled dynamically by ImageReader schedule
    }

    override fun onTriggerSignalGeneration(candleTimestampMs: Long, secondsRemaining: Int) {
        scope.launch {
            generateSignal(candleTimestampMs, secondsRemaining)
        }
    }

    override fun onCandleClosed(candleTimestampMs: Long) {
        if (_isPaperTestingEnabled.value) {
            scope.launch {
                val lastFrame = lastFrameResult.get()
                val priceEstimate = if (lastFrame != null && lastFrame.bullishPixelCount > lastFrame.bearishPixelCount) {
                    1.0002
                } else {
                    0.9998
                }
                paperTestingManager.evaluatePendingSignals(priceEstimate)
            }
        }
    }

    private suspend fun generateSignal(candleTimestampMs: Long, secondsRemaining: Int) {
        val instrument = _selectedInstrument.value
        val frameResult = lastFrameResult.get()

        // Choose appropriate adapter: if OTC, must use ScreenOnly adapter; if REAL, try live feed with screen fallback
        val adapter = if (instrument.marketType == MarketType.OTC) {
            screenOnlyAdapter
        } else {
            liveForexAdapter
        }

        val candlesResult = adapter.getCandles(instrument.symbol, instrument.marketType, "M1", 5)
        val candles = candlesResult.getOrDefault(emptyList())

        val dataStatus = if (instrument.marketType == MarketType.OTC) {
            screenOnlyAdapter.checkFreshness(_observationState.value.lastScanTimeMs)
        } else {
            liveForexAdapter.checkFreshness(_observationState.value.lastScanTimeMs)
        }

        val result = signalEngine.evaluateSignal(
            instrument = instrument,
            latestCandles = candles,
            frameResult = frameResult,
            dataStatus = dataStatus,
            timingQuality = _observationState.value.timingQuality,
            secondsRemaining = secondsRemaining,
            isTimingReliable = candleTimer.isTimingReliable()
        )

        _latestSignal.value = result

        // Persist to Room database
        val entity = SignalEntity.fromDomain(result)
        val insertedId = database.signalDao().insertSignal(entity)
        _latestSignal.value = result.copy(id = insertedId)
    }

    companion object {
        @Volatile
        private var INSTANCE: AppStateManager? = null

        fun getInstance(context: Context, database: AppDatabase): AppStateManager {
            return INSTANCE ?: synchronized(this) {
                val instance = AppStateManager(context.applicationContext, database)
                INSTANCE = instance
                instance
            }
        }
    }
}
