package com.example.data.market

import com.example.data.model.CandleData
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType

interface MarketDataProvider {
    val providerId: String
    val providerName: String
    val isOtcSupported: Boolean

    suspend fun getCandles(
        symbol: String,
        marketType: MarketType,
        timeframe: String = "M1",
        count: Int = 10
    ): Result<List<CandleData>>

    suspend fun getLatestQuote(
        symbol: String,
        marketType: MarketType
    ): Result<QuoteData>

    fun checkFreshness(lastUpdateTimestampMs: Long): DataSourceStatus
}

data class QuoteData(
    val symbol: String,
    val marketType: MarketType,
    val bid: Double,
    val ask: Double,
    val lastPrice: Double,
    val timestampMs: Long,
    val provider: String,
    val status: DataSourceStatus
)
