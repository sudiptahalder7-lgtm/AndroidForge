package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrencyInstrument
import com.example.ui.MarketFilterTab
import com.example.ui.components.MarketBadge
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CurrencySelectorScreen(
    instruments: List<CurrencyInstrument>,
    selectedInstrument: CurrencyInstrument,
    searchQuery: String,
    selectedTab: MarketFilterTab,
    onSearchQueryChanged: (String) -> Unit,
    onTabSelected: (MarketFilterTab) -> Unit,
    onInstrumentSelected: (CurrencyInstrument) -> Unit,
    onToggleFavorite: (CurrencyInstrument) -> Unit,
    onImportAssetList: (String) -> Int
) {
    var showImportDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Search bar & Import action
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChanged,
                modifier = Modifier
                    .weight(1f)
                    .testTag("currency_search_input"),
                placeholder = { Text("Search currency pairs...", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextSecondary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AccentCyan,
                    unfocusedBorderColor = DarkCardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = { showImportDialog = true },
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurfaceVariant)
                    .size(50.dp)
                    .testTag("import_assets_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Import Pairs", tint = AccentCyan)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tabs: ALL, REAL, OTC, FAVORITES
        ScrollableTabRow(
            selectedTabIndex = selectedTab.ordinal,
            containerColor = Color.Transparent,
            contentColor = AccentCyan,
            edgePadding = 0.dp,
            divider = {}
        ) {
            MarketFilterTab.values().forEach { tab ->
                val isSelected = selectedTab == tab
                Tab(
                    selected = isSelected,
                    onClick = { onTabSelected(tab) },
                    text = {
                        Text(
                            text = when (tab) {
                                MarketFilterTab.ALL -> "ALL PAIRS"
                                MarketFilterTab.REAL -> "REAL MARKET"
                                MarketFilterTab.OTC -> "OTC (QUOTEX)"
                                MarketFilterTab.FAVORITES -> "FAVORITES"
                            },
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) AccentCyan else TextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Instrument List
        Text(
            text = "${instruments.size} Instruments Available",
            color = TextMuted,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(instruments, key = { it.symbol }) { instrument ->
                InstrumentRowItem(
                    instrument = instrument,
                    isSelected = instrument.symbol == selectedInstrument.symbol,
                    onSelect = { onInstrumentSelected(instrument) },
                    onToggleFavorite = { onToggleFavorite(instrument) }
                )
            }
        }
    }

    if (showImportDialog) {
        ImportAssetDialog(
            onDismiss = { showImportDialog = false },
            onImport = { csv ->
                val count = onImportAssetList(csv)
                showImportDialog = false
            }
        )
    }
}

@Composable
private fun InstrumentRowItem(
    instrument: CurrencyInstrument,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("instrument_row_${instrument.canonicalSymbol}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DarkSurfaceVariant else DarkSurface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) AccentCyan else DarkCardBorder
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = instrument.symbol,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    MarketBadge(marketType = instrument.marketType)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = instrument.displayName,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Text(
                    text = "Source: ${instrument.sourceProvider} • ${instrument.validationStatus}",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = AccentCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (instrument.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (instrument.isFavorite) SignalAmber else TextMuted
                )
            }
        }
    }
}

@Composable
private fun ImportAssetDialog(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var textInput by remember {
        mutableStateOf(
            "# Format: SYMBOL,MARKET_TYPE,DISPLAY_NAME\n" +
            "USD/TRY,OTC,US Dollar / Turkish Lira\n" +
            "EUR/PLN,REAL,Euro / Polish Zloty"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Import Custom Asset List", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text(
                    text = "Paste comma-separated currency pairs below. Specify MARKET_TYPE as REAL or OTC.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentCyan,
                        unfocusedBorderColor = DarkCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onImport(textInput) }) {
                Text("Import", color = AccentCyan, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = DarkSurface
    )
}
