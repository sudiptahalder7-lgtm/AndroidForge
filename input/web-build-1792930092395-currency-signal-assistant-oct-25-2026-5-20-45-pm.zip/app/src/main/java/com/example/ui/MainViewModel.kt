package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.CurrencySignalApp
import com.example.data.local.InstrumentEntity
import com.example.data.model.CurrencyInstrument
import com.example.data.model.MarketType
import com.example.data.model.SignalResult
import com.example.data.registry.InstrumentRegistry
import com.example.engine.PaperTestSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MarketFilterTab {
    ALL,
    REAL,
    OTC,
    FAVORITES
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as CurrencySignalApp
    private val stateManager = app.stateManager
    private val database = app.database

    // State from central AppStateManager
    val selectedInstrument: StateFlow<CurrencyInstrument> = stateManager.selectedInstrument
    val observationState = stateManager.observationState
    val latestSignal: StateFlow<SignalResult?> = stateManager.latestSignal
    val isPaperTestingEnabled = stateManager.isPaperTestingEnabled
    val samplingFps = stateManager.samplingFps
    val timingTolerance = stateManager.timingTolerance
    val latestFrameBitmap = stateManager.latestFrameBitmap

    // Registry Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(MarketFilterTab.ALL)
    val selectedTab = _selectedTab.asStateFlow()

    // Instruments from Room
    val allInstruments: StateFlow<List<CurrencyInstrument>> = database.instrumentDao()
        .getAllInstruments()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Instruments
    val filteredInstruments: StateFlow<List<CurrencyInstrument>> = combine(
        allInstruments,
        searchQuery,
        selectedTab
    ) { instruments, query, tab ->
        instruments.filter { inst ->
            val matchesQuery = query.isBlank() ||
                    inst.symbol.contains(query, ignoreCase = true) ||
                    inst.displayName.contains(query, ignoreCase = true)

            val matchesTab = when (tab) {
                MarketFilterTab.ALL -> true
                MarketFilterTab.REAL -> inst.marketType == MarketType.REAL
                MarketFilterTab.OTC -> inst.marketType == MarketType.OTC
                MarketFilterTab.FAVORITES -> inst.isFavorite
            }

            matchesQuery && matchesTab
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Signal History from Room
    val signalHistory: StateFlow<List<SignalResult>> = database.signalDao()
        .getAllSignals()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Paper test summary
    val paperTestSummary: StateFlow<PaperTestSummary> = signalHistory.map { history ->
        stateManager.paperTestingManager.calculateSummary(history)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        PaperTestSummary(0, 0, 0, 0, 0, 0, 0f, 0, "")
    )

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedTab(tab: MarketFilterTab) {
        _selectedTab.value = tab
    }

    fun selectInstrument(instrument: CurrencyInstrument) {
        stateManager.setSelectedInstrument(instrument)
    }

    fun toggleFavorite(instrument: CurrencyInstrument) {
        viewModelScope.launch {
            val newFav = !instrument.isFavorite
            database.instrumentDao().updateFavorite(instrument.symbol, newFav)
        }
    }

    fun clearSignalHistory() {
        viewModelScope.launch {
            database.signalDao().clearAllSignals()
        }
    }

    fun importCustomPairs(csvText: String): Int {
        val parsed = InstrumentRegistry.parseCustomAssetList(csvText)
        if (parsed.isNotEmpty()) {
            viewModelScope.launch {
                parsed.forEach { item ->
                    database.instrumentDao().insertOrUpdate(InstrumentEntity.fromDomain(item))
                }
            }
        }
        return parsed.size
    }

    fun setPaperTesting(enabled: Boolean) {
        stateManager.setPaperTestingEnabled(enabled)
    }

    fun setSamplingRate(fps: Float) {
        stateManager.setSamplingFps(fps)
    }

    fun setTimingToleranceSeconds(tolerance: Float) {
        stateManager.setTimingTolerance(tolerance)
    }
}
