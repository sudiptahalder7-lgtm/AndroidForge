package com.example

import com.example.data.market.LiveForexMarketAdapter
import com.example.data.model.MarketType
import com.example.data.registry.InstrumentRegistry
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InstrumentRegistryTest {

    @Test
    fun testOtcSeedContainsFortyOneScreenshotPairs() {
        assertEquals("OTC registry must contain exactly 41 screenshot-derived pairs", 41, InstrumentRegistry.OTC_SEED_SYMBOLS.size)

        val symbols = InstrumentRegistry.OTC_SEED_SYMBOLS.map { it.first }
        assertTrue(symbols.contains("USD/DZD"))
        assertTrue(symbols.contains("USD/INR"))
        assertTrue(symbols.contains("EUR/USD"))
        assertTrue(symbols.contains("GBP/USD"))
        assertTrue(symbols.contains("EUR/NZD"))
        assertTrue(symbols.contains("USD/NGN"))
        assertTrue(symbols.contains("USD/ARS"))
    }

    @Test
    fun testRealAndOtcAreStrictlySeparate() {
        val initialEntities = InstrumentRegistry.createInitialEntities()
        val otcEntities = initialEntities.filter { it.marketType == MarketType.OTC.name }
        val realEntities = initialEntities.filter { it.marketType == MarketType.REAL.name }

        assertEquals(41, otcEntities.size)
        assertEquals(21, realEntities.size)

        otcEntities.forEach { entity ->
            assertTrue("OTC entity must have OTC market type", entity.marketType == "OTC")
            assertTrue("OTC symbol must have (OTC) label or distinction", entity.symbol.contains("OTC"))
            assertTrue("OTC validation status must note screenshot-derived unverified feed",
                entity.validationStatus.contains("Screenshot-derived"))
        }

        realEntities.forEach { entity ->
            assertEquals("REAL", entity.marketType)
            assertEquals("Verified Real Market", entity.validationStatus)
        }
    }

    @Test
    fun testLiveForexAdapterRejectsOtcPairs() = runBlocking {
        val adapter = LiveForexMarketAdapter()
        assertFalse("Live Forex Adapter cannot support OTC pairs", adapter.isOtcSupported)

        val result = adapter.getCandles("EUR/USD (OTC)", MarketType.OTC)
        assertTrue("Attempting to fetch OTC quotes from Real provider must fail", result.isFailure)
    }

    @Test
    fun testCustomAssetListCsvParsing() {
        val csv = """
            # User defined watchlist
            USD/TRY,OTC,US Dollar / Turkish Lira
            EUR/PLN,REAL,Euro / Polish Zloty
        """.trimIndent()

        val parsed = InstrumentRegistry.parseCustomAssetList(csv)
        assertEquals(2, parsed.size)

        val tryPair = parsed.first { it.canonicalSymbol == "USDTRY" }
        assertEquals(MarketType.OTC, tryPair.marketType)
        assertTrue(tryPair.symbol.contains("(OTC)"))

        val plnPair = parsed.first { it.canonicalSymbol == "EURPLN" }
        assertEquals(MarketType.REAL, plnPair.marketType)
        assertEquals("EUR/PLN", plnPair.symbol)
    }
}
