package com.example

import com.example.cv.FrameAnalysisResult
import com.example.engine.CandleTimer
import com.example.engine.CandleTimerListener
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class CandleTimerTest {

    private var triggeredSignal = false
    private var triggeredFinalWindow = false
    private var candleClosedCount = 0
    private var lastObservedSeconds = 60

    private val testListener = object : CandleTimerListener {
        override fun onSecondsRemainingChanged(secondsRemaining: Int, isFinalSevenSeconds: Boolean, timingQuality: String) {
            lastObservedSeconds = secondsRemaining
        }

        override fun onFinalSevenSecondsWindowStarted(candleTimestampMs: Long) {
            triggeredFinalWindow = true
        }

        override fun onTriggerSignalGeneration(candleTimestampMs: Long, secondsRemaining: Int) {
            triggeredSignal = true
        }

        override fun onCandleClosed(candleTimestampMs: Long) {
            candleClosedCount++
        }
    }

    private lateinit var timer: CandleTimer

    @Before
    fun setup() {
        triggeredSignal = false
        triggeredFinalWindow = false
        candleClosedCount = 0
        timer = CandleTimer(timingToleranceSeconds = 1.5f, listener = testListener)
    }

    @Test
    fun testInitialStartAndSecondsCalculation() {
        timer.start()
        assertTrue(timer.isRunning)

        val seconds = timer.calculateSecondsRemaining()
        assertTrue("Seconds remaining should be between 0 and 60", seconds in 0..60)
    }

    @Test
    fun testFinalSevenSecondsTrigger() {
        timer.start()

        // Simulate frame with countdown detected at 5 seconds
        val frameResult = FrameAnalysisResult(
            isValidChart = true,
            bullishPixelCount = 500,
            bearishPixelCount = 100,
            upperWickIntensity = 0.1f,
            lowerWickIntensity = 0.5f,
            detectedSecondsRemaining = 5,
            estimatedCandleTrend = "BULLISH",
            isScreenObscured = false,
            analysisDurationMs = 12L
        )

        timer.onFrameAnalyzed(frameResult)
        assertTrue("Final 7-second window should have triggered", triggeredFinalWindow)
    }

    @Test
    fun testSignalTriggerAtTMinusOne() {
        timer.start()

        // Simulate frame with countdown at 1 second
        val frameResult = FrameAnalysisResult(
            isValidChart = true,
            bullishPixelCount = 500,
            bearishPixelCount = 100,
            upperWickIntensity = 0.1f,
            lowerWickIntensity = 0.5f,
            detectedSecondsRemaining = 1,
            estimatedCandleTrend = "BULLISH",
            isScreenObscured = false,
            analysisDurationMs = 10L
        )

        timer.onFrameAnalyzed(frameResult)
        assertTrue("Signal generation should trigger at T-1s", triggeredSignal)
    }

    @Test
    fun testTimingDriftTolerance() {
        timer.start()
        assertTrue("Fresh timer should be reliable", timer.isTimingReliable())
    }
}
