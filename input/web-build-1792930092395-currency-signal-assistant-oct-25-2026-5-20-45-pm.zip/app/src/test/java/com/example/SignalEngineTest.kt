package com.example

import com.example.cv.FrameAnalysisResult
import com.example.data.model.CandleData
import com.example.data.model.CurrencyInstrument
import com.example.data.model.DataSourceStatus
import com.example.data.model.MarketType
import com.example.data.model.SignalType
import com.example.engine.SignalEngine
import com.example.engine.SignalEngineConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class SignalEngineTest {

    private lateinit var engine: SignalEngine
    private val testInstrument = CurrencyInstrument(
        symbol = "EUR/USD (OTC)",
        canonicalSymbol = "EURUSD",
        displayName = "Euro / US Dollar (OTC)",
        marketType = MarketType.OTC,
        sourceProvider = "SCREEN_CAPTURE",
        isAvailable = true,
        validationStatus = "Screenshot-derived OTC"
    )

    @Before
    fun setup() {
        engine = SignalEngine(
            SignalEngineConfig(
                minConfidenceThreshold = 0.60f,
                maxTimingDriftSeconds = 1.5f
            )
        )
    }

    @Test
    fun testFailsSafeToNoTradeWhenDataIsStale() {
        val result = engine.evaluateSignal(
            instrument = testInstrument,
            latestCandles = emptyList(),
            frameResult = null,
            dataStatus = DataSourceStatus.STALE,
            timingQuality = "Synced",
            secondsRemaining = 1,
            isTimingReliable = true
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertTrue(result.reason.contains("stale", ignoreCase = true))
    }

    @Test
    fun testFailsSafeToNoTradeWhenScreenObscured() {
        val obscuredFrame = FrameAnalysisResult(
            isValidChart = false,
            bullishPixelCount = 0,
            bearishPixelCount = 0,
            upperWickIntensity = 0f,
            lowerWickIntensity = 0f,
            detectedSecondsRemaining = null,
            estimatedCandleTrend = "INCONCLUSIVE",
            isScreenObscured = true,
            analysisDurationMs = 5L
        )

        val result = engine.evaluateSignal(
            instrument = testInstrument,
            latestCandles = emptyList(),
            frameResult = obscuredFrame,
            dataStatus = DataSourceStatus.SCREEN_ONLY,
            timingQuality = "Synced",
            secondsRemaining = 1,
            isTimingReliable = true
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertTrue(result.reason.contains("obscured", ignoreCase = true))
    }

    @Test
    fun testFailsSafeToNoTradeWhenTimingIsUnreliable() {
        val result = engine.evaluateSignal(
            instrument = testInstrument,
            latestCandles = emptyList(),
            frameResult = null,
            dataStatus = DataSourceStatus.SCREEN_ONLY,
            timingQuality = "Drift Detected (2.2s)",
            secondsRemaining = 1,
            isTimingReliable = false
        )

        assertEquals(SignalType.NO_TRADE, result.signal)
        assertTrue(result.reason.contains("timing", ignoreCase = true))
    }

    @Test
    fun testBullishSignalGeneration() {
        val bullishFrame = FrameAnalysisResult(
            isValidChart = true,
            bullishPixelCount = 800,
            bearishPixelCount = 80,
            upperWickIntensity = 0.1f,
            lowerWickIntensity = 0.55f, // strong buying pressure rejection
            detectedSecondsRemaining = 1,
            estimatedCandleTrend = "BULLISH",
            isScreenObscured = false,
            analysisDurationMs = 8L
        )

        val candle = CandleData(
            timestampMs = System.currentTimeMillis() - 60000L,
            open = 1.0500,
            high = 1.0530,
            low = 1.0490,
            close = 1.0525
        )

        val result = engine.evaluateSignal(
            instrument = testInstrument,
            latestCandles = listOf(candle),
            frameResult = bullishFrame,
            dataStatus = DataSourceStatus.SCREEN_ONLY,
            timingQuality = "Synced",
            secondsRemaining = 1,
            isTimingReliable = true
        )

        assertEquals(SignalType.UP, result.signal)
        assertTrue("Confidence should be above threshold", result.confidence >= 0.60f)
        assertFalse("Heuristic score should not be marked as calibrated probability", result.isCalibrated)
    }

    @Test
    fun testBearishSignalGeneration() {
        val bearishFrame = FrameAnalysisResult(
            isValidChart = true,
            bullishPixelCount = 50,
            bearishPixelCount = 750,
            upperWickIntensity = 0.55f, // strong selling pressure rejection
            lowerWickIntensity = 0.1f,
            detectedSecondsRemaining = 1,
            estimatedCandleTrend = "BEARISH",
            isScreenObscured = false,
            analysisDurationMs = 8L
        )

        val candle = CandleData(
            timestampMs = System.currentTimeMillis() - 60000L,
            open = 1.0530,
            high = 1.0535,
            low = 1.0490,
            close = 1.0495
        )

        val result = engine.evaluateSignal(
            instrument = testInstrument,
            latestCandles = listOf(candle),
            frameResult = bearishFrame,
            dataStatus = DataSourceStatus.SCREEN_ONLY,
            timingQuality = "Synced",
            secondsRemaining = 1,
            isTimingReliable = true
        )

        assertEquals(SignalType.DOWN, result.signal)
        assertTrue("Confidence should be above threshold", result.confidence >= 0.60f)
    }
}
