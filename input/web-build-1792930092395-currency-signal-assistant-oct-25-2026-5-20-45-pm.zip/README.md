# Quotex Currency Signal Assistant

A native Android application designed for **educational market observation, candle timing analysis, and signal generation** for Android 12 (API 31) through Android 15+ (API 35+).

> **EDUCATIONAL NOTICE & DISCLAIMER**
> This application is strictly an educational tool for chart observation and signal analysis. It **never** executes trades automatically, **never** connects to or requests Quotex accounts/passwords, and **never** extracts session tokens or cookies. All trading carries risk of financial loss.

---

## 1. Key Features

- **MediaProjection Background Screen Observation:** Controlled, battery-conscious screen capture with explicit system consent prompt and foreground notification with instant STOP action.
- **Movable Floating Signal Overlay:** Compact and resizable overlay floating above other apps (including Quotex) using `WindowManager` and `TYPE_APPLICATION_OVERLAY`. Features START/STOP, MINIMIZE, and CLOSE controls.
- **One-Minute Candle Timer & Signal Scheduler:**
  - Synchronizes to the 1-minute candle lifecycle using monotonic clock timestamps (`SystemClock.elapsedRealtime()`).
  - Initiates active candle analysis during the final 7 seconds (T-7s to T-1s).
  - Displays signals approximately 1 second before the candle closes (T-1s).
  - De-duplicates signals so each 1-minute boundary generates at most one decision.
- **Strict REAL vs OTC Market Separation:**
  - **41 OTC pairs** seeded directly from Quotex screenshots, explicitly labeled `OTC` and marked as unverified screenshot-derived entries.
  - **REAL market pairs** maintained in a separate registry and validated against interbank spot feeds.
  - Third-party real-market feeds strictly refuse to serve synthetic OTC pairs.
- **Fail-Safe Signal Engine:**
  - Evaluates candlestick body/wick ratios, momentum, and multi-factor consensus.
  - Outputs `UP` (Call), `DOWN` (Put), or `NO TRADE`.
  - Automatically fails safe to `NO TRADE` when data is stale, the screen is obscured, candle boundaries drift, or indicators conflict.
  - Distinguishes heuristic scores from statistically calibrated probabilities.
- **Paper-Testing & Backtesting Mode:**
  - Simulates 1-minute candle expirations without placing real trades.
  - Compiles reports detailing total sample size, wins, losses, win rate %, and calculation methodology.
- **User Asset Import:**
  - Supports importing custom pair lists in CSV or text format.

---

## 2. Supported OTC Instrument Registry (41 Seed Pairs)

`USD/DZD`, `USD/INR`, `AUD/JPY`, `NZD/CHF`, `EUR/JPY`, `USD/CHF`, `AUD/CAD`, `USD/MXN`, `EUR/CHF`, `EUR/GBP`, `GBP/USD`, `USD/BRL`, `EUR/USD`, `USD/BDT`, `EUR/AUD`, `USD/IDR`, `AUD/USD`, `USD/COP`, `GBP/AUD`, `GBP/CAD`, `AUD/CHF`, `AUD/NZD`, `NZD/JPY`, `EUR/CAD`, `GBP/JPY`, `NZD/USD`, `CHF/JPY`, `USD/EGP`, `USD/JPY`, `USD/NGN`, `NZD/CAD`, `USD/ARS`, `USD/CAD`, `USD/PHP`, `USD/PKR`, `CAD/CHF`, `CAD/JPY`, `USD/ZAR`, `GBP/CHF`, `GBP/NZD`, `EUR/NZD`.

---

## 3. Architecture Overview

```
com.example/
├── CurrencySignalApp.kt            # Application initialization & notification channels
├── MainActivity.kt                 # Jetpack Compose UI with Edge-to-Edge & Navigation
├── data/
│   ├── model/                      # Domain models (MarketType, CandleData, SignalResult)
│   ├── local/                      # Room database (SignalDao, InstrumentDao, AppDatabase)
│   ├── registry/                   # InstrumentRegistry (41 OTC seed, REAL seed, CSV import)
│   └── market/                     # MarketDataProvider, ScreenOnlyAdapter, LiveForexAdapter
├── cv/
│   └── ChartAnalyzer.kt            # Fast sampling pixel vision (body & wick detection)
├── engine/
│   ├── CandleTimer.kt              # Monotonic 1-minute candle countdown & T-7s trigger
│   ├── SignalEngine.kt             # Multi-factor signal generation & fail-safe rules
│   └── PaperTestingManager.kt      # Simulated 1M outcome evaluation & win rate metrics
├── service/
│   ├── ScreenCaptureService.kt     # MediaProjection Foreground Service (type mediaProjection)
│   ├── FloatingOverlayService.kt   # TYPE_APPLICATION_OVERLAY movable window
│   └── AppStateManager.kt          # Central reactive StateFlow hub
└── ui/
    ├── theme/                      # Trading dark theme (Color, Theme, Typography)
    ├── components/                 # Badges, status indicators, disclaimers
    ├── screens/                    # Dashboard, Pairs, History, Permissions, Settings
    └── MainViewModel.kt            # ViewModel connecting StateManager & Room
```

---

## 4. Android 12 - 15+ System & Permission Requirements

| Permission | Purpose | System Behavior |
|------------|---------|-----------------|
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Screen capture service | Android 14+ requires service started before `getMediaProjection()` |
| `SYSTEM_ALERT_WINDOW` | Floating overlay window | Guided user grant in `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` |
| `POST_NOTIFICATIONS` | Foreground service notification | Android 13+ runtime permission prompt |
| `INTERNET` & `ACCESS_NETWORK_STATE` | Live real-market spot rates | Install-time normal permissions |

---

## 5. Building and Running

### Prerequisites
- Android Studio Ladybug / Meerkat (or newer)
- Android SDK 34 / 35 / 36
- JDK 17 or 21

### Build Instructions
```bash
# Compile and build the debug APK
gradle assembleDebug

# Run unit tests
gradle :app:testDebugUnitTest
```
