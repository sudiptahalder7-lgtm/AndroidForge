package com.qxvisionpro.domain

enum class SignalDirection { UP, DOWN, NO_TRADE }
enum class ValidationStatus {
    VALIDATED, CAPTURE_INVALID, STALE_FRAME, CHART_UNREADABLE, PAIR_MISMATCH,
    MARKET_UNVERIFIED, TIMING_UNVERIFIED, AMBIGUOUS, CONFLICTING_EVIDENCE,
    INSUFFICIENT_EVIDENCE, LATE, CAPTURE_FAILED, PERMISSION_DENIED
}
data class SignalResult(
    val pair: PairConfig,
    val direction: SignalDirection,
    val status: ValidationStatus,
    val reason: String,
    val capturedAtMillis: Long,
    val modelScore: Float? = null,
    val timeframeSeconds: Int = 60
) {
    init {
        require(modelScore == null || modelScore in 0f..1f)
        require(timeframeSeconds == 60)
        require(reason.isNotBlank())
    }
}
data class CaptureFrame(
    val width: Int,
    val height: Int,
    val capturedAtMillis: Long,
    val visiblePixelRatio: Float,
    val chartRegionConfigured: Boolean,
    val pairLabelVerified: Boolean,
    val marketModeVerified: Boolean,
    val candleBoundariesReadable: Boolean,
    val timingVerified: Boolean,
    val analysisCompletedAtMillis: Long
)
