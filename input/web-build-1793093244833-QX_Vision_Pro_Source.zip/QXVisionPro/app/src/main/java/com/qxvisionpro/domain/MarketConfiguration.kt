package com.qxvisionpro.domain

enum class MarketMode { REAL, OTC }
enum class CurrencyPair(val label: String) {
    GBP_USD("GBP/USD"), USD_JPY("USD/JPY"), USD_CHF("USD/CHF"),
    AUD_USD("AUD/USD"), USD_CAD("USD/CAD"), NZD_USD("NZD/USD"),
    EUR_GBP("EUR/GBP"), EUR_JPY("EUR/JPY"), EUR_AUD("EUR/AUD"),
    GBP_JPY("GBP/JPY")
}
data class PairConfig(val pair: CurrencyPair, val mode: MarketMode) {
    val displayName: String get() = if (mode == MarketMode.OTC) "${pair.label} (OTC)" else pair.label
}
object MarketConfiguration {
    val realPairs: List<PairConfig> = CurrencyPair.entries.map { PairConfig(it, MarketMode.REAL) }
    val otcPairs: List<PairConfig> = CurrencyPair.entries.map { PairConfig(it, MarketMode.OTC) }
    val allPairs: List<PairConfig> = realPairs + otcPairs

    init {
        require(realPairs.size == 10 && otcPairs.size == 10)
        require(realPairs.map { it.pair }.toSet().size == 10)
        require(otcPairs.map { it.pair }.toSet().size == 10)
        require(realPairs.all { it.mode == MarketMode.REAL })
        require(otcPairs.all { it.mode == MarketMode.OTC })
    }

    fun pairs(mode: MarketMode): List<PairConfig> = when (mode) {
        MarketMode.REAL -> realPairs
        MarketMode.OTC -> otcPairs
    }
}
