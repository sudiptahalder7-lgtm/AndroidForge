package com.qxvisionpro.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout
import android.graphics.Color
import android.graphics.Typeface

/**
 * Lightweight draggable overlay. Android's overlay permission must be granted by the user.
 * This service does not perform trades and does not claim analysis is running unless wired to a session.
 */
class FloatingOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var root: View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val bubble = TextView(this).apply {
            text = "QX"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(24, 180, 100))
            elevation = 12f
            setOnClickListener { showPanel() }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(58, 58, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 20; y = 180
        }
        bubble.setOnTouchListener(DragTouchListener(params))
        root = bubble
        windowManager?.addView(bubble, params)
    }

    private fun showPanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(Color.rgb(20, 29, 47))
            addView(TextView(context).apply {
                text = "QX Vision Pro\nChart analysis only\nState: waiting for app session"
                setTextColor(Color.WHITE); textSize = 15f
            })
            addView(TextView(context).apply {
                text = "Open app to configure • No auto-trading"
                setTextColor(Color.LTGRAY); textSize = 12f
            })
            setOnClickListener { startActivity(packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = 90; y = 180
        }
        try { windowManager?.addView(panel, p) } catch (e: Exception) {
            android.util.Log.e("QXOverlay", "Could not show overlay panel", e)
        }
    }

    override fun onDestroy() { root?.let { windowManager?.removeView(it) }; root = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private inner class DragTouchListener(private val params: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; return true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager?.updateViewLayout(v, params); return true
                }
                MotionEvent.ACTION_UP -> { v.performClick(); return true }
            }
            return false
        }
    }
}
