package com.qxvisionpro.capture

import android.graphics.Bitmap

data class ImageValidation(val valid: Boolean, val reason: String)

object ChartImageValidator {
    fun validate(bitmap: Bitmap?, configuredRegion: Boolean): ImageValidation {
        if (bitmap == null || bitmap.isRecycled || bitmap.width < 100 || bitmap.height < 100)
            return ImageValidation(false, "Capture is empty or too small")
        if (!configuredRegion) return ImageValidation(false, "Configure the chart region first")
        val sampleX = (0 until 10).map { bitmap.width * it / 10 }
        val sampleY = (0 until 10).map { bitmap.height * it / 10 }
        var luminanceSum = 0L
        var count = 0
        for (x in sampleX) for (y in sampleY) {
            val c = bitmap.getPixel(x, y)
            luminanceSum += ((android.graphics.Color.red(c) * 299 +
                android.graphics.Color.green(c) * 587 + android.graphics.Color.blue(c) * 114) / 1000)
            count++
        }
        val mean = luminanceSum.toFloat() / count.coerceAtLeast(1)
        if (mean < 2f || mean > 253f) return ImageValidation(false, "Image appears blank or clipped")
        return ImageValidation(true, "Basic image checks passed; chart readability still needs review")
    }
}
