package com.qxvisionpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF35E58C),
    secondary = Color(0xFF68A8FF),
    background = Color(0xFF0B1020),
    surface = Color(0xFF151E31),
    error = Color(0xFFFF5D6C),
    onPrimary = Color(0xFF062114),
    onBackground = Color.White,
    onSurface = Color.White
)
@Composable fun QXTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
