package com.qxvisionpro.ui

import androidx.lifecycle.ViewModel
import com.qxvisionpro.domain.*

class MainViewModel : ViewModel() {
    var mode: MarketMode = MarketMode.REAL
        private set
    var pair: PairConfig = MarketConfiguration.realPairs.first()
        private set
    var state: String = "Ready — capture permission required"
        private set

    fun setMode(value: MarketMode) {
        mode = value
        pair = MarketConfiguration.pairs(value).first()
        state = "Ready — ${value.name} market selected"
    }
    fun setPair(value: PairConfig) {
        require(value.mode == mode) { "Pair belongs to a different market mode" }
        pair = value
        state = "Ready — ${value.displayName} selected"
    }
    fun stop() { state = "Service stopped" }
}
