package com.qxvisionpro.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.qxvisionpro.domain.*
import com.qxvisionpro.ui.MainViewModel
import com.qxvisionpro.ui.theme.QXTheme

class MainActivity : ComponentActivity() {
    private val captureConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, com.qxvisionpro.service.ScreenCaptureService::class.java)
            startForegroundService(service)
            // Consent result must be passed into a session manager in the next integration step.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QXTheme {
                val vm: MainViewModel = viewModel()
                Dashboard(
                    mode = vm.mode, pair = vm.pair, state = vm.state,
                    onMode = vm::setMode, onPair = vm::setPair,
                    onCapture = {
                        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        captureConsent.launch(mgr.createScreenCaptureIntent())
                    },
                    onStop = vm::stop,
                    onOverlay = {
                        if (android.provider.Settings.canDrawOverlays(this)) {
                            startService(Intent(this, com.qxvisionpro.overlay.FloatingOverlayService::class.java))
                        } else startActivity(com.qxvisionpro.permissions.OverlayPermissionManager.settingsIntent(this))
                    }
                )
            }
        }
    }
}

@Composable
private fun Dashboard(
    mode: MarketMode, pair: PairConfig, state: String,
    onMode: (MarketMode) -> Unit, onPair: (PairConfig) -> Unit,
    onCapture: () -> Unit, onStop: () -> Unit, onOverlay: () -> Unit
) {
    var tab by remember { mutableStateOf("Dashboard") }
    var showPairs by remember { mutableStateOf(false) }
    Surface(Modifier.fillMaxSize(), color = Color(0xFF0B1020)) {
        LazyColumn(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Text("QX VISION PRO", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Native chart analysis assistant • 1 minute", color = Color(0xFF9CA8BD))
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151E31)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("CURRENT CONFIGURATION", color = Color(0xFF9CA8BD), style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = mode == MarketMode.REAL, onClick = { onMode(MarketMode.REAL) }, label = { Text("REAL") })
                            FilterChip(selected = mode == MarketMode.OTC, onClick = { onMode(MarketMode.OTC) }, label = { Text("OTC") })
                        }
                        OutlinedButton(onClick = { showPairs = !showPairs }, modifier = Modifier.fillMaxWidth()) {
                            Text(pair.displayName + "  •  Change pair")
                        }
                        if (showPairs) {
                            MarketConfiguration.pairs(mode).forEach { p ->
                                TextButton(onClick = { onPair(p); showPairs = false }) {
                                    Text(p.displayName, color = Color.White)
                                }
                            }
                        }
                        Text("Timeframe: 1 minute", color = Color.White)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151E31)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("SCAN STATUS", color = Color(0xFF9CA8BD))
                        Text(state, color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("Directional results are disabled until pair, market mode, chart region and candle timing can be verified.", color = Color(0xFFBAC4D5))
                        Button(onClick = onCapture, modifier = Modifier.fillMaxWidth()) { Text("Grant screen-capture consent") }
                        OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text("Stop scanning") }
                        OutlinedButton(onClick = onOverlay, modifier = Modifier.fillMaxWidth()) { Text("Enable floating overlay") }
                    }
                }
            }
            item {
                Text("Safety", color = Color.White, fontWeight = FontWeight.Bold)
                Text("This build is a project foundation. It does not automatically trade, does not fetch hidden Quotex data, and does not claim predictive accuracy.", color = Color(0xFF9CA8BD))
            }
        }
    }
}
