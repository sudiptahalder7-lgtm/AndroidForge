package com.qxvisionpro.data

import android.content.Context
import androidx.room.Room
import com.qxvisionpro.data.local.ScanHistoryDatabase
import com.qxvisionpro.data.local.ScanHistoryEntity
import com.qxvisionpro.domain.SignalResult
import kotlinx.coroutines.flow.Flow

class ScanRepository(context: Context) {
    private val db = Room.databaseBuilder(
        context.applicationContext, ScanHistoryDatabase::class.java, "qx_vision_history.db"
    ).build()
    fun history(mode: String): Flow<List<ScanHistoryEntity>> = db.dao().observeByMode(mode)
    suspend fun save(result: SignalResult) {
        db.dao().insert(
            ScanHistoryEntity(
                pairLabel = result.pair.pair.label,
                marketMode = result.pair.mode.name,
                timestampMillis = result.capturedAtMillis,
                direction = result.direction.name,
                validationStatus = result.status.name,
                noTradeReason = if (result.direction.name == "NO_TRADE") result.reason else "",
                modelScore = result.modelScore
            )
        )
    }
    suspend fun verifiedSampleCount(mode: String) = db.dao().verifiedSampleCount(mode)
}
