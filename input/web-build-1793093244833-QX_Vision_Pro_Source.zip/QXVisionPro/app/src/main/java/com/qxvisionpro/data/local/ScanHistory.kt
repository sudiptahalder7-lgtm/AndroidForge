package com.qxvisionpro.data.local

import androidx.room.*
import com.qxvisionpro.domain.MarketMode
import com.qxvisionpro.domain.SignalDirection
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "scan_history", indices = [Index(value = ["marketMode", "timestampMillis"])])
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val pairLabel: String,
    val marketMode: String,
    val timestampMillis: Long,
    val direction: String,
    val validationStatus: String,
    val noTradeReason: String,
    val modelScore: Float?,
    val verifiedOutcome: String? = null
)

@Dao
interface ScanHistoryDao {
    @Insert suspend fun insert(item: ScanHistoryEntity): Long
    @Query("SELECT * FROM scan_history WHERE marketMode = :mode ORDER BY timestampMillis DESC")
    fun observeByMode(mode: String): Flow<List<ScanHistoryEntity>>
    @Query("UPDATE scan_history SET verifiedOutcome = :outcome WHERE id = :id")
    suspend fun setVerifiedOutcome(id: Long, outcome: String)
    @Query("SELECT COUNT(*) FROM scan_history WHERE marketMode = :mode AND verifiedOutcome IS NOT NULL")
    suspend fun verifiedSampleCount(mode: String): Int
}

@Database(entities = [ScanHistoryEntity::class], version = 1, exportSchema = false)
abstract class ScanHistoryDatabase : RoomDatabase() {
    abstract fun dao(): ScanHistoryDao
}
