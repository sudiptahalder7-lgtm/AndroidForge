package com.qxvisionpro.domain.validation

import com.qxvisionpro.domain.*

class SignalDecisionEngine {
    fun validate(frame: CaptureFrame, selectedPair: PairConfig, nowMillis: Long): ValidationStatus {
        if (frame.width <= 0 || frame.height <= 0 || frame.visiblePixelRatio < 0.15f)
            return ValidationStatus.CAPTURE_INVALID
        if (nowMillis - frame.capturedAtMillis > 2_000L || frame.capturedAtMillis > nowMillis + 500L)
            return ValidationStatus.STALE_FRAME
        if (!frame.chartRegionConfigured || !frame.candleBoundariesReadable)
            return ValidationStatus.CHART_UNREADABLE
        if (!frame.pairLabelVerified) return ValidationStatus.PAIR_MISMATCH
        if (!frame.marketModeVerified) return ValidationStatus.MARKET_UNVERIFIED
        if (!frame.timingVerified) return ValidationStatus.TIMING_UNVERIFIED
        if (frame.analysisCompletedAtMillis > frame.capturedAtMillis + 6_000L)
            return ValidationStatus.LATE
        return ValidationStatus.VALIDATED
    }

    fun noTrade(pair: PairConfig, status: ValidationStatus, timestamp: Long, reason: String) =
        SignalResult(pair, SignalDirection.NO_TRADE, status, reason, timestamp)

    fun decide(
        pair: PairConfig,
        status: ValidationStatus,
        timestamp: Long,
        bullishEvidence: Float,
        bearishEvidence: Float
    ): SignalResult {
        if (status != ValidationStatus.VALIDATED)
            return noTrade(pair, status, timestamp, status.toReason())
        if (bullishEvidence !in 0f..1f || bearishEvidence !in 0f..1f)
            return noTrade(pair, ValidationStatus.INSUFFICIENT_EVIDENCE, timestamp, "Evidence score invalid")
        val margin = kotlin.math.abs(bullishEvidence - bearishEvidence)
        if (margin < 0.20f || maxOf(bullishEvidence, bearishEvidence) < 0.60f)
            return noTrade(pair, ValidationStatus.AMBIGUOUS, timestamp, "Visual evidence is weak or conflicting")
        val direction = if (bullishEvidence > bearishEvidence) SignalDirection.UP else SignalDirection.DOWN
        return SignalResult(pair, direction, ValidationStatus.VALIDATED, "Visual heuristic only; not a verified probability", timestamp, maxOf(bullishEvidence, bearishEvidence))
    }

    private fun ValidationStatus.toReason(): String = when (this) {
        ValidationStatus.CAPTURE_INVALID -> "Captured image is blank or invalid"
        ValidationStatus.STALE_FRAME -> "Captured frame is stale"
        ValidationStatus.CHART_UNREADABLE -> "Chart region or candle boundaries are unreadable"
        ValidationStatus.PAIR_MISMATCH -> "Visible pair does not match selected pair"
        ValidationStatus.MARKET_UNVERIFIED -> "REAL/OTC market mode could not be verified"
        ValidationStatus.TIMING_UNVERIFIED -> "Candle timing is unverified"
        ValidationStatus.LATE -> "Analysis completed too late"
        ValidationStatus.PERMISSION_DENIED -> "Screen-capture permission was denied"
        ValidationStatus.CAPTURE_FAILED -> "Screen capture failed"
        ValidationStatus.CONFLICTING_EVIDENCE -> "Visual evidence conflicts"
        ValidationStatus.INSUFFICIENT_EVIDENCE -> "Insufficient visual evidence"
        ValidationStatus.AMBIGUOUS -> "Candle structure is ambiguous"
        ValidationStatus.VALIDATED -> "Validation passed"
    }
}
