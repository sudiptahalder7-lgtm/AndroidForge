package com.qxvisionpro.permissions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object OverlayPermissionManager {
    fun isGranted(context: Context) = Settings.canDrawOverlays(context)
    fun settingsIntent(context: Context) = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}")
    )
}
