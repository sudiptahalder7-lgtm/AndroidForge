package com.qxvisionpro.capture

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

data class CandleFeature(
    val centerX: Int,
    val bodyHeightPx: Int,
    val wickHeightPx: Int,
    val bullishColorHint: Boolean?,
    val measured: Boolean = true
)

/**
 * Conservative color/geometry helper for a manually configured chart crop.
 * This is not a full candle detector and does not infer OHLC values.
 */
object CandleFeatureExtractor {
    fun sampleColorHint(bitmap: Bitmap, x: Int, top: Int, bottom: Int): Boolean? {
        if (bitmap.isRecycled || x !in 0 until bitmap.width) return null
        val y1 = top.coerceIn(0, bitmap.height - 1)
        val y2 = bottom.coerceIn(0, bitmap.height - 1)
        if (y2 <= y1) return null
        var green = 0; var red = 0; var n = 0
        for (y in y1..y2 step 2) {
            val c = bitmap.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (g > r * 1.25 && g > b * 1.05) green++
            if (r > g * 1.25 && r > b * 1.05) red++
            n++
        }
        if (n == 0 || abs(green - red) < n * 0.15) return null
        return green > red
    }
}
