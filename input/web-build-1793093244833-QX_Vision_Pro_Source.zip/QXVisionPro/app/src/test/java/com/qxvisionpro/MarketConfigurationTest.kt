package com.qxvisionpro

import com.qxvisionpro.domain.*
import org.junit.Assert.*
import org.junit.Test

class MarketConfigurationTest {
    @Test fun exactlyTenPairsPerMode() {
        assertEquals(10, MarketConfiguration.pairs(MarketMode.REAL).size)
        assertEquals(10, MarketConfiguration.pairs(MarketMode.OTC).size)
    }
    @Test fun noDuplicatesWithinMarket() {
        assertEquals(10, MarketConfiguration.realPairs.map { it.pair }.toSet().size)
        assertEquals(10, MarketConfiguration.otcPairs.map { it.pair }.toSet().size)
    }
    @Test fun marketModesAreSeparated() {
        assertTrue(MarketConfiguration.realPairs.all { it.mode == MarketMode.REAL })
        assertTrue(MarketConfiguration.otcPairs.all { it.mode == MarketMode.OTC })
        assertNotEquals(MarketConfiguration.realPairs.first(), MarketConfiguration.otcPairs.first())
    }
}
