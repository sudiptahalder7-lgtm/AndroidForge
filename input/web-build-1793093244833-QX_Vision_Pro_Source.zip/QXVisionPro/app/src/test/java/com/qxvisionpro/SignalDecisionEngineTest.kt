package com.qxvisionpro

import com.qxvisionpro.domain.*
import com.qxvisionpro.domain.validation.SignalDecisionEngine
import org.junit.Assert.*
import org.junit.Test

class SignalDecisionEngineTest {
    private val engine = SignalDecisionEngine()
    private val pair = MarketConfiguration.realPairs.first()

    @Test fun invalidStatusAlwaysNoTrade() {
        val result = engine.decide(pair, ValidationStatus.TIMING_UNVERIFIED, 1000, .9f, .1f)
        assertEquals(SignalDirection.NO_TRADE, result.direction)
        assertTrue(result.reason.isNotBlank())
    }
    @Test fun ambiguousEvidenceIsNoTrade() {
        val result = engine.decide(pair, ValidationStatus.VALIDATED, 1000, .55f, .48f)
        assertEquals(SignalDirection.NO_TRADE, result.direction)
    }
    @Test fun strongEvidenceCanProduceHeuristicDirection() {
        val result = engine.decide(pair, ValidationStatus.VALIDATED, 1000, .85f, .1f)
        assertEquals(SignalDirection.UP, result.direction)
        assertNotNull(result.modelScore)
    }
}
