# QX Vision Pro — Native Android foundation

A Kotlin + Jetpack Compose Android project foundation for a screen-observation chart assistant. It is deliberately conservative: no auto-trading, no broker API, no hidden market data, and no claimed win rate.

## Current implementation included
- Native Compose dark dashboard with REAL/OTC selection and the exact 10 pairs per mode.
- Strongly typed market/pair configuration.
- Signal and validation domain models; conservative NO TRADE decision engine.
- MediaProjection capture manager that receives explicit user consent and does not persist frames.
- Basic blank/size image checks and a limited candle color hint helper.
- Draggable overlay bubble and compact explanatory panel.
- Foreground media-projection service declaration and notification.
- Room history schema/repository with REAL/OTC filtering and verified-outcome fields.
- Unit tests for pair configuration and signal decisions.

## Important integration status
This is a source project foundation, **not a verified production-ready chart-recognition product**. The capture consent result is not yet connected end-to-end to `ScreenCaptureManager`; the dashboard does not yet run a full live scan coordinator; chart-region selection UI, reliable visible pair-label OCR, countdown OCR, candle-boundary segmentation, complete overlay-to-session state sync, performance-statistics screen, and full lifecycle/revocation integration remain to be implemented. The app intentionally does not output time-sensitive directional signals from unverified visual evidence.

## Requirements
- Android Studio with JDK 17
- Android SDK platform 35
- Android Gradle Plugin 8.7.3 compatible Gradle distribution
- Physical Android device recommended for MediaProjection and overlay testing

## Build
1. Open this directory in Android Studio.
2. Allow Gradle sync to download dependencies.
3. Connect a device or start an emulator.
4. Run `./gradlew test` to run local unit tests.
5. Run `./gradlew assembleDebug` to build a debug APK.
6. APK output, if the build succeeds, is normally `app/build/outputs/apk/debug/app-debug.apk`.

No build or test result is claimed by this deliverable; run the commands in your environment.

## Permissions and workflow
1. Launch the app.
2. Select REAL or OTC and a pair matching the visible chart.
3. Grant screen capture through Android's system consent dialog.
4. Grant overlay permission only if you want the floating bubble.
5. Stop the service from the app when finished.

Android may stop services or revoke capture. The app must never attempt to bypass these restrictions.

## Timing and signal semantics
A device clock is not proof of a candle boundary. A valid time-sensitive signal requires reliable visible countdown evidence and a verified pair/market mode. If any stage is uncertain, use NO TRADE. The helper decision engine's scores are illustrative heuristic inputs, not trained model output or verified probabilities.

## Troubleshooting
- **Gradle sync fails:** verify JDK 17, internet access for dependency resolution, and SDK platform 35.
- **Overlay missing:** enable “Display over other apps” in Android settings, then reopen the app.
- **Capture stops:** Android system consent may be revoked; stop and request consent again.
- **No directional signal:** expected when pair, market mode, candle boundaries, image quality, or timing cannot be verified.
- **No APK:** build with `./gradlew assembleDebug`; do not treat source generation as a successful build.

## Privacy
Captured frames are held in memory only by the capture manager and are not written to disk. Avoid logging screenshots or sensitive screen content.
