# Quotex Floating Market Analyzer (starter source)

This Android Kotlin starter includes a draggable floating overlay, an India Standard Time (IST) clock, and a demo countdown. It is not a finished or verified trading bot.

## Added QuotexPy bridge

The `backend/` folder contains an experimental, read-only adapter based on the unofficial `zagmi/qxbroker` Python library. It can attempt to read the instrument list and one-minute candles after a user configures their own credentials locally. Read `backend/README.md` before use. This bridge is separate from the APK and is not wired into the Android UI yet.

## Android app currently includes
- Overlay permission flow and foreground service
- Draggable floating panel
- IST clock using `Asia/Kolkata`
- Demo UP / DOWN / WAIT button and demo countdown

## Not yet implemented or verified
- No live API calls from the Android UI
- No verified full live/OTC market catalogue
- No screen capture/OCR chart reader
- No validated two-minute candle aggregation or signal model
- No live order execution
- Demo signal is arbitrary and has no predictive value
- APK build and live API connection have not been tested

## Build Android APK
Open the Android project in Android Studio, use JDK 17, sync Gradle, and build the `app` debug APK. This source ZIP is not an APK.

## Safety and data quality
The `zagmi/qxbroker` project is unofficial and communicates with a private platform protocol that can change. Never share your Quotex password/session ID in chat or commit it to GitHub. Keep the signal-only design and show `WAIT` for stale or invalid data.
