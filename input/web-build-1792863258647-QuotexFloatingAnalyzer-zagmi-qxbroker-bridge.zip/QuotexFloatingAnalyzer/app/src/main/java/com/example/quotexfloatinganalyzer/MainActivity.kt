package com.example.quotexfloatinganalyzer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Floating Market Analyzer"
            textSize = 24f
            setPadding(0, 0, 0, 18)
        }
        val info = TextView(this).apply {
            text = "A movable on-screen panel with demo UP / DOWN / WAIT signals. This starter does not connect to Quotex or provide verified live prices."
            textSize = 16f
            setPadding(0, 0, 0, 18)
        }
        val permission = Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "Start floating pop-up"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Grant overlay permission first", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    val intent = Intent(this@MainActivity, FloatingService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
                    Toast.makeText(this@MainActivity, "Floating panel started", Toast.LENGTH_SHORT).show()
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(permission, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(start, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(layout)
    }
}
