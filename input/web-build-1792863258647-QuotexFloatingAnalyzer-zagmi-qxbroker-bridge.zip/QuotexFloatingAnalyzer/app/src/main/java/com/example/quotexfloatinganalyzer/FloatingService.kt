package com.example.quotexfloatinganalyzer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var status: TextView
    private lateinit var countdown: TextView
    private lateinit var clockIst: TextView
    private var startedAt = System.currentTimeMillis()

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(41, buildNotification())
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf(); return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createPanel()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("floating_analyzer", "Floating Analyzer",
                NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "floating_analyzer") else Notification.Builder(this)
        return builder.setContentTitle("Floating Market Analyzer")
            .setContentText("Floating panel is active")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true).build()
    }

    private fun createPanel() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(24, 28, 36))
        }
        val header = TextView(this).apply {
            text = "☰  MARKET ANALYZER  •  DEMO"
            setTextColor(Color.WHITE); textSize = 13f
            setPadding(0, 0, 0, 8)
        }
        status = TextView(this).apply {
            text = "Signal: WAIT"
            setTextColor(Color.rgb(255, 210, 90)); textSize = 22f
            setPadding(0, 5, 0, 5)
        }
        clockIst = TextView(this).apply {\n            text = "IST: --:--:--"\n            setTextColor(Color.LTGRAY); textSize = 13f\n            setPadding(0, 0, 0, 4)\n        }\n        countdown = TextView(this).apply {
            text = "2-minute candle: --"
            setTextColor(Color.LTGRAY); textSize = 13f
            setPadding(0, 0, 0, 8)
        }
        val analyze = Button(this).apply {
            text = "Analyze (demo)"
            setOnClickListener { analyzeDemo() }
        }
        val close = Button(this).apply {
            text = "Close panel"
            setOnClickListener { stopSelf() }
        }
        container.addView(header)
        container.addView(status)
        container.addView(countdown)
        container.addView(analyze)
        container.addView(close)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 180
        }

        // Drag by touching the header; button taps continue to work.
        header.setOnTouchListener(object : View.OnTouchListener {
            var initialX = 0
            var initialY = 0
            var touchX = 0f
            var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x; initialY = params.y
                        touchX = event.rawX; touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - touchX).toInt()
                        params.y = initialY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(container, params)
                        return true
                    }
                }
                return false
            }
        })
        panel = container
        windowManager.addView(container, params)
        updateCountdown()
        container.post(object : Runnable {
            override fun run() {
                if (panel == null) return
                updateCountdown()
                container.postDelayed(this, 1000)
            }
        })
    }

    private fun updateCountdown() {
        val elapsed = ((System.currentTimeMillis() / 1000) % 120).toInt()
        val remaining = 120 - elapsed
        countdown.text = "2m candle demo • next in ${remaining / 60}:${String.format(Locale.US, "%02d", remaining % 60)}"
    }

    private fun analyzeDemo() {
        // Deterministic toy example, deliberately labelled demo.
        // Replace with an authorized market-data feed and validated strategy before live use.
        val seconds = System.currentTimeMillis() / 1000
        val demoValue = abs((seconds * 31L + startedAt / 1000) % 3).toInt()
        val signal = when (demoValue) { 0 -> "UP"; 1 -> "DOWN"; else -> "WAIT" }
        status.text = "Signal: $signal"
        status.setTextColor(when (signal) {
            "UP" -> Color.rgb(92, 220, 145)
            "DOWN" -> Color.rgb(255, 105, 105)
            else -> Color.rgb(255, 210, 90)
        })
    }

    override fun onDestroy() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
