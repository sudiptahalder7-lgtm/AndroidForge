# QuotexPy read-only bridge (experimental)

This bridge is based on the unofficial `zagmi/qxbroker` / `QuotexPy` project. It is **not** an official Quotex API, and it may stop working if the platform changes its private protocol. The library's README documents desktop Linux/Windows Python versions, so Android/Termux compatibility is not guaranteed.

## What it does

- `/health`: connection status and IST clock
- `/assets`: current asset names and open/closed state, with `_otc` assets labelled OTC when the library returns that suffix
- `/candles/{asset}?period_seconds=60`: raw one-minute candle payload
- Read-only only: no endpoint places trades, edits balances, or closes positions

The 2-minute endpoint is deliberately not faked: this adapter requests one-minute candles and requires the app to validate and aggregate them into 2-minute OHLC candles. The current source does not assume a two-minute enum exists.

## Run on a supported Python computer/server

Use Python 3.10–3.12, following the upstream README. In a private terminal:

```bash
python -m venv .venv
# Activate the venv for your operating system
pip install -r requirements.txt
export QUOTEX_EMAIL='your-email'
export QUOTEX_PASSWORD='your-password'
python quotex_bridge.py
```

On Windows PowerShell, use `$env:QUOTEX_EMAIL='your-email'` and `$env:QUOTEX_PASSWORD='your-password'` instead of `export`.

Open `http://127.0.0.1:8765/docs` locally to inspect the endpoints. If an email PIN is requested, the bridge asks for it in the terminal. Do not put account credentials or session IDs into the Android app, source code, GitHub, or this chat.

## Important integration limits

- This bridge is separate from the Android APK. The APK must be given a reachable bridge URL and its UI must be wired to these endpoints before it can show live data.
- Binding to `127.0.0.1` means only the same device can access the service. If hosting remotely, use HTTPS, authentication, firewall restrictions, and a private deployment; do not expose this unauthenticated sample to the public internet.
- Asset names and OTC availability may differ by account/time. The response is only what the library returns, not a guarantee of all markets on the Quotex website.
- No signal has guaranteed accuracy. Stale, missing, malformed or mismatched candle data should result in `WAIT`.
- The adapter has not been run against a live Quotex account or compiled as part of the Android app. Test with demo data first.
