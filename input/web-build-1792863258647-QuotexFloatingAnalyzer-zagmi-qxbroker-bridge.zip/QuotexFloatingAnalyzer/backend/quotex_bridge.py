"""Read-only bridge for the unofficial zagmi/qxbroker QuotexPy library.

This service exposes only instrument metadata and candle data. It deliberately
contains no order-placement endpoint. Use only with an account you control and
only if using this unofficial client is permitted by the platform's terms.
"""
from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

IST = ZoneInfo("Asia/Kolkata")
client = None
client_lock = asyncio.Lock()


def json_safe(value: Any) -> Any:
    """Convert common Python objects into JSON-safe data without assuming schema."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if hasattr(value, "__dict__"):
        return json_safe(vars(value))
    return str(value)


def pin_callback() -> str:
    # If Quotex asks for an email PIN, enter it in the terminal running this service.
    return input("Quotex email verification code: ").strip()


async def connect_client():
    global client
    email = os.environ.get("QUOTEX_EMAIL", "").strip()
    password = os.environ.get("QUOTEX_PASSWORD", "")
    if not email or not password:
        raise RuntimeError("Set QUOTEX_EMAIL and QUOTEX_PASSWORD in your local environment first.")

    from quotexpy import Quotex  # imported only after environment is configured

    client = Quotex(email=email, password=password, headless=True, on_pin_code=pin_callback)
    ok = await client.connect()
    if not ok:
        client = None
        raise RuntimeError("QuotexPy could not connect. Check network, login and library compatibility.")


app = FastAPI(title="QuotexPy Read-only Bridge", version="0.1.0")
# Local-only default is recommended. Do not expose this service to the public internet.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1", "http://localhost"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    # A failed connection leaves health endpoint available with connected=false.
    try:
        await connect_client()
    except Exception as exc:
        app.state.connection_error = str(exc)
    else:
        app.state.connection_error = None


@app.on_event("shutdown")
async def shutdown():
    global client
    if client is not None:
        try:
            client.close()
        except Exception:
            pass
        client = None


@app.get("/health")
async def health():
    now = datetime.now(IST)
    return {
        "service": "quotexpy-readonly-bridge",
        "connected": client is not None and bool(getattr(client, "websocket_alive", lambda: False)()),
        "error": getattr(app.state, "connection_error", None),
        "timezone": "Asia/Kolkata",
        "ist": now.isoformat(),
        "utc": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/assets")
async def assets():
    if client is None:
        raise HTTPException(status_code=503, detail="Quotex data connection is unavailable; check /health.")
    async with client_lock:
        try:
            names = client.get_all_asset_name()
            result = []
            for name in names:
                try:
                    status = client.check_asset(name)
                    opened = bool(status and len(status) > 2 and status[2])
                except Exception:
                    opened = False
                text_name = str(name)
                is_otc = text_name.lower().endswith("_otc") or " otc" in text_name.lower()
                result.append({"name": text_name, "market_type": "OTC" if is_otc else "REGULAR", "open": opened})
            return {"count": len(result), "assets": result, "fetched_at_ist": datetime.now(IST).isoformat()}
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Asset lookup failed: {exc}") from exc


@app.get("/candles/{asset}")
async def candles(
    asset: str,
    period_seconds: int = Query(default=60, ge=60, le=300),
):
    """Return raw candle payload from QuotexPy; supported periods vary by library version.

    For the bot's 2-minute analysis, request 60-second candles and aggregate them
    only after validating their timestamp/OHLC schema. This endpoint does not guess
    an unsupported two-minute enum or fabricate candle data.
    """
    if client is None:
        raise HTTPException(status_code=503, detail="Quotex data connection is unavailable; check /health.")
    if period_seconds not in (60, 120, 180, 300):
        raise HTTPException(status_code=400, detail="period_seconds must be 60, 120, 180, or 300")
    try:
        from quotexpy.utils.candles_period import CandlesPeriod
        period_map = {
            60: CandlesPeriod.ONE_MINUTE,
        }
        if period_seconds not in period_map:
            raise HTTPException(
                status_code=501,
                detail="This QuotexPy version's supported period enum has not been verified for this duration. Request 60s candles and aggregate validated OHLC data for 2-minute analysis.",
            )
        async with client_lock:
            payload = await client.get_candle_v2(asset, period_map[period_seconds])
        return {
            "asset": asset,
            "period_seconds": period_seconds,
            "timezone": "Asia/Kolkata",
            "fetched_at_ist": datetime.now(IST).isoformat(),
            "data": json_safe(payload),
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Candle fetch failed: {exc}") from exc


if __name__ == "__main__":
    import uvicorn
    # Bind to loopback only. Do not change to 0.0.0.0 unless you understand the risk.
    uvicorn.run("quotex_bridge:app", host="127.0.0.1", port=8765, reload=False)
