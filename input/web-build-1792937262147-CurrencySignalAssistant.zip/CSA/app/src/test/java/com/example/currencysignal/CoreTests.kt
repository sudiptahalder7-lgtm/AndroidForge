package com.example.currencysignal

import com.example.currencysignal.data.DataValidator
import com.example.currencysignal.domain.Candle
import com.example.currencysignal.domain.DataStatus
import com.example.currencysignal.domain.InstrumentCatalog
import com.example.currencysignal.domain.MarketType
import com.example.currencysignal.domain.Outcome
import com.example.currencysignal.domain.SeedData
import com.example.currencysignal.domain.Signal
import com.example.currencysignal.signal.Backtester
import com.example.currencysignal.signal.DecisionInput
import com.example.currencysignal.signal.Outcomes
import com.example.currencysignal.signal.PerformanceReport
import com.example.currencysignal.signal.SignalEngine
import com.example.currencysignal.timing.CandleTimer
import com.example.currencysignal.vision.CountdownParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun candles(n: Int, start: Double = 1.0, step: Double = 0.001, t0: Long = 0): List<Candle> =
    (0 until n).map { i ->
        val o = start + i * step
        val c = o + step
        Candle(t0 + i * 60_000L, o, maxOf(o, c) + 0.0002, minOf(o, c) - 0.0002, c)
    }

class CandleTimerTest {
    private fun primed(): CandleTimer {
        val t = CandleTimer()
        t.observe(30, 0); t.observe(29, 1000); t.observe(28, 2000)
        return t
    }

    @Test fun reliableAfterConsistentReadings() {
        val s = primed().state(2000)
        assertTrue(s.reason, s.reliable)
        assertTrue(s.remainingMs in 27_000..28_500)
    }

    @Test fun notReliableWithoutCountdown() {
        val s = CandleTimer().state(0)
        assertFalse(s.reliable)
        assertNotNull(s.reason)
    }

    @Test fun staleObservationsBecomeUnreliable() {
        assertFalse(primed().state(20_000).reliable)
    }

    @Test fun jumpResetsTrust() {
        val t = primed()
        t.observe(10, 3000) // should have been 27
        assertFalse(t.state(3000).reliable)
    }

    @Test fun analysisAndPublishWindows() {
        val t = CandleTimer()
        t.observe(8, 0); t.observe(7, 1000); t.observe(6, 2000)
        assertFalse(t.inAnalysisWindow(t.state(0).copy(remainingMs = 8000)))
        val s = t.state(2000)
        assertTrue(t.inAnalysisWindow(s))
        assertFalse(t.inPublishWindow(s))
        val late = t.state(2000).copy(remainingMs = 900)
        assertTrue(t.inPublishWindow(late))
    }

    @Test fun rolloverKeepsWorkingAndChangesSeq() {
        val t = primed()
        val before = t.state(2000).candleSeq
        t.observe(59, 31_000) // new candle: boundary +60s
        assertTrue(t.state(31_000).candleSeq != before)
    }

    @Test fun sameCandleSameSeq() {
        val t = primed()
        val a = t.state(2000).candleSeq
        t.observe(27, 3000)
        assertEquals(a, t.state(3000).candleSeq)
    }
}

class DataValidatorTest {
    private val now = 20 * 60_000L

    @Test fun freshDataIsLive() {
        val c = candles(15, t0 = now - 14 * 60_000L)
        assertEquals(DataStatus.LIVE, DataValidator.validate(c, now, 15_000).status)
    }

    @Test fun oldDataIsStale() {
        val c = candles(15, t0 = now - 14 * 60_000L - 10 * 60_000L)
        assertEquals(DataStatus.STALE, DataValidator.validate(c, now, 15_000).status)
    }

    @Test fun oldFetchIsStale() {
        val c = candles(15, t0 = now - 14 * 60_000L)
        assertEquals(DataStatus.STALE, DataValidator.validate(c, now, 15_000, fetchAgeMs = 60_000).status)
    }

    @Test fun missingCandleRejected() {
        val c = candles(15, t0 = now - 14 * 60_000L).toMutableList().also { it.removeAt(7) }
        assertEquals(DataStatus.UNAVAILABLE, DataValidator.validate(c, now, 15_000).status)
    }

    @Test fun unorderedRejected() {
        val c = candles(15, t0 = now - 14 * 60_000L).reversed()
        assertEquals(DataStatus.UNAVAILABLE, DataValidator.validate(c, now, 15_000).status)
    }

    @Test fun emptyAndShortRejected() {
        assertEquals(DataStatus.UNAVAILABLE, DataValidator.validate(emptyList(), now, 15_000).status)
        assertEquals(DataStatus.UNAVAILABLE, DataValidator.validate(candles(3, t0 = now - 2 * 60_000L), now, 15_000).status)
    }
}

class InstrumentCatalogTest {
    @Test fun seedHas41OtcAndNoReal() {
        assertEquals(41, SeedData.otcInstruments().size)
        assertTrue(SeedData.realInstruments().isEmpty())
        assertTrue(SeedData.otcInstruments().all { it.marketType == MarketType.OTC && it.providerId == "none" })
    }

    @Test fun realAndOtcStaySeparate() {
        val cat = InstrumentCatalog(SeedData.otcInstruments())
        assertTrue(cat.filter(MarketType.REAL, "", emptySet(), false).isEmpty())
        val r = InstrumentCatalog.parseImport("REAL,EUR/USD,EURUSD,example-http,60")
        r.imported.forEach { cat.add(it) }
        assertEquals(1, cat.filter(MarketType.REAL, "eur", emptySet(), false).size)
        assertEquals(1, cat.filter(MarketType.OTC, "eurusd", emptySet(), false).size)
        assertEquals(2, cat.filter(null, "eurusd", emptySet(), false).size)
    }

    @Test fun importReportsErrors() {
        val r = InstrumentCatalog.parseImport("market,displayName,symbol,providerId\nFOO,X,X,none\nOTC,A/B,AB")
        assertEquals(0, r.imported.size)
        assertEquals(2, r.errors.size)
    }

    @Test fun favoritesFilter() {
        val cat = InstrumentCatalog(SeedData.otcInstruments())
        val fav = setOf("OTC:EURUSD")
        assertEquals(1, cat.filter(null, "", fav, true).size)
    }
}

class SignalEngineTest {
    private val okTiming = com.example.currencysignal.domain.TimingState(true, 5000, 1, 100, null)

    private fun input(c: List<Candle>, status: DataStatus = DataStatus.LIVE, timing: com.example.currencysignal.domain.TimingState? = okTiming) =
        DecisionInput(c, status, timing, "test")

    @Test fun uptrendGivesUp() {
        assertEquals(Signal.UP, SignalEngine.decide(input(candles(20))).signal)
    }

    @Test fun downtrendGivesDown() {
        assertEquals(Signal.DOWN, SignalEngine.decide(input(candles(20, start = 2.0, step = -0.001))).signal)
    }

    @Test fun staleOrUnavailableIsNoTrade() {
        assertEquals(Signal.NO_TRADE, SignalEngine.decide(input(candles(20), DataStatus.STALE)).signal)
        assertEquals(Signal.NO_TRADE, SignalEngine.decide(input(candles(20), DataStatus.UNAVAILABLE)).signal)
    }

    @Test fun unreliableTimingIsNoTrade() {
        val bad = okTiming.copy(reliable = false, reason = "x")
        assertEquals(Signal.NO_TRADE, SignalEngine.decide(input(candles(20), timing = bad)).signal)
        assertEquals(Signal.NO_TRADE, SignalEngine.decide(input(candles(20), timing = null)).signal)
    }

    @Test fun tooFewCandlesIsNoTrade() {
        assertEquals(Signal.NO_TRADE, SignalEngine.decide(input(candles(5))).signal)
    }

    @Test fun conflictingSignalsIsNoTrade() {
        // long uptrend then a sharp last-candle drop: votes conflict
        val c = candles(20).toMutableList()
        val l = c.last()
        c[c.size - 1] = Candle(l.openTimeMs, l.close, l.close + 0.0001, l.close - 0.01, l.close - 0.009)
        assertEquals(Signal.NO_TRADE, SignalEngine.decide(input(c)).signal)
    }

    @Test fun noScoreIsPresentedAsProbability() {
        val r = SignalEngine.decide(input(candles(20)))
        assertTrue(r.heuristicScore!! in 0.0..1.0)
    }
}

class PerformanceTest {
    @Test fun outcomeResolution() {
        val up = Candle(0, 1.0, 1.2, 0.9, 1.1)
        assertEquals(Outcome.WIN, Outcomes.resolve(Signal.UP, up))
        assertEquals(Outcome.LOSS, Outcomes.resolve(Signal.DOWN, up))
        assertEquals(Outcome.SKIPPED, Outcomes.resolve(Signal.NO_TRADE, up))
        assertEquals(Outcome.DRAW, Outcomes.resolve(Signal.UP, Candle(0, 1.0, 1.1, 0.9, 1.0)))
    }

    @Test fun reportCountsAndEmptySample() {
        val r = PerformanceReport.from(listOf(Outcome.WIN, Outcome.WIN, Outcome.LOSS, Outcome.SKIPPED, Outcome.DRAW))
        assertEquals(3, r.decided)
        assertEquals(1, r.skipped)
        assertEquals(2.0 / 3.0, r.hitRate!!, 1e-9)
        assertNull(PerformanceReport.from(listOf(Outcome.SKIPPED)).hitRate)
    }

    @Test fun backtestRunsOnTrend() {
        val r = Backtester.run(candles(60))
        assertTrue(r.decided > 0)
        assertEquals(r.decided, r.wins + r.losses)
    }
}

class CountdownParserTest {
    @Test fun parsesFormats() {
        assertEquals(7, CountdownParser.parse("0:07"))
        assertEquals(7, CountdownParser.parse("00:07"))
        assertEquals(7, CountdownParser.parse(":07"))
        assertEquals(60, CountdownParser.parse("1:00"))
    }

    @Test fun rejectsGarbage() {
        assertNull(CountdownParser.parse("EUR/USD 1.0845"))
        assertNull(CountdownParser.parse("12:30"))
        assertNull(CountdownParser.parse(""))
    }
}
