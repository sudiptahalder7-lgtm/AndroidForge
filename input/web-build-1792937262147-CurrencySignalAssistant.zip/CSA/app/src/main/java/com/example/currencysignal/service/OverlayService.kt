package com.example.currencysignal.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.currencysignal.data.AppState
import com.example.currencysignal.domain.DataStatus
import com.example.currencysignal.domain.Signal
import com.example.currencysignal.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Movable compact overlay (TYPE_APPLICATION_OVERLAY). Requires the user to grant "Display over other apps". */
class OverlayService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var header: TextView
    private lateinit var signalView: TextView
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var details: LinearLayout
    private lateinit var startStop: Button
    private var minimized = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            AppState.update { it.copy(overlayRunning = false) }
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) build()
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun build() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 18, 22, 30)); cornerRadius = dp(10).toFloat()
            }
        }
        header = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 11f }
        signalView = TextView(this).apply { textSize = 22f; setTextColor(Color.WHITE); setPadding(0, dp(2), 0, dp(2)) }
        info = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 11f }
        status = TextView(this).apply { setTextColor(Color.YELLOW); textSize = 11f }
        details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(info); addView(status) }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; textSize = 10f; isAllCaps = true
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            setPadding(dp(8), dp(2), dp(8), dp(2))
            setOnClickListener { onClick() }
        }
        startStop = btn("START") {
            if (AppState.state.value.captureActive) {
                startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            } else {
                // Screen-capture consent can only be requested from an Activity.
                startActivity(Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra(MainActivity.EXTRA_REQUEST_SCAN, true))
            }
        }
        val min = btn("MIN") {
            minimized = !minimized
            details.visibility = if (minimized) View.GONE else View.VISIBLE
        }
        val close = btn("CLOSE") { stopSelf() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(startStop); addView(min); addView(close)
        }
        box.addView(header); box.addView(signalView); box.addView(details); box.addView(row)
        root = box

        params = WindowManager.LayoutParams(
            dp(210), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(box, params) }
                    true
                }
                else -> false
            }
        }
        wm.addView(box, params)
        AppState.update { it.copy(overlayRunning = true) }

        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        scope.launch {
            combine(AppState.state, AppState.selected) { s, inst -> s to inst }.collect { (s, inst) ->
                header.text = if (inst != null) "${inst.displayName}  ${inst.marketType.name}  1M" else "No pair selected  1M"
                startStop.text = if (s.captureActive) "STOP" else "START"
                if (!s.captureActive) {
                    signalView.text = "SCAN OFF"
                    signalView.setTextColor(Color.GRAY)
                    info.text = "Capture is not running"
                    status.text = s.statusMessage
                } else {
                    val sig = s.signal
                    signalView.text = sig?.label ?: "WAITING"
                    signalView.setTextColor(when (sig) {
                        Signal.UP -> Color.rgb(60, 200, 110)
                        Signal.DOWN -> Color.rgb(240, 80, 70)
                        Signal.NO_TRADE -> Color.rgb(240, 190, 60)
                        null -> Color.GRAY
                    })
                    val cd = if (s.timingReliable && s.countdownSec != null) "${s.countdownSec}s" else "--"
                    val scan = s.lastScanMs?.let { fmt.format(Date(it)) } ?: "--"
                    info.text = "Countdown $cd | Scan $scan\n${s.signalReason}"
                    status.text = "Data: ${s.dataStatus.label}" +
                        (if (s.dataStatus == DataStatus.SCREEN_ONLY) " (experimental)" else "") +
                        "\nExperimental - not advice"
                }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        AppState.update { it.copy(overlayRunning = false) }
        super.onDestroy()
    }
}
