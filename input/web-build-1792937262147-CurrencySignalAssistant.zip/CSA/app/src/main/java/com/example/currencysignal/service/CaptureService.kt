package com.example.currencysignal.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.graphics.PixelFormat
import android.view.WindowManager
import androidx.core.content.IntentCompat
import com.example.currencysignal.data.AppState
import com.example.currencysignal.data.AppStore
import com.example.currencysignal.data.DataValidator
import com.example.currencysignal.data.FetchResult
import com.example.currencysignal.data.MarketDataProvider
import com.example.currencysignal.data.Providers
import com.example.currencysignal.domain.AppSettings
import com.example.currencysignal.domain.Candle
import com.example.currencysignal.domain.DataStatus
import com.example.currencysignal.domain.HistoryEntry
import com.example.currencysignal.domain.Instrument
import com.example.currencysignal.domain.Outcome
import com.example.currencysignal.domain.Region
import com.example.currencysignal.domain.Signal
import com.example.currencysignal.domain.TimingState
import com.example.currencysignal.signal.DecisionInput
import com.example.currencysignal.signal.Outcomes
import com.example.currencysignal.signal.SignalEngine
import com.example.currencysignal.timing.CandleTimer
import com.example.currencysignal.vision.ChartAnalyzer
import com.example.currencysignal.vision.CountdownReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

/**
 * User-authorized screen observation. Runs ONLY as a visible mediaProjection foreground service
 * with a persistent notification and STOP action. Frames are processed in memory and never saved
 * or uploaded. It never taps or types anything and never places trades.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.currencysignal.START"
        const val ACTION_STOP = "com.example.currencysignal.STOP"
        const val EXTRA_CODE = "resultCode"
        const val EXTRA_DATA = "resultData"
        private const val CHANNEL = "scan"
        private const val NID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var loop: Job? = null
    private var stopping = false
    private var active = false
    @Volatile private var screenOn = true
    private var receiverRegistered = false

    private lateinit var store: AppStore
    private val timer = CandleTimer()
    private val countdownReader by lazy { CountdownReader() }

    private var lastPublishedSeq = -1L
    private var cacheSeq = -1L
    private var cachedFetch: FetchResult? = null
    private var imgW = 0
    private var imgH = 0

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            screenOn = i.action != Intent.ACTION_SCREEN_OFF
            if (!screenOn) AppState.update { it.copy(statusMessage = "Screen off - capture paused, NO TRADE") }
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopScanning("Screen capture session ended (system or user)") }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startScanning(intent)
            ACTION_STOP -> stopScanning("Stopped by user")
            else -> if (!active) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startScanning(intent: Intent) {
        if (active) return
        store = AppStore.get(this)
        createChannel()
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Currency Signal Assistant")
            .setContentText("Observing your screen (experimental). Tap STOP to end.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "STOP", stopPi).build())
            .build()
        // Must be foreground BEFORE obtaining the projection (Android 14+ requirement).
        startForeground(NID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) { stopScanning("No screen-capture consent"); return }

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val proj = mpm.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(projectionCallback, main) // required before createVirtualDisplay on Android 14+

            val bounds = getSystemService(WindowManager::class.java).currentWindowMetrics.bounds
            imgW = (bounds.width() / 2).coerceAtLeast(240)
            imgH = (bounds.height() / 2).coerceAtLeast(240)
            val r = ImageReader.newInstance(imgW, imgH, PixelFormat.RGBA_8888, 2)
            reader = r
            display = proj.createVirtualDisplay(
                "csa-scan", imgW, imgH, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
        } catch (e: Exception) {
            stopScanning("Could not start capture: ${e.javaClass.simpleName}")
            return
        }

        androidx.core.content.ContextCompat.registerReceiver(
            this, screenReceiver,
            IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) },
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true

        active = true
        timer.reset("Waiting for countdown")
        AppState.update { it.copy(captureActive = true, statusMessage = "Scanning (waiting for countdown)") }
        loop = scope.launch {
            while (isActive) {
                val s = store.settings()
                timer.toleranceMs = s.toleranceMs
                var next = s.samplingMs
                try {
                    if (screenOn) next = cycle(s)
                } catch (e: Exception) {
                    AppState.update { it.copy(statusMessage = "Scan error: ${e.javaClass.simpleName}; NO TRADE") }
                }
                delay(next)
            }
        }
    }

    /** One observation. Returns the delay before the next one (faster near the candle boundary). */
    private suspend fun cycle(s: AppSettings): Long {
        val now = SystemClock.elapsedRealtime()
        val bmp = grab() ?: return s.samplingMs
        try {
            if (isBlank(bmp)) {
                AppState.update {
                    it.copy(obscured = true, chartDetected = false, signal = Signal.NO_TRADE,
                        signalReason = "Screen not readable (blank/secure window or app not shared)",
                        statusMessage = "Screen obscured or protected")
                }
                return s.samplingMs
            }
            val cd = crop(bmp, s.countdownRegion)
            val sec = countdownReader.read(cd)
            cd.recycle()
            if (sec != null) timer.observe(sec, now)
            val ts = timer.state(now)

            AppState.update {
                it.copy(obscured = false, lastScanMs = System.currentTimeMillis(), countdownSec = sec,
                    timingReliable = ts.reliable,
                    statusMessage = if (ts.reliable) "Scanning; timing OK" else "Scanning; ${ts.reason}")
            }

            val inst = AppState.selected.value
            if (inst == null) {
                AppState.update { it.copy(signal = Signal.NO_TRADE, signalReason = "No currency pair selected") }
                return s.samplingMs
            }
            if (!ts.reliable) {
                AppState.update { it.copy(signal = Signal.NO_TRADE, signalReason = ts.reason ?: "Timing unreliable") }
                return s.samplingMs
            }

            if (timer.inAnalysisWindow(ts)) {
                // analysis begins in the final 7 seconds: gather chart pixels and/or feed data once
                val chart = chartCandles(bmp, s.chartRegion)
                AppState.update { it.copy(chartDetected = chart.isNotEmpty()) }
                if (cacheSeq != ts.candleSeq) {
                    cacheSeq = ts.candleSeq
                    val provider = Providers.forInstrument(inst, s)
                    cachedFetch = if (provider != null) fetch(provider, inst) else null
                }
                // re-check the boundary right before publishing
                val fresh = timer.state(SystemClock.elapsedRealtime())
                if (timer.inPublishWindow(fresh) && lastPublishedSeq != fresh.candleSeq) {
                    publish(inst, s, chart, fresh)
                }
                return s.fastSamplingMs
            }
            return s.samplingMs
        } finally {
            bmp.recycle()
        }
    }

    private suspend fun fetch(p: MarketDataProvider, inst: Instrument): FetchResult =
        withTimeoutOrNull(4000) { p.fetchCandles(inst, 30) }
            ?: FetchResult.Failure(com.example.currencysignal.data.FailureKind.TIMEOUT, "Feed request timed out")

    private fun publish(inst: Instrument, s: AppSettings, chart: List<Candle>, ts: TimingState) {
        lastPublishedSeq = ts.candleSeq
        val provider = Providers.forInstrument(inst, s)
        val input: DecisionInput
        var lastCandle: Candle? = null
        var verifiedMs: Long? = null
        if (provider != null) {
            when (val f = cachedFetch) {
                is FetchResult.Success -> {
                    val wall = System.currentTimeMillis()
                    val age = wall - f.fetchedAtMs
                    val refNow = f.serverTimeMs?.plus(age) ?: wall
                    val v = DataValidator.validate(f.candles, refNow, s.maxStaleMs, age)
                    input = DecisionInput(f.candles, v.status, ts, f.providerName, v.reason)
                    lastCandle = f.candles.lastOrNull()
                    if (v.status == DataStatus.LIVE) verifiedMs = f.fetchedAtMs
                }
                is FetchResult.Failure ->
                    input = DecisionInput(emptyList(), DataStatus.UNAVAILABLE, ts, provider.displayName, "Feed error: ${f.reason}")
                null ->
                    input = DecisionInput(emptyList(), DataStatus.UNAVAILABLE, ts, provider.displayName, "No feed data")
            }
        } else if (s.allowScreenOnly) {
            input = DecisionInput(chart, DataStatus.SCREEN_ONLY, ts, "SCREEN-ONLY", "Chart not detected")
            lastCandle = chart.lastOrNull()
        } else {
            input = DecisionInput(emptyList(), DataStatus.UNAVAILABLE, ts, "none",
                "No data feed mapped to ${inst.key} and screen-only mode is off")
        }

        val res = SignalEngine.decide(if (input.candles.isEmpty() && input.dataStatus == DataStatus.SCREEN_ONLY)
            input.copy(note = "Chart not detected") else input)
        val finalRes = if (input.dataStatus == DataStatus.SCREEN_ONLY && input.candles.isEmpty())
            res.copy(signal = Signal.NO_TRADE, reason = "Chart not detected in selected region") else res
        val wallNow = System.currentTimeMillis()

        // Resolve the previous paper signal for this instrument using the (nearly closed) last candle.
        store.updateHistory { list ->
            list.map { e ->
                if (e.instrumentKey == inst.key && e.outcome == Outcome.PENDING) {
                    val lc = lastCandle
                    when {
                        e.candleSeq + 1 == ts.candleSeq && lc != null ->
                            e.copy(outcome = Outcomes.resolve(e.signal, lc))
                        else -> e.copy(outcome = Outcome.UNRESOLVED)
                    }
                } else e
            } + HistoryEntry(
                id = UUID.randomUUID().toString(), instrumentKey = inst.key, displayName = inst.displayName,
                market = inst.marketType, timeMs = wallNow, candleSeq = ts.candleSeq, signal = finalRes.signal,
                dataStatus = finalRes.dataStatus, source = finalRes.source, reason = finalRes.reason,
                outcome = if (finalRes.signal == Signal.NO_TRADE) Outcome.SKIPPED else Outcome.PENDING,
                paper = s.paperMode
            )
        }
        AppState.update {
            it.copy(signal = finalRes.signal, signalReason = finalRes.reason, signalTimeMs = wallNow,
                dataStatus = finalRes.dataStatus, providerName = finalRes.source,
                lastVerifiedUpdateMs = verifiedMs ?: it.lastVerifiedUpdateMs)
        }
    }

    private fun chartCandles(bmp: Bitmap, r: Region): List<Candle> {
        val c = crop(bmp, r)
        val px = IntArray(c.width * c.height)
        c.getPixels(px, 0, c.width, 0, 0, c.width, c.height)
        val out = ChartAnalyzer.analyze(px, c.width, c.height)
        c.recycle()
        return out
    }

    private fun crop(b: Bitmap, r: Region): Bitmap {
        val l = (r.l.coerceIn(0f, 1f) * b.width).toInt()
        val t = (r.t.coerceIn(0f, 1f) * b.height).toInt()
        val rr = (r.r.coerceIn(0f, 1f) * b.width).toInt().coerceAtLeast(l + 8).coerceAtMost(b.width)
        val bb = (r.b.coerceIn(0f, 1f) * b.height).toInt().coerceAtLeast(t + 8).coerceAtMost(b.height)
        return Bitmap.createBitmap(b, l.coerceAtMost(rr - 8), t.coerceAtMost(bb - 8), rr - l.coerceAtMost(rr - 8), bb - t.coerceAtMost(bb - 8))
    }

    private fun grab(): Bitmap? {
        val image = reader?.acquireLatestImage() ?: return null
        image.use { img ->
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * img.width
            val wide = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
            wide.copyPixelsFromBuffer(plane.buffer)
            val out = Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
            if (out !== wide) wide.recycle()
            return out
        }
    }

    private fun isBlank(b: Bitmap): Boolean {
        for (yi in 0 until 20) for (xi in 0 until 20) {
            val p = b.getPixel(xi * (b.width - 1) / 19, yi * (b.height - 1) / 19)
            if ((p and 0x00FFFFFF) != 0) return false
        }
        return true
    }

    private fun stopScanning(reason: String) {
        if (stopping) return
        stopping = true
        active = false
        loop?.cancel()
        runCatching { display?.release() }
        runCatching { reader?.close() }
        projection?.let { p -> runCatching { p.unregisterCallback(projectionCallback); p.stop() } }
        display = null; reader = null; projection = null
        if (receiverRegistered) { runCatching { unregisterReceiver(screenReceiver) }; receiverRegistered = false }
        AppState.update {
            it.copy(captureActive = false, statusMessage = reason, timingReliable = false, countdownSec = null,
                signal = Signal.NO_TRADE, signalReason = reason, chartDetected = false)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (!stopping) stopScanning("Service destroyed by Android")
        runCatching { countdownReader.close() }
        scope.cancel()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Screen scanning", NotificationManager.IMPORTANCE_LOW)
        )
    }
}
