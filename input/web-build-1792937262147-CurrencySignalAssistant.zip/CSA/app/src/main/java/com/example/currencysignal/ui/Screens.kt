package com.example.currencysignal.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.currencysignal.data.AppState
import com.example.currencysignal.domain.AppSettings
import com.example.currencysignal.domain.Instrument
import com.example.currencysignal.domain.MarketType
import com.example.currencysignal.domain.Outcome
import com.example.currencysignal.domain.Region
import com.example.currencysignal.domain.Signal
import com.example.currencysignal.signal.PerformanceReport
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
private fun time(ms: Long?) = ms?.let { fmt.format(Date(it)) } ?: "--"

@Composable
fun App(vm: MainViewModel, actions: Actions, resumeTick: Int) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        val tabs = listOf("Dashboard", "Pairs", "History", "Access", "Testing")
        val showConsent by vm.showConsent.collectAsState()
        Scaffold(bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(t.take(1)) }, label = { Text(t, fontSize = 10.sp, maxLines = 1) })
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> Dashboard(vm, actions)
                    1 -> Pairs(vm)
                    2 -> History(vm)
                    3 -> Access(vm, actions, resumeTick)
                    else -> Testing(vm)
                }
            }
        }
        if (showConsent) {
            AlertDialog(
                onDismissRequest = { vm.showConsent.value = false },
                title = { Text("Start screen observation?") },
                text = {
                    Text(
                        "Android will ask for permission to capture your screen. While scanning, this app reads " +
                            "pixels of your screen (the chart area and the countdown text) on this device only. " +
                            "Frames are not saved or uploaded. Signals are experimental; you can lose money. " +
                            "The app never places trades or clicks anything. Stop any time from the notification, " +
                            "overlay or this app."
                    )
                },
                confirmButton = { TextButton(onClick = { (actions as? MainActivity)?.confirmedScan() }) { Text("Continue") } },
                dismissButton = { TextButton(onClick = { vm.showConsent.value = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun Dashboard(vm: MainViewModel, actions: Actions) {
    val s by AppState.state.collectAsState()
    val sel by AppState.selected.collectAsState()
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Currency Signal Assistant", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Experimental, educational. Not financial advice. You can lose money. No trades are ever placed by this app.", fontSize = 12.sp)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Pair: ${sel?.displayName ?: "none selected"}  (${sel?.marketType?.name ?: "-"})  1M")
                Text("Signal: ${s.signal?.label ?: "-"}  at ${time(s.signalTimeMs)}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Reason: ${s.signalReason.ifEmpty { "-" }}")
                Text("Data: ${s.dataStatus.label}  Source: ${s.providerName}")
                Text("Last verified feed update: ${time(s.lastVerifiedUpdateMs)}")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Status", fontWeight = FontWeight.Bold)
                Text("Screen capture: ${if (s.captureActive) "ACTIVE" else "OFF"}${if (s.obscured) " (screen obscured)" else ""}")
                Text("Timing: ${if (s.timingReliable) "OK, countdown ${s.countdownSec ?: "--"}s" else "NOT RELIABLE"}")
                Text("Chart detected: ${if (s.chartDetected) "yes" else "no"}")
                Text("Last scan: ${time(s.lastScanMs)}")
                Text("Overlay: ${if (s.overlayRunning) "shown" else "hidden"}")
                Text(s.statusMessage, fontSize = 12.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { actions.startScan() }, enabled = !s.captureActive) { Text("START SCANNING") }
            OutlinedButton(onClick = { actions.stopScan() }, enabled = s.captureActive) { Text("STOP SCANNING") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { actions.startOverlay() }) { Text("Show overlay") }
            OutlinedButton(onClick = { actions.stopOverlay() }) { Text("Hide overlay") }
        }
        Text("Android or the device maker may stop background work at any time; this app shows scanning as OFF when that happens.", fontSize = 11.sp)
    }
}

@Composable
private fun Pairs(vm: MainViewModel) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableIntStateOf(0) } // 0 ALL, 1 REAL, 2 OTC
    var onlyFav by rememberSaveable { mutableStateOf(false) }
    val all by vm.instruments.collectAsState()
    val favs by vm.favorites.collectAsState()
    val sel by AppState.selected.collectAsState()
    val market = when (filter) { 1 -> MarketType.REAL; 2 -> MarketType.OTC; else -> null }
    val list = remember(all, favs, query, filter, onlyFav) { vm.filtered(market, query, onlyFav) }
    Column(Modifier.padding(12.dp)) {
        OutlinedTextField(query, { query = it }, label = { Text("Search pairs") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(filter == 0, { filter = 0 }, { Text("ALL CURRENCIES") })
            FilterChip(filter == 1, { filter = 1 }, { Text("REAL") })
            FilterChip(filter == 2, { filter = 2 }, { Text("OTC") })
            FilterChip(onlyFav, { onlyFav = !onlyFav }, { Text("Favorites") })
        }
        Text("OTC list is screenshot-derived, not a verified/complete asset list. REAL list stays empty until you import confirmed instruments (Testing tab).", fontSize = 11.sp)
        LazyColumn {
            items(list, key = { it.key }) { i -> PairRow(i, i.key in favs, sel?.key == i.key, { vm.select(i) }, { vm.toggleFavorite(i) }) }
        }
    }
}

@Composable
private fun PairRow(i: Instrument, fav: Boolean, selected: Boolean, onSelect: () -> Unit, onFav: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onSelect() }.padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text((if (selected) "> " else "") + "${i.displayName}  [${i.marketType.name}]", fontWeight = FontWeight.Bold)
            Text("source: ${i.providerId} | ${i.validation.name} | availability: ${i.availability.name}" +
                (if (i.providerId == "none") " | no data feed (SCREEN-ONLY at best)" else ""), fontSize = 11.sp)
        }
        TextButton(onClick = onFav) { Text(if (fav) "★" else "☆") }
    }
}

@Composable
private fun History(vm: MainViewModel) {
    val h by vm.history.collectAsState()
    var market by rememberSaveable { mutableIntStateOf(0) }
    var sig by rememberSaveable { mutableIntStateOf(0) }
    val shown = h.asReversed().filter {
        (market == 0 || it.market == if (market == 1) MarketType.REAL else MarketType.OTC) &&
            (sig == 0 || it.signal == when (sig) { 1 -> Signal.UP; 2 -> Signal.DOWN; else -> Signal.NO_TRADE })
    }
    Column(Modifier.padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("All", "REAL", "OTC").forEachIndexed { i, t -> FilterChip(market == i, { market = i }, { Text(t) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Any", "UP", "DOWN", "NO TRADE").forEachIndexed { i, t -> FilterChip(sig == i, { sig = i }, { Text(t, fontSize = 11.sp) }) }
        }
        OutlinedButton(onClick = { vm.clearHistory() }) { Text("Clear history") }
        LazyColumn {
            items(shown, key = { it.id }) { e ->
                Column(Modifier.padding(vertical = 5.dp)) {
                    Text("${e.displayName} [${e.market.name}]  ${e.signal.label}  ${time(e.timeMs)}", fontWeight = FontWeight.Bold)
                    Text("source ${e.source} | ${e.dataStatus.label} | outcome ${e.outcome.name}${if (e.paper) " (paper)" else ""}", fontSize = 11.sp)
                    Text(e.reason, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun Access(vm: MainViewModel, actions: Actions, tick: Int) {
    val s by AppState.state.collectAsState()
    val settings by vm.settings.collectAsState()
    val overlay = remember(tick) { actions.overlayGranted() }
    val notif = remember(tick) { actions.notificationsGranted() }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Data and permissions", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("Screen capture: ${if (s.captureActive) "granted & active" else "not active (Android asks each time you start)"}")
        Text("Overlay (display over other apps): ${if (overlay) "granted" else "MISSING"}")
        if (!overlay) {
            Text("Open the system page, find this app, and allow 'Display over other apps'. The app cannot grant this itself.", fontSize = 12.sp)
            Button(onClick = { actions.openOverlaySettings() }) { Text("Open overlay settings") }
        }
        Text("Notifications: ${if (notif) "granted" else "denied (STOP notification may be hidden; enable in system settings)"}")
        Text("Live-data feed: ${if (settings.providerBaseUrl.isBlank()) "not configured" else "configured: ${settings.providerBaseUrl}"}")
        Text("Current data status: ${s.dataStatus.label}  Source: ${s.providerName}")
        Text("Latest verified feed update: ${time(s.lastVerifiedUpdateMs)}")
        if (s.dataStatus == com.example.currencysignal.domain.DataStatus.STALE) Text("WARNING: data is stale - signals are blocked (NO TRADE).")
        if (s.obscured) Text("WARNING: screen content is not readable (blank/secure window, or you shared a different app).")
        Text("If you choose 'share one app' in Android 14+, share the Quotex app, not this one.", fontSize = 12.sp)
        Text("Some phone makers kill background services; battery-optimization exceptions may help but are not guaranteed.", fontSize = 12.sp)
    }
}

@Composable
private fun Testing(vm: MainViewModel) {
    val st by vm.settings.collectAsState()
    val h by vm.history.collectAsState()
    val bt by vm.backtestText.collectAsState()
    val imp by vm.importMessage.collectAsState()
    var csv by rememberSaveable { mutableStateOf("") }
    var imports by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable(st.providerBaseUrl) { mutableStateOf(st.providerBaseUrl) }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Testing and settings", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Slide("Sampling interval ${st.samplingMs} ms", st.samplingMs.toFloat(), 500f, 3000f) { vm.saveSettings(st.copy(samplingMs = it.toLong())) }
        Slide("Fast sampling near boundary ${st.fastSamplingMs} ms", st.fastSamplingMs.toFloat(), 150f, 1000f) { vm.saveSettings(st.copy(fastSamplingMs = it.toLong())) }
        Slide("Timing tolerance ${st.toleranceMs} ms", st.toleranceMs.toFloat(), 500f, 4000f) { vm.saveSettings(st.copy(toleranceMs = it.toLong())) }
        Slide("Max data age ${st.maxStaleMs} ms", st.maxStaleMs.toFloat(), 3000f, 60000f) { vm.saveSettings(st.copy(maxStaleMs = it.toLong())) }
        Text("Chart region (fractions of screen)", fontWeight = FontWeight.Bold)
        RegionEditor(st.chartRegion) { vm.saveSettings(st.copy(chartRegion = it)) }
        Text("Countdown region", fontWeight = FontWeight.Bold)
        RegionEditor(st.countdownRegion) { vm.saveSettings(st.copy(countdownRegion = it)) }
        Row { Switch(st.paperMode, { vm.saveSettings(st.copy(paperMode = it)) }); Text("  Paper-testing mode (record only, never trade)") }
        Row { Switch(st.allowScreenOnly, { vm.saveSettings(st.copy(allowScreenOnly = it)) }); Text("  Allow experimental SCREEN-ONLY signals") }
        OutlinedTextField(url, { url = it }, label = { Text("Feed backend base URL (optional, example adapter)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedButton(onClick = { vm.saveSettings(st.copy(providerBaseUrl = url.trim())) }) { Text("Save feed URL") }

        Text("Paper-test report (from history)", fontWeight = FontWeight.Bold)
        Text(PerformanceReport.from(h.filter { it.paper }.map { it.outcome }).format(), fontSize = 11.sp)

        Text("Backtest: paste CSV time,open,high,low,close (>= 20 rows, REAL feed data you trust)", fontWeight = FontWeight.Bold)
        OutlinedTextField(csv, { csv = it }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(onClick = { vm.runBacktest(csv) }) { Text("Run backtest") }
        if (bt.isNotEmpty()) Text(bt, fontSize = 11.sp)

        Text("Import instruments: market,displayName,symbol,providerId[,60]", fontWeight = FontWeight.Bold)
        OutlinedTextField(imports, { imports = it }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(onClick = { vm.importInstruments(imports) }) { Text("Import") }
        if (imp.isNotEmpty()) Text(imp, fontSize = 11.sp)

        Text("Privacy", fontWeight = FontWeight.Bold)
        Text("Screen frames are processed in memory on this device and are never saved or uploaded. This app never asks for Quotex credentials, cookies or tokens, never clicks or places trades. Signals are heuristic and experimental; no win rate is proven. Financial loss is possible.", fontSize = 12.sp)
    }
}

@Composable
private fun Slide(label: String, v: Float, min: Float, max: Float, onDone: (Float) -> Unit) {
    var cur by remember(v) { mutableStateOf(v) }
    Column {
        Text(label, fontSize = 12.sp)
        Slider(cur, { cur = it }, valueRange = min..max, onValueChangeFinished = { onDone(cur) })
    }
}

@Composable
private fun RegionEditor(r: Region, onChange: (Region) -> Unit) {
    Column {
        FSlide("left %.2f".format(r.l), r.l) { onChange(r.copy(l = it.coerceAtMost(r.r - 0.05f))) }
        FSlide("top %.2f".format(r.t), r.t) { onChange(r.copy(t = it.coerceAtMost(r.b - 0.03f))) }
        FSlide("right %.2f".format(r.r), r.r) { onChange(r.copy(r = it.coerceAtLeast(r.l + 0.05f))) }
        FSlide("bottom %.2f".format(r.b), r.b) { onChange(r.copy(b = it.coerceAtLeast(r.t + 0.03f))) }
    }
}

@Composable
private fun FSlide(label: String, v: Float, onDone: (Float) -> Unit) = Slide(label, v, 0f, 1f, onDone)
