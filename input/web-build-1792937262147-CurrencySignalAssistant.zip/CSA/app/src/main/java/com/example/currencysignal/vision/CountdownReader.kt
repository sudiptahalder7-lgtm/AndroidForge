package com.example.currencysignal.vision

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/** On-device OCR of the countdown crop. Nothing leaves the device. */
class CountdownReader {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun read(crop: Bitmap): Int? {
        return try {
            val scaled = if (crop.width < 200) {
                Bitmap.createScaledBitmap(crop, crop.width * 3, crop.height * 3, true)
            } else crop
            val result = recognizer.process(InputImage.fromBitmap(scaled, 0)).await()
            CountdownParser.parse(result.text)
        } catch (e: Exception) {
            null
        }
    }

    fun close() = recognizer.close()
}
