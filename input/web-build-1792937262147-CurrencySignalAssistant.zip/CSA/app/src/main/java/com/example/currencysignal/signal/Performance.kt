package com.example.currencysignal.signal

import com.example.currencysignal.domain.Candle
import com.example.currencysignal.domain.DataStatus
import com.example.currencysignal.domain.Outcome
import com.example.currencysignal.domain.Signal
import kotlin.math.sqrt

object Outcomes {
    /** Outcome of a signal against the candle it targeted (close vs open). */
    fun resolve(signal: Signal, target: Candle): Outcome {
        if (signal == Signal.NO_TRADE) return Outcome.SKIPPED
        val move = target.close - target.open
        return when {
            move == 0.0 -> Outcome.DRAW
            (move > 0 && signal == Signal.UP) || (move < 0 && signal == Signal.DOWN) -> Outcome.WIN
            else -> Outcome.LOSS
        }
    }
}

data class PerformanceReport(
    val wins: Int, val losses: Int, val draws: Int, val skipped: Int, val unresolved: Int,
    val decided: Int, val hitRate: Double?, val ciLow: Double?, val ciHigh: Double?
) {
    fun format(): String = buildString {
        appendLine("Sample size (decided WIN+LOSS): $decided")
        appendLine("Wins: $wins  Losses: $losses  Draws: $draws  Skipped (NO TRADE): $skipped  Unresolved/pending: $unresolved")
        if (hitRate == null) appendLine("Hit rate: n/a (no decided signals)")
        else appendLine("Hit rate: %.1f%% (95%% Wilson interval %.1f%%-%.1f%%)".format(hitRate * 100, ciLow!! * 100, ciHigh!! * 100))
        appendLine("Methodology: hit rate = wins / (wins + losses); draws, skipped and unresolved excluded from the rate but listed.")
        appendLine("Interval: Wilson score, z=1.96. Small samples give wide intervals. No payout, spread or fees modelled.")
        append("This is an in-sample/paper measurement, not a calibrated probability or proof of edge.")
    }

    companion object {
        fun from(outcomes: List<Outcome>): PerformanceReport {
            val w = outcomes.count { it == Outcome.WIN }
            val l = outcomes.count { it == Outcome.LOSS }
            val d = outcomes.count { it == Outcome.DRAW }
            val s = outcomes.count { it == Outcome.SKIPPED }
            val u = outcomes.count { it == Outcome.PENDING || it == Outcome.UNRESOLVED }
            val n = w + l
            if (n == 0) return PerformanceReport(w, l, d, s, u, 0, null, null, null)
            val z = 1.96
            val p = w.toDouble() / n
            val denom = 1 + z * z / n
            val centre = (p + z * z / (2 * n)) / denom
            val half = z * sqrt(p * (1 - p) / n + z * z / (4.0 * n * n)) / denom
            return PerformanceReport(w, l, d, s, u, n, p, centre - half, centre + half)
        }
    }
}

/** Walk-forward backtest: the signal at candle i uses only candles[0..i] and is scored on candle i+1. */
object Backtester {
    fun run(candles: List<Candle>, params: EngineParams = EngineParams()): PerformanceReport {
        val outcomes = ArrayList<Outcome>()
        for (i in (params.minCandles - 1) until candles.size - 1) {
            val window = candles.subList(maxOf(0, i - 59), i + 1)
            val r = SignalEngine.decide(
                DecisionInput(window, DataStatus.LIVE, null, "BACKTEST", requireTiming = false), params
            )
            outcomes += Outcomes.resolve(r.signal, candles[i + 1])
        }
        return PerformanceReport.from(outcomes)
    }

    /** CSV: time,open,high,low,close (header optional). Returns candles or an error message. */
    fun parseCsv(text: String): Pair<List<Candle>, String?> {
        val out = ArrayList<Candle>()
        text.lines().forEachIndexed { idx, raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEachIndexed
            val f = line.split(",").map { it.trim() }
            val nums = f.map { it.toDoubleOrNull() }
            if (f.size < 5 || nums.any { it == null }) {
                if (idx == 0) return@forEachIndexed
                return Pair(emptyList(), "Line ${idx + 1}: expected time,open,high,low,close")
            }
            out += Candle(nums[0]!!.toLong(), nums[1]!!, nums[2]!!, nums[3]!!, nums[4]!!)
        }
        return Pair(out, null)
    }
}
