package com.example.currencysignal.signal

import com.example.currencysignal.domain.Candle
import com.example.currencysignal.domain.DataStatus
import com.example.currencysignal.domain.Signal
import com.example.currencysignal.domain.SignalResult
import com.example.currencysignal.domain.TimingState
import kotlin.math.abs

/**
 * Heuristic strategy parameters. ASSUMPTIONS (untested): short EMA vs long EMA direction, recent
 * close-to-close momentum, and the last candle body direction (only if the body is a meaningful share
 * of the range) each cast one vote. A signal needs [requiredAgreement] votes in one direction and zero
 * opposing votes. None of this is shown to predict the next candle; see Backtester / paper mode.
 */
data class EngineParams(
    val minCandles: Int = 12,
    val fastEma: Int = 5,
    val slowEma: Int = 12,
    val momentumLookback: Int = 3,
    val minBodyRatio: Double = 0.35,
    val requiredAgreement: Int = 2
)

data class DecisionInput(
    val candles: List<Candle>,
    val dataStatus: DataStatus,
    val timing: TimingState?,
    val source: String,
    val note: String? = null,
    val requireTiming: Boolean = true
)

object SignalEngine {
    fun decide(input: DecisionInput, p: EngineParams = EngineParams()): SignalResult {
        fun no(reason: String) = SignalResult(Signal.NO_TRADE, reason, null, input.dataStatus, input.source)

        if (input.requireTiming) {
            val t = input.timing
            if (t == null || !t.reliable) return no("Timing unreliable: ${t?.reason ?: "no countdown"}")
        }
        when (input.dataStatus) {
            DataStatus.UNAVAILABLE -> return no(input.note ?: "Market data unavailable")
            DataStatus.STALE -> return no(input.note ?: "Market data stale")
            else -> Unit
        }
        val c = input.candles
        if (c.size < p.minCandles) return no("Insufficient candles (${c.size}/${p.minCandles})")

        val closes = c.map { it.close }
        val avgRange = c.takeLast(10).map { it.high - it.low }.average()
        if (!(avgRange > 0.0)) return no("No measurable price range")

        val fast = ema(closes, p.fastEma)
        val slow = ema(closes, p.slowEma)
        val emaVote = when {
            fast > slow + 0.05 * avgRange -> 1
            fast < slow - 0.05 * avgRange -> -1
            else -> 0
        }
        val back = closes.size - 1 - p.momentumLookback
        val mom = closes.last() - closes[back]
        val momVote = when {
            mom > 0.1 * avgRange -> 1
            mom < -0.1 * avgRange -> -1
            else -> 0
        }
        val l = c.last()
        val range = l.high - l.low
        val body = l.close - l.open
        val bodyVote = if (range > 0 && abs(body) / range >= p.minBodyRatio) (if (body > 0) 1 else -1) else 0

        val votes = listOf(emaVote, momVote, bodyVote)
        val up = votes.count { it > 0 }
        val down = votes.count { it < 0 }
        return when {
            up >= p.requiredAgreement && down == 0 ->
                SignalResult(Signal.UP, "EMA/momentum/body votes agree upward", up / 3.0, input.dataStatus, input.source)
            down >= p.requiredAgreement && up == 0 ->
                SignalResult(Signal.DOWN, "EMA/momentum/body votes agree downward", down / 3.0, input.dataStatus, input.source)
            up > 0 && down > 0 -> no("Indicators conflict")
            else -> no("Weak or neutral indicators")
        }
    }

    fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1)
        var e = values.first()
        for (i in 1 until values.size) e = values[i] * k + e * (1 - k)
        return e
    }
}
