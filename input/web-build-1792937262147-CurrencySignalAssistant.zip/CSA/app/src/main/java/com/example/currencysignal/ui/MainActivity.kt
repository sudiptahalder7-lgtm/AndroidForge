package com.example.currencysignal.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.mutableIntStateOf
import androidx.core.content.ContextCompat
import com.example.currencysignal.data.AppState
import com.example.currencysignal.service.CaptureService
import com.example.currencysignal.service.OverlayService

interface Actions {
    fun startScan()
    fun stopScan()
    fun openOverlaySettings()
    fun startOverlay()
    fun stopOverlay()
    fun overlayGranted(): Boolean
    fun notificationsGranted(): Boolean
}

class MainActivity : ComponentActivity(), Actions {
    companion object { const val EXTRA_REQUEST_SCAN = "request_scan" }

    private val vm by viewModels<MainViewModel>()
    private val resumeTick = mutableIntStateOf(0)

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_START)
                        .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                        .putExtra(CaptureService.EXTRA_DATA, data)
                )
            } else {
                AppState.update { it.copy(captureActive = false, statusMessage = "Screen-capture permission denied - scanning stays OFF") }
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            // Scanning works without it, but the STOP notification may be hidden; continue to consent.
            launchProjection()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent { App(vm, this, resumeTick.intValue) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_REQUEST_SCAN, false) == true) {
            i.removeExtra(EXTRA_REQUEST_SCAN)
            startScan()
        }
    }

    /** Step 1: explain what will be observed. The consent dialog's confirm calls [confirmedScan]. */
    override fun startScan() { vm.showConsent.value = true }

    fun confirmedScan() {
        vm.showConsent.value = false
        if (AppState.selected.value == null) {
            AppState.update { it.copy(statusMessage = "Select a currency pair first") }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !notificationsGranted()) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else launchProjection()
    }

    private fun launchProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent()) // official system consent prompt
    }

    override fun stopScan() {
        startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
    }

    override fun overlayGranted() = Settings.canDrawOverlays(this)

    override fun notificationsGranted() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    override fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun startOverlay() {
        if (!overlayGranted()) { openOverlaySettings(); return }
        startService(Intent(this, OverlayService::class.java))
    }

    override fun stopOverlay() { stopService(Intent(this, OverlayService::class.java)) }
}
