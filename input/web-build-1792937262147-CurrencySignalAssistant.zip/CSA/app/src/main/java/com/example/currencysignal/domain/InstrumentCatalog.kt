package com.example.currencysignal.domain

data class ImportResult(val imported: List<Instrument>, val errors: List<String>)

/**
 * Pure (Android-free) instrument catalog. REAL and OTC entries are keyed separately.
 *
 * Import format (CSV, one instrument per line, '#' comments allowed):
 *   market,displayName,symbol,providerId[,timeframesSec separated by |]
 *   REAL,EUR/USD,EURUSD,example-http,60
 *   OTC,EUR/USD,EURUSD,none
 */
class InstrumentCatalog(initial: List<Instrument>) {
    private val map = LinkedHashMap<String, Instrument>()

    init { initial.forEach { add(it) } }

    fun add(i: Instrument) { map[i.key] = i }
    fun all(): List<Instrument> = map.values.toList()
    fun get(key: String): Instrument? = map[key]

    fun filter(
        market: MarketType?,
        query: String,
        favorites: Set<String>,
        onlyFavorites: Boolean
    ): List<Instrument> {
        val q = query.trim().lowercase()
        return map.values.filter { i ->
            (market == null || i.marketType == market) &&
                (!onlyFavorites || i.key in favorites) &&
                (q.isEmpty() || i.displayName.lowercase().contains(q) || i.symbol.lowercase().contains(q))
        }
    }

    companion object {
        fun parseImport(text: String): ImportResult {
            val ok = ArrayList<Instrument>()
            val errors = ArrayList<String>()
            text.lines().forEachIndexed { idx, raw ->
                val line = raw.trim()
                if (line.isEmpty() || line.startsWith("#")) return@forEachIndexed
                val parts = line.split(",").map { it.trim() }
                if (idx == 0 && parts[0].equals("market", ignoreCase = true)) return@forEachIndexed
                if (parts.size < 4) { errors += "Line ${idx + 1}: expected at least 4 fields"; return@forEachIndexed }
                val market = runCatching { MarketType.valueOf(parts[0].uppercase()) }.getOrNull()
                if (market == null) { errors += "Line ${idx + 1}: market must be REAL or OTC"; return@forEachIndexed }
                if (parts[1].isEmpty() || parts[2].isEmpty()) { errors += "Line ${idx + 1}: empty name or symbol"; return@forEachIndexed }
                val tfs = if (parts.size >= 5 && parts[4].isNotEmpty())
                    parts[4].split("|").mapNotNull { it.trim().toIntOrNull() }.ifEmpty { listOf(60) }
                else listOf(60)
                ok += Instrument(
                    displayName = parts[1],
                    symbol = parts[2],
                    marketType = market,
                    providerId = parts[3].ifEmpty { "none" },
                    supportedTimeframesSec = tfs,
                    validation = ValidationStatus.USER_IMPORTED
                )
            }
            return ImportResult(ok, errors)
        }
    }
}
