package com.example.currencysignal.vision

import com.example.currencysignal.domain.Candle

/** Parses the on-chart candle countdown text. Accepts "0:07", "00:07", ":07"; rejects anything else. */
object CountdownParser {
    private val full = Regex("""(?<!\d)(\d{1,2})\s*:\s*(\d{2})(?!\d)""")
    private val secsOnly = Regex("""(?<![\d:])\s*:(\d{2})(?!\d)""")

    fun parse(text: String): Int? {
        full.find(text)?.let { m ->
            val min = m.groupValues[1].toInt()
            val sec = m.groupValues[2].toInt()
            return when {
                min == 0 && sec in 0..59 -> sec
                min == 1 && sec == 0 -> 60
                else -> null
            }
        }
        secsOnly.find(text)?.let { m ->
            val sec = m.groupValues[1].toInt()
            if (sec in 0..59) return sec
        }
        return null
    }
}

/**
 * Experimental, local-only pixel analysis of a cropped chart image. It looks for green/red candle
 * colour columns, groups adjacent columns into candles, and reports prices in RELATIVE units
 * (0..1 of the chart region height, auto-scale dependent). Output is SCREEN-ONLY data, never
 * verified price data. Assumes green = up and red = down candles on a dark chart.
 */
object ChartAnalyzer {
    private fun isGreen(p: Int): Boolean {
        val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
        return g > 140 && r < 120 && b < 140 && g - r > 50
    }

    private fun isRed(p: Int): Boolean {
        val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
        return r > 170 && g < 120 && b < 120 && r - g > 70
    }

    fun analyze(pixels: IntArray, w: Int, h: Int, maxCandleWidthPx: Int = 60): List<Candle> {
        if (w <= 0 || h <= 0 || pixels.size < w * h) return emptyList()
        // per column: colour class (1 green, -1 red, 0 none), top and bottom row
        val cls = IntArray(w); val top = IntArray(w) { h }; val bot = IntArray(w) { -1 }
        for (x in 0 until w) {
            var gc = 0; var rc = 0
            for (y in 0 until h) {
                val p = pixels[y * w + x]
                val g = isGreen(p); val r = !g && isRed(p)
                if (g || r) {
                    if (g) gc++ else rc++
                    if (y < top[x]) top[x] = y
                    if (y > bot[x]) bot[x] = y
                }
            }
            cls[x] = when {
                gc >= 2 && gc >= rc -> 1
                rc >= 2 -> -1
                else -> 0
            }
        }
        val candles = ArrayList<Candle>()
        var x = 0
        var index = 0L
        while (x < w) {
            if (cls[x] == 0) { x++; continue }
            val c = cls[x]; var e = x
            while (e + 1 < w && cls[e + 1] == c) e++
            val width = e - x + 1
            if (width in 2..maxCandleWidthPx) {
                var gTop = h; var gBot = -1
                val rowCount = IntArray(h)
                for (cx in x..e) {
                    if (top[cx] < gTop) gTop = top[cx]
                    if (bot[cx] > gBot) gBot = bot[cx]
                    for (y in top[cx]..bot[cx]) {
                        val p = pixels[y * w + cx]
                        if (if (c == 1) isGreen(p) else isRed(p)) rowCount[y]++
                    }
                }
                val maxRow = rowCount.max()
                val thr = maxOf(2, (maxRow * 0.6).toInt())
                var bTop = -1; var bBot = -1
                for (y in gTop..gBot) if (rowCount[y] >= thr) { if (bTop < 0) bTop = y; bBot = y }
                if (gBot - gTop >= 2 && bTop >= 0) {
                    fun price(y: Int) = (h - y).toDouble() / h
                    val open = if (c == 1) price(bBot) else price(bTop)
                    val close = if (c == 1) price(bTop) else price(bBot)
                    candles += Candle(index * 60_000L, open, price(gTop), price(gBot), close)
                    index++
                }
            }
            x = e + 1
        }
        return candles
    }
}
