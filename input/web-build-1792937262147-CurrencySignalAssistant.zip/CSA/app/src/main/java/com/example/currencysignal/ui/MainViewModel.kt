package com.example.currencysignal.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.currencysignal.data.AppState
import com.example.currencysignal.data.AppStore
import com.example.currencysignal.domain.AppSettings
import com.example.currencysignal.domain.Instrument
import com.example.currencysignal.domain.InstrumentCatalog
import com.example.currencysignal.domain.SeedData
import com.example.currencysignal.signal.Backtester
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = AppStore.get(app)
    private var catalog = InstrumentCatalog(SeedData.otcInstruments() + SeedData.realInstruments() + store.imported())

    val instruments = MutableStateFlow(catalog.all())
    val favorites = MutableStateFlow(store.favorites())
    val settings = MutableStateFlow(store.settings())
    val history: StateFlow<List<com.example.currencysignal.domain.HistoryEntry>> = AppState.history
    val importMessage = MutableStateFlow("")
    val backtestText = MutableStateFlow("")
    val showConsent = MutableStateFlow(false)
    val toast = MutableStateFlow("")

    fun select(i: Instrument) = store.saveSelected(i)

    fun toggleFavorite(i: Instrument) {
        val f = favorites.value.toMutableSet()
        if (!f.add(i.key)) f.remove(i.key)
        store.saveFavorites(f); favorites.value = f
    }

    fun filtered(market: com.example.currencysignal.domain.MarketType?, query: String, onlyFav: Boolean) =
        catalog.filter(market, query, favorites.value, onlyFav)

    fun importInstruments(text: String) {
        val r = InstrumentCatalog.parseImport(text)
        r.imported.forEach { catalog.add(it) }
        store.saveImported(store.imported().filter { old -> r.imported.none { it.key == old.key } } + r.imported)
        instruments.value = catalog.all()
        importMessage.value = "Imported ${r.imported.size} instrument(s)." +
            if (r.errors.isNotEmpty()) " Errors: " + r.errors.joinToString("; ") else ""
    }

    fun saveSettings(s: AppSettings) { store.saveSettings(s); settings.value = s }
    fun clearHistory() = store.clearHistory()

    fun runBacktest(csv: String) {
        val (candles, err) = Backtester.parseCsv(csv)
        backtestText.value = when {
            err != null -> err
            candles.size < 20 -> "Need at least 20 candles (got ${candles.size})."
            else -> Backtester.run(candles).format()
        }
    }
}
