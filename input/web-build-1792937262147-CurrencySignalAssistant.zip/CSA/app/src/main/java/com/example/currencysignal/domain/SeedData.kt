package com.example.currencysignal.domain

/**
 * Screenshot-derived OTC seed list. NOT a verified or complete Quotex asset list.
 * The REAL registry is intentionally empty: REAL instruments are added only through
 * user import after the user confirms they exist on the platform.
 */
object SeedData {
    private const val OTC_PAIRS =
        "USD/DZD, USD/INR, AUD/JPY, NZD/CHF, EUR/JPY, USD/CHF, AUD/CAD, USD/MXN, EUR/CHF, EUR/GBP, " +
            "GBP/USD, USD/BRL, EUR/USD, USD/BDT, EUR/AUD, USD/IDR, AUD/USD, USD/COP, GBP/AUD, GBP/CAD, " +
            "AUD/CHF, AUD/NZD, NZD/JPY, EUR/CAD, GBP/JPY, NZD/USD, CHF/JPY, USD/EGP, USD/JPY, USD/NGN, " +
            "NZD/CAD, USD/ARS, USD/CAD, USD/PHP, USD/PKR, CAD/CHF, CAD/JPY, USD/ZAR, GBP/CHF, GBP/NZD, EUR/NZD"

    /** providerId "none" = no market-data feed is mapped to this instrument. */
    fun otcInstruments(): List<Instrument> =
        OTC_PAIRS.split(",").map { it.trim() }.filter { it.isNotEmpty() }.map { pair ->
            Instrument(
                displayName = pair,
                symbol = pair.replace("/", ""),
                marketType = MarketType.OTC,
                providerId = "none",
                availability = Availability.UNKNOWN,
                lastUpdateMs = null,
                supportedTimeframesSec = listOf(60),
                validation = ValidationStatus.SCREENSHOT_DERIVED
            )
        }

    fun realInstruments(): List<Instrument> = emptyList()
}
