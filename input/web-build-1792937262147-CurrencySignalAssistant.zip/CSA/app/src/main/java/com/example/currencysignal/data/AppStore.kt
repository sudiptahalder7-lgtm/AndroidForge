package com.example.currencysignal.data

import android.content.Context
import android.content.SharedPreferences
import com.example.currencysignal.domain.AppSettings
import com.example.currencysignal.domain.Availability
import com.example.currencysignal.domain.DataStatus
import com.example.currencysignal.domain.HistoryEntry
import com.example.currencysignal.domain.Instrument
import com.example.currencysignal.domain.MarketType
import com.example.currencysignal.domain.Outcome
import com.example.currencysignal.domain.Region
import com.example.currencysignal.domain.Signal
import com.example.currencysignal.domain.ValidationStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** In-memory shared state observed by the UI, overlay and capture service. */
data class UiState(
    val captureActive: Boolean = false,
    val statusMessage: String = "Scanning is OFF",
    val lastScanMs: Long? = null,
    val countdownSec: Int? = null,
    val timingReliable: Boolean = false,
    val signal: Signal? = null,
    val signalReason: String = "",
    val signalTimeMs: Long? = null,
    val dataStatus: DataStatus = DataStatus.UNAVAILABLE,
    val providerName: String = "none",
    val lastVerifiedUpdateMs: Long? = null,
    val chartDetected: Boolean = false,
    val obscured: Boolean = false,
    val overlayRunning: Boolean = false
)

object AppState {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    fun update(f: (UiState) -> UiState) { _state.value = f(_state.value) }

    val selected = MutableStateFlow<Instrument?>(null)
    val history = MutableStateFlow<List<HistoryEntry>>(emptyList())
}

/** SharedPreferences-backed persistence for settings, favorites, imported instruments, history. */
class AppStore private constructor(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("csa", Context.MODE_PRIVATE)

    init {
        AppState.history.value = loadHistory()
        selectedKey()?.let { key ->
            (SeedDataHolder.all() + imported()).firstOrNull { it.key == key }?.let { AppState.selected.value = it }
        }
    }

    fun settings(): AppSettings {
        val d = AppSettings()
        fun reg(k: String, def: Region) = Region(
            sp.getFloat("$k.l", def.l), sp.getFloat("$k.t", def.t), sp.getFloat("$k.r", def.r), sp.getFloat("$k.b", def.b)
        )
        return AppSettings(
            samplingMs = sp.getLong("samplingMs", d.samplingMs),
            fastSamplingMs = sp.getLong("fastSamplingMs", d.fastSamplingMs),
            toleranceMs = sp.getLong("toleranceMs", d.toleranceMs),
            maxStaleMs = sp.getLong("maxStaleMs", d.maxStaleMs),
            chartRegion = reg("chart", d.chartRegion),
            countdownRegion = reg("cd", d.countdownRegion),
            paperMode = sp.getBoolean("paperMode", d.paperMode),
            allowScreenOnly = sp.getBoolean("allowScreenOnly", d.allowScreenOnly),
            providerBaseUrl = sp.getString("providerBaseUrl", "") ?: ""
        )
    }

    fun saveSettings(s: AppSettings) {
        sp.edit().apply {
            putLong("samplingMs", s.samplingMs); putLong("fastSamplingMs", s.fastSamplingMs)
            putLong("toleranceMs", s.toleranceMs); putLong("maxStaleMs", s.maxStaleMs)
            putBoolean("paperMode", s.paperMode); putBoolean("allowScreenOnly", s.allowScreenOnly)
            putString("providerBaseUrl", s.providerBaseUrl)
            for ((k, r) in listOf("chart" to s.chartRegion, "cd" to s.countdownRegion)) {
                putFloat("$k.l", r.l); putFloat("$k.t", r.t); putFloat("$k.r", r.r); putFloat("$k.b", r.b)
            }
        }.apply()
    }

    fun favorites(): Set<String> = sp.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
    fun saveFavorites(f: Set<String>) = sp.edit().putStringSet("favorites", f).apply()

    fun selectedKey(): String? = sp.getString("selected", null)
    fun saveSelected(i: Instrument) { sp.edit().putString("selected", i.key).apply(); AppState.selected.value = i }

    fun imported(): List<Instrument> {
        val arr = JSONArray(sp.getString("imported", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Instrument(
                o.getString("n"), o.getString("s"), MarketType.valueOf(o.getString("m")), o.getString("p"),
                Availability.UNKNOWN, null, listOf(60).let { _ ->
                    val t = o.getJSONArray("tf"); (0 until t.length()).map { i -> t.getInt(i) }
                }, ValidationStatus.USER_IMPORTED
            )
        }
    }

    fun saveImported(list: List<Instrument>) {
        val arr = JSONArray()
        list.forEach { i ->
            arr.put(JSONObject().put("n", i.displayName).put("s", i.symbol).put("m", i.marketType.name)
                .put("p", i.providerId).put("tf", JSONArray(i.supportedTimeframesSec)))
        }
        sp.edit().putString("imported", arr.toString()).apply()
    }

    private fun loadHistory(): List<HistoryEntry> = runCatching {
        val arr = JSONArray(sp.getString("history", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryEntry(
                o.getString("id"), o.getString("k"), o.getString("n"), MarketType.valueOf(o.getString("m")),
                o.getLong("t"), o.getLong("seq"), Signal.valueOf(o.getString("sig")),
                DataStatus.valueOf(o.getString("ds")), o.getString("src"), o.getString("why"),
                Outcome.valueOf(o.getString("out")), o.getBoolean("paper")
            )
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun updateHistory(transform: (List<HistoryEntry>) -> List<HistoryEntry>) {
        val next = transform(AppState.history.value).takeLast(500)
        AppState.history.value = next
        val arr = JSONArray()
        next.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("k", e.instrumentKey).put("n", e.displayName)
                .put("m", e.market.name).put("t", e.timeMs).put("seq", e.candleSeq).put("sig", e.signal.name)
                .put("ds", e.dataStatus.name).put("src", e.source).put("why", e.reason)
                .put("out", e.outcome.name).put("paper", e.paper))
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() = updateHistory { emptyList() }

    companion object {
        @Volatile private var inst: AppStore? = null
        fun get(ctx: Context): AppStore =
            inst ?: synchronized(this) { inst ?: AppStore(ctx).also { inst = it } }
    }
}

private object SeedDataHolder {
    fun all() = com.example.currencysignal.domain.SeedData.otcInstruments() +
        com.example.currencysignal.domain.SeedData.realInstruments()
}
