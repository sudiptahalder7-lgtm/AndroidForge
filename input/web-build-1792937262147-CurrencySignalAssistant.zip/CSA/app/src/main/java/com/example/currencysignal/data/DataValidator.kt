package com.example.currencysignal.data

import com.example.currencysignal.domain.Candle
import com.example.currencysignal.domain.DataStatus

/** Validates provider candles. Pure and unit-tested. */
object DataValidator {
    data class Result(val status: DataStatus, val reason: String?)

    fun validate(
        candles: List<Candle>,
        nowMs: Long,
        maxStaleMs: Long,
        fetchAgeMs: Long = 0,
        minCount: Int = 10,
        candleMs: Long = 60_000
    ): Result {
        if (candles.isEmpty()) return Result(DataStatus.UNAVAILABLE, "No candles returned")
        if (candles.size < minCount) return Result(DataStatus.UNAVAILABLE, "Only ${candles.size} candles (need $minCount)")
        for (i in candles.indices) {
            val c = candles[i]
            val vals = listOf(c.open, c.high, c.low, c.close)
            if (vals.any { !it.isFinite() || it <= 0.0 }) return Result(DataStatus.UNAVAILABLE, "Invalid price values")
            if (c.high < maxOf(c.open, c.close) || c.low > minOf(c.open, c.close))
                return Result(DataStatus.UNAVAILABLE, "Inconsistent OHLC at index $i")
            if (i > 0) {
                val dt = c.openTimeMs - candles[i - 1].openTimeMs
                if (dt <= 0) return Result(DataStatus.UNAVAILABLE, "Candles not strictly ordered")
                if (dt != candleMs) return Result(DataStatus.UNAVAILABLE, "Missing candle(s): gap of ${dt}ms")
            }
        }
        if (fetchAgeMs > maxStaleMs) return Result(DataStatus.STALE, "Data fetched ${fetchAgeMs}ms ago")
        val lag = nowMs - candles.last().openTimeMs
        if (lag > candleMs + maxStaleMs) return Result(DataStatus.STALE, "Latest candle is ${lag}ms old")
        return Result(DataStatus.LIVE, null)
    }
}
