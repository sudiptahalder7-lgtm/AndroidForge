package com.example.currencysignal.domain

enum class MarketType { REAL, OTC }

enum class Signal(val label: String) { UP("UP"), DOWN("DOWN"), NO_TRADE("NO TRADE") }

enum class DataStatus(val label: String) {
    LIVE("LIVE"), STALE("STALE"), UNAVAILABLE("UNAVAILABLE"), SCREEN_ONLY("SCREEN-ONLY")
}

enum class ValidationStatus { SCREENSHOT_DERIVED, USER_IMPORTED, VERIFIED }
enum class Availability { UNKNOWN, AVAILABLE, UNAVAILABLE }
enum class Outcome { PENDING, WIN, LOSS, DRAW, SKIPPED, UNRESOLVED }

data class Instrument(
    val displayName: String,
    val symbol: String,
    val marketType: MarketType,
    val providerId: String,
    val availability: Availability = Availability.UNKNOWN,
    val lastUpdateMs: Long? = null,
    val supportedTimeframesSec: List<Int> = listOf(60),
    val validation: ValidationStatus
) {
    /** REAL and OTC never share a key, even with an identical symbol. */
    val key: String get() = "${marketType.name}:$symbol"
}

data class Candle(
    val openTimeMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

data class TimingState(
    val reliable: Boolean,
    val remainingMs: Long,
    val candleSeq: Long,
    val jitterMs: Long,
    val reason: String?
)

data class SignalResult(
    val signal: Signal,
    val reason: String,
    /** Heuristic agreement score 0..1. NOT a calibrated probability. */
    val heuristicScore: Double?,
    val dataStatus: DataStatus,
    val source: String
)

data class HistoryEntry(
    val id: String,
    val instrumentKey: String,
    val displayName: String,
    val market: MarketType,
    val timeMs: Long,
    val candleSeq: Long,
    val signal: Signal,
    val dataStatus: DataStatus,
    val source: String,
    val reason: String,
    val outcome: Outcome,
    val paper: Boolean
)

data class Region(val l: Float, val t: Float, val r: Float, val b: Float)

data class AppSettings(
    val samplingMs: Long = 1000,
    val fastSamplingMs: Long = 250,
    val toleranceMs: Long = 1500,
    val maxStaleMs: Long = 15_000,
    val chartRegion: Region = Region(0f, 0.12f, 0.85f, 0.70f),
    val countdownRegion: Region = Region(0.55f, 0.06f, 1f, 0.14f),
    val paperMode: Boolean = true,
    val allowScreenOnly: Boolean = true,
    val providerBaseUrl: String = ""
)
