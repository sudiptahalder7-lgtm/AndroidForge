package com.example.currencysignal.data

import com.example.currencysignal.domain.AppSettings
import com.example.currencysignal.domain.Candle
import com.example.currencysignal.domain.Instrument
import com.example.currencysignal.domain.MarketType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder

enum class FailureKind { NETWORK, TIMEOUT, RATE_LIMITED, HTTP, PARSE, SYMBOL_MISMATCH, UNSUPPORTED }

sealed class FetchResult {
    data class Success(
        val candles: List<Candle>,
        val fetchedAtMs: Long,
        val serverTimeMs: Long?,
        val providerName: String
    ) : FetchResult()

    data class Failure(val kind: FailureKind, val reason: String) : FetchResult()
}

/** Provider-independent market-data interface. */
interface MarketDataProvider {
    val id: String
    val displayName: String
    fun supports(instrument: Instrument): Boolean
    suspend fun fetchCandles(instrument: Instrument, count: Int): FetchResult
}

object Providers {
    /** An instrument is served by a feed only if its providerId explicitly names that feed. */
    fun forInstrument(i: Instrument, s: AppSettings): MarketDataProvider? {
        if (s.providerBaseUrl.isBlank()) return null
        val p = ExampleHttpAdapter(s.providerBaseUrl.trim())
        return if (p.supports(i)) p else null
    }
}

/**
 * EXAMPLE ADAPTER - NOT a real provider. It talks to a backend YOU run and defines this contract:
 *
 *   GET {baseUrl}/candles?symbol=EURUSD&market=OTC&tf=60&limit=30
 *   200 -> {"symbol":"EURUSD","market":"OTC","serverTimeMs":1700000000000,
 *           "candles":[{"t":1699999940000,"o":1.0,"h":1.1,"l":0.9,"c":1.05}, ...]}
 *
 * No endpoint is invented here and no claim is made that any provider supports Quotex OTC prices.
 * Secrets (API keys) must stay on your backend; this adapter sends none.
 * Only instruments whose providerId == "example-http" are routed to it.
 */
class ExampleHttpAdapter(
    private val baseUrl: String,
    private val clock: () -> Long = { System.currentTimeMillis() }
) : MarketDataProvider {
    override val id = "example-http"
    override val displayName = "Example HTTP adapter (user backend)"

    override fun supports(instrument: Instrument) =
        instrument.providerId == id && 60 in instrument.supportedTimeframesSec

    override suspend fun fetchCandles(instrument: Instrument, count: Int): FetchResult {
        if (!supports(instrument)) return FetchResult.Failure(FailureKind.UNSUPPORTED, "No feed mapped to ${instrument.key}")
        var last: FetchResult.Failure? = null
        repeat(2) { attempt ->
            when (val r = once(instrument, count)) {
                is FetchResult.Success -> return r
                is FetchResult.Failure -> {
                    last = r
                    if (r.kind != FailureKind.NETWORK && r.kind != FailureKind.TIMEOUT) return r
                    if (attempt == 0) delay(400)
                }
            }
        }
        return last ?: FetchResult.Failure(FailureKind.NETWORK, "Unknown error")
    }

    private suspend fun once(i: Instrument, count: Int): FetchResult = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            val url = URL(
                baseUrl.trimEnd('/') + "/candles?symbol=" + URLEncoder.encode(i.symbol, "UTF-8") +
                    "&market=${i.marketType.name}&tf=60&limit=$count"
            )
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 3000; readTimeout = 3000; requestMethod = "GET"
            }
            val code = conn.responseCode
            if (code == 429) return@withContext FetchResult.Failure(FailureKind.RATE_LIMITED, "Rate limited (HTTP 429)")
            if (code != 200) return@withContext FetchResult.Failure(FailureKind.HTTP, "HTTP $code")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val market = runCatching { MarketType.valueOf(json.getString("market").uppercase()) }.getOrNull()
            if (json.optString("symbol") != i.symbol || market != i.marketType)
                return@withContext FetchResult.Failure(FailureKind.SYMBOL_MISMATCH, "Feed returned ${json.optString("symbol")}/${json.optString("market")}, expected ${i.key}")
            val arr = json.getJSONArray("candles")
            val candles = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Candle(o.getLong("t"), o.getDouble("o"), o.getDouble("h"), o.getDouble("l"), o.getDouble("c"))
            }
            val server = if (json.has("serverTimeMs")) json.getLong("serverTimeMs") else null
            FetchResult.Success(candles, clock(), server, displayName)
        } catch (e: SocketTimeoutException) {
            FetchResult.Failure(FailureKind.TIMEOUT, "Timed out")
        } catch (e: org.json.JSONException) {
            FetchResult.Failure(FailureKind.PARSE, "Malformed response")
        } catch (e: java.io.IOException) {
            FetchResult.Failure(FailureKind.NETWORK, "Network error: ${e.javaClass.simpleName}")
        } finally {
            conn?.disconnect()
        }
    }
}
