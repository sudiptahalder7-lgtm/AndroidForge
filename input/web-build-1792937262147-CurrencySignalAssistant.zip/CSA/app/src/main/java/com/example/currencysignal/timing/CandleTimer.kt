package com.example.currencysignal.timing

import com.example.currencysignal.domain.TimingState

/**
 * Derives the candle boundary from OBSERVED on-screen countdown readings (not from the phone clock
 * matching the broker). All times are monotonic (SystemClock.elapsedRealtime) milliseconds passed in
 * by the caller, which keeps this class pure and unit-testable.
 *
 * The displayed countdown is whole seconds, so each reading carries ~500 ms inherent uncertainty.
 */
class CandleTimer(
    var toleranceMs: Long = 1500,
    private val maxObsAgeMs: Long = 5000,
    private val minObservations: Int = 3,
    val candleMs: Long = 60_000,
    val publishLeadMs: Long = 1000,
    val analysisWindowMs: Long = 7000
) {
    private data class Obs(val atMs: Long, val boundaryMs: Long)

    private val obs = ArrayList<Obs>()
    private var seq = 0L
    private var discontinuity: String? = null

    fun reset(reason: String? = null) {
        obs.clear(); seq++; discontinuity = reason
    }

    fun observe(secondsRemaining: Int, nowMs: Long) {
        if (secondsRemaining !in 0..60) return
        val boundary = nowMs + secondsRemaining * 1000L - 500L
        val last = obs.lastOrNull()
        if (last != null) {
            val diff = boundary - estimatedBoundary()
            when {
                kotlin.math.abs(diff) <= toleranceMs -> Unit
                kotlin.math.abs(diff - candleMs) <= toleranceMs && nowMs >= estimatedBoundary() - toleranceMs -> {
                    // normal rollover into the next candle
                    obs.clear(); seq++; discontinuity = null
                }
                else -> { obs.clear(); seq++; discontinuity = "Countdown jumped unexpectedly" }
            }
        } else {
            seq++
        }
        obs.add(Obs(nowMs, boundary))
        if (obs.size > 8) obs.removeAt(0)
        if (obs.size >= 2) discontinuity = null
    }

    private fun estimatedBoundary(): Long {
        val sorted = obs.map { it.boundaryMs }.sorted()
        return sorted[sorted.size / 2]
    }

    fun state(nowMs: Long): TimingState {
        if (obs.isEmpty()) return TimingState(false, 0, seq, 0, discontinuity ?: "Countdown not detected")
        val jitter = obs.maxOf { it.boundaryMs } - obs.minOf { it.boundaryMs }
        val age = nowMs - obs.last().atMs
        val remaining = estimatedBoundary() - nowMs
        val reason = when {
            age > maxObsAgeMs -> "Countdown not seen for ${age / 1000}s"
            obs.size < minObservations -> "Collecting countdown readings (${obs.size}/$minObservations)"
            jitter > toleranceMs -> "Timing uncertainty ${jitter}ms exceeds ${toleranceMs}ms"
            remaining < -toleranceMs -> "Candle boundary passed; waiting for new countdown"
            else -> null
        }
        return TimingState(reason == null, remaining, seq, jitter, reason)
    }

    fun inAnalysisWindow(s: TimingState) = s.reliable && s.remainingMs in 1..analysisWindowMs
    fun inPublishWindow(s: TimingState) = s.reliable && s.remainingMs in 0..publishLeadMs
}
