# Currency Signal Assistant (native Android, Kotlin + Compose)

Educational, experimental market-observation tool. It **never places trades**, never clicks anything, never asks for
Quotex credentials, and never reads cookies/tokens. Signals are heuristic; no win rate is proven; **you can lose money**.

> **Build status: NOT built or run by the author of this package.** Source was written and reasoned through but no
> Gradle build, device run or unit-test run was performed in the generation environment. Treat the first
> build as unverified; expect to fix small compile or version issues.

## Requirements
- Android Studio Ladybug (2024.2.1) or newer, JDK 17 (bundled with Studio), Android SDK 35 installed.
- A physical phone/emulator on Android 12 (API 31) or newer.
- Versions used: AGP 8.7.3, Kotlin 2.0.21 (Compose compiler plugin), Gradle 8.9, Compose BOM 2024.10.01, ML Kit text-recognition 16.0.1.

## Build and install
1. Unzip, then in Android Studio: **File > Open** the `CurrencySignalAssistant` folder.
   (The Gradle wrapper *jar* is not included; Studio uses its own Gradle, or run `gradle wrapper --gradle-version 8.9` once.)
2. Let Gradle sync, then run unit tests: `./gradlew :app:testDebugUnitTest`
3. Install: `./gradlew :app:installDebug` (USB debugging on) or press Run in Studio.

## Using it
1. **Pairs** tab: pick a pair (OTC seed list is screenshot-derived, NOT a verified or complete Quotex list; REAL is empty until you import confirmed instruments).
2. **Access** tab: grant *Display over other apps* (opens the system page; the app cannot grant it itself).
3. **Dashboard > START SCANNING**: read the explanation, accept the Android screen-capture prompt (Android 14+ lets you share one app: choose the Quotex app). A persistent notification with STOP appears.
4. **Testing** tab: if the countdown/chart is not found, adjust the countdown and chart regions (fractions of the screen) so they cover the on-chart countdown text and the candles.
5. **Show overlay**: draggable panel with pair, REAL/OTC, 1M, countdown, last scan, signal, data status, START/STOP, MIN, CLOSE.

## Architecture (package `com.example.currencysignal`)
- `domain/` models, seed data, pure `InstrumentCatalog` (REAL and OTC keyed separately: `REAL:EURUSD` vs `OTC:EURUSD`).
- `timing/CandleTimer` countdown-observation based boundary estimate (monotonic ms, jitter/tolerance checks, per-candle sequence to prevent duplicate signals).
- `vision/` local pixel analysis (green/red candle columns -> relative OHLC, SCREEN-ONLY) and ML Kit OCR for the countdown.
- `data/` provider interface, `DataValidator` (order, gaps, OHLC sanity, staleness), `ExampleHttpAdapter` (clearly an EXAMPLE contract for a backend you run), `AppStore` persistence.
- `signal/` `SignalEngine`, `Backtester`, paper outcomes and `PerformanceReport` (Wilson interval).
- `service/CaptureService` (mediaProjection foreground service), `service/OverlayService` (TYPE_APPLICATION_OVERLAY).
- `ui/` Compose screens: Dashboard, Pairs, History, Access, Testing/Settings.

## Signal engine assumptions
Three votes: fast vs slow EMA, 3-candle momentum, last candle body direction (if body >= 35% of range). A signal needs 2 agreeing
votes and 0 opposing, else NO TRADE. Dozens of conditions force NO TRADE (unreliable timing, stale/unavailable data, <12 candles).
The shown score is a vote fraction, **not a probability**; no confidence percentage is displayed because nothing is calibrated.
Use the Backtest box (CSV `time,open,high,low,close`) and paper mode to measure results; reports list wins, losses, draws, skipped, sample size and method.

## Data feeds
No real provider is bundled and none is claimed to support Quotex OTC prices. `ExampleHttpAdapter` expects a backend you operate:
`GET {base}/candles?symbol=EURUSD&market=OTC&tf=60&limit=30` returning `{"symbol","market","serverTimeMs","candles":[{"t","o","h","l","c"}]}`.
It rejects symbol/market mismatches. Only instruments whose `providerId` is `example-http` are routed to it; everything else is SCREEN-ONLY (if allowed) or NO TRADE. Keep API keys on your backend, never in the app.
Instrument import (Testing tab) CSV: `market,displayName,symbol,providerId[,timeframesSec|...]`, e.g. `REAL,EUR/USD,EURUSD,example-http,60`.
Plain HTTP backends need a network-security-config; use HTTPS.

## Android version notes
- Android 12/13: `FOREGROUND_SERVICE` + MediaProjection consent; `POST_NOTIFICATIONS` runtime permission on 13+.
- Android 14+ (targetSdk 34+): `FOREGROUND_SERVICE_MEDIA_PROJECTION` permission and `foregroundServiceType="mediaProjection"` are declared; the service enters the foreground *before* obtaining the projection and registers a `MediaProjection.Callback` before creating the virtual display; the consent token is single-use, so each scan asks again. Users may share a single app.
- Android 15: capture of other apps is limited by the system; secure windows (FLAG_SECURE) show blank frames and the app reports NO TRADE.
- Overlay: `SYSTEM_ALERT_WINDOW` must be granted by the user in system settings. Overlay START opens the app to ask for capture consent (an Activity is required).
- OEMs may kill background services. The UI shows scanning OFF whenever the service/projection ends.

## Limitations (honest list)
- Countdown OCR and chart colour detection are best-effort, tuned for a dark chart with green/red candles; regions must be set manually. Screen-only prices are relative to chart auto-scale and are **not** verified price data.
- 1-second accuracy is not guaranteed: countdown is whole seconds (~0.5 s uncertainty) plus capture/OCR latency; if confidence is low the result is NO TRADE.
- Paper outcomes use the nearly-closed target candle (~1 s before close) so they are approximate.
- No diagnostic screenshot storage is implemented: frames are never saved.
- Not covered by automated tests: the Android services, OCR, overlay and Compose UI (they need a device). Reasoned scenarios: permission denied -> scanning stays OFF with message; user stops -> service releases projection and removes notification; overlay permission missing -> button opens settings, service self-stops; background -> foreground service keeps running; screen off -> paused with NO TRADE; no countdown -> NO TRADE with reason; stale feed -> STALE + NO TRADE; OTC symbol with no feed -> SCREEN-ONLY or NO TRADE; network down -> feed Failure -> UNAVAILABLE + NO TRADE; repeat scans in one candle -> one signal per candle sequence.
