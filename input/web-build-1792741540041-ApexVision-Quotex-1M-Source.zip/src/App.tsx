import React, { useState, useEffect, useRef } from 'react';
import {
  Smartphone,
  ShieldAlert,
  BarChart2,
  History,
  Code2,
  Sparkles,
  Info,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  Layers,
  Clock,
  Zap,
  Download,
  FileCode,
  CheckCircle2,
} from 'lucide-react';

import {
  TradeSignal,
  SignalOutcome,
  ChartAnalysisResult,
  SignalRecord,
  AccuracyStats,
} from './types/analyzer';

import { GlowingIndicator } from './components/GlowingIndicator';
import { ChartUploader } from './components/ChartUploader';
import { AnalysisDisplay } from './components/AnalysisDisplay';
import { AccuracyTracker } from './components/AccuracyTracker';
import { SignalHistory } from './components/SignalHistory';
import { AndroidBlueprintModal } from './components/AndroidBlueprintModal';
import { QuotexCandleTimer } from './components/QuotexCandleTimer';
import { FloatingQuotexOverlay } from './components/FloatingQuotexOverlay';
import { SourceCodeExplorerModal } from './components/SourceCodeExplorerModal';
import { analyzeChartImage } from './services/chartAnalyzer';

// Starter 1-minute historical signals demonstrating strict closed-candle outcome validation
const INITIAL_SIGNALS: SignalRecord[] = [
  {
    id: 'quotex-sig-1',
    timestamp: Date.now() - 1000 * 60 * 4,
    dateStr: 'Today',
    timeStr: '12:01:58',
    candleTargetTime: 'Next 1m (12:02:00 - 12:03:00)',
    asset: 'EUR/USD (Quotex)',
    timeframe: '1m',
    signal: 'UP',
    pattern: '1m Hammer Rejection at Round Support',
    confidence: 82,
    rationale: 'Long lower shadow with 65% wick rejection at round 1.08450 level during final 7s.',
    support: '1.08450',
    resistance: '1.08500',
    outcome: 'WIN',
    actualNextCandle: 'GREEN',
    latencyMs: 740,
    resolvedAt: Date.now() - 1000 * 60 * 3,
  },
  {
    id: 'quotex-sig-2',
    timestamp: Date.now() - 1000 * 60 * 2,
    dateStr: 'Today',
    timeStr: '12:03:59',
    candleTargetTime: 'Next 1m (12:04:00 - 12:05:00)',
    asset: 'USD/JPY (Quotex)',
    timeframe: '1m',
    signal: 'DOWN',
    pattern: '1m Shooting Star at Round Resistance',
    confidence: 79,
    rationale: 'Upper wick rejection off 155.000 round ceiling in final 7s indicated buyer exhaustion.',
    support: '154.850',
    resistance: '155.000',
    outcome: 'WIN',
    actualNextCandle: 'RED',
    latencyMs: 810,
    resolvedAt: Date.now() - 1000 * 60 * 1,
  },
  {
    id: 'quotex-sig-3',
    timestamp: Date.now() - 1000 * 40,
    dateStr: 'Today',
    timeStr: '12:05:58',
    candleTargetTime: 'Next 1m (12:06:00 - 12:07:00)',
    asset: 'GBP/USD (Quotex)',
    timeframe: '1m',
    signal: 'NO_TRADE',
    pattern: 'Indecision Spinning Top (Equilibrium)',
    confidence: 52,
    rationale: 'Current 1m candle closed as a flat doji with balanced wicks. Insufficient evidence.',
    support: '1.26400',
    resistance: '1.26450',
    outcome: 'SKIPPED',
    actualNextCandle: 'DOJI',
    latencyMs: 650,
  },
];

export default function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ChartAnalysisResult | null>(null);
  const [activeTab, setActiveTab] = useState<'analyzer' | 'history' | 'android' | 'about'>('analyzer');
  const [isBlueprintOpen, setIsBlueprintOpen] = useState(false);
  const [isSavedInHistory, setIsSavedInHistory] = useState(false);
  const [isDeviceFrame, setIsDeviceFrame] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // 1-Minute Quotex Timing & Floating Overlay states
  const [showFloatingOverlay, setShowFloatingOverlay] = useState(false);
  const [autoTriggerFinal7s, setAutoTriggerFinal7s] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleDownloadZip = () => {
    const link = document.createElement('a');
    link.href = '/ApexVision-Quotex-1M-Source.zip';
    link.download = 'ApexVision-Quotex-1M-Source.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Load persistent signals from localStorage
  const [signals, setSignals] = useState<SignalRecord[]>(() => {
    try {
      const stored = localStorage.getItem('apex_quotex_1m_signals');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to parse stored signals:', e);
    }
    return INITIAL_SIGNALS;
  });

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('apex_quotex_1m_signals', JSON.stringify(signals));
    } catch (e) {
      console.warn('Failed to save signals to storage:', e);
    }
  }, [signals]);

  // Synchronized 1-minute countdown timer loop
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const currentSec = now.getSeconds();
      const remaining = 60 - currentSec;
      setSecondsRemaining(remaining === 0 ? 60 : remaining);
    }, 250);

    return () => clearInterval(timer);
  }, []);

  // Compute strictly outcome-verified statistics (never invented)
  const stats: AccuracyStats = React.useMemo(() => {
    let wins = 0;
    let losses = 0;
    let skipped = 0;
    let missedDeadlines = 0;
    let pending = 0;

    signals.forEach((s) => {
      if (s.outcome === 'WIN') wins++;
      else if (s.outcome === 'LOSS') losses++;
      else if (s.outcome === 'SKIPPED') skipped++;
      else if (s.outcome === 'MISSED_DEADLINE' || s.signal === 'MISSED_SIGNAL') missedDeadlines++;
      else pending++;
    });

    const evaluated = wins + losses;
    const winRate = evaluated > 0 ? Math.round((wins / evaluated) * 100) : null;

    return {
      totalLogged: signals.length,
      totalEvaluated: evaluated,
      wins,
      losses,
      skipped,
      missedDeadlines,
      pending,
      winRate,
    };
  }, [signals]);

  // Audio tone feedback for trade signals
  const playSignalSound = (signal: TradeSignal) => {
    if (!soundEnabled || typeof window === 'undefined') return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (signal === 'UP') {
        // High ascending 1-minute CALL chime
        osc.frequency.setValueAtTime(587.33, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      } else if (signal === 'DOWN') {
        // Deep alert 1-minute PUT chime
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(261.63, ctx.currentTime + 0.18);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      } else if (signal === 'MISSED_SIGNAL') {
        // Double warning buzz
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      }
    } catch {
      // AudioContext gestures
    }
  };

  const handleImageSelected = (dataUrl: string, presetName?: string) => {
    setSelectedImage(dataUrl);
    setAnalysisResult(null);
    setIsSavedInHistory(false);
  };

  const handleClearImage = () => {
    setSelectedImage(null);
    setAnalysisResult(null);
    setIsSavedInHistory(false);
  };

  // Run 1-minute candle analysis (focusing on final 7 seconds)
  const handleRunAnalysis = async (candleSec?: number) => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    const windowSec = candleSec ?? secondsRemaining;

    try {
      const result = await analyzeChartImage(selectedImage, undefined, windowSec);
      setAnalysisResult(result);

      if (result.chartDetected) {
        playSignalSound(result.suggestedSignal);

        // Auto-save signal as PENDING to history for closed-candle outcome verification
        const targetNextMinute = new Date(Date.now() + 60000);
        const targetTimeStr = `Next 1m (${targetNextMinute.toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        })})`;

        const newRecord: SignalRecord = {
          id: 'sig-' + Date.now(),
          timestamp: Date.now(),
          dateStr: new Date().toLocaleDateString([], { month: 'short', day: 'numeric' }),
          timeStr: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          candleTargetTime: targetTimeStr,
          asset: result.assetOrPair || 'EUR/USD (Quotex)',
          timeframe: '1m',
          signal: result.suggestedSignal,
          pattern: result.pattern,
          confidence: result.confidenceScore,
          rationale: result.rationale,
          support: result.supportLevel || '--',
          resistance: result.resistanceLevel || '--',
          latencyMs: result.latencyMs,
          outcome: result.suggestedSignal === 'MISSED_SIGNAL'
            ? 'MISSED_DEADLINE'
            : result.suggestedSignal === 'NO_TRADE'
            ? 'SKIPPED'
            : 'PENDING',
        };

        setSignals((prev) => [newRecord, ...prev]);
        setIsSavedInHistory(true);
      }
    } catch (err) {
      console.error('Analysis failed:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Update outcome based on the closed next 1m candle
  const handleUpdateOutcome = (id: string, outcome: SignalOutcome, actualColor?: 'GREEN' | 'RED' | 'DOJI') => {
    setSignals((prev) =>
      prev.map((s) => (s.id === id ? { ...s, outcome, actualNextCandle: actualColor, resolvedAt: Date.now() } : s))
    );
  };

  const handleDeleteSignal = (id: string) => {
    setSignals((prev) => prev.filter((s) => s.id !== id));
  };

  const handleClearAllSignals = () => {
    if (confirm('Clear all 1-minute signal history? Outcome tracking will reset.')) {
      setSignals([]);
    }
  };

  const currentSignal: TradeSignal | 'IDLE' = isAnalyzing
    ? 'IDLE'
    : analysisResult?.chartDetected
    ? analysisResult.suggestedSignal
    : 'IDLE';

  return (
    <div className="min-h-screen bg-[#070a12] text-slate-100 flex flex-col items-center justify-start p-2 sm:p-4 selection:bg-cyan-500 selection:text-black">
      {/* Top Device Bar (Desktop Toggle) */}
      <div className="w-full max-w-md hidden sm:flex items-center justify-between mb-2 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-1.5">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-slate-300">Quotex 1M Android Terminal</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="flex items-center gap-1 text-[11px] hover:text-slate-200 transition-colors"
            title="Toggle Audio Cues"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
            <span>{soundEnabled ? 'Audio On' : 'Muted'}</span>
          </button>
          <button
            onClick={() => setIsDeviceFrame(!isDeviceFrame)}
            className="flex items-center gap-1 text-[11px] hover:text-slate-200 transition-colors"
          >
            {isDeviceFrame ? <Maximize2 className="w-3 h-3" /> : <Minimize2 className="w-3 h-3" />}
            <span>{isDeviceFrame ? 'Full Width' : 'Phone Shell'}</span>
          </button>
        </div>
      </div>

      {/* Main Container - Android Mobile Dimensions */}
      <div
        ref={containerRef}
        className={`w-full transition-all duration-300 flex flex-col relative ${
          isDeviceFrame
            ? 'max-w-[440px] rounded-3xl border border-slate-800 bg-[#090d16] shadow-2xl shadow-cyan-950/20 overflow-hidden min-h-[92vh]'
            : 'max-w-2xl rounded-2xl border border-slate-800 bg-[#090d16] p-4'
        }`}
      >
        {/* Android Phone Status Bar Simulation */}
        {isDeviceFrame && (
          <div className="px-5 pt-3 pb-1 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none border-b border-slate-800/40">
            <span className="font-bold text-slate-300">09:41</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-slate-800 px-1 rounded text-cyan-300 font-bold">Quotex 1m</span>
              <span className="text-[10px] text-emerald-400">● 100%</span>
            </div>
          </div>
        )}

        {/* Header */}
        <header className="px-4 py-2.5 flex items-center justify-between border-b border-slate-800/80 bg-slate-900/40">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 flex items-center justify-center text-slate-950 font-black text-sm shadow-md shadow-cyan-500/20">
              ⚡
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm font-extrabold tracking-tight text-white">
                  ApexVision
                </h1>
                <span className="px-1.5 py-0.2 rounded bg-cyan-500/15 border border-cyan-500/30 text-[9px] font-bold text-cyan-300 uppercase tracking-wider font-mono">
                  1M Quotex
                </span>
              </div>
              <p className="text-[10px] text-slate-400">Next 1-Minute Candle Analyzer</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowFloatingOverlay(!showFloatingOverlay)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border active:scale-95 transition-all shadow-sm ${
                showFloatingOverlay
                  ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                  : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border-cyan-500/30'
              }`}
              title="Toggle Circular Floating Overlay Concept"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{showFloatingOverlay ? 'Overlay On' : 'Floating UI'}</span>
            </button>

            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition-all"
              title="Download Full Source Code (.zip)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .zip</span>
            </button>

            <button
              onClick={() => setIsBlueprintOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-emerald-400 border border-emerald-500/30 active:scale-95 transition-all shadow-sm"
            >
              <Code2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Android</span>
            </button>
          </div>
        </header>

        {/* Safety Disclaimer Banner */}
        <div className="mx-3 mt-2.5 p-2 rounded-xl border border-rose-500/30 bg-rose-950/20 text-rose-200 text-[10px] flex items-start gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
          <div className="leading-tight">
            <strong>1-Minute Binary Options Rule:</strong> Evaluates ONLY the single next 1m candle during the final 7s window. <strong>Does not execute trades automatically.</strong> Late signals are marked MISSED.
          </div>
        </div>

        {/* 1-Minute Quotex Candle Timer */}
        <div className="px-3 pt-2.5">
          <QuotexCandleTimer
            autoTriggerFinal7s={autoTriggerFinal7s}
            onToggleAutoTrigger={() => setAutoTriggerFinal7s(!autoTriggerFinal7s)}
            onFinal7SecondsWindow={(sec) => {
              if (selectedImage && !isAnalyzing) {
                handleRunAnalysis(sec);
              }
            }}
          />
        </div>

        {/* Signal Hero Stage (Circular Glowing Indicator) */}
        <div className="px-4 pt-2 pb-1 flex flex-col items-center">
          <GlowingIndicator
            signal={currentSignal}
            confidence={analysisResult?.confidenceScore}
            isAnalyzing={isAnalyzing}
            secondsRemaining={secondsRemaining}
            latencyMs={analysisResult?.latencyMs}
            size="large"
          />

          <div className="text-center mt-1">
            <div
              className={`text-base font-extrabold tracking-tight font-mono ${
                currentSignal === 'UP'
                  ? 'text-emerald-400'
                  : currentSignal === 'DOWN'
                  ? 'text-rose-400'
                  : currentSignal === 'NO_TRADE'
                  ? 'text-slate-300'
                  : currentSignal === 'MISSED_SIGNAL'
                  ? 'text-amber-400'
                  : 'text-slate-400'
              }`}
            >
              {isAnalyzing
                ? 'Inspecting Final 7s Candlestick Rejection...'
                : currentSignal === 'UP'
                ? 'NEXT 1M: CALL / UP (GREEN)'
                : currentSignal === 'DOWN'
                ? 'NEXT 1M: PUT / DOWN (RED)'
                : currentSignal === 'NO_TRADE'
                ? 'NEXT 1M: NO TRADE (HOLD)'
                : currentSignal === 'MISSED_SIGNAL'
                ? 'MISSED SIGNAL (EXPIRED)'
                : 'Awaiting 7s Candle Frame'}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              {currentSignal === 'IDLE'
                ? 'Target entry: ~1s before next candle opens (:59 mark)'
                : `${analysisResult?.pattern || 'Next 60s Candle'}`}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-3 py-2 flex items-center gap-1 border-y border-slate-800 bg-slate-900/60 text-xs">
          <button
            onClick={() => setActiveTab('analyzer')}
            className={`flex-1 py-1.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'analyzer'
                ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>1M Scalper</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'history'
                ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Log & Stats ({signals.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 py-1.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'android'
                ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android Blueprint</span>
          </button>

          <button
            onClick={() => setActiveTab('about')}
            className={`py-1.5 px-2 rounded-xl font-bold flex items-center justify-center transition-all ${
              activeTab === 'about'
                ? 'bg-slate-800 text-cyan-300 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Timing Rules"
          >
            <Info className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 p-3 overflow-y-auto space-y-3">
          {activeTab === 'analyzer' && (
            <>
              {/* Uploader / Frame Grabber */}
              <ChartUploader
                selectedImage={selectedImage}
                onImageSelected={handleImageSelected}
                onClearImage={handleClearImage}
                isAnalyzing={isAnalyzing}
                onAnalyze={handleRunAnalysis}
                secondsRemaining={secondsRemaining}
              />

              {/* Analysis Results Display */}
              {analysisResult && (
                <AnalysisDisplay
                  analysis={analysisResult}
                  isSaved={isSavedInHistory}
                  onRecordSignal={() => {
                    if (!isSavedInHistory && analysisResult.chartDetected) {
                      const targetNextMinute = new Date(Date.now() + 60000);
                      const targetTimeStr = `Next 1m (${targetNextMinute.toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })})`;

                      const newRecord: SignalRecord = {
                        id: 'sig-' + Date.now(),
                        timestamp: Date.now(),
                        dateStr: 'Today',
                        timeStr: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
                        candleTargetTime: targetTimeStr,
                        asset: analysisResult.assetOrPair || 'EUR/USD (Quotex)',
                        timeframe: '1m',
                        signal: analysisResult.suggestedSignal,
                        pattern: analysisResult.pattern,
                        confidence: analysisResult.confidenceScore,
                        rationale: analysisResult.rationale,
                        support: analysisResult.supportLevel || '--',
                        resistance: analysisResult.resistanceLevel || '--',
                        latencyMs: analysisResult.latencyMs,
                        outcome: analysisResult.suggestedSignal === 'MISSED_SIGNAL'
                          ? 'MISSED_DEADLINE'
                          : analysisResult.suggestedSignal === 'NO_TRADE'
                          ? 'SKIPPED'
                          : 'PENDING',
                      };
                      setSignals((prev) => [newRecord, ...prev]);
                      setIsSavedInHistory(true);
                    }
                  }}
                />
              )}

              {/* Outcome Validation Tracker */}
              <AccuracyTracker stats={stats} />
            </>
          )}

          {activeTab === 'history' && (
            <div className="space-y-3">
              <AccuracyTracker stats={stats} />
              <SignalHistory
                signals={signals}
                onUpdateOutcome={handleUpdateOutcome}
                onDeleteSignal={handleDeleteSignal}
                onClearAll={handleClearAllSignals}
              />
            </div>
          )}

          {activeTab === 'android' && (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 space-y-3.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold">
                  Q
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Quotex 1M Android Implementation</h3>
                  <p className="text-[11px] text-slate-400">
                    Native Kotlin services for live overlay & MediaProjection frame grab
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
                <div className="font-semibold text-emerald-400 flex items-center gap-1.5 text-[11px]">
                  <span>Android Production Architecture:</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block text-[9px] uppercase">Floating Window</span>
                    <strong className="text-white">SYSTEM_ALERT_WINDOW</strong>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block text-[9px] uppercase">Screen Capture</span>
                    <strong className="text-white">MediaProjection (7s Loop)</strong>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block text-[9px] uppercase">Local Accuracy DB</span>
                    <strong className="text-white">Room SQLite (Closed 1m)</strong>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block text-[9px] uppercase">Fail-safe</span>
                    <strong className="text-amber-400">Missed Deadline Suppress</strong>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setIsBlueprintOpen(true)}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-all active:scale-95"
                >
                  <Code2 className="w-4 h-4 text-emerald-400" />
                  <span>View Kotlin Code</span>
                </button>

                <button
                  onClick={() => setIsDownloadModalOpen(true)}
                  className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Download .zip</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'about' && (
            <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 space-y-3 text-xs leading-relaxed text-slate-300">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Info className="w-4 h-4 text-cyan-400" />
                <span>1-Minute Quotex Scalping Methodology</span>
              </h3>

              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1 text-[11px]">
                <strong className="text-slate-200">1. The 60-Second Interval & 7-Second Rule</strong>
                <p className="text-slate-400">
                  Each candle represents 60 seconds. Quotex binary options lock in at :00. The final 7 seconds (:53 to :59) capture critical liquidity sweeps, wick formation, and absorption.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1 text-[11px]">
                <strong className="text-slate-200">2. The 1-Second Pre-Rollover Target</strong>
                <p className="text-slate-400">
                  To give the trader time to evaluate without delay, the signal targets arrival at approximately :59s (1 second before the next candle opens).
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1 text-[11px]">
                <strong className="text-slate-200">3. Missed Signal Fail-Safe</strong>
                <p className="text-slate-400">
                  If network latency causes analysis to return after 00:00 rollover, the signal is invalidated as MISSED SIGNAL. Stale predictions are never executed.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Floating Quotex Overlay (Interactive Concept) */}
        {showFloatingOverlay && (
          <FloatingQuotexOverlay
            signal={currentSignal}
            analysisResult={analysisResult}
            secondsRemaining={secondsRemaining}
            isAnalyzing={isAnalyzing}
            onClose={() => setShowFloatingOverlay(false)}
            onTriggerAnalysis={() => handleRunAnalysis(secondsRemaining)}
            containerRef={containerRef}
          />
        )}

        {/* Footer */}
        <div className="p-2.5 border-t border-slate-800/60 text-center text-[10px] text-slate-400 flex items-center justify-between px-4 bg-slate-950/40">
          <span>ApexVision Quotex 1M</span>
          <span>Only Next Candle Analyzed</span>
        </div>
      </div>

      {/* Kotlin Android Blueprint Modal */}
      <AndroidBlueprintModal
        isOpen={isBlueprintOpen}
        onClose={() => setIsBlueprintOpen(false)}
      />

      {/* Source Code Explorer & Verified Zip Download Modal */}
      <SourceCodeExplorerModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}
