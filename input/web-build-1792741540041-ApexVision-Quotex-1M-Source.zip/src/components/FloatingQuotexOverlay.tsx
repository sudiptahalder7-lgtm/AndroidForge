import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TradeSignal, ChartAnalysisResult } from '../types/analyzer';
import { GlowingIndicator } from './GlowingIndicator';
import { X, Minimize2, Sparkles, Move, GripHorizontal, Activity } from 'lucide-react';

interface FloatingQuotexOverlayProps {
  signal: TradeSignal | 'IDLE';
  analysisResult: ChartAnalysisResult | null;
  secondsRemaining: number;
  isAnalyzing: boolean;
  onClose: () => void;
  onTriggerAnalysis: () => void;
  containerRef?: React.RefObject<HTMLDivElement | null>;
}

export const FloatingQuotexOverlay: React.FC<FloatingQuotexOverlayProps> = ({
  signal,
  analysisResult,
  secondsRemaining,
  isAnalyzing,
  onClose,
  onTriggerAnalysis,
  containerRef,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [hapticPulse, setHapticPulse] = useState(false);
  const dragRef = useRef<HTMLDivElement>(null);

  const isUp = signal === 'UP';
  const isDown = signal === 'DOWN';
  const isNoTrade = signal === 'NO_TRADE';
  const isMissed = signal === 'MISSED_SIGNAL';

  // Trigger tactile vibration on hardware if supported
  const triggerHaptic = (pattern: number | number[] = 15) => {
    try {
      if (typeof window !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(pattern);
      }
    } catch {
      // Haptic unsupported or user disabled gestures
    }
    // Visual haptic pulse
    setHapticPulse(true);
    setTimeout(() => setHapticPulse(false), 240);
  };

  const handleDragStart = () => {
    setIsDragging(true);
    triggerHaptic(18);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    triggerHaptic([8, 30, 10]);
  };

  // Determine signal theme colors
  const themeColors = isUp
    ? {
        border: 'border-emerald-500/80',
        glow: 'shadow-emerald-500/30',
        ring: 'ring-emerald-400',
        text: 'text-emerald-400',
        accent: 'bg-emerald-500',
      }
    : isDown
    ? {
        border: 'border-rose-500/80',
        glow: 'shadow-rose-500/30',
        ring: 'ring-rose-400',
        text: 'text-rose-400',
        accent: 'bg-rose-500',
      }
    : isNoTrade
    ? {
        border: 'border-slate-500/80',
        glow: 'shadow-slate-500/20',
        ring: 'ring-slate-400',
        text: 'text-slate-300',
        accent: 'bg-slate-600',
      }
    : isMissed
    ? {
        border: 'border-amber-500/80',
        glow: 'shadow-amber-500/25',
        ring: 'ring-amber-400',
        text: 'text-amber-400',
        accent: 'bg-amber-500',
      }
    : {
        border: 'border-cyan-500/70',
        glow: 'shadow-cyan-500/25',
        ring: 'ring-cyan-400',
        text: 'text-cyan-400',
        accent: 'bg-cyan-500',
      };

  return (
    <AnimatePresence mode="wait">
      {isMinimized ? (
        <motion.div
          key="minimized-bubble"
          ref={dragRef}
          drag
          dragConstraints={containerRef || undefined}
          dragElastic={0.08}
          dragMomentum={false}
          dragTransition={{
            bounceStiffness: 450,
            bounceDamping: 26,
            power: 0.15,
          }}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{
            scale: hapticPulse ? [1, 1.08, 0.98, 1] : 1,
            opacity: 1,
            rotate: isDragging ? [0, -2, 2, 0] : 0,
          }}
          exit={{ scale: 0.8, opacity: 0 }}
          whileDrag={{
            scale: 1.12,
            boxShadow: '0 25px 40px -10px rgba(0, 230, 118, 0.45)',
            cursor: 'grabbing',
          }}
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.95 }}
          transition={{
            type: 'spring',
            stiffness: 420,
            damping: 24,
          }}
          onClick={(e) => {
            if (!isDragging) {
              triggerHaptic(12);
              setIsMinimized(false);
            }
          }}
          className={`absolute bottom-16 right-4 z-50 cursor-grab p-1.5 rounded-full bg-slate-900/95 border-2 shadow-2xl backdrop-blur-xl flex flex-col items-center justify-center select-none ${themeColors.border} ${themeColors.glow} ${
            hapticPulse ? 'ring-2 ring-cyan-400/80 shadow-cyan-400/50' : ''
          }`}
          title="Drag anywhere • Tap to expand overlay"
        >
          {/* Haptic tactile ring wave */}
          {hapticPulse && (
            <motion.span
              initial={{ scale: 0.9, opacity: 0.8 }}
              animate={{ scale: 1.45, opacity: 0 }}
              transition={{ duration: 0.28, ease: 'easeOut' }}
              className={`absolute inset-0 rounded-full border-2 ${themeColors.border} pointer-events-none`}
            />
          )}

          <div className="w-13 h-13 rounded-full flex flex-col items-center justify-center text-center p-1 relative">
            <span className="text-[11px] font-black font-mono leading-none text-white tracking-wider">
              {signal === 'IDLE' ? '1M' : signal}
            </span>
            <span className="text-[9px] font-mono text-cyan-300 mt-0.5 font-bold">
              :{secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining}
            </span>
            <span className="text-[7px] text-slate-400 font-sans tracking-tight">DRAG</span>
          </div>
        </motion.div>
      ) : (
        <motion.div
          key="expanded-overlay"
          ref={dragRef}
          drag
          dragConstraints={containerRef || undefined}
          dragElastic={0.08}
          dragMomentum={false}
          dragTransition={{
            bounceStiffness: 450,
            bounceDamping: 26,
            power: 0.15,
          }}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          initial={{ scale: 0.92, opacity: 0, y: 15 }}
          animate={{
            scale: hapticPulse ? [1, 1.02, 0.99, 1] : 1,
            opacity: 1,
            y: 0,
            x: hapticPulse ? [0, -2, 2, -1, 1, 0] : 0,
          }}
          exit={{ scale: 0.92, opacity: 0, y: 15 }}
          whileDrag={{
            scale: 1.03,
            rotate: isDragging ? 0.8 : 0,
            boxShadow: '0 30px 60px -12px rgba(14, 165, 233, 0.4)',
            cursor: 'grabbing',
          }}
          transition={{
            type: 'spring',
            stiffness: 400,
            damping: 28,
            mass: 0.8,
          }}
          className={`absolute bottom-16 right-3 z-50 w-72 rounded-3xl bg-slate-900/95 border-2 shadow-2xl backdrop-blur-2xl p-3.5 text-slate-100 select-none ${themeColors.border} ${themeColors.glow} ${
            hapticPulse ? 'ring-2 ring-cyan-400/70 shadow-cyan-400/40' : ''
          }`}
        >
          {/* Visual Haptic Boundary Ripple */}
          {hapticPulse && (
            <motion.div
              initial={{ opacity: 0.6, scale: 0.97 }}
              animate={{ opacity: 0, scale: 1.03 }}
              transition={{ duration: 0.24, ease: 'easeOut' }}
              className="absolute inset-0 rounded-3xl border-2 border-cyan-400 pointer-events-none"
            />
          )}

          {/* Draggable Grip Handle Bar */}
          <div className="flex flex-col items-center justify-center pb-1.5 cursor-grab active:cursor-grabbing">
            <div className="flex items-center gap-1.5 text-slate-400 hover:text-slate-200 py-0.5 px-3 rounded-full bg-slate-800/60 border border-slate-700/50">
              <GripHorizontal className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[9px] font-mono tracking-wider font-semibold uppercase text-slate-300">
                {isDragging ? 'Spring Drag Active' : 'Touch & Drag'}
              </span>
            </div>
          </div>

          {/* Overlay Header */}
          <div className="flex items-center justify-between pb-2 border-b border-slate-800/90 text-xs">
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${themeColors.accent} animate-pulse`} />
              <span className="font-extrabold text-[11px] tracking-tight text-white uppercase font-mono">
                ApexVision Overlay
              </span>
              <span className="text-[8px] bg-cyan-500/20 text-cyan-300 px-1 py-0.2 rounded font-bold font-mono">
                SPRING
              </span>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  triggerHaptic(12);
                  setIsMinimized(true);
                }}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
                title="Minimize into Floating Bubble"
              >
                <Minimize2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic(15);
                  onClose();
                }}
                className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800/80 transition-colors"
                title="Close Overlay"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Main Signal Indicator */}
          <div className="py-2 flex flex-col items-center">
            <GlowingIndicator
              signal={signal}
              confidence={analysisResult?.confidenceScore}
              isAnalyzing={isAnalyzing}
              secondsRemaining={secondsRemaining}
              latencyMs={analysisResult?.latencyMs}
              size="compact"
            />

            {/* Real-time Status */}
            <div className="text-center mt-1">
              <div className="text-xs font-black font-mono">
                {isAnalyzing ? (
                  <span className="text-cyan-400 animate-pulse">ANALYZING 1M FEED...</span>
                ) : isUp ? (
                  <span className="text-emerald-400">NEXT 1M: CALL / UP ▲</span>
                ) : isDown ? (
                  <span className="text-rose-400">NEXT 1M: PUT / DOWN ▼</span>
                ) : isNoTrade ? (
                  <span className="text-slate-300">NEXT 1M: NO TRADE (HOLD)</span>
                ) : isMissed ? (
                  <span className="text-amber-400">EXPIRED CANDLE</span>
                ) : (
                  <span className="text-slate-400">READY FOR 1M WINDOW</span>
                )}
              </div>

              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                Candle closes in:{' '}
                <strong className="text-white">
                  00:{secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining}
                </strong>
              </div>
            </div>
          </div>

          {/* Brief Rationale / Indicator Snapshot */}
          {analysisResult && (
            <div className="mt-1 p-2 rounded-xl bg-slate-950/85 border border-slate-800 text-[10px] leading-snug">
              <div className="text-slate-200 font-semibold truncate mb-0.5 flex items-center justify-between">
                <span>{analysisResult.pattern}</span>
                <span className="text-cyan-400 font-mono">
                  {analysisResult.confidenceScore ? `${analysisResult.confidenceScore}% Score` : ''}
                </span>
              </div>
              <p className="text-slate-400 line-clamp-2">
                {analysisResult.rationale}
              </p>
            </div>
          )}

          {/* Action Trigger Button with Spring Press Feedback */}
          <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between gap-1.5">
            <motion.button
              type="button"
              whileTap={{ scale: 0.95 }}
              whileHover={{ scale: 1.02 }}
              onClick={() => {
                triggerHaptic(20);
                onTriggerAnalysis();
              }}
              disabled={isAnalyzing}
              className="flex-1 py-1.5 px-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-slate-950 font-bold text-[10px] flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-3 h-3" />
              <span>{isAnalyzing ? 'Scanning Feed...' : 'READY (Analyze 1M)'}</span>
            </motion.button>

            <div className="flex items-center gap-1 text-[8px] text-slate-400 font-mono">
              <Activity className="w-2.5 h-2.5 text-cyan-400" />
              <span>HAPTIC ON</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
