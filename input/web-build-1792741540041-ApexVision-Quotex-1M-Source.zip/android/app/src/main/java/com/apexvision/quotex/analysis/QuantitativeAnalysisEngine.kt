package com.apexvision.quotex.analysis

import com.apexvision.quotex.model.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class QuantitativeAnalysisEngine(
    var confidenceThreshold: Int = 70 // Configurable threshold (default 70%)
) {

    fun analyze(
        asset: MarketAsset,
        candles: List<MarketCandle>,
        currentClockMillis: Long = System.currentTimeMillis()
    ): QuantitativeSignalResult {
        if (candles.size < 28) {
            return QuantitativeSignalResult(
                signal = TradeSignal.NO_TRADE,
                analysisScore = 0,
                thresholdUsed = confidenceThreshold,
                asset = asset,
                lastPrice = candles.lastOrNull()?.close ?: 0.0,
                dataTimestamp = candles.lastOrNull()?.closeTime ?: 0L,
                dataAgeSeconds = if (candles.isNotEmpty()) (currentClockMillis - candles.last().closeTime) / 1000 else 999L,
                isDataStale = true,
                dataProvider = asset.provider,
                status = AnalysisStatus.INSUFFICIENT_DATA,
                statusMessage = "Need at least 28 completed 1m candles for reliable EMA/MACD/RSI indicators (Found: ${candles.size}).",
                primaryReasons = listOf("Insufficient candle sample size"),
                conflictingFactors = emptyList(),
                indicators = null,
                targetCandleLabel = "Awaiting Data"
            )
        }

        val completedCandles = if (!candles.last().isComplete && candles.size > 28) {
            candles.dropLast(1)
        } else {
            candles
        }

        val latest = completedCandles.last()
        val dataAgeSeconds = (currentClockMillis - latest.closeTime) / 1000

        // Stale Data Check: If data is older than 120 seconds, reject live signals
        if (dataAgeSeconds > 120) {
            return QuantitativeSignalResult(
                signal = TradeSignal.NO_TRADE,
                analysisScore = 0,
                thresholdUsed = confidenceThreshold,
                asset = asset,
                lastPrice = latest.close,
                dataTimestamp = latest.closeTime,
                dataAgeSeconds = dataAgeSeconds,
                isDataStale = true,
                dataProvider = asset.provider,
                status = AnalysisStatus.STALE_DATA,
                statusMessage = "DATA STALE: Last candle received ${dataAgeSeconds}s ago (>120s limit). Live signals halted for safety.",
                primaryReasons = listOf("Data feed latency exceeded maximum threshold"),
                conflictingFactors = listOf("Timestamp out-of-date"),
                indicators = null,
                targetCandleLabel = "Data Stale"
            )
        }

        val closes = completedCandles.map { it.close }
        val ema9Values = calculateEMA(9, closes)
        val ema21Values = calculateEMA(21, closes)

        val ema9 = ema9Values.last()
        val ema21 = ema21Values.last()
        val prevEma9 = ema9Values[ema9Values.size - 2]
        val prevEma21 = ema21Values[ema21Values.size - 2]

        // 1. EMA Trend & Crossover
        val emaBullishTrend = ema9 > ema21 && latest.close > ema21
        val emaBearishTrend = ema9 < ema21 && latest.close < ema21
        val emaBullishCross = prevEma9 <= prevEma21 && ema9 > ema21
        val emaBearishCross = prevEma9 >= prevEma21 && ema9 < ema21

        // 2. RSI-14 (Wilder's Smoothing)
        val rsi14 = calculateRSI(14, closes)
        val rsiBullish = rsi14 in 48.0..68.0
        val rsiBearish = rsi14 in 32.0..52.0
        val rsiOverbought = rsi14 >= 70.0
        val rsiOversold = rsi14 <= 30.0

        // 3. MACD (12, 26, 9)
        val macdResult = calculateMACD(closes)
        val macdBullish = macdResult.histogram > 0 && macdResult.macdLine > macdResult.signalLine
        val macdBearish = macdResult.histogram < 0 && macdResult.macdLine < macdResult.signalLine

        // 4. ATR-14 Volatility
        val atr14 = calculateATR(14, completedCandles)
        val avgRange = completedCandles.takeLast(14).map { it.totalRange }.average()
        val isVolatilityDead = atr14 < (avgRange * 0.35)
        val isVolatilityAbnormal = latest.totalRange > (atr14 * 2.8)

        // 5. Support & Resistance Swing Clusters (last 20 candles)
        val recent20 = completedCandles.takeLast(20)
        val supportLevel = recent20.map { it.low }.minOrNull() ?: latest.low
        val resistanceLevel = recent20.map { it.high }.maxOrNull() ?: latest.high

        // 6. Candlestick Price Action Geometry
        val body = latest.bodySize
        val upperWick = latest.upperWick
        val lowerWick = latest.lowerWick

        val lowerWickRejection = lowerWick >= (body * 1.6) && (latest.low <= supportLevel * 1.001)
        val upperWickRejection = upperWick >= (body * 1.6) && (latest.high >= resistanceLevel * 0.999)

        // Previous candle for engulfing detection
        val prev = completedCandles[completedCandles.size - 2]
        val bullishEngulfing = !prev.isGreen && latest.isGreen && latest.close > prev.open && latest.open < prev.close
        val bearishEngulfing = prev.isGreen && !latest.isGreen && latest.close < prev.open && latest.open > prev.close

        // Market Regime Detection
        val regime = when {
            isVolatilityDead -> MarketRegime.LOW_VOLATILITY_COMPRESSION
            isVolatilityAbnormal -> MarketRegime.HIGH_VOLATILITY_CHOP
            emaBullishTrend && rsi14 > 50 -> MarketRegime.BULLISH_TREND
            emaBearishTrend && rsi14 < 50 -> MarketRegime.BEARISH_TREND
            else -> MarketRegime.RANGING_CONSOLIDATION
        }

        val indicators = TechnicalIndicators(
            ema9 = ema9,
            ema21 = ema21,
            rsi14 = rsi14,
            macdLine = macdResult.macdLine,
            macdSignal = macdResult.signalLine,
            macdHistogram = macdResult.histogram,
            atr14 = atr14,
            supportLevel = supportLevel,
            resistanceLevel = resistanceLevel,
            regime = regime,
            emaTrendBullish = emaBullishTrend,
            rsiBullish = rsiBullish,
            macdBullish = macdBullish,
            wickRejectionBullish = lowerWickRejection || bullishEngulfing,
            wickRejectionBearish = upperWickRejection || bearishEngulfing
        )

        // Scoring Confluence (0 to 100)
        var bullishScore = 0
        var bearishScore = 0
        val bullishReasons = mutableListOf<String>()
        val bearishReasons = mutableListOf<String>()
        val conflicts = mutableListOf<String>()

        // Trend points (up to 30)
        if (emaBullishCross) {
            bullishScore += 30
            bullishReasons.add("Fresh EMA-9 / EMA-21 Bullish Golden Cross")
        } else if (emaBullishTrend) {
            bullishScore += 25
            bullishReasons.add("Uptrend aligned: Price > EMA-9 > EMA-21")
        }

        if (emaBearishCross) {
            bearishScore += 30
            bearishReasons.add("Fresh EMA-9 / EMA-21 Bearish Death Cross")
        } else if (emaBearishTrend) {
            bearishScore += 25
            bearishReasons.add("Downtrend aligned: Price < EMA-9 < EMA-21")
        }

        // Momentum points (up to 30)
        if (macdBullish) {
            bullishScore += 15
            bullishReasons.add("MACD histogram positive & expanding")
        }
        if (rsiBullish) {
            bullishScore += 15
            bullishReasons.add("RSI-14 constructive momentum (${String.format("%.1f", rsi14)})")
        }

        if (macdBearish) {
            bearishScore += 15
            bearishReasons.add("MACD histogram negative & contracting")
        }
        if (rsiBearish) {
            bearishScore += 15
            bearishReasons.add("RSI-14 bearish momentum (${String.format("%.1f", rsi14)})")
        }

        // Price action points (up to 25)
        if (lowerWickRejection) {
            bullishScore += 25
            bullishReasons.add("Candle absorbed liquidity at Support (${String.format("%.2f", supportLevel)}) with strong lower wick")
        } else if (bullishEngulfing) {
            bullishScore += 20
            bullishReasons.add("Bullish Engulfing pattern formed")
        }

        if (upperWickRejection) {
            bearishScore += 25
            bearishReasons.add("Candle rejected Resistance ceiling (${String.format("%.2f", resistanceLevel)}) with long upper wick")
        } else if (bearishEngulfing) {
            bearishScore += 20
            bearishReasons.add("Bearish Engulfing pattern formed")
        }

        // Volatility health (up to 15)
        if (!isVolatilityDead && !isVolatilityAbnormal) {
            bullishScore += 15
            bearishScore += 15
        } else if (isVolatilityDead) {
            conflicts.add("Low volatility compression (ATR ${String.format("%.4f", atr14)}) - prone to false breakouts")
        } else if (isVolatilityAbnormal) {
            conflicts.add("Extreme candle spike (${String.format("%.2f", latest.totalRange)} vs ATR ${String.format("%.2f", atr14)}) - prone to sharp reversal")
        }

        // Detect Major Conflicts
        if (bullishScore > 40 && rsiOverbought) {
            conflicts.add("RSI Overbought (${String.format("%.1f", rsi14)}) - upside exhausted")
            bullishScore -= 20
        }
        if (bearishScore > 40 && rsiOversold) {
            conflicts.add("RSI Oversold (${String.format("%.1f", rsi14)}) - downside exhausted")
            bearishScore -= 20
        }
        if (emaBullishTrend && macdBearish) {
            conflicts.add("Trend is bullish but MACD momentum is negative")
        }
        if (emaBearishTrend && macdBullish) {
            conflicts.add("Trend is bearish but MACD momentum is positive")
        }

        val targetLabel = "Next 1m (${java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(latest.closeTime + 60000)})"

        // Final Decision against configurable threshold
        val signal: TradeSignal
        val finalScore: Int
        val primaryReasons: List<String>
        val statusMessage: String

        if (bullishScore >= confidenceThreshold && bullishScore > bearishScore && conflicts.size <= 1) {
            signal = TradeSignal.UP
            finalScore = min(95, bullishScore)
            primaryReasons = bullishReasons
            statusMessage = "CONFLUENCE UP: ${primaryReasons.joinToString("; ")}"
        } else if (bearishScore >= confidenceThreshold && bearishScore > bullishScore && conflicts.size <= 1) {
            signal = TradeSignal.DOWN
            finalScore = min(95, bearishScore)
            primaryReasons = bearishReasons
            statusMessage = "CONFLUENCE DOWN: ${primaryReasons.joinToString("; ")}"
        } else {
            signal = TradeSignal.NO_TRADE
            finalScore = max(bullishScore, bearishScore)
            primaryReasons = if (conflicts.isNotEmpty()) conflicts else listOf("Score ($finalScore%) below required threshold ($confidenceThreshold%)")
            statusMessage = "NO TRADE: Market in equilibrium or conflicting indicators (${primaryReasons.joinToString("; ")})"
        }

        return QuantitativeSignalResult(
            signal = signal,
            analysisScore = finalScore,
            thresholdUsed = confidenceThreshold,
            asset = asset,
            lastPrice = latest.close,
            dataTimestamp = latest.closeTime,
            dataAgeSeconds = dataAgeSeconds,
            isDataStale = false,
            dataProvider = asset.provider,
            status = AnalysisStatus.LIVE_SUCCESS,
            statusMessage = statusMessage,
            primaryReasons = primaryReasons,
            conflictingFactors = conflicts,
            indicators = indicators,
            targetCandleLabel = targetLabel
        )
    }

    // Helper: Exponential Moving Average
    fun calculateEMA(period: Int, values: List<Double>): List<Double> {
        if (values.size < period) return values
        val k = 2.0 / (period + 1.0)
        val result = mutableListOf<Double>()

        // Seed with SMA
        var sum = 0.0
        for (i in 0 until period) {
            sum += values[i]
            result.add(sum / (i + 1))
        }

        var currentEma = sum / period
        for (i in period until values.size) {
            currentEma = (values[i] * k) + (currentEma * (1.0 - k))
            result.add(currentEma)
        }

        return result
    }

    // Helper: Relative Strength Index (Wilder's Smoothing)
    fun calculateRSI(period: Int = 14, closes: List<Double>): Double {
        if (closes.size <= period) return 50.0

        var gainSum = 0.0
        var lossSum = 0.0

        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) gainSum += diff else lossSum += abs(diff)
        }

        var avgGain = gainSum / period
        var avgLoss = lossSum / period

        for (i in (period + 1) until closes.size) {
            val diff = closes[i] - closes[i - 1]
            val gain = if (diff >= 0) diff else 0.0
            val loss = if (diff < 0) abs(diff) else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    // Helper: MACD (12, 26, 9)
    fun calculateMACD(closes: List<Double>): MACDResult {
        val ema12 = calculateEMA(12, closes)
        val ema26 = calculateEMA(26, closes)

        val macdLineValues = mutableListOf<Double>()
        val startIdx = max(0, ema26.size - closes.size)
        for (i in startIdx until closes.size) {
            macdLineValues.add(ema12[i] - ema26[i])
        }

        val signalLineValues = calculateEMA(9, macdLineValues)
        val latestMacd = macdLineValues.last()
        val latestSignal = signalLineValues.last()
        val histogram = latestMacd - latestSignal

        return MACDResult(latestMacd, latestSignal, histogram)
    }

    // Helper: Average True Range (14)
    fun calculateATR(period: Int = 14, candles: List<MarketCandle>): Double {
        if (candles.size <= period) return candles.lastOrNull()?.totalRange ?: 0.0

        val trueRanges = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val h = candles[i].high
            val l = candles[i].low
            val prevC = candles[i - 1].close
            val tr = max(h - l, max(abs(h - prevC), abs(l - prevC)))
            trueRanges.add(tr)
        }

        if (trueRanges.size < period) return trueRanges.average()

        var atr = trueRanges.take(period).average()
        for (i in period until trueRanges.size) {
            atr = ((atr * (period - 1)) + trueRanges[i]) / period
        }

        return atr
    }

    data class MACDResult(
        val macdLine: Double,
        val signalLine: Double,
        val histogram: Double
    )
}
