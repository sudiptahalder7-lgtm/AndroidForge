package com.apexvision.quotex.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.*
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.apexvision.quotex.ApexVisionApp
import com.apexvision.quotex.MainActivity
import com.apexvision.quotex.R
import com.apexvision.quotex.analysis.QuantitativeAnalysisEngine
import com.apexvision.quotex.data.local.SignalHistoryEntity
import com.apexvision.quotex.market.BinanceLiveMarketDataEngine
import com.apexvision.quotex.market.LiveMarketDataEngine
import com.apexvision.quotex.model.*
import com.apexvision.quotex.ui.FloatingOverlayView
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

class QuotexFloatingOverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val marketDataEngine: LiveMarketDataEngine = BinanceLiveMarketDataEngine()
    private val analysisEngine = QuantitativeAnalysisEngine(confidenceThreshold = 70)

    private val _selectedAsset = MutableStateFlow(MarketAsset.DEFAULT_ASSETS.first())
    val selectedAsset: StateFlow<MarketAsset> = _selectedAsset.asStateFlow()

    private val _signalResult = MutableStateFlow<QuantitativeSignalResult?>(null)
    val signalResult: StateFlow<QuantitativeSignalResult?> = _signalResult.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _isScanningActive = MutableStateFlow(false)
    val isScanningActive: StateFlow<Boolean> = _isScanningActive.asStateFlow()

    private var pollingJob: Job? = null
    private var isMinimized = false

    private var screenWidth = 1080
    private var screenHeight = 2400

    // LifecycleOwner, ViewModelStoreOwner, and SavedStateRegistryOwner for Compose in Service
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        var isRunning: Boolean = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        loadUserPreferences()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        measureScreenDimensions()
        startForegroundNotification()
        setupFloatingWindow()
    }

    private fun loadUserPreferences() {
        try {
            val prefs = getSharedPreferences("apex_engine_prefs", Context.MODE_PRIVATE)
            val threshold = prefs.getInt("confidence_threshold", 70)
            analysisEngine.confidenceThreshold = threshold
        } catch (_: Exception) {}
    }

    private fun measureScreenDimensions() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
    }

    private fun startForegroundNotification() {
        val channelId = "apex_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "ApexVision Floating Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Live market data quantitative analyzer over Quotex"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("ApexVision Live Market Analyzer")
            .setContentText("Monitoring live market data (Binance public feed)")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1001, notification)
        }
    }

    private fun setupFloatingWindow() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 180
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@QuotexFloatingOverlayService)
            setViewTreeViewModelStoreOwner(this@QuotexFloatingOverlayService)
            setViewTreeSavedStateRegistryOwner(this@QuotexFloatingOverlayService)

            setContent {
                FloatingOverlayView(
                    selectedAsset = _selectedAsset,
                    signalResult = _signalResult,
                    isAnalyzing = _isAnalyzing,
                    isScanning = _isScanningActive,
                    isMinimized = isMinimized,
                    onSelectAsset = { newAsset ->
                        _selectedAsset.value = newAsset
                        if (_isScanningActive.value) {
                            executeAnalysis()
                        }
                    },
                    onReadyClick = {
                        // User pressed READY: Start analysis immediately
                        _isScanningActive.value = true
                        executeAnalysis()
                        startLiveRefreshLoop()
                    },
                    onStopScan = {
                        _isScanningActive.value = false
                        stopLiveRefreshLoop()
                    },
                    onToggleMinimize = {
                        isMinimized = !isMinimized
                    },
                    onClose = {
                        stopSelf()
                    }
                )
            }
        }

        // Draggable gesture listener that preserves internal button clicks
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        composeView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    // Return false to allow child buttons inside Compose to receive clicks
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()

                    if (hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                        isDragging = true
                        val maxX = maxOf(0, screenWidth - view.width)
                        val maxY = maxOf(0, screenHeight - view.height)
                        // Keep overlay within screen bounds
                        params.x = (initialX + dx).coerceIn(0, maxX)
                        params.y = (initialY + dy).coerceIn(60, maxY)
                        windowManager?.updateViewLayout(view, params)
                        true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP -> {
                    isDragging
                }
                else -> false
            }
        }

        overlayView = composeView
        windowManager?.addView(overlayView, params)
    }

    private fun startLiveRefreshLoop() {
        pollingJob?.cancel()
        pollingJob = serviceScope.launch {
            while (isActive && _isScanningActive.value) {
                // Refresh market data every 10 seconds or near the :53 mark of the 1-minute candle
                delay(10000)
                if (_isScanningActive.value) {
                    executeAnalysis()
                }
            }
        }
    }

    private fun stopLiveRefreshLoop() {
        pollingJob?.cancel()
        pollingJob = null
    }

    private fun executeAnalysis() {
        if (_isAnalyzing.value) return // Prevent duplicate concurrent fetch jobs

        loadUserPreferences()
        serviceScope.launch {
            _isAnalyzing.value = true
            val asset = _selectedAsset.value

            val startTime = System.currentTimeMillis()
            val candlesResult = marketDataEngine.fetchLatestCandles(asset, limit = 60)

            candlesResult.onSuccess { candles ->
                val result = analysisEngine.analyze(asset, candles, System.currentTimeMillis())
                _signalResult.value = result.copy(latencyMs = System.currentTimeMillis() - startTime)

                // Persist to Room SQLite
                recordSignalToDatabase(result)
            }.onFailure { err ->
                _signalResult.value = QuantitativeSignalResult(
                    signal = TradeSignal.NO_TRADE,
                    analysisScore = 0,
                    thresholdUsed = analysisEngine.confidenceThreshold,
                    asset = asset,
                    lastPrice = 0.0,
                    dataTimestamp = System.currentTimeMillis(),
                    dataAgeSeconds = 999,
                    isDataStale = true,
                    dataProvider = asset.provider,
                    status = AnalysisStatus.NETWORK_ERROR,
                    statusMessage = "DATA UNAVAILABLE: ${err.message ?: "Failed to connect to Binance live feed"}",
                    primaryReasons = listOf("Network error or connection timed out"),
                    conflictingFactors = listOf("Check internet connection"),
                    indicators = null,
                    targetCandleLabel = "Feed Offline",
                    latencyMs = System.currentTimeMillis() - startTime
                )
            }

            _isAnalyzing.value = false
        }
    }

    private fun recordSignalToDatabase(result: QuantitativeSignalResult) {
        serviceScope.launch(Dispatchers.IO) {
            try {
                val app = application as? ApexVisionApp ?: return@launch
                val now = Date()
                val sdfDate = SimpleDateFormat("MMM d", Locale.US)
                val sdfTime = SimpleDateFormat("HH:mm:ss", Locale.US)

                val entity = SignalHistoryEntity(
                    dateStr = sdfDate.format(now),
                    timeStr = sdfTime.format(now),
                    targetCandle = result.targetCandleLabel,
                    asset = "${result.asset.displayName} (${result.dataProvider})",
                    signal = result.signal.name,
                    confidence = result.analysisScore,
                    rationale = result.statusMessage,
                    pattern = result.indicators?.regime?.name ?: "Market Confluence",
                    support = String.format("%.2f", result.indicators?.supportLevel ?: 0.0),
                    resistance = String.format("%.2f", result.indicators?.resistanceLevel ?: 0.0),
                    latencyMs = result.latencyMs,
                    timingValid = !result.isDataStale,
                    outcome = if (result.signal == TradeSignal.NO_TRADE) "SKIPPED" else "PENDING"
                )
                app.repository.recordSignal(entity)
            } catch (e: Exception) {
                // Silently prevent database errors from disrupting overlay
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        stopLiveRefreshLoop()
        serviceScope.cancel()

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()

        overlayView?.let {
            windowManager?.removeView(it)
            overlayView = null
        }
    }
}
