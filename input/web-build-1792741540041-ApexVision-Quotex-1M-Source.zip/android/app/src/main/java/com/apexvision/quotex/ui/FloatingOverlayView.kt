package com.apexvision.quotex.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexvision.quotex.model.*
import kotlinx.coroutines.flow.StateFlow

@Composable
fun FloatingOverlayView(
    selectedAsset: StateFlow<MarketAsset>,
    signalResult: StateFlow<QuantitativeSignalResult?>,
    isAnalyzing: StateFlow<Boolean>,
    isScanning: StateFlow<Boolean>,
    isMinimized: Boolean,
    onSelectAsset: (MarketAsset) -> Unit,
    onReadyClick: () -> Unit,
    onStopScan: () -> Unit,
    onToggleMinimize: () -> Unit,
    onClose: () -> Unit
) {
    val currentAsset by selectedAsset.collectAsState()
    val currentResult by signalResult.collectAsState()
    val analyzing by isAnalyzing.collectAsState()
    val scanning by isScanning.collectAsState()

    val signal = currentResult?.signal ?: TradeSignal.IDLE
    val score = currentResult?.analysisScore ?: 0

    if (isMinimized) {
        CompactFloatingBubble(
            signal = signal,
            score = score,
            symbol = currentAsset.symbol.replace("USDT", ""),
            isScanning = scanning,
            onExpand = onToggleMinimize
        )
    } else {
        Surface(
            color = Color(0xFB090D16),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF1E293B)),
            shadowElevation = 18.dp,
            modifier = Modifier
                .width(260.dp)
                .padding(4.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(10.dp)
            ) {
                // Header Bar & Drag Handle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(if (scanning) Color(0xFF00E676) else Color(0xFF64748B), CircleShape)
                        )
                        Text(
                            text = "ApexVision AI",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "QUANT",
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.sp,
                            modifier = Modifier
                                .background(Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onToggleMinimize, modifier = Modifier.size(22.dp)) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = "Minimize",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(onClick = onClose, modifier = Modifier.size(22.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Scanning Analyzer Title & Market Name
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp, bottom = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Scanning Analyzer",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF94A3B8)
                    )
                    Text(
                        text = currentAsset.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF38BDF8)
                    )
                    Text(
                        text = "Provider: ${currentAsset.provider}",
                        fontSize = 8.sp,
                        color = Color(0xFF64748B)
                    )
                }

                // Asset Selector Quick Pills
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    MarketAsset.DEFAULT_ASSETS.forEach { asset ->
                        val isSelected = asset.symbol == currentAsset.symbol
                        val label = asset.symbol.replace("USDT", "")
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF00E676).copy(alpha = 0.25f) else Color(0xFF1E293B))
                                .border(1.dp, if (isSelected) Color(0xFF00E676) else Color.Transparent, RoundedCornerShape(6.dp))
                                .clickable { onSelectAsset(asset) }
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 8.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                color = if (isSelected) Color(0xFF00E676) else Color(0xFF94A3B8)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Price & Status Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentResult != null && currentResult!!.lastPrice > 0.0) {
                        Text(
                            text = "$${String.format(if (currentResult!!.lastPrice > 100) "%.2f" else "%.4f", currentResult!!.lastPrice)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White
                        )
                        val age = currentResult!!.dataAgeSeconds
                        val statusText = if (currentResult!!.isDataStale) "STALE (${age}s)" else "LIVE (${age}s)"
                        val statusColor = if (currentResult!!.isDataStale) Color(0xFFF59E0B) else Color(0xFF00E676)
                        Text(
                            text = statusText,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor,
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    } else {
                        Text(
                            text = if (analyzing) "Connecting to live feed..." else "Awaiting live data",
                            fontSize = 9.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Glowing Signal Puck
                GlowingSignalPuck(signal = signal)

                Spacer(modifier = Modifier.height(6.dp))

                // Score / Status Text
                if (currentResult != null) {
                    Text(
                        text = "Analysis Score: $score% (Threshold: ${currentResult!!.thresholdUsed}%)",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (score >= currentResult!!.thresholdUsed) Color(0xFF00E676) else Color(0xFF94A3B8)
                    )

                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = currentResult!!.statusMessage,
                        fontSize = 8.sp,
                        lineHeight = 11.sp,
                        textAlign = TextAlign.Center,
                        color = Color(0xFFCBD5E1),
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                } else {
                    Text(
                        text = "Press READY to analyze live 1m market feed",
                        fontSize = 9.sp,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // READY / STOP Action Button
                Button(
                    onClick = {
                        if (scanning) {
                            onStopScan()
                        } else {
                            onReadyClick()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (scanning) Color(0xFFEF4444) else Color(0xFF00E676)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = if (scanning) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = if (scanning) Color.White else Color(0xFF090D16),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (scanning) "STOP SCAN" else "READY (Analyze Live)",
                        color = if (scanning) Color.White else Color(0xFF090D16),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
fun CompactFloatingBubble(
    signal: TradeSignal,
    score: Int,
    symbol: String,
    isScanning: Boolean,
    onExpand: () -> Unit
) {
    val (glowColor, solidColor, text) = when (signal) {
        TradeSignal.UP -> Triple(Color(0xFF00E676), Color(0xFF00C853), "UP")
        TradeSignal.DOWN -> Triple(Color(0xFFFF1744), Color(0xFFD50000), "DOWN")
        TradeSignal.NO_TRADE -> Triple(Color(0xFF64748B), Color(0xFF475569), "HOLD")
        TradeSignal.MISSED_SIGNAL -> Triple(Color(0xFFF59E0B), Color(0xFFD97706), "LATE")
        TradeSignal.IDLE -> Triple(Color(0xFF334155), Color(0xFF1E293B), symbol)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(solidColor)
            .border(2.dp, glowColor, CircleShape)
            .clickable { onExpand() }
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = text,
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
            if (signal != TradeSignal.IDLE && score > 0) {
                Text(
                    text = "$score%",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun GlowingSignalPuck(signal: TradeSignal) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val (glowColor, solidColor, text) = when (signal) {
        TradeSignal.UP -> Triple(Color(0xFF00E676), Color(0xFF00C853), "UP")
        TradeSignal.DOWN -> Triple(Color(0xFFFF1744), Color(0xFFD50000), "DOWN")
        TradeSignal.NO_TRADE -> Triple(Color(0xFF64748B), Color(0xFF475569), "NO TRADE")
        TradeSignal.MISSED_SIGNAL -> Triple(Color(0xFFF59E0B), Color(0xFFD97706), "EXPIRED")
        TradeSignal.IDLE -> Triple(Color(0xFF334155), Color(0xFF1E293B), "READY")
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(68.dp)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glowColor.copy(alpha = 0.55f), Color.Transparent),
                        radius = size.minDimension / 1.1f * pulseScale
                    )
                )
            }
            .border(2.dp, glowColor.copy(alpha = 0.85f), CircleShape)
            .background(solidColor, CircleShape)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = if (text.length > 5) 10.sp else 14.sp,
            textAlign = TextAlign.Center
        )
    }
}
