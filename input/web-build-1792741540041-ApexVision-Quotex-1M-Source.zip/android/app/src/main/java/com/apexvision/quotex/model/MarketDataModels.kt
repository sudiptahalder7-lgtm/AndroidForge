package com.apexvision.quotex.model

enum class TradeSignal {
    UP,
    DOWN,
    NO_TRADE,
    MISSED_SIGNAL,
    IDLE
}

enum class AnalysisStatus {
    IDLE,
    FETCHING,
    LIVE_SUCCESS,
    STALE_DATA,
    DATA_UNAVAILABLE,
    INSUFFICIENT_DATA,
    NETWORK_ERROR
}

enum class MarketRegime {
    BULLISH_TREND,
    BEARISH_TREND,
    RANGING_CONSOLIDATION,
    HIGH_VOLATILITY_CHOP,
    LOW_VOLATILITY_COMPRESSION
}

data class MarketAsset(
    val id: String,
    val symbol: String,
    val displayName: String,
    val provider: String,
    val baseCurrency: String,
    val quoteCurrency: String,
    val isCrypto: Boolean = true
) {
    companion object {
        val DEFAULT_ASSETS = listOf(
            MarketAsset("btc_usdt", "BTCUSDT", "BTC/USDT", "Binance Public API", "BTC", "USDT", true),
            MarketAsset("eth_usdt", "ETHUSDT", "ETH/USDT", "Binance Public API", "ETH", "USDT", true),
            MarketAsset("eur_usdt", "EURUSDT", "EUR/USDT (Forex Proxy)", "Binance Public API", "EUR", "USDT", false),
            MarketAsset("gbp_usdt", "GBPUSDT", "GBP/USDT (Forex Proxy)", "Binance Public API", "GBP", "USDT", false),
            MarketAsset("sol_usdt", "SOLUSDT", "SOL/USDT", "Binance Public API", "SOL", "USDT", true),
            MarketAsset("xrp_usdt", "XRPUSDT", "XRP/USDT", "Binance Public API", "XRP", "USDT", true)
        )
    }
}

data class MarketCandle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val closeTime: Long,
    val isComplete: Boolean = true
) {
    val bodySize: Double get() = kotlin.math.abs(close - open)
    val totalRange: Double get() = high - low
    val isGreen: Boolean get() = close >= open
    val upperWick: Double get() = high - kotlin.math.max(open, close)
    val lowerWick: Double get() = kotlin.math.min(open, close) - low
}

data class TechnicalIndicators(
    val ema9: Double,
    val ema21: Double,
    val rsi14: Double,
    val macdLine: Double,
    val macdSignal: Double,
    val macdHistogram: Double,
    val atr14: Double,
    val supportLevel: Double,
    val resistanceLevel: Double,
    val regime: MarketRegime,
    val emaTrendBullish: Boolean,
    val rsiBullish: Boolean,
    val macdBullish: Boolean,
    val wickRejectionBullish: Boolean,
    val wickRejectionBearish: Boolean
)

data class QuantitativeSignalResult(
    val signal: TradeSignal,
    val analysisScore: Int, // Calibrated analysis score between 0 and 100
    val thresholdUsed: Int, // Configurable threshold (e.g. 70%)
    val asset: MarketAsset,
    val lastPrice: Double,
    val dataTimestamp: Long,
    val dataAgeSeconds: Long,
    val isDataStale: Boolean,
    val dataProvider: String,
    val status: AnalysisStatus,
    val statusMessage: String,
    val primaryReasons: List<String>,
    val conflictingFactors: List<String>,
    val indicators: TechnicalIndicators?,
    val targetCandleLabel: String,
    val latencyMs: Long = 0
) {
    val disclaimer: String
        get() = "Analysis score reflects indicator confluence. Past performance does not guarantee future results. No automatic trades."
}
