package com.apexvision.quotex

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexvision.quotex.analysis.QuantitativeAnalysisEngine
import com.apexvision.quotex.data.local.SignalHistoryEntity
import com.apexvision.quotex.market.BinanceLiveMarketDataEngine
import com.apexvision.quotex.model.*
import com.apexvision.quotex.overlay.QuotexFloatingOverlayService
import com.apexvision.quotex.ui.GlowingSignalPuck
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ApexVisionAppTheme {
                MainAppScaffold(this)
            }
        }
    }
}

@Composable
fun ApexVisionAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF070A12),
            surface = Color(0xFF090D16),
            primary = Color(0xFF00E676),
            secondary = Color(0xFF38BDF8),
            error = Color(0xFFFF1744)
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(activity: Activity) {
    var selectedTab by remember { mutableStateOf(0) }
    var hasOverlayPermission by remember { mutableStateOf(checkOverlayPermission(activity)) }

    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPermission = checkOverlayPermission(activity)
    }

    // 1-minute candle countdown loop (:00 to :59)
    var secondsRemaining by remember { mutableStateOf(60) }
    LaunchedEffect(Unit) {
        while (true) {
            val nowSec = ((System.currentTimeMillis() / 1000) % 60).toInt()
            val rem = 60 - nowSec
            secondsRemaining = if (rem == 0) 60 else rem
            delay(250)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF00E676)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚡", fontSize = 16.sp)
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("ApexVision AI", fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
                                Text(
                                    "LIVE FEED",
                                    fontSize = 8.sp,
                                    color = Color(0xFF38BDF8),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .background(Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                            Text("Live 1-Minute Quantitative Engine", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090D16))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF090D16)) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = null) },
                    label = { Text("Live Scanner", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Layers, contentDescription = null) },
                    label = { Text("Overlay", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Quant Settings", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text("Accuracy", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Download, contentDescription = null) },
                    label = { Text("Build APK", fontSize = 10.sp) }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070A12))
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> LiveScannerTab(
                    activity = activity,
                    secondsRemaining = secondsRemaining,
                    hasOverlayPermission = hasOverlayPermission,
                    onRequestOverlay = { requestOverlayPermission(activity, overlayPermissionLauncher) }
                )
                1 -> OverlayControlsTab(
                    activity = activity,
                    hasOverlayPermission = hasOverlayPermission,
                    onRequestOverlay = { requestOverlayPermission(activity, overlayPermissionLauncher) }
                )
                2 -> QuantitativeSettingsTab(activity = activity)
                3 -> AccuracyHistoryTab()
                4 -> PhoneBuildGuideTab()
            }
        }
    }
}

@Composable
fun LiveScannerTab(
    activity: Activity,
    secondsRemaining: Int,
    hasOverlayPermission: Boolean,
    onRequestOverlay: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val prefs = activity.getSharedPreferences("apex_engine_prefs", Context.MODE_PRIVATE)

    var selectedAsset by remember { mutableStateOf(MarketAsset.DEFAULT_ASSETS.first()) }
    var currentResult by remember { mutableStateOf<QuantitativeSignalResult?>(null) }
    var isFetching by remember { mutableStateOf(false) }

    val marketEngine = remember { BinanceLiveMarketDataEngine() }
    val quantEngine = remember { QuantitativeAnalysisEngine(prefs.getInt("confidence_threshold", 70)) }

    fun runLiveAnalysis() {
        if (isFetching) return
        coroutineScope.launch {
            isFetching = true
            quantEngine.confidenceThreshold = prefs.getInt("confidence_threshold", 70)
            val startTime = System.currentTimeMillis()
            val fetchResult = marketEngine.fetchLatestCandles(selectedAsset, limit = 60)

            fetchResult.onSuccess { candles ->
                val res = quantEngine.analyze(selectedAsset, candles, System.currentTimeMillis())
                currentResult = res.copy(latencyMs = System.currentTimeMillis() - startTime)

                // Save to Room database
                val app = activity.application as? ApexVisionApp
                if (app != null) {
                    val now = Date()
                    val sdfDate = SimpleDateFormat("MMM d", Locale.US)
                    val sdfTime = SimpleDateFormat("HH:mm:ss", Locale.US)
                    val entity = SignalHistoryEntity(
                        dateStr = sdfDate.format(now),
                        timeStr = sdfTime.format(now),
                        targetCandle = res.targetCandleLabel,
                        asset = "${res.asset.displayName} (${res.dataProvider})",
                        signal = res.signal.name,
                        confidence = res.analysisScore,
                        rationale = res.statusMessage,
                        pattern = res.indicators?.regime?.name ?: "Market Confluence",
                        support = String.format("%.2f", res.indicators?.supportLevel ?: 0.0),
                        resistance = String.format("%.2f", res.indicators?.resistanceLevel ?: 0.0),
                        latencyMs = res.latencyMs,
                        timingValid = !res.isDataStale,
                        outcome = if (res.signal == TradeSignal.NO_TRADE) "SKIPPED" else "PENDING"
                    )
                    app.repository.recordSignal(entity)
                }
            }.onFailure { err ->
                currentResult = QuantitativeSignalResult(
                    signal = TradeSignal.NO_TRADE,
                    analysisScore = 0,
                    thresholdUsed = quantEngine.confidenceThreshold,
                    asset = selectedAsset,
                    lastPrice = 0.0,
                    dataTimestamp = System.currentTimeMillis(),
                    dataAgeSeconds = 999,
                    isDataStale = true,
                    dataProvider = selectedAsset.provider,
                    status = AnalysisStatus.NETWORK_ERROR,
                    statusMessage = "DATA UNAVAILABLE: ${err.message ?: "Failed to connect to Binance spot feed"}",
                    primaryReasons = listOf("Network error or connection timed out"),
                    conflictingFactors = listOf("Check internet connection"),
                    indicators = null,
                    targetCandleLabel = "Offline",
                    latencyMs = System.currentTimeMillis() - startTime
                )
            }
            isFetching = false
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            // Safety & Integrity Banner
            Surface(
                color = Color(0xFF0F172A),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Real Spot Market Feeds (Binance Public API). Zero screen capture, OCR, or private Quotex API claims. Informational directional signal for user review; does not automate trades.",
                        fontSize = 10.sp,
                        color = Color(0xFFE2E8F0),
                        lineHeight = 13.sp
                    )
                }
            }
        }

        // Asset Selector Chips
        item {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
                Text("SELECT MARKET ASSET", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MarketAsset.DEFAULT_ASSETS.forEach { asset ->
                        val isSelected = asset.symbol == selectedAsset.symbol
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF00E676).copy(alpha = 0.25f) else Color(0xFF090D16))
                                .border(1.dp, if (isSelected) Color(0xFF00E676) else Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .clickable {
                                    selectedAsset = asset
                                    runLiveAnalysis()
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = asset.symbol.replace("USDT", ""),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isSelected) Color(0xFF00E676) else Color.White
                                )
                                Text(
                                    text = asset.category,
                                    fontSize = 7.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Signal & Price Card
        item {
            Surface(
                color = Color(0xFF090D16),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(selectedAsset.displayName, fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("Data Provider: ${selectedAsset.provider}", fontSize = 9.sp, color = Color(0xFF64748B))
                        }

                        if (currentResult != null && currentResult!!.lastPrice > 0.0) {
                            val age = currentResult!!.dataAgeSeconds
                            val statusText = if (currentResult!!.isDataStale) "STALE (${age}s)" else "LIVE (${age}s)"
                            val statusColor = if (currentResult!!.isDataStale) Color(0xFFF59E0B) else Color(0xFF00E676)
                            Text(
                                text = statusText,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                modifier = Modifier
                                    .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        } else {
                            Text("Awaiting Feed", fontSize = 9.sp, color = Color(0xFF64748B))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    GlowingSignalPuck(signal = currentResult?.signal ?: TradeSignal.IDLE)

                    Spacer(modifier = Modifier.height(8.dp))

                    if (currentResult != null && currentResult!!.lastPrice > 0.0) {
                        Text(
                            text = "$${String.format(if (currentResult!!.lastPrice > 100) "%.2f" else "%.4f", currentResult!!.lastPrice)}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White
                        )
                        Text(
                            text = "Analysis Score: ${currentResult!!.analysisScore}% (Min Threshold: ${currentResult!!.thresholdUsed}%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentResult!!.analysisScore >= currentResult!!.thresholdUsed) Color(0xFF00E676) else Color(0xFF94A3B8)
                        )
                    } else {
                        Text(
                            text = if (isFetching) "Connecting to live feed..." else "Press READY to analyze",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = currentResult?.statusMessage ?: "Tap READY to fetch 60 completed 1-minute OHLC candles and calculate momentum confluence.",
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 13.sp
                    )
                }
            }
        }

        // Real Indicators Breakdown (if analyzed)
        item {
            val ind = currentResult?.indicators
            if (ind != null) {
                Surface(
                    color = Color(0xFF090D16),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("CALCULATED QUANTITATIVE INDICATORS", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IndicatorBadge("EMA 9", String.format("%.2f", ind.ema9), Modifier.weight(1f))
                            IndicatorBadge("EMA 21", String.format("%.2f", ind.ema21), Modifier.weight(1f))
                            IndicatorBadge("RSI (14)", String.format("%.1f", ind.rsi14), Modifier.weight(1f),
                                if (ind.rsi14 >= 70) Color(0xFFFF1744) else if (ind.rsi14 <= 30) Color(0xFF00E676) else Color(0xFF38BDF8)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IndicatorBadge("MACD Hist", String.format("%.3f", ind.macdHist), Modifier.weight(1f),
                                if (ind.macdHist > 0) Color(0xFF00E676) else Color(0xFFFF1744)
                            )
                            IndicatorBadge("ATR (14)", String.format("%.4f", ind.atr14), Modifier.weight(1f))
                            IndicatorBadge("Regime", ind.regime.name.replace("_", " "), Modifier.weight(1f), Color(0xFFF59E0B))
                        }

                        if (currentResult!!.primaryReasons.isNotEmpty()) {
                            Text(
                                text = "Supporting Factors: " + currentResult!!.primaryReasons.joinToString(" • "),
                                fontSize = 9.sp,
                                color = Color(0xFF00E676)
                            )
                        }

                        if (currentResult!!.conflictingFactors.isNotEmpty()) {
                            Text(
                                text = "Conflicting/Risk Factors: " + currentResult!!.conflictingFactors.joinToString(" • "),
                                fontSize = 9.sp,
                                color = Color(0xFFF59E0B)
                            )
                        }
                    }
                }
            }
        }

        // 1-Minute Candle Window Tracker
        item {
            Surface(
                color = Color(0xFF090D16),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("1-MINUTE CANDLE TIMER", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                        Text(
                            text = if (secondsRemaining in 1..7) "Final :53-:59 evaluation window" else "Candle forming...",
                            fontSize = 11.sp,
                            color = if (secondsRemaining in 1..7) Color(0xFF00E676) else Color(0xFF64748B)
                        )
                    }

                    val formattedSec = if (secondsRemaining < 10) "0$secondsRemaining" else "$secondsRemaining"
                    Text(
                        text = "00:$formattedSec",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = if (secondsRemaining in 1..7) Color(0xFF00E676) else Color(0xFF38BDF8)
                    )
                }
            }
        }

        // Action Buttons: READY & Floating Overlay
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { runLiveAnalysis() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).height(46.dp),
                    enabled = !isFetching
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF090D16), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isFetching) "Analyzing..." else "READY (Analyze)", color = Color(0xFF090D16), fontSize = 12.sp, fontWeight = FontWeight.Black)
                }

                Button(
                    onClick = {
                        if (!hasOverlayPermission) {
                            onRequestOverlay()
                            return@Button
                        }
                        val intent = Intent(activity, QuotexFloatingOverlayService::class.java)
                        if (QuotexFloatingOverlayService.isRunning) {
                            activity.stopService(intent)
                        } else {
                            activity.startService(intent)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (QuotexFloatingOverlayService.isRunning) Color(0xFFEF4444) else Color(0xFF38BDF8)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f).height(46.dp)
                ) {
                    Icon(
                        imageVector = if (QuotexFloatingOverlayService.isRunning) Icons.Default.Stop else Icons.Default.Layers,
                        contentDescription = null,
                        tint = Color(0xFF090D16),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (QuotexFloatingOverlayService.isRunning) "Stop Overlay" else "Launch Overlay",
                        color = Color(0xFF090D16),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
fun IndicatorBadge(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color.White) {
    Surface(
        color = Color(0xFF070A12),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 8.sp, color = Color(0xFF64748B))
            Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        }
    }
}

@Composable
fun OverlayControlsTab(
    activity: Activity,
    hasOverlayPermission: Boolean,
    onRequestOverlay: () -> Unit
) {
    var isRunning by remember { mutableStateOf(QuotexFloatingOverlayService.isRunning) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("FLOATING OVERLAY CONTROLS", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Draw Over Other Apps Permission", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Allows floating analysis window on top of Quotex", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    if (hasOverlayPermission) {
                        Text("GRANTED", color = Color(0xFF00E676), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Button(
                            onClick = onRequestOverlay,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Grant", color = Color(0xFF090D16), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Overlay Status", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(if (isRunning) "Active and draggable on screen" else "Service stopped", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    Button(
                        onClick = {
                            if (!hasOverlayPermission) {
                                onRequestOverlay()
                                return@Button
                            }
                            val intent = Intent(activity, QuotexFloatingOverlayService::class.java)
                            if (isRunning) {
                                activity.stopService(intent)
                                isRunning = false
                            } else {
                                activity.startService(intent)
                                isRunning = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isRunning) Color(0xFFEF4444) else Color(0xFF00E676)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(if (isRunning) "Stop Overlay" else "Start Overlay", color = Color(0xFF090D16), fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("GESTURE & INTERACTION GUIDE", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                Text("• Drag the floating window anywhere on screen — it smoothly stays within display borders.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                Text("• Tap the READY button to immediately trigger live market data fetching.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                Text("• Tap the Minimize arrow (▲) to collapse into a compact, unobtrusive glowing bubble.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                Text("• Asset selector pills let you switch symbols directly inside the floating window.", fontSize = 11.sp, color = Color(0xFFCBD5E1))
            }
        }
    }
}

@Composable
fun QuantitativeSettingsTab(activity: Activity) {
    val prefs = activity.getSharedPreferences("apex_engine_prefs", Context.MODE_PRIVATE)
    var threshold by remember { mutableStateOf(prefs.getInt("confidence_threshold", 70).toFloat()) }
    var saveFeedback by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("QUANTITATIVE ENGINE CONFIGURATION", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

        // Threshold Slider Card
        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Minimum Analysis Score Threshold", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("${threshold.toInt()}%", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color(0xFF00E676))
                }
                Text(
                    text = "Signals below this threshold strictly yield NO TRADE to preserve disciplined capital management.",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8)
                )

                Slider(
                    value = threshold,
                    onValueChange = {
                        threshold = it
                        prefs.edit().putInt("confidence_threshold", it.toInt()).apply()
                        saveFeedback = true
                    },
                    valueRange = 60f..85f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E676),
                        activeTrackColor = Color(0xFF00E676),
                        inactiveTrackColor = Color(0xFF1E293B)
                    )
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("60% (More frequent)", fontSize = 8.sp, color = Color(0xFF64748B))
                    Text("70% (Recommended)", fontSize = 8.sp, color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
                    Text("85% (Ultra selective)", fontSize = 8.sp, color = Color(0xFF64748B))
                }

                if (saveFeedback) {
                    Text("Saved setting to SharedPreferences", fontSize = 9.sp, color = Color(0xFF00E676))
                }
            }
        }

        // Engine Specifications Card
        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("INDICATOR SPECIFICATIONS", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                EngineSpecRow("Trend Filter", "Exponential Moving Averages: EMA-9 & EMA-21")
                EngineSpecRow("Momentum Index", "Wilder's RSI-14 (Overbought 70, Oversold 30)")
                EngineSpecRow("MACD Trend", "Standard 12 / 26 / 9 Fast/Slow/Signal EMAs")
                EngineSpecRow("Volatility Metric", "Average True Range (ATR-14)")
                EngineSpecRow("Price Action", "Rejection Wicks & Engulfing Candle Structure")
                EngineSpecRow("Conflict Resolution", "Multi-factor agreement matrix (forces NO TRADE on conflict)")
            }
        }

        // Provider Integrity Card
        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("DATA INTEGRITY & COMPLIANCE", fontSize = 10.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                Text(
                    "All price data is obtained directly from documented public spot market endpoints (Binance Public REST API) without scraping or reverse-engineering Quotex. Differences in broker spread or payout percentages may exist.",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 13.sp
                )
            }
        }
    }
}

@Composable
fun EngineSpecRow(title: String, desc: String) {
    Column {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(desc, fontSize = 9.sp, color = Color(0xFF64748B))
    }
}

@Composable
fun AccuracyHistoryTab() {
    val app = ApexVisionApp.instance
    val allSignalsFlow = remember { app.repository.allSignals }
    val accuracyStatsFlow = remember { app.repository.accuracyStats }

    val signals by allSignalsFlow.collectAsState(initial = emptyList())
    val stats by accuracyStatsFlow.collectAsState(initial = null)
    val coroutineScope = rememberCoroutineScope()

    var showClearDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Accuracy Card
            Surface(
                color = Color(0xFF090D16),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("VERIFIED OUTCOME TRACKING", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showClearDialog = true }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear History", tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val accText = if (stats != null && stats!!.accuracyPercentage != null) {
                        "${stats!!.accuracyPercentage!!.toInt()}%"
                    } else {
                        "--"
                    }

                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(accText, fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color(0xFF00E676))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (stats?.hasSufficientData == true) "Verified Win Rate" else "Awaiting sufficient sample (min 5)",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatPill("Wins", "${stats?.wins ?: 0}", Color(0xFF00E676))
                        StatPill("Losses", "${stats?.losses ?: 0}", Color(0xFFFF1744))
                        StatPill("Skipped", "${stats?.skipped ?: 0}", Color(0xFF64748B))
                        StatPill("Logged", "${signals.size}", Color(0xFF38BDF8))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Accuracy = Wins / (Wins + Losses) × 100. NO TRADE and unverified signals are strictly excluded from calculation. Analysis scores are calibrated mathematical confluences, not guaranteed win probabilities.",
                        fontSize = 9.sp,
                        color = Color(0xFF64748B),
                        lineHeight = 12.sp
                    )
                }
            }
        }

        item {
            Text("HISTORICAL 1-MINUTE SIGNALS", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
        }

        if (signals.isEmpty()) {
            item {
                Surface(
                    color = Color(0xFF090D16),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "No 1-minute signals recorded yet. Start scanning on the live market feed.",
                        color = Color(0xFF64748B),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        } else {
            items(signals, key = { it.id }) { item ->
                SignalHistoryRow(
                    entity = item,
                    onMarkWin = {
                        coroutineScope.launch {
                            app.repository.updateEntity(item.copy(outcome = "WIN", actualNextCandle = "GREEN"))
                        }
                    },
                    onMarkLoss = {
                        coroutineScope.launch {
                            app.repository.updateEntity(item.copy(outcome = "LOSS", actualNextCandle = "RED"))
                        }
                    },
                    onDelete = {
                        coroutineScope.launch {
                            app.repository.deleteSignal(item)
                        }
                    }
                )
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear All Signal History?", color = Color.White) },
            text = { Text("This will permanently delete all recorded signals and reset verified accuracy tracking.", color = Color(0xFF94A3B8)) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch { app.repository.clearAll() }
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF090D16)
        )
    }
}

@Composable
fun RowScope.StatPill(label: String, value: String, color: Color) {
    Surface(
        color = Color(0xFF070A12),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.weight(1f)
    ) {
        Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, fontSize = 9.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
fun SignalHistoryRow(
    entity: SignalHistoryEntity,
    onMarkWin: () -> Unit,
    onMarkLoss: () -> Unit,
    onDelete: () -> Unit
) {
    val signalColor = when (entity.signal) {
        "UP" -> Color(0xFF00E676)
        "DOWN" -> Color(0xFFFF1744)
        "NO_TRADE" -> Color(0xFF64748B)
        else -> Color(0xFFF59E0B)
    }

    Surface(
        color = Color(0xFF090D16),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = entity.signal,
                        color = signalColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                    Text(
                        text = entity.targetCandle,
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp
                    )
                }

                Text(
                    text = entity.timeStr,
                    color = Color(0xFF64748B),
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = entity.rationale, color = Color(0xFFCBD5E1), fontSize = 10.sp, lineHeight = 13.sp)

            Spacer(modifier = Modifier.height(6.dp))

            // Outcome Verification Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val outcomeColor = when (entity.outcome) {
                    "WIN" -> Color(0xFF00E676)
                    "LOSS" -> Color(0xFFFF1744)
                    "SKIPPED" -> Color(0xFF64748B)
                    "MISSED_DEADLINE" -> Color(0xFFF59E0B)
                    else -> Color(0xFF38BDF8)
                }
                Text(
                    text = "OUTCOME: ${entity.outcome}",
                    color = outcomeColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )

                if (entity.outcome == "PENDING") {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = onMarkWin,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676).copy(alpha = 0.2f)),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Win", color = Color(0xFF00E676), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onMarkLoss,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744).copy(alpha = 0.2f)),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Loss", color = Color(0xFFFF1744), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PhoneBuildGuideTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PHONE-ONLY CLOUD APK BUILD GUIDE", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "You do not need a computer or laptop! Use free GitHub Actions to build your debug APK in 3 minutes:",
                    fontSize = 11.sp,
                    color = Color.White
                )

                GuideStep(
                    number = "1",
                    title = "Download the Complete Source ZIP",
                    desc = "Use the Download button in the top bar to save 'ApexVision-Quotex-1M-Source.zip' directly to your Android Downloads folder."
                )

                GuideStep(
                    number = "2",
                    title = "Create a Free GitHub Repository",
                    desc = "Open github.com in Chrome on your phone. Tap '+' -> 'New repository' -> Name it 'apexvision-quotex' -> Set to Private or Public."
                )

                GuideStep(
                    number = "3",
                    title = "Upload the Project Files",
                    desc = "Tap 'Add file' -> 'Upload files'. Upload the unzipped android project files (including gradle wrapper and .github/workflows/build-apk.yml)."
                )

                GuideStep(
                    number = "4",
                    title = "Download APK from 'Actions' Tab",
                    desc = "GitHub automatically starts the 'Build Android Debug APK' workflow. After ~3 minutes, tap 'ApexVision-Quotex-1M-Debug-APK' under Artifacts to download and install!"
                )
            }
        }
    }
}

@Composable
fun GuideStep(number: String, title: String, desc: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .background(Color(0xFF00E676), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = Color(0xFF090D16), fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
        Column {
            Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
            Text(desc, color = Color(0xFF94A3B8), fontSize = 10.sp, lineHeight = 13.sp)
        }
    }
}

private fun checkOverlayPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else {
        true
    }
}

private fun requestOverlayPermission(
    context: Context,
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        launcher.launch(intent)
    }
}
