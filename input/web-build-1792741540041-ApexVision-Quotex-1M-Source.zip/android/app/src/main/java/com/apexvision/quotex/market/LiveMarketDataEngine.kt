package com.apexvision.quotex.market

import com.apexvision.quotex.model.MarketAsset
import com.apexvision.quotex.model.MarketCandle
import com.google.gson.Gson
import com.google.gson.JsonArray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

interface LiveMarketDataEngine {
    suspend fun fetchLatestCandles(asset: MarketAsset, limit: Int = 60): Result<List<MarketCandle>>
    suspend fun fetchLatestPrice(asset: MarketAsset): Result<Pair<Double, Long>>
}

/**
 * Legitimate, official public live market data client using Binance Public Spot API.
 * Requires NO API key, zero private secrets, official free rate limits (1200 req/min).
 */
class BinanceLiveMarketDataEngine(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()
) : LiveMarketDataEngine {

    private val gson = Gson()

    // Official documented public endpoints with automatic fallback
    private val baseUrls = listOf(
        "https://api.binance.com",
        "https://api1.binance.com",
        "https://data-api.binance.vision"
    )

    override suspend fun fetchLatestCandles(asset: MarketAsset, limit: Int): Result<List<MarketCandle>> = withContext(Dispatchers.IO) {
        var lastException: Exception? = null

        for (baseUrl in baseUrls) {
            try {
                val url = "$baseUrl/api/v3/klines?symbol=${asset.symbol}&interval=1m&limit=$limit"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "ApexVision-AI-MarketAnalyzer/1.0")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IOException("HTTP ${response.code}: ${response.message}")
                    }

                    val bodyString = response.body?.string() ?: throw IOException("Empty response body")
                    val jsonArray = gson.fromJson(bodyString, JsonArray::class.java)

                    val candles = mutableListOf<MarketCandle>()
                    for (i in 0 until jsonArray.size()) {
                        val item = jsonArray.get(i).asJsonArray
                        val openTime = item.get(0).asLong
                        val open = item.get(1).asString.toDoubleOrNull() ?: 0.0
                        val high = item.get(2).asString.toDoubleOrNull() ?: 0.0
                        val low = item.get(3).asString.toDoubleOrNull() ?: 0.0
                        val close = item.get(4).asString.toDoubleOrNull() ?: 0.0
                        val volume = item.get(5).asString.toDoubleOrNull() ?: 0.0
                        val closeTime = item.get(6).asLong

                        val isComplete = (i < jsonArray.size() - 1)

                        candles.add(
                            MarketCandle(
                                openTime = openTime,
                                open = open,
                                high = high,
                                low = low,
                                close = close,
                                volume = volume,
                                closeTime = closeTime,
                                isComplete = isComplete
                            )
                        )
                    }

                    if (candles.isEmpty()) {
                        throw IOException("No candlestick data returned from provider.")
                    }

                    return@withContext Result.success(candles)
                }
            } catch (e: Exception) {
                lastException = e
            }
        }

        Result.failure(lastException ?: IOException("Failed to connect to live market data provider."))
    }

    override suspend fun fetchLatestPrice(asset: MarketAsset): Result<Pair<Double, Long>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.binance.com/api/v3/ticker/price?symbol=${asset.symbol}"
            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
                val body = response.body?.string() ?: throw IOException("Empty response")
                val json = gson.fromJson(body, com.google.gson.JsonObject::class.java)
                val price = json.get("price").asString.toDoubleOrNull() ?: 0.0
                val now = System.currentTimeMillis()
                return@withContext Result.success(Pair(price, now))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
