package com.apexvision.quotex

import com.apexvision.quotex.model.MarketCandle
import org.junit.Assert.*
import org.junit.Test

class CandleAggregationTest {

    @Test
    fun testCandleOhlcInvariants() {
        val candle = MarketCandle(
            openTime = 1700000000000L,
            closeTime = 1700000059999L,
            open = 100.5,
            high = 102.0,
            low = 99.8,
            close = 101.2,
            volume = 55.4,
            isComplete = true
        )

        assertTrue("High must be >= open", candle.high >= candle.open)
        assertTrue("High must be >= close", candle.high >= candle.close)
        assertTrue("Low must be <= open", candle.low <= candle.open)
        assertTrue("Low must be <= close", candle.low <= candle.close)
        assertTrue("Volume must be non-negative", candle.volume >= 0.0)
        assertTrue("Candle must span exactly 1 minute window", candle.closeTime > candle.openTime)
    }

    @Test
    fun testTickTo1MinuteCandleAggregation() {
        // Simulate a series of incoming price ticks within a 60-second minute window
        data class PriceTick(val timestamp: Long, val price: Double, val volume: Double)

        val windowStart = 1700000000000L
        val ticks = listOf(
            PriceTick(windowStart + 1000L, 50000.0, 0.5),
            PriceTick(windowStart + 15000L, 50150.0, 1.2),
            PriceTick(windowStart + 30000L, 49920.0, 2.0),
            PriceTick(windowStart + 45000L, 50080.0, 0.8),
            PriceTick(windowStart + 58000L, 50050.0, 0.3)
        )

        // Aggregation logic
        val open = ticks.first().price
        val close = ticks.last().price
        var high = Double.NEGATIVE_INFINITY
        var low = Double.POSITIVE_INFINITY
        var totalVolume = 0.0

        for (tick in ticks) {
            if (tick.price > high) high = tick.price
            if (tick.price < low) low = tick.price
            totalVolume += tick.volume
        }

        val aggregatedCandle = MarketCandle(
            openTime = windowStart,
            closeTime = windowStart + 59999L,
            open = open,
            high = high,
            low = low,
            close = close,
            volume = totalVolume,
            isComplete = true
        )

        assertEquals("Open price must match first tick", 50000.0, aggregatedCandle.open, 0.001)
        assertEquals("Close price must match last tick", 50050.0, aggregatedCandle.close, 0.001)
        assertEquals("High price must match maximum tick", 50150.0, aggregatedCandle.high, 0.001)
        assertEquals("Low price must match minimum tick", 49920.0, aggregatedCandle.low, 0.001)
        assertEquals("Volume must be the sum of tick volumes", 4.8, aggregatedCandle.volume, 0.001)
    }

    @Test
    fun testFormingCandleFilteringAvoidsLookaheadBias() {
        // If the newest candle is still forming (isComplete == false), quantitative models
        // drop it to use only fully finalized candles, preventing repainting or look-ahead bias.
        val candles = (1..30).map { i ->
            MarketCandle(
                openTime = i * 60_000L,
                closeTime = (i * 60_000L) + 59_999L,
                open = 100.0 + i,
                high = 101.0 + i,
                low = 99.0 + i,
                close = 100.5 + i,
                volume = 10.0,
                isComplete = i < 30 // 30th candle is incomplete
            )
        }

        assertEquals(30, candles.size)
        assertFalse("Last candle is incomplete", candles.last().isComplete)

        val stableCandles = if (!candles.last().isComplete && candles.size > 28) {
            candles.dropLast(1)
        } else {
            candles
        }

        assertEquals("Incomplete candle must be dropped", 29, stableCandles.size)
        assertTrue("All retained candles must be complete", stableCandles.all { it.isComplete })
    }
}
