package com.apexvision.quotex

import com.apexvision.quotex.analysis.QuantitativeAnalysisEngine
import com.apexvision.quotex.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class IndicatorCalculationTest {

    private lateinit var engine: QuantitativeAnalysisEngine
    private val testAsset = MarketAsset.DEFAULT_ASSETS.first()

    @Before
    fun setup() {
        engine = QuantitativeAnalysisEngine(confidenceThreshold = 70)
    }

    private fun generateTrendingCandles(count: Int, startPrice: Double, step: Double): List<MarketCandle> {
        val now = System.currentTimeMillis()
        var currentPrice = startPrice
        return (0 until count).map { i ->
            val open = currentPrice
            val close = currentPrice + step
            val high = maxOf(open, close) + 0.5
            val low = minOf(open, close) - 0.5
            val time = now - ((count - i) * 60_000L)
            currentPrice = close
            MarketCandle(
                openTime = time,
                closeTime = time + 59_999L,
                open = open,
                high = high,
                low = low,
                close = close,
                volume = 100.0,
                isComplete = true
            )
        }
    }

    @Test
    fun testBullishEmaCrossoverAndTrend() {
        // 40 candles with sustained upward trend
        val candles = generateTrendingCandles(count = 40, startPrice = 100.0, step = 1.0)
        val now = candles.last().closeTime + 5_000L // 5 seconds fresh

        val result = engine.analyze(testAsset, candles, currentClockMillis = now)
        assertNotNull("Indicators must be computed", result.indicators)
        val ind = result.indicators!!

        assertTrue("EMA 9 should be greater than EMA 21 in sustained uptrend", ind.ema9 > ind.ema21)
        assertTrue("RSI 14 should reflect positive momentum (> 50)", ind.rsi14 > 50.0)
        assertTrue("RSI 14 must stay within [0, 100]", ind.rsi14 in 0.0..100.0)
        assertTrue("ATR 14 must be positive", ind.atr14 > 0.0)
        assertTrue("MACD Histogram should be positive in strong uptrend", ind.macdHist > 0.0)
    }

    @Test
    fun testBearishEmaTrendAndRsiDownturn() {
        // 40 candles with sustained downward trend
        val candles = generateTrendingCandles(count = 40, startPrice = 200.0, step = -1.5)
        val now = candles.last().closeTime + 5_000L

        val result = engine.analyze(testAsset, candles, currentClockMillis = now)
        assertNotNull("Indicators must be computed", result.indicators)
        val ind = result.indicators!!

        assertTrue("EMA 9 should be less than EMA 21 in sustained downtrend", ind.ema9 < ind.ema21)
        assertTrue("RSI 14 should reflect negative momentum (< 50)", ind.rsi14 < 50.0)
        assertTrue("MACD line should be below signal line", ind.macdHist < 0.0)
    }

    @Test
    fun testRangingMarketRegimeDetection() {
        // 40 candles oscillating in a tight range
        val now = System.currentTimeMillis()
        val candles = (0 until 40).map { i ->
            val base = 150.0 + if (i % 2 == 0) 0.2 else -0.2
            val time = now - ((40 - i) * 60_000L)
            MarketCandle(
                openTime = time,
                closeTime = time + 59_999L,
                open = base,
                high = base + 0.3,
                low = base - 0.3,
                close = base + if (i % 2 == 0) 0.1 else -0.1,
                volume = 50.0,
                isComplete = true
            )
        }

        val result = engine.analyze(testAsset, candles, currentClockMillis = candles.last().closeTime + 5_000L)
        assertNotNull(result.indicators)
        // In tight oscillation, regime should be detected as RANGING
        assertEquals(MarketRegime.RANGING, result.indicators?.regime)
    }
}
