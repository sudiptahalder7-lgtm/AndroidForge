package com.apexvision.quotex

import com.apexvision.quotex.analysis.QuantitativeAnalysisEngine
import com.apexvision.quotex.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class StaleDataDetectionTest {

    private lateinit var engine: QuantitativeAnalysisEngine
    private val testAsset = MarketAsset.DEFAULT_ASSETS.first()

    @Before
    fun setup() {
        engine = QuantitativeAnalysisEngine(confidenceThreshold = 70)
    }

    private fun generateCandles(count: Int, lastCandleCloseTime: Long): List<MarketCandle> {
        return (0 until count).map { i ->
            val closeTime = lastCandleCloseTime - ((count - 1 - i) * 60_000L)
            val openTime = closeTime - 59_999L
            MarketCandle(
                openTime = openTime,
                closeTime = closeTime,
                open = 100.0 + i,
                high = 101.0 + i,
                low = 99.0 + i,
                close = 100.5 + i,
                volume = 50.0,
                isComplete = true
            )
        }
    }

    @Test
    fun testStaleDataRejectionForcesNoTrade() {
        val lastCloseTime = 1700000000000L
        val candles = generateCandles(count = 35, lastCandleCloseTime = lastCloseTime)

        // Current clock is 180 seconds AFTER the last candle close (exceeds 120s safety limit)
        val now = lastCloseTime + (180 * 1000L)

        val result = engine.analyze(testAsset, candles, currentClockMillis = now)

        assertEquals("Stale data must strictly force NO_TRADE signal", TradeSignal.NO_TRADE, result.signal)
        assertTrue("Data must be flagged as stale", result.isDataStale)
        assertEquals(AnalysisStatus.STALE_DATA, result.status)
        assertEquals("Analysis score must be 0 for stale data", 0, result.analysisScore)
        assertTrue("Status message must explain data is stale", result.statusMessage.contains("DATA STALE"))
    }

    @Test
    fun testFreshDataAcceptance() {
        val lastCloseTime = 1700000000000L
        val candles = generateCandles(count = 35, lastCandleCloseTime = lastCloseTime)

        // Current clock is only 15 seconds after candle close (fresh within 120s limit)
        val now = lastCloseTime + (15 * 1000L)

        val result = engine.analyze(testAsset, candles, currentClockMillis = now)

        assertFalse("Data should be recognized as fresh", result.isDataStale)
        assertEquals(15L, result.dataAgeSeconds)
        assertNotEquals(AnalysisStatus.STALE_DATA, result.status)
    }
}
