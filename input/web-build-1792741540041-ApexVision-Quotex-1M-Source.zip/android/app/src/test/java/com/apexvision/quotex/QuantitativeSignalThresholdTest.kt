package com.apexvision.quotex

import com.apexvision.quotex.analysis.QuantitativeAnalysisEngine
import com.apexvision.quotex.model.*
import org.junit.Assert.*
import org.junit.Test

class QuantitativeSignalThresholdTest {

    private val testAsset = MarketAsset.DEFAULT_ASSETS.first()

    @Test
    fun testInsufficientCandleSampleSizeReturnsNoTrade() {
        val engine = QuantitativeAnalysisEngine(confidenceThreshold = 70)
        val now = System.currentTimeMillis()

        // Provide only 15 candles (need at least 28 for reliable EMA/MACD/RSI)
        val shortCandles = (0 until 15).map { i ->
            val time = now - ((15 - i) * 60_000L)
            MarketCandle(time, time + 59999L, 100.0, 101.0, 99.0, 100.5, 10.0, true)
        }

        val result = engine.analyze(testAsset, shortCandles, currentClockMillis = now)
        assertEquals(TradeSignal.NO_TRADE, result.signal)
        assertEquals(AnalysisStatus.INSUFFICIENT_DATA, result.status)
        assertEquals(0, result.analysisScore)
        assertTrue(result.statusMessage.contains("Need at least 28 completed 1m candles"))
    }

    @Test
    fun testConfigurableThresholdEnforcement() {
        // Build a moderately bullish sequence
        val now = System.currentTimeMillis()
        var price = 50.0
        val candles = (0 until 40).map { i ->
            val open = price
            val close = price + if (i > 25) 0.3 else 0.1
            val time = now - ((40 - i) * 60_000L)
            price = close
            MarketCandle(time, time + 59999L, open, close + 0.2, open - 0.2, close, 100.0, true)
        }

        val clockTime = candles.last().closeTime + 10_000L

        // Test with strict 85% threshold
        val strictEngine = QuantitativeAnalysisEngine(confidenceThreshold = 85)
        val strictResult = strictEngine.analyze(testAsset, candles, currentClockMillis = clockTime)

        if (strictResult.analysisScore < 85) {
            assertEquals("Score below 85% threshold must produce NO_TRADE", TradeSignal.NO_TRADE, strictResult.signal)
            assertEquals(85, strictResult.thresholdUsed)
        }

        // Test with standard 70% threshold
        val standardEngine = QuantitativeAnalysisEngine(confidenceThreshold = 70)
        val standardResult = standardEngine.analyze(testAsset, candles, currentClockMillis = clockTime)
        assertEquals(70, standardResult.thresholdUsed)

        if (standardResult.analysisScore >= 70) {
            assertEquals(TradeSignal.UP, standardResult.signal)
        }
    }

    @Test
    fun testNeverForceTradeSignalToAvoidNoTrade() {
        // Choppy contradictory market with frequent wicks and flat price
        val now = System.currentTimeMillis()
        val candles = (0 until 45).map { i ->
            val base = 100.0
            val isEven = i % 2 == 0
            val time = now - ((45 - i) * 60_000L)
            MarketCandle(
                openTime = time,
                closeTime = time + 59999L,
                open = if (isEven) base - 0.5 else base + 0.5,
                high = base + 1.2,
                low = base - 1.2,
                close = if (isEven) base + 0.1 else base - 0.1,
                volume = 20.0,
                isComplete = true
            )
        }

        val engine = QuantitativeAnalysisEngine(confidenceThreshold = 70)
        val result = engine.analyze(testAsset, candles, currentClockMillis = candles.last().closeTime + 5_000L)

        // Must NOT force UP or DOWN when indicators conflict or regime is choppy/ranging
        assertEquals("Choppy conflict market must strictly yield NO_TRADE", TradeSignal.NO_TRADE, result.signal)
        assertTrue("Analysis score should be below 70%", result.analysisScore < 70)
    }

    @Test
    fun testIndicatorConflictPenalizesScore() {
        // Upward trend but last candle has massive upper rejection wick and touches high resistance
        val now = System.currentTimeMillis()
        var price = 100.0
        val candles = (0 until 40).map { i ->
            val open = price
            val isLast = i == 39
            val close = if (isLast) price + 0.1 else price + 0.8
            val high = if (isLast) price + 4.0 else close + 0.2 // Huge upper wick on last candle
            val low = open - 0.1
            val time = now - ((40 - i) * 60_000L)
            price = close
            MarketCandle(time, time + 59999L, open, high, low, close, 150.0, true)
        }

        val engine = QuantitativeAnalysisEngine(confidenceThreshold = 70)
        val result = engine.analyze(testAsset, candles, currentClockMillis = candles.last().closeTime + 10_000L)

        // Upper rejection wick creates conflict against long position
        assertNotNull(result.indicators)
        assertTrue(result.conflictingFactors.isNotEmpty() || result.primaryReasons.isNotEmpty())
    }
}
