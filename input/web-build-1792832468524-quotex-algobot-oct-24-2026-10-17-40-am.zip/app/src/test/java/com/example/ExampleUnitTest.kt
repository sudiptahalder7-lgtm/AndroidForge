package com.example

import com.example.engine.IndicatorCalculator
import com.example.engine.PatternDetector
import com.example.engine.PredictionEngine
import com.example.model.Candle
import com.example.model.PatternType
import com.example.model.SignalDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testBullishEngulfingPatternDetection() {
        val candles = listOf(
            Candle(1000L, 1.0850, 1.0855, 1.0845, 1.0848, 100.0), // Red
            Candle(2000L, 1.0847, 1.0860, 1.0846, 1.0856, 250.0)  // Green engulfing
        )
        // Need at least 3 candles
        val fullList = listOf(
            Candle(0L, 1.0860, 1.0865, 1.0855, 1.0858, 80.0),
            candles[0],
            candles[1]
        )
        val detected = PatternDetector.detectPattern(fullList)
        assertEquals(PatternType.BULLISH_ENGULFING, detected.type)
        assertTrue(detected.type.isBullish)
    }

    @Test
    fun testIndicatorCalculationValid() {
        val candles = (1..30).map { i ->
            val p = 1.0800 + (i * 0.0002)
            Candle(i * 60000L, p, p + 0.0003, p - 0.0002, p + 0.0001, 100.0)
        }
        val indicators = IndicatorCalculator.calculateIndicators(candles)
        assertTrue(indicators.rsi in 0.0..100.0)
        assertTrue(indicators.upperBB > indicators.lowerBB)
        assertTrue(indicators.ema9 > 0.0)
    }

    @Test
    fun testPredictionEngineGeneratesConfluence() {
        val candles = (1..30).map { i ->
            val p = 1.0800 + (i * 0.0002)
            Candle(i * 60000L, p, p + 0.0003, p - 0.0002, p + 0.0001, 100.0)
        }
        val prediction = PredictionEngine.generatePrediction("EUR/USD (OTC)", candles, 45)
        assertNotNull(prediction)
        assertTrue(prediction.probability in 50..100)
        assertTrue(prediction.confluencePoints.isNotEmpty())
    }
}
