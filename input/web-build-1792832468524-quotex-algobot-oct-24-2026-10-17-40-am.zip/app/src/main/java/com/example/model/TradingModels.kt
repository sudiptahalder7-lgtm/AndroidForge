package com.example.model

enum class MarketType(val displayName: String) {
    REAL("Real Market"),
    OTC("Quotex OTC")
}

enum class SignalDirection(val label: String) {
    CALL("CALL ▲"),
    PUT("PUT ▼"),
    NEUTRAL("WAIT ━")
}

enum class TradeStatus {
    ACTIVE,
    WON,
    LOST,
    TIE
}

enum class ExecutionMode(val title: String) {
    PAPER_SIMULATION("Paper Trading (Safe Mode)"),
    QUOTEX_API_BRIDGE("Quotex API Webhook / Bridge")
}

data class Asset(
    val symbol: String,
    val name: String,
    val marketType: MarketType,
    val currentPrice: Double,
    val change24h: Double,
    val payoutPercentage: Int, // e.g. 92%
    val decimalPlaces: Int = 5
)

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val isBullish: Boolean get() = close >= open
    val bodySize: Double get() = Math.abs(close - open)
    val upperWick: Double get() = high - Math.max(open, close)
    val lowerWick: Double get() = Math.min(open, close) - low
    val totalRange: Double get() = Math.max(high - low, 0.00001)
}

enum class PatternType(val displayName: String, val isBullish: Boolean, val reliability: Int) {
    BULLISH_ENGULFING("Bullish Engulfing", true, 85),
    BEARISH_ENGULFING("Bearish Engulfing", false, 85),
    HAMMER("Bullish Hammer", true, 82),
    INVERTED_HAMMER("Inverted Hammer", true, 76),
    SHOOTING_STAR("Shooting Star", false, 83),
    MORNING_STAR("Morning Star (3-Candle)", true, 88),
    EVENING_STAR("Evening Star (3-Candle)", false, 88),
    THREE_WHITE_SOLDIERS("Three White Soldiers", true, 86),
    THREE_BLACK_CROWS("Three Black Crows", false, 86),
    BULLISH_MARUBOZU("Bullish Marubozu", true, 80),
    BEARISH_MARUBOZU("Bearish Marubozu", false, 80),
    DOJI_REVERSAL("Doji Indecision", true, 68),
    NONE("No Clear Formation", false, 0)
}

data class CandlePattern(
    val type: PatternType,
    val description: String
)

data class TechnicalIndicators(
    val rsi: Double,
    val macdLine: Double,
    val macdSignal: Double,
    val macdHist: Double,
    val upperBB: Double,
    val middleBB: Double,
    val lowerBB: Double,
    val ema9: Double,
    val ema21: Double,
    val ema50: Double,
    val stochK: Double,
    val stochD: Double
)

data class PredictionSignal(
    val id: String,
    val assetSymbol: String,
    val direction: SignalDirection,
    val probability: Int, // 50 to 98%
    val pattern: CandlePattern,
    val indicators: TechnicalIndicators,
    val strikePrice: Double,
    val expirySeconds: Int = 60,
    val confluencePoints: List<String>,
    val timestamp: Long,
    val candleTimeRemainingSeconds: Int
)

data class Trade(
    val id: String,
    val assetSymbol: String,
    val direction: SignalDirection,
    val stakeAmount: Double,
    val payoutPercent: Int,
    val entryPrice: Double,
    var exitPrice: Double? = null,
    val openTime: Long,
    val expiryDurationSeconds: Int = 60,
    var status: TradeStatus = TradeStatus.ACTIVE,
    var profitLoss: Double = 0.0,
    var remainingSeconds: Int = 60
)

data class BotSettings(
    val isAutoTrading: Boolean = false,
    val executionMode: ExecutionMode = ExecutionMode.PAPER_SIMULATION,
    val stakeAmount: Double = 10.0,
    val useMartingale: Boolean = true,
    val martingaleMultiplier: Double = 2.0,
    val maxMartingaleSteps: Int = 3,
    val minConfidenceThreshold: Int = 78,
    val stopLossAmount: Double = 100.0,
    val takeProfitAmount: Double = 250.0,
    val soundAlerts: Boolean = true,
    val tradeOnCandleCloseOnly: Boolean = true
)

data class QuotexBridgeConfig(
    val apiKey: String = "qtx_live_sec_88492041b3f",
    val webhookUrl: String = "https://ws.quotex.io/api/v2/bot/signals",
    val isConnected: Boolean = true,
    val accountType: String = "DEMO", // "DEMO" or "REAL"
    val balance: Double = 10000.00,
    val pingMs: Int = 24,
    val lastSyncTime: Long = System.currentTimeMillis()
)
