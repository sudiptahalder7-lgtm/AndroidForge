package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PredictionSignal
import com.example.model.SignalDirection
import com.example.ui.theme.IndicatorRsi
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingPurpleAccent
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary

@Composable
fun PredictionCard(
    signal: PredictionSignal?,
    payoutPercentage: Int,
    currentStake: Double,
    onStakeChange: (Double) -> Unit,
    onCallClick: () -> Unit,
    onPutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expandedReasons by remember { mutableStateOf(false) }

    val dirColor = when (signal?.direction) {
        SignalDirection.CALL -> TradingBullishGreen
        SignalDirection.PUT -> TradingBearishRed
        else -> TradingAmberWarning
    }

    val dirGradient = when (signal?.direction) {
        SignalDirection.CALL -> Brush.linearGradient(
            listOf(TradingBullishGreen.copy(alpha = 0.25f), TradingDarkCard)
        )
        SignalDirection.PUT -> Brush.linearGradient(
            listOf(TradingBearishRed.copy(alpha = 0.25f), TradingDarkCard)
        )
        else -> Brush.linearGradient(
            listOf(TradingAmberWarning.copy(alpha = 0.15f), TradingDarkCard)
        )
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(dirGradient)
            .border(1.dp, dirColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        // Prediction Header with Glow Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(dirColor.copy(alpha = 0.2f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (signal?.direction) {
                            SignalDirection.CALL -> Icons.Default.ArrowUpward
                            SignalDirection.PUT -> Icons.Default.ArrowDownward
                            else -> Icons.Default.AutoAwesome
                        },
                        contentDescription = "Signal Icon",
                        tint = dirColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "PREDICTED NEXT 1M CANDLE",
                            style = MaterialTheme.typography.labelSmall,
                            color = TradingTextMuted,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Text(
                        text = signal?.direction?.label ?: "ANALYZING...",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = dirColor,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Probability Confidence Badge
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${signal?.probability ?: 50}%",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = dirColor,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "WIN PROBABILITY",
                    style = TextStyle(fontSize = 9.sp, color = TradingTextSecondary, fontWeight = FontWeight.Bold)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Progress Confidence Bar
        LinearProgressIndicator(
            progress = { (signal?.probability ?: 50) / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = dirColor,
            trackColor = TradingDarkSurface
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Detected Formation & Indicator Badges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Pattern badge
            val patternName = signal?.pattern?.type?.displayName ?: "Scanning..."
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(TradingDarkSurface, RoundedCornerShape(8.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Column {
                    Text("FORMATION", fontSize = 9.sp, color = TradingCyanAccent, fontWeight = FontWeight.Bold)
                    Text(
                        text = patternName,
                        fontSize = 11.sp,
                        color = TradingTextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }

            // RSI badge
            val rsiVal = signal?.indicators?.rsi ?: 50.0
            Box(
                modifier = Modifier
                    .weight(0.7f)
                    .background(TradingDarkSurface, RoundedCornerShape(8.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Column {
                    Text("RSI (14)", fontSize = 9.sp, color = IndicatorRsi, fontWeight = FontWeight.Bold)
                    Text(
                        text = "%.1f".format(rsiVal),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            rsiVal <= 30.0 -> TradingBullishGreen
                            rsiVal >= 70.0 -> TradingBearishRed
                            else -> TradingTextPrimary
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // MACD badge
            val macdHist = signal?.indicators?.macdHist ?: 0.0
            Box(
                modifier = Modifier
                    .weight(0.7f)
                    .background(TradingDarkSurface, RoundedCornerShape(8.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Column {
                    Text("MACD", fontSize = 9.sp, color = TradingPurpleAccent, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (macdHist >= 0) "+%.4f".format(macdHist) else "%.4f".format(macdHist),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (macdHist >= 0) TradingBullishGreen else TradingBearishRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Expandable Rationale Details
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expandedReasons = !expandedReasons }
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.ShowChart,
                    contentDescription = null,
                    tint = TradingCyanAccent,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Technical Confluence (${signal?.confluencePoints?.size ?: 0} Factors)",
                    fontSize = 12.sp,
                    color = TradingTextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
            Icon(
                imageVector = if (expandedReasons) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                contentDescription = "Expand",
                tint = TradingTextSecondary,
                modifier = Modifier.size(18.dp)
            )
        }

        AnimatedVisibility(visible = expandedReasons) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                signal?.confluencePoints?.forEach { point ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = dirColor,
                            modifier = Modifier
                                .padding(top = 2.dp)
                                .size(12.dp)
                        )
                        Text(
                            text = point,
                            fontSize = 11.sp,
                            color = TradingTextPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Stake Selector Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Investment Stake:",
                style = MaterialTheme.typography.bodySmall,
                color = TradingTextSecondary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(5.0, 10.0, 25.0, 50.0).forEach { amt ->
                    val isSelected = currentStake == amt
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) TradingCyanAccent else TradingDarkSurface)
                            .border(1.dp, if (isSelected) TradingCyanAccent else TradingDarkCardBorder, RoundedCornerShape(6.dp))
                            .clickable { onStakeChange(amt) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$${amt.toInt()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.Black else TradingTextPrimary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Big Action Buttons: CALL ▲ and PUT ▼
        val payoutReturn = currentStake * (1.0 + payoutPercentage / 100.0)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // CALL BUTTON
            Button(
                onClick = onCallClick,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
                    .testTag("call_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TradingBullishGreen,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("CALL ▲", fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                    Text(
                        text = "+$payoutPercentage% (+$${"%.1f".format(payoutReturn)})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // PUT BUTTON
            Button(
                onClick = onPutClick,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
                    .testTag("put_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TradingBearishRed,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PUT ▼", fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                    Text(
                        text = "+$payoutPercentage% (+$${"%.1f".format(payoutReturn)})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
