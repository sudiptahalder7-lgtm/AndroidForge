package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ApiTelemetryLog
import com.example.engine.QuotexBridge
import com.example.model.QuotexBridgeConfig
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingPurpleAccent
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun QuotexBridgeScreen(
    config: QuotexBridgeConfig,
    telemetryLogs: List<ApiTelemetryLog>,
    onConfigChanged: (QuotexBridgeConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var apiKey by remember(config.apiKey) { mutableStateOf(config.apiKey) }
    var webhookUrl by remember(config.webhookUrl) { mutableStateOf(config.webhookUrl) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TradingDarkBg)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Connection Header & Health Badge
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(TradingDarkCard)
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(TradingBullishGreen, CircleShape)
                        )
                        Column {
                            Text(
                                text = "Quotex API Gateway",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TradingTextPrimary
                            )
                            Text(
                                text = "Protocol: WSS v2.4 (Live Feed)",
                                fontSize = 11.sp,
                                color = TradingCyanAccent
                            )
                        }
                    }

                    // Ping Latency
                    Box(
                        modifier = Modifier
                            .background(TradingBullishGreen.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${config.pingMs} ms",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TradingBullishGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Account Switcher (DEMO vs REAL)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(TradingDarkSurface)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "${config.accountType} ACCOUNT",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (config.accountType == "REAL") TradingAmberWarning else TradingCyanAccent
                            )
                        }
                        Text(
                            text = "$${"%.2f".format(config.balance)}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = TradingTextPrimary
                        )
                    }

                    Button(
                        onClick = { QuotexBridge.toggleAccountType() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TradingCyanAccent.copy(alpha = 0.2f),
                            contentColor = TradingCyanAccent
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("switch_account_button")
                    ) {
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Switch", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 2. Credentials Configuration Card
        item {
            Text(
                text = "API & WEBHOOK INTEGRATION",
                style = MaterialTheme.typography.labelMedium,
                color = TradingCyanAccent,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingDarkCard, RoundedCornerShape(12.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = {
                        apiKey = it
                        onConfigChanged(config.copy(apiKey = it))
                    },
                    label = { Text("Quotex API Session Token / Secret") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TradingTextPrimary,
                        unfocusedTextColor = TradingTextPrimary,
                        focusedBorderColor = TradingCyanAccent,
                        unfocusedBorderColor = TradingDarkCardBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = webhookUrl,
                    onValueChange = {
                        webhookUrl = it
                        onConfigChanged(config.copy(webhookUrl = it))
                    },
                    label = { Text("Quotex Webhook / Signal Receiver URL") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("webhook_url_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TradingTextPrimary,
                        unfocusedTextColor = TradingTextPrimary,
                        focusedBorderColor = TradingCyanAccent,
                        unfocusedBorderColor = TradingDarkCardBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                Button(
                    onClick = {
                        QuotexBridge.logTelemetry(
                            "PING_TEST",
                            """{"event":"manual_ping","endpoint":"$webhookUrl","status":"200 OK","rtt_ms":${(18..35).random()}}""",
                            true
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = TradingCyanAccent, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Connection & Validate Latency", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // 3. Real-Time Telemetry & JSON Payload Stream
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE API TELEMETRY STREAM",
                    style = MaterialTheme.typography.labelMedium,
                    color = TradingCyanAccent,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "JSON Payload Monitor",
                    fontSize = 10.sp,
                    color = TradingTextMuted
                )
            }
        }

        items(telemetryLogs.take(12)) { log ->
            TelemetryLogItem(log)
        }

        // 4. Quotex & Binary Options Disclaimer
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingAmberWarning.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                    .border(1.dp, TradingAmberWarning.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = TradingAmberWarning,
                    modifier = Modifier.size(18.dp)
                )
                Column {
                    Text("Educational & Compliance Advisory", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TradingAmberWarning)
                    Text(
                        text = "Quotex is an online digital trading platform. Automated algorithmic bots operate under simulated or webhook execution protocols. Financial markets carry substantial risk; past performance does not guarantee future results.",
                        fontSize = 11.sp,
                        color = TradingTextSecondary,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TelemetryLogItem(log: ApiTelemetryLog) {
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val tagColor = when (log.type) {
        "REQUEST" -> TradingCyanAccent
        "RESPONSE" -> TradingBullishGreen
        "FEED" -> TradingPurpleAccent
        else -> TradingAmberWarning
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TradingDarkCard)
            .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .background(tagColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(log.type, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = tagColor)
                }
                Text(
                    text = timeFormat.format(Date(log.timestamp)),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TradingTextMuted
                )
            }

            Text(
                text = if (log.isSuccess) "OK" else "FAIL",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (log.isSuccess) TradingBullishGreen else TradingBearishRed
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = log.payload,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = TradingTextPrimary,
            lineHeight = 14.sp
        )
    }
}
