package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TradingCyanAccent,
    onPrimary = Color(0xFF001F29),
    primaryContainer = Color(0xFF004D61),
    onPrimaryContainer = Color(0xFFB8EAFF),
    secondary = TradingPurpleAccent,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF3700B3),
    onSecondaryContainer = Color(0xFFE8DDFF),
    tertiary = TradingBullishGreen,
    onTertiary = Color(0xFF003919),
    background = TradingDarkBg,
    onBackground = TradingTextPrimary,
    surface = TradingDarkSurface,
    onSurface = TradingTextPrimary,
    surfaceVariant = TradingDarkCard,
    onSurfaceVariant = TradingTextSecondary,
    outline = TradingDarkCardBorder,
    error = TradingBearishRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek trading terminal dark theme
    dynamicColor: Boolean = false, // Keep high-contrast neon trading palette consistent
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
