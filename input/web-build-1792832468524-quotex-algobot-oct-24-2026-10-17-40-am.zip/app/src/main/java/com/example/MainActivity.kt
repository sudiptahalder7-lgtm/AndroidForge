package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.screens.BotConfigScreen
import com.example.ui.screens.MarketScannerScreen
import com.example.ui.screens.QuotexBridgeScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.TradeHistoryScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }

    val assets by viewModel.assets.collectAsStateWithLifecycle()
    val selectedAsset by viewModel.selectedAsset.collectAsStateWithLifecycle()
    val currentCandles by viewModel.currentCandles.collectAsStateWithLifecycle()
    val secondsRemaining by viewModel.candleSecondsRemaining.collectAsStateWithLifecycle()
    val currentPrediction by viewModel.currentPrediction.collectAsStateWithLifecycle()
    val botSettings by viewModel.botSettings.collectAsStateWithLifecycle()
    val activeTrades by viewModel.activeTrades.collectAsStateWithLifecycle()
    val completedTrades by viewModel.completedTrades.collectAsStateWithLifecycle()
    val quotexConfig by viewModel.quotexConfig.collectAsStateWithLifecycle()
    val telemetryLogs by viewModel.telemetryLogs.collectAsStateWithLifecycle()

    // Handle system back navigation to return to Terminal tab first
    BackHandler(enabled = selectedTab != 0) {
        selectedTab = 0
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = TradingDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(TradingCyanAccent.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "QX",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp,
                                    color = TradingCyanAccent,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column {
                                Text(
                                    text = "Quotex AlgoBot",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TradingTextPrimary
                                )
                                Text(
                                    text = "1M Candle Predictor",
                                    fontSize = 10.sp,
                                    color = TradingCyanAccent
                                )
                            }
                        }

                        // Account Balance Pill in TopBar
                        Row(
                            modifier = Modifier
                                .background(TradingDarkCard, RoundedCornerShape(20.dp))
                                .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        if (quotexConfig.accountType == "REAL") TradingAmberWarning else TradingBullishGreen,
                                        CircleShape
                                    )
                            )
                            Text(
                                text = "$${"%.2f".format(quotexConfig.balance)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TradingTextPrimary
                            )
                            Text(
                                text = quotexConfig.accountType,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (quotexConfig.accountType == "REAL") TradingAmberWarning else TradingCyanAccent
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TradingDarkSurface,
                    titleContentColor = TradingTextPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = TradingDarkSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.border(width = 0.5.dp, color = TradingDarkCardBorder)
            ) {
                val navItems = listOf(
                    Triple(0, "Terminal", Icons.Default.ShowChart),
                    Triple(1, "Auto-Bot", Icons.Default.PlayCircle),
                    Triple(2, "Markets", Icons.Default.ViewList),
                    Triple(3, "Quotex API", Icons.Default.Cable),
                    Triple(4, "Trades", Icons.Default.History)
                )

                navItems.forEach { (index, title, icon) ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TradingCyanAccent,
                            selectedTextColor = TradingCyanAccent,
                            unselectedIconColor = TradingTextSecondary,
                            unselectedTextColor = TradingTextSecondary,
                            indicatorColor = TradingCyanAccent.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_item_$index")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> TerminalScreen(
                    selectedAsset = selectedAsset,
                    assets = assets,
                    candles = currentCandles,
                    secondsRemaining = secondsRemaining,
                    currentPrediction = currentPrediction,
                    activeTrades = activeTrades,
                    isAutoTrading = botSettings.isAutoTrading,
                    onAssetSelected = { viewModel.selectAsset(it) },
                    onToggleAutoTrading = { viewModel.toggleAutoTrading() },
                    onPlaceTrade = { dir, stake -> viewModel.placeTrade(dir, stake) }
                )
                1 -> BotConfigScreen(
                    settings = botSettings,
                    completedTrades = completedTrades,
                    onSettingsChanged = { viewModel.updateBotSettings(it) },
                    onToggleAutoTrading = { viewModel.toggleAutoTrading() }
                )
                2 -> MarketScannerScreen(
                    assets = assets,
                    selectedAsset = selectedAsset,
                    onAssetSelected = {
                        viewModel.selectAsset(it)
                        selectedTab = 0 // Switch to chart
                    }
                )
                3 -> QuotexBridgeScreen(
                    config = quotexConfig,
                    telemetryLogs = telemetryLogs,
                    onConfigChanged = { viewModel.updateQuotexConfig(it) }
                )
                4 -> TradeHistoryScreen(
                    trades = completedTrades
                )
            }
        }
    }
}
