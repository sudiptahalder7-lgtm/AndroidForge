package com.example.engine

import com.example.model.Candle
import com.example.model.CandlePattern
import com.example.model.PatternType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object PatternDetector {

    fun detectPattern(candles: List<Candle>): CandlePattern {
        if (candles.size < 3) {
            return CandlePattern(PatternType.NONE, "Insufficient candle history")
        }

        val c0 = candles.last() // Current completed / forming candle
        val c1 = candles[candles.size - 2] // 1 candle ago
        val c2 = candles[candles.size - 3] // 2 candles ago

        val c0Body = c0.bodySize
        val c0Range = max(c0.totalRange, 0.00001)
        val c0UpperWick = c0.upperWick
        val c0LowerWick = c0.lowerWick

        val c1Body = c1.bodySize
        val c1Range = max(c1.totalRange, 0.00001)

        val c2Body = c2.bodySize
        val c2Range = max(c2.totalRange, 0.00001)

        // 1. Three White Soldiers (3 strong consecutive bullish candles)
        if (c2.isBullish && c1.isBullish && c0.isBullish &&
            c0.close > c1.close && c1.close > c2.close &&
            c0Body > (c0Range * 0.6) && c1Body > (c1Range * 0.6)
        ) {
            return CandlePattern(
                PatternType.THREE_WHITE_SOLDIERS,
                "Strong 3-candle institutional bullish continuation momentum."
            )
        }

        // 2. Three Black Crows (3 strong consecutive bearish candles)
        if (!c2.isBullish && !c1.isBullish && !c0.isBullish &&
            c0.close < c1.close && c1.close < c2.close &&
            c0Body > (c0Range * 0.6) && c1Body > (c1Range * 0.6)
        ) {
            return CandlePattern(
                PatternType.THREE_BLACK_CROWS,
                "Intense selling pressure with 3 consecutive lower closes."
            )
        }

        // 3. Morning Star (Downtrend -> Small indecision -> Strong green reversal)
        if (!c2.isBullish && c2Body > (c2.totalRange * 0.5) &&
            c1Body < (c1Range * 0.3) &&
            c0.isBullish && c0.close > (c2.open + c2.close) / 2.0
        ) {
            return CandlePattern(
                PatternType.MORNING_STAR,
                "Textbook 3-candle bullish reversal after consolidation at support."
            )
        }

        // 4. Evening Star (Uptrend -> Small indecision -> Strong red reversal)
        if (c2.isBullish && c2Body > (c2.totalRange * 0.5) &&
            c1Body < (c1Range * 0.3) &&
            !c0.isBullish && c0.close < (c2.open + c2.close) / 2.0
        ) {
            return CandlePattern(
                PatternType.EVENING_STAR,
                "Classic 3-candle bearish reversal exhausted buyer exhaustion."
            )
        }

        // 5. Bullish Engulfing (Red candle engulfed by large Green candle)
        if (!c1.isBullish && c0.isBullish &&
            c0.open <= c1.close && c0.close >= c1.open &&
            c0Body > c1Body
        ) {
            return CandlePattern(
                PatternType.BULLISH_ENGULFING,
                "Buyers completely overwhelmed sellers. High win-rate CALL trigger."
            )
        }

        // 6. Bearish Engulfing (Green candle engulfed by large Red candle)
        if (c1.isBullish && !c0.isBullish &&
            c0.open >= c1.close && c0.close <= c1.open &&
            c0Body > c1Body
        ) {
            return CandlePattern(
                PatternType.BEARISH_ENGULFING,
                "Sellers aggressively overwhelmed buyers. High win-rate PUT trigger."
            )
        }

        // 7. Bullish Hammer (Small body near top, lower wick >= 2x body, tiny upper wick)
        if (c0LowerWick >= (c0Body * 1.8) && c0UpperWick <= (c0Body * 0.5) && c0Body > 0) {
            return CandlePattern(
                PatternType.HAMMER,
                "Price rejected sharply from the lows, showing strong buyers stepping in."
            )
        }

        // 8. Shooting Star (Small body near bottom, upper wick >= 2x body, tiny lower wick)
        if (c0UpperWick >= (c0Body * 1.8) && c0LowerWick <= (c0Body * 0.5) && c0Body > 0) {
            return CandlePattern(
                PatternType.SHOOTING_STAR,
                "Strong price rejection from the highs, indicating immediate downward reversal."
            )
        }

        // 9. Inverted Hammer (Small body near bottom, long upper wick in a downtrend)
        if (c0UpperWick >= (c0Body * 1.5) && c0LowerWick <= (c0Body * 0.3) && !c1.isBullish) {
            return CandlePattern(
                PatternType.INVERTED_HAMMER,
                "Bulls tested higher price levels; potential bottom turnaround."
            )
        }

        // 10. Marubozu (Almost no wicks, heavy momentum body)
        if (c0Body > (c0Range * 0.88)) {
            return if (c0.isBullish) {
                CandlePattern(
                    PatternType.BULLISH_MARUBOZU,
                    "Dominant bullish continuation bar with near-zero wick rejection."
                )
            } else {
                CandlePattern(
                    PatternType.BEARISH_MARUBOZU,
                    "Dominant bearish continuation bar with pure selling velocity."
                )
            }
        }

        // 11. Doji (Indecision candle)
        if (c0Body <= (c0Range * 0.12)) {
            return CandlePattern(
                PatternType.DOJI_REVERSAL,
                "Equilibrium reached between buyers & sellers. Volatility breakout imminent."
            )
        }

        return CandlePattern(PatternType.NONE, "Standard market fluctuation without defined pattern.")
    }
}
