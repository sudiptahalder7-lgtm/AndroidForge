package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TradingRepository
import com.example.engine.QuotexBridge
import com.example.model.Asset
import com.example.model.Candle
import com.example.model.MarketType
import com.example.model.PredictionSignal
import com.example.model.SignalDirection
import com.example.model.Trade
import com.example.model.TradeStatus
import com.example.ui.components.CandleChart
import com.example.ui.components.PredictionCard
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary

@Composable
fun TerminalScreen(
    selectedAsset: Asset,
    assets: List<Asset>,
    candles: List<Candle>,
    secondsRemaining: Int,
    currentPrediction: PredictionSignal?,
    activeTrades: List<Trade>,
    isAutoTrading: Boolean,
    onAssetSelected: (Asset) -> Unit,
    onToggleAutoTrading: () -> Unit,
    onPlaceTrade: (SignalDirection, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var stake by remember { mutableDoubleStateOf(10.0) }
    var assetMenuExpanded by remember { mutableStateOf(false) }

    val formatStr = "%.${selectedAsset.decimalPlaces}f"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TradingDarkBg)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Asset Bar & Quick Status Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Asset Selector Dropdown Button
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(TradingDarkCard)
                            .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(10.dp))
                            .clickable { assetMenuExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("asset_selector"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = selectedAsset.symbol,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TradingTextPrimary
                                )
                                if (selectedAsset.marketType == MarketType.OTC) {
                                    Box(
                                        modifier = Modifier
                                            .background(TradingCyanAccent.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("OTC", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TradingCyanAccent)
                                    }
                                }
                            }
                            Text(
                                text = "Payout ${selectedAsset.payoutPercentage}%",
                                fontSize = 10.sp,
                                color = TradingBullishGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Select Asset",
                            tint = TradingTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = assetMenuExpanded,
                        onDismissRequest = { assetMenuExpanded = false },
                        modifier = Modifier
                            .background(TradingDarkSurface)
                            .border(1.dp, TradingDarkCardBorder)
                    ) {
                        assets.forEach { asset ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(asset.symbol, color = TradingTextPrimary, fontWeight = FontWeight.Bold)
                                            Text(asset.name, color = TradingTextSecondary, fontSize = 11.sp)
                                        }
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Text(
                                            "${asset.payoutPercentage}%",
                                            color = TradingBullishGreen,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                },
                                onClick = {
                                    onAssetSelected(asset)
                                    assetMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Live Price & Tick Indicator
                Column(horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(
                            imageVector = Icons.Default.FiberManualRecord,
                            contentDescription = "Live",
                            tint = TradingBullishGreen,
                            modifier = Modifier.size(10.dp)
                        )
                        Text(
                            text = formatStr.format(selectedAsset.currentPrice),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = TradingTextPrimary
                        )
                    }

                    val changeColor = if (selectedAsset.change24h >= 0) TradingBullishGreen else TradingBearishRed
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (selectedAsset.change24h >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                            contentDescription = null,
                            tint = changeColor,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "${if (selectedAsset.change24h >= 0) "+" else ""}${selectedAsset.change24h}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = changeColor
                        )
                    }
                }
            }
        }

        // 2. Bot Active / Quick Toggle Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isAutoTrading) TradingBullishGreen.copy(alpha = 0.12f) else TradingDarkCard)
                    .border(
                        1.dp,
                        if (isAutoTrading) TradingBullishGreen.copy(alpha = 0.4f) else TradingDarkCardBorder,
                        RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(if (isAutoTrading) TradingBullishGreen else TradingAmberWarning, CircleShape)
                    )
                    Column {
                        Text(
                            text = if (isAutoTrading) "ALGO-BOT ACTIVE" else "AUTO-BOT PAUSED",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAutoTrading) TradingBullishGreen else TradingTextPrimary
                        )
                        Text(
                            text = if (isAutoTrading) "Auto-executing on ≥78% confluence" else "Tap Start to automate 1M signals",
                            fontSize = 10.sp,
                            color = TradingTextSecondary
                        )
                    }
                }

                Button(
                    onClick = onToggleAutoTrading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAutoTrading) TradingBearishRed else TradingBullishGreen,
                        contentColor = if (isAutoTrading) Color.White else Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("bot_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isAutoTrading) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isAutoTrading) "PAUSE" else "START BOT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 3. Live 1-Minute Candlestick Chart
        item {
            CandleChart(
                candles = candles,
                activeTrades = activeTrades,
                secondsRemaining = secondsRemaining,
                decimalPlaces = selectedAsset.decimalPlaces,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp)
            )
        }

        // 4. Algorithmic Prediction & Trade Execution Hub
        item {
            PredictionCard(
                signal = currentPrediction,
                payoutPercentage = selectedAsset.payoutPercentage,
                currentStake = stake,
                onStakeChange = { stake = it },
                onCallClick = { onPlaceTrade(SignalDirection.CALL, stake) },
                onPutClick = { onPlaceTrade(SignalDirection.PUT, stake) }
            )
        }

        // 5. Active Trades Section
        if (activeTrades.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE TRADES (${activeTrades.size})",
                        style = MaterialTheme.typography.labelMedium,
                        color = TradingCyanAccent,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "1M Expiry Countdown",
                        fontSize = 10.sp,
                        color = TradingTextMuted
                    )
                }
            }

            items(activeTrades) { trade ->
                ActiveTradeRow(trade = trade, currentPrice = selectedAsset.currentPrice, decimalPlaces = selectedAsset.decimalPlaces)
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ActiveTradeRow(
    trade: Trade,
    currentPrice: Double,
    decimalPlaces: Int
) {
    val formatStr = "%.${decimalPlaces}f"
    val isInTheMoney = when (trade.direction) {
        SignalDirection.CALL -> currentPrice > trade.entryPrice
        SignalDirection.PUT -> currentPrice < trade.entryPrice
        else -> false
    }

    val statusColor = if (isInTheMoney) TradingBullishGreen else TradingBearishRed

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TradingDarkCard)
            .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(
                        if (trade.direction == SignalDirection.CALL) TradingBullishGreen.copy(alpha = 0.2f)
                        else TradingBearishRed.copy(alpha = 0.2f),
                        RoundedCornerShape(6.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (trade.direction == SignalDirection.CALL) "▲" else "▼",
                    color = if (trade.direction == SignalDirection.CALL) TradingBullishGreen else TradingBearishRed,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }

            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(trade.assetSymbol, fontWeight = FontWeight.Bold, color = TradingTextPrimary, fontSize = 13.sp)
                    Text("$$${trade.stakeAmount.toInt()}", color = TradingCyanAccent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(
                    text = "Strike: ${formatStr.format(trade.entryPrice)}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TradingTextSecondary
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${trade.remainingSeconds}s",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = if (trade.remainingSeconds <= 10) TradingBearishRed else TradingCyanAccent
            )
            Text(
                text = if (isInTheMoney) "IN THE MONEY (WIN)" else "OUT OF MONEY",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = statusColor
            )
        }
    }
}
