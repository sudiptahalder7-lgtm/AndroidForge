package com.example.data

import com.example.engine.PredictionEngine
import com.example.engine.QuotexBridge
import com.example.model.Asset
import com.example.model.BotSettings
import com.example.model.Candle
import com.example.model.MarketType
import com.example.model.PredictionSignal
import com.example.model.SignalDirection
import com.example.model.Trade
import com.example.model.TradeStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

object TradingRepository {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Pre-configured Market Assets
    val initialAssets = listOf(
        // OTC Pairs (Quotex high-payout weekend & 24/7 OTC markets)
        Asset("EUR/USD (OTC)", "Euro / US Dollar OTC", MarketType.OTC, 1.08420, 0.42, 93, 5),
        Asset("GBP/USD (OTC)", "British Pound / USD OTC", MarketType.OTC, 1.29850, -0.28, 91, 5),
        Asset("USD/JPY (OTC)", "US Dollar / Japanese Yen OTC", MarketType.OTC, 152.450, 0.65, 92, 3),
        Asset("BTC/USD (OTC)", "Bitcoin / USD OTC", MarketType.OTC, 67420.50, 2.15, 94, 2),
        Asset("Gold (OTC)", "Gold / US Dollar OTC", MarketType.OTC, 2735.80, 0.85, 92, 2),
        Asset("AUD/CAD (OTC)", "Australian Dollar / CAD OTC", MarketType.OTC, 0.91340, -0.15, 89, 5),
        Asset("US Crude (OTC)", "WTI Crude Oil OTC", MarketType.OTC, 71.45, -1.10, 90, 2),

        // Real Market Pairs
        Asset("EUR/USD", "Euro / US Dollar", MarketType.REAL, 1.08380, 0.12, 88, 5),
        Asset("GBP/USD", "British Pound / USD", MarketType.REAL, 1.29790, -0.18, 87, 5),
        Asset("USD/JPY", "US Dollar / Japanese Yen", MarketType.REAL, 152.320, 0.45, 85, 3),
        Asset("BTC/USD", "Bitcoin Real Market", MarketType.REAL, 67380.00, 1.95, 89, 2),
        Asset("ETH/USD", "Ethereum Real Market", MarketType.REAL, 2520.40, 1.40, 86, 2),
        Asset("XAU/USD", "Gold Spot Real Market", MarketType.REAL, 2732.10, 0.72, 88, 2)
    )

    private val _assets = MutableStateFlow(initialAssets)
    val assets: StateFlow<List<Asset>> = _assets.asStateFlow()

    private val _selectedAsset = MutableStateFlow(initialAssets.first())
    val selectedAsset: StateFlow<Asset> = _selectedAsset.asStateFlow()

    // Map of symbol -> List of 1-minute Candles
    private val candleStore = mutableMapOf<String, MutableList<Candle>>()

    private val _currentCandles = MutableStateFlow<List<Candle>>(emptyList())
    val currentCandles: StateFlow<List<Candle>> = _currentCandles.asStateFlow()

    private val _candleSecondsRemaining = MutableStateFlow(60)
    val candleSecondsRemaining: StateFlow<Int> = _candleSecondsRemaining.asStateFlow()

    private val _currentPrediction = MutableStateFlow<PredictionSignal?>(null)
    val currentPrediction: StateFlow<PredictionSignal?> = _currentPrediction.asStateFlow()

    private val _botSettings = MutableStateFlow(BotSettings())
    val botSettings: StateFlow<BotSettings> = _botSettings.asStateFlow()

    private val _activeTrades = MutableStateFlow<List<Trade>>(emptyList())
    val activeTrades: StateFlow<List<Trade>> = _activeTrades.asStateFlow()

    private val _completedTrades = MutableStateFlow<List<Trade>>(emptyList())
    val completedTrades: StateFlow<List<Trade>> = _completedTrades.asStateFlow()

    private var currentMartingaleStep = 0
    private var lastTradeResultWasWin = true

    init {
        // Generate initial 60 candles for each pair
        initialAssets.forEach { asset ->
            candleStore[asset.symbol] = generateHistoricalCandles(asset.currentPrice, asset.decimalPlaces)
        }
        _currentCandles.value = candleStore[_selectedAsset.value.symbol] ?: emptyList()
        updatePrediction()

        // Start real-time tick engine
        startTickEngine()
    }

    fun selectAsset(asset: Asset) {
        _selectedAsset.value = asset
        val candles = candleStore[asset.symbol] ?: generateHistoricalCandles(asset.currentPrice, asset.decimalPlaces)
        candleStore[asset.symbol] = candles
        _currentCandles.value = candles
        updatePrediction()
    }

    fun updateBotSettings(settings: BotSettings) {
        _botSettings.value = settings
    }

    fun toggleAutoTrade() {
        val current = _botSettings.value
        val updated = current.copy(isAutoTrading = !current.isAutoTrading)
        _botSettings.value = updated
        QuotexBridge.logTelemetry(
            "BOT_STATE",
            """{"auto_trading":${updated.isAutoTrading},"mode":"${updated.executionMode.name}"}""",
            true
        )
    }

    fun placeManualTrade(direction: SignalDirection, stakeAmount: Double = _botSettings.value.stakeAmount) {
        val asset = _selectedAsset.value
        val newTrade = Trade(
            id = "TRD_${UUID.randomUUID().toString().take(8).uppercase()}",
            assetSymbol = asset.symbol,
            direction = direction,
            stakeAmount = stakeAmount,
            payoutPercent = asset.payoutPercentage,
            entryPrice = asset.currentPrice,
            openTime = System.currentTimeMillis(),
            expiryDurationSeconds = 60,
            remainingSeconds = 60
        )

        QuotexBridge.dispatchTradeExecution(newTrade, _botSettings.value.executionMode)

        _activeTrades.update { it + newTrade }
    }

    private fun startTickEngine() {
        scope.launch {
            while (true) {
                delay(1000L) // 1-second pulse
                onSecondTick()
            }
        }
    }

    private fun onSecondTick() {
        var sec = _candleSecondsRemaining.value - 1
        val isNewCandle = sec <= 0
        if (isNewCandle) sec = 60
        _candleSecondsRemaining.value = sec

        // Update all assets slightly to simulate live liquidity
        _assets.update { currentList ->
            currentList.map { asset ->
                val tickDelta = generateMicroTick(asset.currentPrice, asset.decimalPlaces)
                val newPrice = (asset.currentPrice + tickDelta).coerceAtLeast(0.0001)
                asset.copy(currentPrice = newPrice)
            }
        }

        // Update selected asset and its forming candle
        val updatedAsset = _assets.value.firstOrNull { it.symbol == _selectedAsset.value.symbol } ?: _selectedAsset.value
        _selectedAsset.value = updatedAsset

        val assetCandles = candleStore[updatedAsset.symbol] ?: return
        if (assetCandles.isNotEmpty()) {
            val lastIndex = assetCandles.lastIndex
            val currentCandle = assetCandles[lastIndex]

            if (isNewCandle) {
                // Finalize candle and spawn a new 1-minute candle
                val newCandle = Candle(
                    timestamp = System.currentTimeMillis(),
                    open = currentCandle.close,
                    high = currentCandle.close,
                    low = currentCandle.close,
                    close = currentCandle.close,
                    volume = Random.nextDouble(100.0, 500.0)
                )
                assetCandles.add(newCandle)
                if (assetCandles.size > 80) {
                    assetCandles.removeAt(0)
                }

                // Check auto bot entry on new candle open
                checkAutoBotExecution()
            } else {
                // Update currently forming candle
                val updatedHigh = maxOf(currentCandle.high, updatedAsset.currentPrice)
                val updatedLow = minOf(currentCandle.low, updatedAsset.currentPrice)
                val updatedCandle = currentCandle.copy(
                    high = updatedHigh,
                    low = updatedLow,
                    close = updatedAsset.currentPrice,
                    volume = currentCandle.volume + Random.nextDouble(5.0, 20.0)
                )
                assetCandles[lastIndex] = updatedCandle
            }
            _currentCandles.value = assetCandles.toList()
        }

        // Update prediction signal
        updatePrediction()

        // Update active trades countdown
        updateActiveTrades()
    }

    private fun checkAutoBotExecution() {
        val settings = _botSettings.value
        if (!settings.isAutoTrading) return

        val signal = _currentPrediction.value ?: return
        if (signal.direction == SignalDirection.NEUTRAL) return
        if (signal.probability < settings.minConfidenceThreshold) return

        // Calculate stake with Martingale if enabled
        val baseStake = settings.stakeAmount
        val finalStake = if (settings.useMartingale && !lastTradeResultWasWin && currentMartingaleStep < settings.maxMartingaleSteps) {
            baseStake * Math.pow(settings.martingaleMultiplier, currentMartingaleStep.toDouble())
        } else {
            baseStake
        }

        placeManualTrade(signal.direction, finalStake)
    }

    private fun updateActiveTrades() {
        val currentActive = _activeTrades.value
        if (currentActive.isEmpty()) return

        val completed = mutableListOf<Trade>()
        val remaining = mutableListOf<Trade>()

        for (trade in currentActive) {
            val updatedSec = trade.remainingSeconds - 1
            if (updatedSec <= 0) {
                // Trade Expired: evaluate win/loss
                val currentPrice = _assets.value.firstOrNull { it.symbol == trade.assetSymbol }?.currentPrice ?: trade.entryPrice
                trade.exitPrice = currentPrice
                trade.remainingSeconds = 0

                val won = when (trade.direction) {
                    SignalDirection.CALL -> currentPrice > trade.entryPrice
                    SignalDirection.PUT -> currentPrice < trade.entryPrice
                    SignalDirection.NEUTRAL -> false
                }

                val isTie = currentPrice == trade.entryPrice

                if (isTie) {
                    trade.status = TradeStatus.TIE
                    trade.profitLoss = 0.0
                } else if (won) {
                    trade.status = TradeStatus.WON
                    trade.profitLoss = trade.stakeAmount * (trade.payoutPercent / 100.0)
                    lastTradeResultWasWin = true
                    currentMartingaleStep = 0
                } else {
                    trade.status = TradeStatus.LOST
                    trade.profitLoss = -trade.stakeAmount
                    lastTradeResultWasWin = false
                    if (currentMartingaleStep < _botSettings.value.maxMartingaleSteps) {
                        currentMartingaleStep++
                    } else {
                        currentMartingaleStep = 0
                    }
                }

                QuotexBridge.recordTradeResult(trade, won, trade.profitLoss)
                completed.add(trade)
            } else {
                trade.remainingSeconds = updatedSec
                remaining.add(trade)
            }
        }

        _activeTrades.value = remaining
        if (completed.isNotEmpty()) {
            _completedTrades.update { completed + it }
        }
    }

    private fun updatePrediction() {
        val candles = _currentCandles.value
        if (candles.isNotEmpty()) {
            val signal = PredictionEngine.generatePrediction(
                assetSymbol = _selectedAsset.value.symbol,
                candles = candles,
                candleTimeRemainingSeconds = _candleSecondsRemaining.value
            )
            _currentPrediction.value = signal
        }
    }

    private fun generateHistoricalCandles(basePrice: Double, decimalPlaces: Int): MutableList<Candle> {
        val list = mutableListOf<Candle>()
        var current = basePrice
        val now = System.currentTimeMillis()
        val count = 50

        for (i in count downTo 1) {
            val open = current
            val volatility = basePrice * 0.0006
            val change = (Random.nextDouble() - 0.49) * volatility
            val close = open + change
            val high = maxOf(open, close) + Random.nextDouble(0.0, volatility * 0.5)
            val low = minOf(open, close) - Random.nextDouble(0.0, volatility * 0.5)
            val volume = Random.nextDouble(150.0, 950.0)

            list.add(
                Candle(
                    timestamp = now - (i * 60_000L),
                    open = roundTo(open, decimalPlaces),
                    high = roundTo(high, decimalPlaces),
                    low = roundTo(low, decimalPlaces),
                    close = roundTo(close, decimalPlaces),
                    volume = volume
                )
            )
            current = close
        }
        return list
    }

    private fun generateMicroTick(price: Double, decimalPlaces: Int): Double {
        val spread = price * 0.00008
        val delta = (Random.nextDouble() - 0.495) * spread
        return roundTo(delta, decimalPlaces)
    }

    private fun roundTo(value: Double, places: Int): Double {
        val factor = Math.pow(10.0, places.toDouble())
        return Math.round(value * factor) / factor
    }
}
