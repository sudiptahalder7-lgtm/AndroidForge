package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.TradingRepository
import com.example.engine.ApiTelemetryLog
import com.example.engine.QuotexBridge
import com.example.model.Asset
import com.example.model.BotSettings
import com.example.model.Candle
import com.example.model.PredictionSignal
import com.example.model.QuotexBridgeConfig
import com.example.model.SignalDirection
import com.example.model.Trade
import kotlinx.coroutines.flow.StateFlow

class MainViewModel : ViewModel() {

    val assets: StateFlow<List<Asset>> = TradingRepository.assets
    val selectedAsset: StateFlow<Asset> = TradingRepository.selectedAsset
    val currentCandles: StateFlow<List<Candle>> = TradingRepository.currentCandles
    val candleSecondsRemaining: StateFlow<Int> = TradingRepository.candleSecondsRemaining
    val currentPrediction: StateFlow<PredictionSignal?> = TradingRepository.currentPrediction
    val botSettings: StateFlow<BotSettings> = TradingRepository.botSettings
    val activeTrades: StateFlow<List<Trade>> = TradingRepository.activeTrades
    val completedTrades: StateFlow<List<Trade>> = TradingRepository.completedTrades

    val quotexConfig: StateFlow<QuotexBridgeConfig> = QuotexBridge.config
    val telemetryLogs: StateFlow<List<ApiTelemetryLog>> = QuotexBridge.telemetryLogs

    fun selectAsset(asset: Asset) {
        TradingRepository.selectAsset(asset)
    }

    fun toggleAutoTrading() {
        TradingRepository.toggleAutoTrade()
    }

    fun updateBotSettings(settings: BotSettings) {
        TradingRepository.updateBotSettings(settings)
    }

    fun placeTrade(direction: SignalDirection, stakeAmount: Double) {
        TradingRepository.placeManualTrade(direction, stakeAmount)
    }

    fun updateQuotexConfig(config: QuotexBridgeConfig) {
        QuotexBridge.updateConfig(config)
    }
}
