package com.example.engine

import com.example.model.Candle
import com.example.model.PredictionSignal
import com.example.model.SignalDirection
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

object PredictionEngine {

    fun generatePrediction(
        assetSymbol: String,
        candles: List<Candle>,
        candleTimeRemainingSeconds: Int
    ): PredictionSignal {
        if (candles.size < 15) {
            val dummyInd = IndicatorCalculator.calculateIndicators(candles)
            val dummyPat = PatternDetector.detectPattern(candles)
            return PredictionSignal(
                id = UUID.randomUUID().toString(),
                assetSymbol = assetSymbol,
                direction = SignalDirection.NEUTRAL,
                probability = 50,
                pattern = dummyPat,
                indicators = dummyInd,
                strikePrice = candles.lastOrNull()?.close ?: 1.0,
                expirySeconds = 60,
                confluencePoints = listOf("Accumulating tick history for 1M timeframe analysis"),
                timestamp = System.currentTimeMillis(),
                candleTimeRemainingSeconds = candleTimeRemainingSeconds
            )
        }

        val indicators = IndicatorCalculator.calculateIndicators(candles)
        val pattern = PatternDetector.detectPattern(candles)
        val currentPrice = candles.last().close

        var bullishScore = 0
        var bearishScore = 0
        val reasons = mutableListOf<String>()

        // 1. Candlestick Formation Evaluation
        if (pattern.type.reliability > 0) {
            if (pattern.type.isBullish) {
                val weight = (pattern.type.reliability * 0.32).roundToInt()
                bullishScore += weight
                reasons.add("${pattern.type.displayName} pattern formed on 1-min chart (Reliability: ${pattern.type.reliability}%)")
            } else {
                val weight = (pattern.type.reliability * 0.32).roundToInt()
                bearishScore += weight
                reasons.add("${pattern.type.displayName} pattern formed on 1-min chart (Reliability: ${pattern.type.reliability}%)")
            }
        }

        // 2. RSI (14) Momentum & Extreme Zones
        when {
            indicators.rsi < 30.0 -> {
                bullishScore += 26
                reasons.add("RSI Oversold at ${"%.1f".format(indicators.rsi)}: Strong mean reversion CALL zone")
            }
            indicators.rsi < 40.0 -> {
                bullishScore += 14
                reasons.add("RSI trending upward from oversold territory (${"%.1f".format(indicators.rsi)})")
            }
            indicators.rsi > 70.0 -> {
                bearishScore += 26
                reasons.add("RSI Overbought at ${"%.1f".format(indicators.rsi)}: High probability PUT rejection zone")
            }
            indicators.rsi > 60.0 -> {
                bearishScore += 14
                reasons.add("RSI reaching overbought threshold (${"%.1f".format(indicators.rsi)})")
            }
            else -> {
                // Neutral zone (40-60)
                if (indicators.rsi > 50.0) bullishScore += 6 else bearishScore += 6
            }
        }

        // 3. Bollinger Bands Dynamic Support / Resistance
        val bbDistanceToLower = (currentPrice - indicators.lowerBB) / currentPrice
        val bbDistanceToUpper = (indicators.upperBB - currentPrice) / currentPrice

        if (bbDistanceToLower <= 0.0004) {
            bullishScore += 22
            reasons.add("Price bounced off Lower Bollinger Band (20, 2.0σ)")
        } else if (bbDistanceToUpper <= 0.0004) {
            bearishScore += 22
            reasons.add("Price rejected at Upper Bollinger Band (20, 2.0σ)")
        }

        // 4. Moving Average Trend Confluence (EMA 9, 21, 50)
        if (indicators.ema9 > indicators.ema21 && indicators.ema21 > indicators.ema50) {
            bullishScore += 18
            reasons.add("Bullish EMA Ribbon alignment (EMA9 > EMA21 > EMA50)")
        } else if (indicators.ema9 < indicators.ema21 && indicators.ema21 < indicators.ema50) {
            bearishScore += 18
            reasons.add("Bearish EMA Ribbon alignment (EMA9 < EMA21 < EMA50)")
        } else if (indicators.ema9 > indicators.ema21) {
            bullishScore += 10
            reasons.add("Short-term bullish EMA9 crossover above EMA21")
        } else {
            bearishScore += 10
            reasons.add("Short-term bearish EMA9 crossover below EMA21")
        }

        // 5. MACD Momentum & Signal Line Crossover
        if (indicators.macdHist > 0 && indicators.macdLine > indicators.macdSignal) {
            bullishScore += 16
            reasons.add("MACD positive histogram expansion (${"%.5f".format(indicators.macdHist)})")
        } else if (indicators.macdHist < 0 && indicators.macdLine < indicators.macdSignal) {
            bearishScore += 16
            reasons.add("MACD negative histogram expansion (${"%.5f".format(indicators.macdHist)})")
        }

        // 6. Stochastic Oscillator (%K & %D)
        if (indicators.stochK < 25.0 && indicators.stochK > indicators.stochD) {
            bullishScore += 14
            reasons.add("Stochastic %K crossed above %D in oversold region (%K: ${"%.1f".format(indicators.stochK)})")
        } else if (indicators.stochK > 75.0 && indicators.stochK < indicators.stochD) {
            bearishScore += 14
            reasons.add("Stochastic %K crossed below %D in overbought region (%K: ${"%.1f".format(indicators.stochK)})")
        }

        // Final Confluence Calculation
        val totalScore = bullishScore + bearishScore
        val diff = abs(bullishScore - bearishScore)

        val direction: SignalDirection
        val probability: Int

        if (diff < 15 || totalScore < 30) {
            direction = SignalDirection.NEUTRAL
            probability = 52
            reasons.add(0, "Market in low-conviction consolidation; awaiting next candle breakout")
        } else if (bullishScore > bearishScore) {
            direction = SignalDirection.CALL
            // Normalize probability between 72% and 94%
            val rawProb = 65 + ((diff.toDouble() / maxOf(totalScore, 1)) * 35).roundToInt()
            probability = rawProb.coerceIn(70, 94)
            reasons.add(0, "High confluence CALL signal confirmed across ${reasons.size} technical factors")
        } else {
            direction = SignalDirection.PUT
            val rawProb = 65 + ((diff.toDouble() / maxOf(totalScore, 1)) * 35).roundToInt()
            probability = rawProb.coerceIn(70, 94)
            reasons.add(0, "High confluence PUT signal confirmed across ${reasons.size} technical factors")
        }

        return PredictionSignal(
            id = UUID.randomUUID().toString(),
            assetSymbol = assetSymbol,
            direction = direction,
            probability = probability,
            pattern = pattern,
            indicators = indicators,
            strikePrice = currentPrice,
            expirySeconds = 60,
            confluencePoints = reasons,
            timestamp = System.currentTimeMillis(),
            candleTimeRemainingSeconds = candleTimeRemainingSeconds
        )
    }
}
