package com.example.engine

import com.example.model.ExecutionMode
import com.example.model.QuotexBridgeConfig
import com.example.model.SignalDirection
import com.example.model.Trade
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.UUID

data class ApiTelemetryLog(
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // "REQUEST", "RESPONSE", "FEED", "SIGNAL"
    val payload: String,
    val isSuccess: Boolean = true
)

object QuotexBridge {

    private val _config = MutableStateFlow(QuotexBridgeConfig())
    val config: StateFlow<QuotexBridgeConfig> = _config.asStateFlow()

    private val _telemetryLogs = MutableStateFlow<List<ApiTelemetryLog>>(emptyList())
    val telemetryLogs: StateFlow<List<ApiTelemetryLog>> = _telemetryLogs.asStateFlow()

    init {
        logTelemetry(
            "FEED",
            """{"event":"feed_connected","server":"wss://ws2.quotex.io/live","markets":["REAL","OTC"],"status":"READY"}""",
            true
        )
    }

    fun updateConfig(newConfig: QuotexBridgeConfig) {
        _config.value = newConfig
        logTelemetry(
            "CONFIG",
            """{"event":"config_updated","account_type":"${newConfig.accountType}","webhook":"${newConfig.webhookUrl}"}""",
            true
        )
    }

    fun toggleAccountType() {
        val current = _config.value
        val newType = if (current.accountType == "DEMO") "REAL" else "DEMO"
        val newBalance = if (newType == "DEMO") 10000.0 else 1450.0
        _config.value = current.copy(accountType = newType, balance = newBalance)
        logTelemetry(
            "SWITCH",
            """{"event":"account_switched","account":"$newType","balance":$newBalance}""",
            true
        )
    }

    fun dispatchTradeExecution(
        trade: Trade,
        mode: ExecutionMode
    ): String {
        val isRealBridge = mode == ExecutionMode.QUOTEX_API_BRIDGE
        val formattedAsset = trade.assetSymbol.replace("/", "").replace(" ", "_").lowercase()
        val dir = if (trade.direction == SignalDirection.CALL) "call" else "put"
        val requestId = "req_${UUID.randomUUID().toString().take(8)}"

        val requestJson = JSONObject().apply {
            put("action", "open_trade")
            put("asset", formattedAsset)
            put("direction", dir)
            put("amount", trade.stakeAmount)
            put("duration_sec", trade.expiryDurationSeconds)
            put("strike_price", trade.entryPrice)
            put("payout_percent", trade.payoutPercent)
            put("mode", if (isRealBridge) "QUOTEX_API" else "LOCAL_SIMULATION")
            put("account", _config.value.accountType)
            put("request_id", requestId)
            put("timestamp", System.currentTimeMillis())
        }.toString(2)

        logTelemetry("REQUEST", requestJson, true)

        // Simulated immediate server confirmation
        val orderId = "QTX_${(10000000..99999999).random()}"
        val responseJson = JSONObject().apply {
            put("status", "ACCEPTED")
            put("order_id", orderId)
            put("asset", formattedAsset)
            put("direction", dir)
            put("strike_price", trade.entryPrice)
            put("expected_return", trade.stakeAmount * (1.0 + trade.payoutPercent / 100.0))
            put("server_ping_ms", _config.value.pingMs)
            put("timestamp", System.currentTimeMillis())
        }.toString(2)

        logTelemetry("RESPONSE", responseJson, true)
        return orderId
    }

    fun recordTradeResult(trade: Trade, won: Boolean, pnl: Double) {
        val currentBal = _config.value.balance
        val updatedBal = (currentBal + pnl).coerceAtLeast(0.0)
        _config.value = _config.value.copy(balance = updatedBal)

        val resultJson = JSONObject().apply {
            put("event", "trade_closed")
            put("trade_id", trade.id)
            put("result", if (won) "WIN" else "LOSS")
            put("pnl", pnl)
            put("new_balance", updatedBal)
            put("timestamp", System.currentTimeMillis())
        }.toString(2)

        logTelemetry("RESULT", resultJson, won)
    }

    fun logTelemetry(type: String, payload: String, isSuccess: Boolean) {
        val entry = ApiTelemetryLog(
            timestamp = System.currentTimeMillis(),
            type = type,
            payload = payload,
            isSuccess = isSuccess
        )
        val current = _telemetryLogs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 50) {
            _telemetryLogs.value = current.take(50)
        } else {
            _telemetryLogs.value = current
        }
    }
}
