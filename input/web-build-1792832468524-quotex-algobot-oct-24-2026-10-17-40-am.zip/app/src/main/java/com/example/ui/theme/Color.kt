package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Trading Terminal Dark Theme Palette
val TradingDarkBg = Color(0xFF090E17)
val TradingDarkSurface = Color(0xFF111A2E)
val TradingDarkCard = Color(0xFF18233C)
val TradingDarkCardBorder = Color(0xFF233558)

val TradingBullishGreen = Color(0xFF00E676)
val TradingBullishGreenAlpha = Color(0x3300E676)
val TradingBearishRed = Color(0xFFFF3366)
val TradingBearishRedAlpha = Color(0x33FF3366)

val TradingCyanAccent = Color(0xFF00E5FF)
val TradingPurpleAccent = Color(0xFF7C4DFF)
val TradingAmberWarning = Color(0xFFFFB300)

val TradingTextPrimary = Color(0xFFF1F5F9)
val TradingTextSecondary = Color(0xFF94A3B8)
val TradingTextMuted = Color(0xFF64748B)

// Indicator line colors
val IndicatorEmaFast = Color(0xFF00E5FF)
val IndicatorEmaSlow = Color(0xFFFFAB00)
val IndicatorBollinger = Color(0xFF7C4DFF)
val IndicatorBollingerFill = Color(0x1A7C4DFF)
val IndicatorRsi = Color(0xFFE040FB)
val IndicatorMacdLine = Color(0xFF2979FF)
val IndicatorMacdSignal = Color(0xFFFF6D00)
