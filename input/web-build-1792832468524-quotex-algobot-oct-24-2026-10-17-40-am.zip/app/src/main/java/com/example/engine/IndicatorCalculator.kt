package com.example.engine

import com.example.model.Candle
import com.example.model.TechnicalIndicators
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

object IndicatorCalculator {

    fun calculateIndicators(candles: List<Candle>): TechnicalIndicators {
        if (candles.isEmpty()) {
            return TechnicalIndicators(
                rsi = 50.0,
                macdLine = 0.0,
                macdSignal = 0.0,
                macdHist = 0.0,
                upperBB = 0.0,
                middleBB = 0.0,
                lowerBB = 0.0,
                ema9 = 0.0,
                ema21 = 0.0,
                ema50 = 0.0,
                stochK = 50.0,
                stochD = 50.0
            )
        }

        val closes = candles.map { it.close }
        val currentPrice = closes.last()

        val rsi = calculateRSI(closes, 14)
        val (upperBB, midBB, lowerBB) = calculateBollingerBands(closes, 20, 2.0)
        val ema9 = calculateEMA(closes, 9)
        val ema21 = calculateEMA(closes, 21)
        val ema50 = calculateEMA(closes, 50)
        val (macdLine, macdSignal, macdHist) = calculateMACD(closes)
        val (stochK, stochD) = calculateStochastic(candles, 14, 3, 3)

        return TechnicalIndicators(
            rsi = rsi,
            macdLine = macdLine,
            macdSignal = macdSignal,
            macdHist = macdHist,
            upperBB = upperBB.takeIf { it > 0 } ?: (currentPrice * 1.002),
            middleBB = midBB.takeIf { it > 0 } ?: currentPrice,
            lowerBB = lowerBB.takeIf { it > 0 } ?: (currentPrice * 0.998),
            ema9 = ema9.takeIf { it > 0 } ?: currentPrice,
            ema21 = ema21.takeIf { it > 0 } ?: currentPrice,
            ema50 = ema50.takeIf { it > 0 } ?: currentPrice,
            stochK = stochK,
            stochD = stochD
        )
    }

    private fun calculateRSI(closes: List<Double>, period: Int = 14): Double {
        if (closes.size <= period) return 50.0
        val changes = closes.zipWithNext { a, b -> b - a }
        val recentChanges = changes.takeLast(period)

        var gains = 0.0
        var losses = 0.0
        for (c in recentChanges) {
            if (c > 0) gains += c else losses += Math.abs(c)
        }

        val avgGain = gains / period
        val avgLoss = losses / period

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    private fun calculateBollingerBands(
        closes: List<Double>,
        period: Int = 20,
        multiplier: Double = 2.0
    ): Triple<Double, Double, Double> {
        val window = closes.takeLast(period)
        if (window.isEmpty()) return Triple(0.0, 0.0, 0.0)

        val sma = window.average()
        val variance = window.sumOf { (it - sma).pow(2) } / window.size
        val stdDev = sqrt(variance)

        val upper = sma + (multiplier * stdDev)
        val lower = sma - (multiplier * stdDev)
        return Triple(upper, sma, lower)
    }

    fun calculateEMA(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        if (values.size < period) return values.average()

        val multiplier = 2.0 / (period + 1.0)
        var ema = values.take(period).average()

        for (i in period until values.size) {
            ema = (values[i] - ema) * multiplier + ema
        }
        return ema
    }

    fun calculateEMASeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val result = mutableListOf<Double>()
        val multiplier = 2.0 / (period + 1.0)
        var ema = values.first()

        for (i in values.indices) {
            if (i == 0) {
                ema = values[0]
            } else {
                ema = (values[i] - ema) * multiplier + ema
            }
            result.add(ema)
        }
        return result
    }

    private fun calculateMACD(closes: List<Double>): Triple<Double, Double, Double> {
        if (closes.size < 26) return Triple(0.0, 0.0, 0.0)

        val ema12 = calculateEMA(closes, 12)
        val ema26 = calculateEMA(closes, 26)
        val macdLine = ema12 - ema26

        // Calculate series for signal line
        val ema12Series = calculateEMASeries(closes, 12)
        val ema26Series = calculateEMASeries(closes, 26)
        val macdSeries = ema12Series.zip(ema26Series) { e12, e26 -> e12 - e26 }
        val signalLine = calculateEMA(macdSeries, 9)
        val hist = macdLine - signalLine

        return Triple(macdLine, signalLine, hist)
    }

    private fun calculateStochastic(
        candles: List<Candle>,
        periodK: Int = 14,
        smoothK: Int = 3,
        periodD: Int = 3
    ): Pair<Double, Double> {
        if (candles.size < periodK) return Pair(50.0, 50.0)

        val window = candles.takeLast(periodK)
        val highestHigh = window.maxOf { it.high }
        val lowestLow = window.minOf { it.low }
        val currentClose = window.last().close

        val range = max(highestHigh - lowestLow, 0.00001)
        val rawK = ((currentClose - lowestLow) / range) * 100.0

        // In a live environment, smooth %K and %D
        val kClamped = rawK.coerceIn(0.0, 100.0)
        // Approximate smooth D as slightly dampened trailing
        val prevClose = if (candles.size >= 2) candles[candles.size - 2].close else currentClose
        val prevK = (((prevClose - lowestLow) / range) * 100.0).coerceIn(0.0, 100.0)
        val d = ((kClamped * 2.0 + prevK) / 3.0).coerceIn(0.0, 100.0)

        return Pair(kClamped, d)
    }
}
