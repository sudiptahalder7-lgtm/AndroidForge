package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BotSettings
import com.example.model.ExecutionMode
import com.example.model.Trade
import com.example.model.TradeStatus
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingPurpleAccent
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary

@Composable
fun BotConfigScreen(
    settings: BotSettings,
    completedTrades: List<Trade>,
    onSettingsChanged: (BotSettings) -> Unit,
    onToggleAutoTrading: () -> Unit,
    modifier: Modifier = Modifier
) {
    var stake by remember(settings.stakeAmount) { mutableDoubleStateOf(settings.stakeAmount) }
    var useMartingale by remember(settings.useMartingale) { mutableStateOf(settings.useMartingale) }
    var martingaleMultiplier by remember(settings.martingaleMultiplier) { mutableDoubleStateOf(settings.martingaleMultiplier) }
    var maxMartingaleSteps by remember(settings.maxMartingaleSteps) { mutableIntStateOf(settings.maxMartingaleSteps) }
    var minConfidence by remember(settings.minConfidenceThreshold) { mutableFloatStateOf(settings.minConfidenceThreshold.toFloat()) }
    var soundAlerts by remember(settings.soundAlerts) { mutableStateOf(settings.soundAlerts) }
    var executionMode by remember(settings.executionMode) { mutableStateOf(settings.executionMode) }

    fun commitSettings() {
        onSettingsChanged(
            settings.copy(
                stakeAmount = stake,
                useMartingale = useMartingale,
                martingaleMultiplier = martingaleMultiplier,
                maxMartingaleSteps = maxMartingaleSteps,
                minConfidenceThreshold = minConfidence.toInt(),
                soundAlerts = soundAlerts,
                executionMode = executionMode
            )
        )
    }

    // Analytics calculations
    val totalTrades = completedTrades.size
    val wonTrades = completedTrades.count { it.status == TradeStatus.WON }
    val lostTrades = completedTrades.count { it.status == TradeStatus.LOST }
    val winRate = if (totalTrades > 0) ((wonTrades.toDouble() / totalTrades) * 100).toInt() else 0
    val totalPnl = completedTrades.sumOf { it.profitLoss }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TradingDarkBg)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header & Live Toggle
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TradingDarkCard),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (settings.isAutoTrading) TradingBullishGreen.copy(alpha = 0.5f) else TradingDarkCardBorder
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Algorithmic Bot Controller",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = TradingTextPrimary
                            )
                            Text(
                                text = if (settings.isAutoTrading) "STATUS: RUNNING & EXECUTING" else "STATUS: STOPPED / IDLE",
                                fontSize = 11.sp,
                                color = if (settings.isAutoTrading) TradingBullishGreen else TradingAmberWarning,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Button(
                            onClick = onToggleAutoTrading,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (settings.isAutoTrading) TradingBearishRed else TradingBullishGreen,
                                contentColor = if (settings.isAutoTrading) Color.White else Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("bot_toggle_main")
                        ) {
                            Icon(
                                imageVector = if (settings.isAutoTrading) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (settings.isAutoTrading) "STOP" else "START", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. Bot Performance KPI Stats Card
        item {
            Text(
                text = "BOT PERFORMANCE OVERVIEW",
                style = MaterialTheme.typography.labelMedium,
                color = TradingCyanAccent,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Win Rate
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(TradingDarkCard, RoundedCornerShape(12.dp))
                        .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text("WIN RATE", fontSize = 10.sp, color = TradingTextSecondary, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (totalTrades > 0) "$winRate%" else "--%",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = if (winRate >= 70) TradingBullishGreen else TradingTextPrimary
                        )
                        Text("$wonTrades W / $lostTrades L", fontSize = 10.sp, color = TradingTextMuted)
                    }
                }

                // Total PnL
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(TradingDarkCard, RoundedCornerShape(12.dp))
                        .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text("TOTAL PROFIT", fontSize = 10.sp, color = TradingTextSecondary, fontWeight = FontWeight.Bold)
                        Text(
                            text = "${if (totalPnl >= 0) "+$" else "-$"}${"%.2f".format(kotlin.math.abs(totalPnl))}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = if (totalPnl >= 0) TradingBullishGreen else TradingBearishRed
                        )
                        Text("$totalTrades trades closed", fontSize = 10.sp, color = TradingTextMuted)
                    }
                }
            }
        }

        // 3. Execution Mode Selector
        item {
            Text(
                text = "EXECUTION MODE",
                style = MaterialTheme.typography.labelMedium,
                color = TradingCyanAccent,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingDarkCard, RoundedCornerShape(12.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf(
                    ExecutionMode.PAPER_SIMULATION to "Paper Trading (Zero Risk Simulation)",
                    ExecutionMode.QUOTEX_API_BRIDGE to "Quotex API Webhook / Live Bridge"
                ).forEach { (mode, label) ->
                    val isSelected = executionMode == mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) TradingCyanAccent.copy(alpha = 0.15f) else TradingDarkSurface)
                            .border(1.dp, if (isSelected) TradingCyanAccent else TradingDarkCardBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                executionMode = mode
                                commitSettings()
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = label,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TradingCyanAccent else TradingTextPrimary
                            )
                            Text(
                                text = if (mode == ExecutionMode.PAPER_SIMULATION) "Virtual capital, test indicators safely" else "Dispatches real JSON telemetry to Quotex",
                                fontSize = 10.sp,
                                color = TradingTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // 4. Stake & Martingale Strategy Configuration
        item {
            Text(
                text = "STAKE & RECOVERY MANAGEMENT",
                style = MaterialTheme.typography.labelMedium,
                color = TradingCyanAccent,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingDarkCard, RoundedCornerShape(12.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Base Stake
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Base Stake Amount:", fontSize = 13.sp, color = TradingTextPrimary, fontWeight = FontWeight.SemiBold)
                    Text("$$${stake.toInt()}", fontSize = 15.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = TradingCyanAccent)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(5.0, 10.0, 25.0, 50.0, 100.0).forEach { amt ->
                        val isSel = stake == amt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) TradingCyanAccent else TradingDarkSurface)
                                .clickable {
                                    stake = amt
                                    commitSettings()
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$${amt.toInt()}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.Black else TradingTextPrimary
                            )
                        }
                    }
                }

                // Martingale Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Martingale Recovery:", fontSize = 13.sp, color = TradingTextPrimary, fontWeight = FontWeight.SemiBold)
                        Text("Multiply stake on loss to recover drawdowns", fontSize = 10.sp, color = TradingTextSecondary)
                    }
                    Switch(
                        checked = useMartingale,
                        onCheckedChange = {
                            useMartingale = it
                            commitSettings()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TradingCyanAccent,
                            checkedTrackColor = TradingCyanAccent.copy(alpha = 0.3f)
                        )
                    )
                }

                if (useMartingale) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Max Recovery Steps: $maxMartingaleSteps steps (2.0x)", fontSize = 12.sp, color = TradingAmberWarning)
                    }
                }
            }
        }

        // 5. Confluence Filter & Minimum Confidence Slider
        item {
            Text(
                text = "SIGNAL CONFLUENCE FILTER",
                style = MaterialTheme.typography.labelMedium,
                color = TradingCyanAccent,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingDarkCard, RoundedCornerShape(12.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Min Prediction Confidence:", fontSize = 13.sp, color = TradingTextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${minConfidence.toInt()}%",
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = TradingBullishGreen
                    )
                }
                Text(
                    text = "Bot will only execute if technical confluence matches or exceeds this threshold.",
                    fontSize = 11.sp,
                    color = TradingTextSecondary,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Slider(
                    value = minConfidence,
                    onValueChange = {
                        minConfidence = it
                        commitSettings()
                    },
                    valueRange = 65f..90f,
                    steps = 4,
                    colors = SliderDefaults.colors(
                        thumbColor = TradingCyanAccent,
                        activeTrackColor = TradingCyanAccent,
                        inactiveTrackColor = TradingDarkSurface
                    ),
                    modifier = Modifier.testTag("confidence_slider")
                )
            }
        }

        // 6. Risk Disclaimer Box
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingDarkSurface, RoundedCornerShape(10.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = TradingAmberWarning,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Risk Notice: Algorithmic bots assist with technical analysis. Real market and OTC binary trading carries high capital risk. Never trade with funds you cannot afford to lose.",
                    fontSize = 11.sp,
                    color = TradingTextSecondary,
                    lineHeight = 15.sp
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
