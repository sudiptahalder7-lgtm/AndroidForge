package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.IndicatorCalculator
import com.example.model.Candle
import com.example.model.Trade
import com.example.model.TradeStatus
import com.example.ui.theme.IndicatorBollinger
import com.example.ui.theme.IndicatorBollingerFill
import com.example.ui.theme.IndicatorEmaFast
import com.example.ui.theme.IndicatorEmaSlow
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandleChart(
    candles: List<Candle>,
    activeTrades: List<Trade> = emptyList(),
    secondsRemaining: Int,
    decimalPlaces: Int = 5,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier.background(TradingDarkCard, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Loading market data...", color = TradingTextSecondary)
        }
        return
    }

    val textMeasurer = rememberTextMeasurer()
    var horizontalPanOffset by remember { mutableFloatStateOf(0f) }

    val lastCandle = candles.last()
    val formatStr = "%.${decimalPlaces}f"

    Column(
        modifier = modifier
            .background(TradingDarkCard, RoundedCornerShape(12.dp))
            .padding(8.dp)
    ) {
        // Chart Header Stats: O, H, L, C, and 1M Countdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "1M CANDLE",
                    style = MaterialTheme.typography.labelSmall,
                    color = TradingCyanAccent,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "O: ${formatStr.format(lastCandle.open)}",
                    style = TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TradingTextSecondary)
                )
                Text(
                    text = "H: ${formatStr.format(lastCandle.high)}",
                    style = TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TradingBullishGreen)
                )
                Text(
                    text = "L: ${formatStr.format(lastCandle.low)}",
                    style = TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TradingBearishRed)
                )
                Text(
                    text = "C: ${formatStr.format(lastCandle.close)}",
                    style = TextStyle(
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (lastCandle.isBullish) TradingBullishGreen else TradingBearishRed,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            // Countdown Pill
            Row(
                modifier = Modifier
                    .background(
                        if (secondsRemaining <= 10) TradingBearishRed.copy(alpha = 0.2f)
                        else TradingCyanAccent.copy(alpha = 0.15f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = "Timer",
                    tint = if (secondsRemaining <= 10) TradingBearishRed else TradingCyanAccent,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = "${if (secondsRemaining < 10) "0" else ""}${secondsRemaining}s",
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (secondsRemaining <= 10) TradingBearishRed else TradingCyanAccent
                    )
                )
            }
        }

        // Main Drawing Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        horizontalPanOffset = (horizontalPanOffset + dragAmount.x).coerceIn(-300f, 300f)
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Reserve right margin for price scale
                val rightAxisWidth = 72.dp.toPx()
                val chartWidth = canvasWidth - rightAxisWidth
                val volumeHeight = 36.dp.toPx()
                val candleAreaHeight = canvasHeight - volumeHeight

                // Determine visible candles (typically 30-40 candles)
                val visibleCount = 34
                val startIndex = max(0, candles.size - visibleCount)
                val visibleCandles = candles.subList(startIndex, candles.size)
                if (visibleCandles.isEmpty()) return@Canvas

                val minPrice = visibleCandles.minOf { it.low }
                val maxPrice = visibleCandles.maxOf { it.high }
                val pricePadding = max((maxPrice - minPrice) * 0.08, 0.0001)
                val chartMinPrice = minPrice - pricePadding
                val chartMaxPrice = maxPrice + pricePadding
                val priceRange = max(chartMaxPrice - chartMinPrice, 0.0001)

                val candleSlotWidth = chartWidth / visibleCandles.size
                val candleBodyWidth = candleSlotWidth * 0.68f

                // Coordinate helper
                fun priceToY(price: Double): Float {
                    val ratio = (chartMaxPrice - price) / priceRange
                    return (ratio * candleAreaHeight).toFloat().coerceIn(0f, candleAreaHeight)
                }

                // Draw Horizontal Price Grid Lines
                val gridSteps = 4
                for (i in 0..gridSteps) {
                    val gridPrice = chartMinPrice + (priceRange * (i.toDouble() / gridSteps))
                    val y = priceToY(gridPrice)

                    drawLine(
                        color = Color(0xFF1E2D48),
                        start = Offset(0f, y),
                        end = Offset(chartWidth, y),
                        strokeWidth = 1.dp.toPx()
                    )

                    // Draw Price Label on right axis
                    drawText(
                        textMeasurer = textMeasurer,
                        text = formatStr.format(gridPrice),
                        topLeft = Offset(chartWidth + 6.dp.toPx(), y - 7.dp.toPx()),
                        style = TextStyle(
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TradingTextMuted
                        )
                    )
                }

                // Calculate EMA 9 and EMA 21 series for visible candles
                val allCloses = candles.map { it.close }
                val ema9Series = IndicatorCalculator.calculateEMASeries(allCloses, 9)
                val ema21Series = IndicatorCalculator.calculateEMASeries(allCloses, 21)

                // Draw EMA Lines
                val ema9Path = Path()
                val ema21Path = Path()
                var hasEma9Started = false
                var hasEma21Started = false

                for (idx in visibleCandles.indices) {
                    val globalIdx = startIndex + idx
                    val x = (idx * candleSlotWidth) + (candleSlotWidth / 2f)

                    if (globalIdx < ema9Series.size) {
                        val ema9Y = priceToY(ema9Series[globalIdx])
                        if (!hasEma9Started) {
                            ema9Path.moveTo(x, ema9Y)
                            hasEma9Started = true
                        } else {
                            ema9Path.lineTo(x, ema9Y)
                        }
                    }

                    if (globalIdx < ema21Series.size) {
                        val ema21Y = priceToY(ema21Series[globalIdx])
                        if (!hasEma21Started) {
                            ema21Path.moveTo(x, ema21Y)
                            hasEma21Started = true
                        } else {
                            ema21Path.lineTo(x, ema21Y)
                        }
                    }
                }

                drawPath(ema9Path, color = IndicatorEmaFast, style = Stroke(width = 1.5.dp.toPx()))
                drawPath(ema21Path, color = IndicatorEmaSlow, style = Stroke(width = 1.5.dp.toPx()))

                // Draw Candlesticks & Volume
                val maxVolume = max(visibleCandles.maxOf { it.volume }, 1.0)

                for (idx in visibleCandles.indices) {
                    val candle = visibleCandles[idx]
                    val xCenter = (idx * candleSlotWidth) + (candleSlotWidth / 2f)
                    val candleColor = if (candle.isBullish) TradingBullishGreen else TradingBearishRed

                    // High-Low Wick
                    val highY = priceToY(candle.high)
                    val lowY = priceToY(candle.low)
                    drawLine(
                        color = candleColor,
                        start = Offset(xCenter, highY),
                        end = Offset(xCenter, lowY),
                        strokeWidth = 1.5.dp.toPx()
                    )

                    // Candle Body
                    val openY = priceToY(candle.open)
                    val closeY = priceToY(candle.close)
                    val topY = min(openY, closeY)
                    val bodyHeight = max(abs(openY - closeY), 2.dp.toPx())

                    drawRect(
                        color = candleColor,
                        topLeft = Offset(xCenter - (candleBodyWidth / 2f), topY),
                        size = Size(candleBodyWidth, bodyHeight)
                    )

                    // Volume Bar at Bottom
                    val volRatio = (candle.volume / maxVolume).toFloat().coerceIn(0.05f, 1f)
                    val volBarHeight = volRatio * (volumeHeight - 8.dp.toPx())
                    val volY = canvasHeight - volBarHeight

                    drawRect(
                        color = candleColor.copy(alpha = 0.35f),
                        topLeft = Offset(xCenter - (candleBodyWidth / 2f), volY),
                        size = Size(candleBodyWidth, volBarHeight)
                    )
                }

                // Current Live Price Dashed Line & Badge
                val currentY = priceToY(lastCandle.close)
                val currentPriceColor = if (lastCandle.isBullish) TradingBullishGreen else TradingBearishRed

                drawLine(
                    color = currentPriceColor.copy(alpha = 0.8f),
                    start = Offset(0f, currentY),
                    end = Offset(chartWidth, currentY),
                    strokeWidth = 1.2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                )

                // Current Price Badge on Axis
                val badgeWidth = rightAxisWidth - 4.dp.toPx()
                val badgeHeight = 18.dp.toPx()
                val badgeTop = currentY - (badgeHeight / 2f)

                drawRect(
                    color = currentPriceColor,
                    topLeft = Offset(chartWidth + 2.dp.toPx(), badgeTop),
                    size = Size(badgeWidth, badgeHeight)
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = formatStr.format(lastCandle.close),
                    topLeft = Offset(chartWidth + 6.dp.toPx(), badgeTop + 2.dp.toPx()),
                    style = TextStyle(
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                )

                // Draw Active Trades Markers (if any trade active for this asset)
                activeTrades.filter { it.status == TradeStatus.ACTIVE }.forEach { trade ->
                    val strikeY = priceToY(trade.entryPrice)
                    val tradeColor = if (trade.direction.name == "CALL") TradingBullishGreen else TradingBearishRed

                    drawLine(
                        color = tradeColor,
                        start = Offset(0f, strikeY),
                        end = Offset(chartWidth, strikeY),
                        strokeWidth = 1.8.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )

                    drawText(
                        textMeasurer = textMeasurer,
                        text = "${trade.direction.label.take(4)} $${trade.stakeAmount.toInt()} (${trade.remainingSeconds}s)",
                        topLeft = Offset(10.dp.toPx(), strikeY - 14.dp.toPx()),
                        style = TextStyle(
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = tradeColor,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        // Indicator Legend Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp, 3.dp)
                        .background(IndicatorEmaFast, RoundedCornerShape(1.dp))
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("EMA 9", fontSize = 10.sp, color = TradingTextMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp, 3.dp)
                        .background(IndicatorEmaSlow, RoundedCornerShape(1.dp))
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("EMA 21", fontSize = 10.sp, color = TradingTextMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp, 3.dp)
                        .background(TradingBullishGreen, RoundedCornerShape(1.dp))
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Vol", fontSize = 10.sp, color = TradingTextMuted)
            }
        }
    }
}

private fun abs(value: Float): Float = kotlin.math.abs(value)
