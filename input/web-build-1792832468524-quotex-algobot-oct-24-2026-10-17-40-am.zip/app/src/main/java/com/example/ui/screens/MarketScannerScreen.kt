package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Asset
import com.example.model.MarketType
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary

@Composable
fun MarketScannerScreen(
    assets: List<Asset>,
    selectedAsset: Asset,
    onAssetSelected: (Asset) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilterIndex by remember { mutableIntStateOf(0) }
    val filters = listOf("All Markets", "Quotex OTC (24/7)", "Real Forex & Crypto")

    val filteredAssets = when (selectedFilterIndex) {
        1 -> assets.filter { it.marketType == MarketType.OTC }
        2 -> assets.filter { it.marketType == MarketType.REAL }
        else -> assets
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TradingDarkBg)
            .padding(horizontal = 14.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Scanner Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Quotex Market Scanner",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TradingTextPrimary
                )
                Text(
                    text = "Real-time algorithmic scanning across ${assets.size} pairs",
                    fontSize = 11.sp,
                    color = TradingTextSecondary
                )
            }
            Box(
                modifier = Modifier
                    .background(TradingBullishGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.FiberManualRecord,
                        contentDescription = null,
                        tint = TradingBullishGreen,
                        modifier = Modifier.size(8.dp)
                    )
                    Text("LIVE TICK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TradingBullishGreen)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Filter
        TabRow(
            selectedTabIndex = selectedFilterIndex,
            containerColor = TradingDarkSurface,
            contentColor = TradingCyanAccent,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedFilterIndex]),
                    color = TradingCyanAccent
                )
            },
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(10.dp))
        ) {
            filters.forEachIndexed { index, title ->
                Tab(
                    selected = selectedFilterIndex == index,
                    onClick = { selectedFilterIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (selectedFilterIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedFilterIndex == index) TradingCyanAccent else TradingTextSecondary
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Assets List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredAssets) { asset ->
                val isSelected = asset.symbol == selectedAsset.symbol
                MarketAssetCard(
                    asset = asset,
                    isSelected = isSelected,
                    onClick = { onAssetSelected(asset) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun MarketAssetCard(
    asset: Asset,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val formatStr = "%.${asset.decimalPlaces}f"
    val isPositive = asset.change24h >= 0

    // Algorithmic simulated signal indicator for scanner preview
    val signalDirection = when {
        asset.payoutPercentage >= 92 && isPositive -> "CALL ▲ 88%"
        asset.payoutPercentage >= 90 && !isPositive -> "PUT ▼ 84%"
        asset.marketType == MarketType.OTC -> "CALL ▲ 82%"
        else -> "WAIT ━"
    }
    val signalColor = when {
        signalDirection.startsWith("CALL") -> TradingBullishGreen
        signalDirection.startsWith("PUT") -> TradingBearishRed
        else -> TradingAmberWarning
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) TradingCyanAccent.copy(alpha = 0.12f) else TradingDarkCard)
            .border(
                1.dp,
                if (isSelected) TradingCyanAccent else TradingDarkCardBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(12.dp)
            .testTag("market_item_${asset.symbol}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = asset.symbol,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TradingTextPrimary
                )
                if (asset.marketType == MarketType.OTC) {
                    Box(
                        modifier = Modifier
                            .background(TradingCyanAccent.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text("OTC", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TradingCyanAccent)
                    }
                }
            }
            Text(
                text = asset.name,
                fontSize = 11.sp,
                color = TradingTextSecondary
            )

            Spacer(modifier = Modifier.height(4.dp))
            // Signal pill
            Box(
                modifier = Modifier
                    .background(signalColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Algo: $signalDirection",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = signalColor,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = formatStr.format(asset.currentPrice),
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = TradingTextPrimary
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isPositive) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    contentDescription = null,
                    tint = if (isPositive) TradingBullishGreen else TradingBearishRed,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "${if (isPositive) "+" else ""}${asset.change24h}%",
                    fontSize = 11.sp,
                    color = if (isPositive) TradingBullishGreen else TradingBearishRed,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .background(TradingBullishGreen.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Payout ${asset.payoutPercentage}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TradingBullishGreen
                )
            }
        }
    }
}
