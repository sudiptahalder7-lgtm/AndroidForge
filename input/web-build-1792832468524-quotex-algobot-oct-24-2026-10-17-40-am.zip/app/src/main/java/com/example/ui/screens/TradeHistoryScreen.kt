package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SignalDirection
import com.example.model.Trade
import com.example.model.TradeStatus
import com.example.ui.theme.TradingAmberWarning
import com.example.ui.theme.TradingBearishRed
import com.example.ui.theme.TradingBullishGreen
import com.example.ui.theme.TradingCyanAccent
import com.example.ui.theme.TradingDarkBg
import com.example.ui.theme.TradingDarkCard
import com.example.ui.theme.TradingDarkCardBorder
import com.example.ui.theme.TradingDarkSurface
import com.example.ui.theme.TradingTextMuted
import com.example.ui.theme.TradingTextPrimary
import com.example.ui.theme.TradingTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TradeHistoryScreen(
    trades: List<Trade>,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("ALL") }

    val filtered = when (selectedFilter) {
        "WON" -> trades.filter { it.status == TradeStatus.WON }
        "LOST" -> trades.filter { it.status == TradeStatus.LOST }
        else -> trades
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TradingDarkBg)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Trade Execution Log",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TradingTextPrimary
                    )
                    Text(
                        text = "Real-time records of bot & manual trades",
                        fontSize = 11.sp,
                        color = TradingTextSecondary
                    )
                }

                // Total Trades Pill
                Box(
                    modifier = Modifier
                        .background(TradingDarkCard, RoundedCornerShape(8.dp))
                        .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${trades.size} TRADES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = TradingCyanAccent
                    )
                }
            }
        }

        // 2. Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "WON", "LOST").forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TradingCyanAccent,
                            selectedLabelColor = androidx.compose.ui.graphics.Color.Black,
                            containerColor = TradingDarkCard,
                            labelColor = TradingTextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedFilter == filter,
                            borderColor = TradingDarkCardBorder,
                            selectedBorderColor = TradingCyanAccent
                        )
                    )
                }
            }
        }

        // 3. Trade History Items
        if (filtered.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(TradingDarkCard, RoundedCornerShape(12.dp))
                        .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = TradingTextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("No trades matching current filter", color = TradingTextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(filtered) { trade ->
                CompletedTradeCard(trade = trade)
            }
        }

        // 4. Educational Candlestick Strategy Primer
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TradingDarkCard, RoundedCornerShape(12.dp))
                    .border(1.dp, TradingDarkCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.Book, contentDescription = null, tint = TradingCyanAccent, modifier = Modifier.size(16.dp))
                    Text("1-Minute Algorithmic Strategy Reference", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TradingTextPrimary)
                }

                Text(
                    text = "• Bullish Engulfing: Large green candle fully absorbing previous red candle body. High win rate on Lower Bollinger Band rebounds.\n" +
                            "• Hammer: Long lower rejection shadow (>1.8x body) indicating buying support at local support levels.\n" +
                            "• Morning Star: 3-candle institutional bottom reversal pattern with >85% confluence.\n" +
                            "• Risk Rule: Never risk more than 1% to 2% of total capital on any single 1-minute expiration.",
                    fontSize = 11.sp,
                    color = TradingTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun CompletedTradeCard(trade: Trade) {
    val isWin = trade.status == TradeStatus.WON
    val resultColor = if (isWin) TradingBullishGreen else TradingBearishRed
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TradingDarkCard)
            .border(1.dp, resultColor.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            .padding(12.dp)
            .testTag("trade_card_${trade.id}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(resultColor.copy(alpha = 0.18f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isWin) Icons.Default.CheckCircle else Icons.Default.Close,
                    contentDescription = null,
                    tint = resultColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(trade.assetSymbol, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TradingTextPrimary)
                    Text(
                        text = trade.direction.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (trade.direction == SignalDirection.CALL) TradingBullishGreen else TradingBearishRed
                    )
                }
                Text(
                    text = "Entry: ${trade.entryPrice}  ➔  Exit: ${trade.exitPrice ?: "--"}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TradingTextSecondary
                )
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${if (isWin) "+$" else "-$"}${"%.2f".format(kotlin.math.abs(trade.profitLoss))}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = resultColor
            )
            Text(
                text = timeFormat.format(Date(trade.openTime)),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TradingTextMuted
            )
        }
    }
}
