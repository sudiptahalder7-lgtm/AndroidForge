# QX Vision Pro AI Proguard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-keep class com.qxvision.pro.model.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
