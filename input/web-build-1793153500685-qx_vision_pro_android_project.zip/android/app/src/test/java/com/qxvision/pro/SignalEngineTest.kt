package com.qxvision.pro

import com.qxvision.pro.engine.SignalEngine
import com.qxvision.pro.engine.TechnicalIndicators
import com.qxvision.pro.model.AssetVariant
import com.qxvision.pro.model.Candle
import com.qxvision.pro.model.SignalDirection
import org.junit.Assert.*
import org.junit.Test

class SignalEngineTest {

    @Test
    fun testRsiCalculationBounds() {
        val flatCloses = List(20) { 100.0 }
        val rsiFlat = TechnicalIndicators.calculateRSI(flatCloses)
        assertEquals(50.0, rsiFlat, 0.01)

        val uptrend = List(25) { 1.2000 + it * 0.001 }
        val rsiUp = TechnicalIndicators.calculateRSI(uptrend)
        assertTrue(rsiUp > 80.0)
    }

    @Test
    fun testSignalEngineEnforcesNoTradeOnStaleOrClosed() {
        // Case 1: Closed market
        val closedRes = SignalEngine.evaluate(
            pairId = "GBPUSD",
            symbol = "GBP/USD",
            variant = AssetVariant.REAL,
            candles = emptyList(),
            isStale = false,
            isOpen = false,
            currentPrice = 1.2980
        )
        assertEquals(SignalDirection.NO_TRADE, closedRes.direction1Min)

        // Case 2: Stale data
        val staleRes = SignalEngine.evaluate(
            pairId = "GBPUSD",
            symbol = "GBP/USD",
            variant = AssetVariant.REAL,
            candles = emptyList(),
            isStale = true,
            isOpen = true,
            currentPrice = 1.2980
        )
        assertEquals(SignalDirection.NO_TRADE, staleRes.direction1Min)
    }

    @Test
    fun testSignalEngineSufficientCandlesRequired() {
        val shortCandles = List(15) {
            Candle(time = 1000L + it * 60, open = 1.0, close = 1.01, high = 1.02, low = 0.99)
        }
        val res = SignalEngine.evaluate(
            pairId = "USDJPY_otc",
            symbol = "USD/JPY (OTC)",
            variant = AssetVariant.OTC,
            candles = shortCandles,
            isStale = false,
            isOpen = true,
            currentPrice = 153.40
        )
        assertEquals(SignalDirection.NO_TRADE, res.direction1Min)
        assertTrue(res.reasons.first().contains("insufficient", ignoreCase = true))
    }
}
