package com.qxvision.pro.data

import com.qxvision.pro.model.Candle
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Native Android OkHttp WebSocket Client for Quotex Engine.IO protocol.
 * Replaces Python/Selenium desktop dependencies with pure native Android networking.
 */
class QuotexWebSocketClient(
    private val ssid: String? = null,
    private val onMessageCallback: (String) -> Unit,
    private val onCandleCallback: (String, List<Candle>) -> Unit,
    private val onStatusChange: (Boolean, String) -> Unit
) {

    private val client = OkHttpClient.Builder()
        .readTimeout(10, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var isConnected = false

    fun connect() {
        val request = Request.Builder()
            .url("wss://ws2.qxbroker.com/socket.io/?EIO=3&transport=websocket")
            .addHeader("Origin", "https://qxbroker.com")
            .addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                isConnected = true
                onStatusChange(true, "Connected to Quotex WebSocket")
                // Handshake Engine.IO probe and tick
                ws.send("2probe")
                ws.send("42[\"tick\"]")

                // If SSID session exists, authenticate
                if (!ssid.isNullOrEmpty()) {
                    val authPayload = JSONObject().apply {
                        put("session", ssid)
                        put("isDemo", 1)
                        put("tournamentId", 0)
                    }
                    ws.send("42[\"authorization\",$authPayload]")
                }
            }

            override fun onMessage(ws: WebSocket, text: String) {
                onMessageCallback(text)

                // Handle Engine.IO Ping (server sends '2', client replies with '3')
                if (text == "2") {
                    ws.send("3")
                    return
                }

                // Handle Candle Data: 42["history/load", ...] or 451-["history/list/v2", ...]
                if (text.contains("history") && text.contains("candles")) {
                    parseCandlesFromMessage(text)
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                isConnected = false
                onStatusChange(false, "Connection error: ${t.localizedMessage}")
            }

            override fun onClosing(ws: WebSocket, code: Int, reason: String) {
                isConnected = false
                onStatusChange(false, "Connection closed ($code): $reason")
            }
        })
    }

    fun requestCandles(asset: String, periodSeconds: Int = 60, offset: Int = 3600) {
        val now = System.currentTimeMillis() / 1000
        val payload = JSONObject().apply {
            put("asset", asset)
            put("index", now)
            put("offset", offset)
            put("period", periodSeconds)
            put("time", now)
        }
        webSocket?.send("42[\"history/load\",$payload]")
    }

    fun subscribeRealtimeTicks(asset: String) {
        webSocket?.send("42[\"depth/follow\",\"$asset\"]")
        val payload = JSONObject().apply {
            put("asset", asset)
            put("period", 60)
        }
        webSocket?.send("42[\"instruments/update\",$payload]")
    }

    private fun parseCandlesFromMessage(text: String) {
        try {
            val jsonStartIndex = text.indexOf('{')
            if (jsonStartIndex != -1) {
                val jsonStr = text.substring(jsonStartIndex, text.lastIndexOf('}') + 1)
                val obj = JSONObject(jsonStr)
                val asset = obj.optString("asset", "UNKNOWN")
                val candlesArray = obj.optJSONArray("candles") ?: return

                val candleList = mutableListOf<Candle>()
                for (i in 0 until candlesArray.length()) {
                    val c = candlesArray.getJSONArray(i)
                    candleList.add(
                        Candle(
                            time = c.getLong(0),
                            open = c.getDouble(1),
                            close = c.getDouble(2),
                            high = c.getDouble(3),
                            low = c.getDouble(4)
                        )
                    )
                }
                onCandleCallback(asset, candleList)
            }
        } catch (_: Exception) {
            // Safe JSON parse fallback
        }
    }

    fun disconnect() {
        webSocket?.close(1000, "Client initiated disconnect")
        isConnected = false
    }
}
