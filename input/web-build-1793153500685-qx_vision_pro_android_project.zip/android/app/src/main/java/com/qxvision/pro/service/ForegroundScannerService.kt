package com.qxvision.pro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.qxvision.pro.MainActivity
import kotlinx.coroutines.*

/**
 * Android Foreground Service managing persistent background market scanning.
 * Provides Start, Pause, Resume, and Stop controls with ongoing status notification.
 */
class ForegroundScannerService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var isScanning = false
    private var isPaused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startScanning()
            ACTION_PAUSE -> pauseScanning()
            ACTION_RESUME -> resumeScanning()
            ACTION_STOP -> stopScanning()
        }
        return START_STICKY
    }

    private fun startScanning() {
        isScanning = true
        isPaused = false
        val notification = buildNotification("Radar Scanning Active", "Monitoring 20 REAL/OTC pairs at 1-sec intervals")
        startForeground(NOTIFICATION_ID, notification)

        serviceScope.launch {
            while (isScanning) {
                if (!isPaused) {
                    // Execute 1-second countdown cycle & 7s pre-close inference
                }
                delay(1000)
            }
        }
    }

    private fun pauseScanning() {
        isPaused = true
        updateNotification("Scanning Paused", "Tap Resume in app or overlay to continue")
    }

    private fun resumeScanning() {
        isPaused = false
        updateNotification("Radar Scanning Active", "Monitoring 20 REAL/OTC pairs at 1-sec intervals")
    }

    private fun stopScanning() {
        isScanning = false
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(title: String, content: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("QX Vision Pro: $title")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(title: String, content: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Market Scanner Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live Quotex market scanning status"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        const val NOTIFICATION_ID = 2001
        const val CHANNEL_ID = "qx_scanner_channel"

        const val ACTION_START = "com.qxvision.pro.ACTION_START"
        const val ACTION_PAUSE = "com.qxvision.pro.ACTION_PAUSE"
        const val ACTION_RESUME = "com.qxvision.pro.ACTION_RESUME"
        const val ACTION_STOP = "com.qxvision.pro.ACTION_STOP"
    }
}
