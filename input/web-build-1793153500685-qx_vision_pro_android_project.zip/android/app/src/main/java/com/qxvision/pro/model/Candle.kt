package com.qxvision.pro.model

data class Candle(
    val time: Long,
    val open: Double,
    val close: Double,
    val high: Double,
    val low: Double,
    val volume: Int = 1
)

enum class AssetVariant {
    REAL,
    OTC
}

data class MarketPair(
    val id: String,
    val symbol: String,
    val variant: AssetVariant,
    val quotexCode: Int,
    val open: Boolean,
    val payoutPercent: Int,
    val currentPrice: Double,
    val spread: Double
)

enum class SignalDirection {
    UP,
    DOWN,
    NO_TRADE
}

data class SignalResult(
    val id: String,
    val pairId: String,
    val symbol: String,
    val variant: AssetVariant,
    val timestamp: Long,
    val targetCandleTime: Long,
    val direction1Min: SignalDirection,
    val direction2Min: SignalDirection,
    val confidence: Int,
    val entryPrice: Double,
    val reasons: List<String>
)
