package com.qxvision.pro.engine

import com.qxvision.pro.model.AssetVariant
import com.qxvision.pro.model.Candle
import com.qxvision.pro.model.SignalDirection
import com.qxvision.pro.model.SignalResult

object SignalEngine {

    /**
     * Evaluates next 1-minute and 2-minute candle direction.
     * Enforces strict NO TRADE for stale data, low volatility, or conflicting indicators.
     */
    fun evaluate(
        pairId: String,
        symbol: String,
        variant: AssetVariant,
        candles: List<Candle>,
        isStale: Boolean,
        isOpen: Boolean,
        currentPrice: Double
    ): SignalResult {
        val nowMs = System.currentTimeMillis()
        val targetCandleTime = (nowMs / 1000) + 60

        // Rule 10: NO TRADE on closed market or stale data
        if (!isOpen) {
            return SignalResult(
                id = "SIG-$nowMs",
                pairId = pairId,
                symbol = symbol,
                variant = variant,
                timestamp = nowMs,
                targetCandleTime = targetCandleTime,
                direction1Min = SignalDirection.NO_TRADE,
                direction2Min = SignalDirection.NO_TRADE,
                confidence = 0,
                entryPrice = currentPrice,
                reasons = listOf("Market is closed on broker.")
            )
        }

        if (isStale || candles.size < 30) {
            return SignalResult(
                id = "SIG-$nowMs",
                pairId = pairId,
                symbol = symbol,
                variant = variant,
                timestamp = nowMs,
                targetCandleTime = targetCandleTime,
                direction1Min = SignalDirection.NO_TRADE,
                direction2Min = SignalDirection.NO_TRADE,
                confidence = 0,
                entryPrice = currentPrice,
                reasons = listOf("Stale or insufficient candle history (<30 bars).")
            )
        }

        val closes = candles.map { it.close }
        val rsi = TechnicalIndicators.calculateRSI(closes, 14)
        val ema9 = TechnicalIndicators.calculateEMA(closes, 9).lastOrNull() ?: currentPrice
        val ema21 = TechnicalIndicators.calculateEMA(closes, 21).lastOrNull() ?: currentPrice
        val ema50 = TechnicalIndicators.calculateEMA(closes, 50).lastOrNull() ?: currentPrice
        val (bbUpper, _, bbLower) = TechnicalIndicators.calculateBollingerBands(closes)
        val atr = TechnicalIndicators.calculateATR(candles)

        var bullishScore = 0.0
        var bearishScore = 0.0
        val reasons = mutableListOf<String>()

        // 1. Triple EMA Stack
        if (ema9 > ema21 && ema21 > ema50) {
            bullishScore += 2.0
            reasons.add("EMA Stack bullish (9 > 21 > 50)")
        } else if (ema9 < ema21 && ema21 < ema50) {
            bearishScore += 2.0
            reasons.add("EMA Stack bearish (9 < 21 < 50)")
        }

        // 2. RSI Oversold/Overbought
        if (rsi < 30) {
            bullishScore += 1.8
            reasons.add("RSI oversold (${rsi.toInt()})")
        } else if (rsi > 70) {
            bearishScore += 1.8
            reasons.add("RSI overbought (${rsi.toInt()})")
        }

        // 3. Bollinger Band touch
        if (currentPrice <= bbLower) {
            bullishScore += 1.5
            reasons.add("Lower Bollinger Band breakout")
        } else if (currentPrice >= bbUpper) {
            bearishScore += 1.5
            reasons.add("Upper Bollinger Band breakout")
        }

        // 4. Volatility check (Rule 10: Doji / flat candle avoidance)
        if (atr < 0.00005) {
            return SignalResult(
                id = "SIG-$nowMs",
                pairId = pairId,
                symbol = symbol,
                variant = variant,
                timestamp = nowMs,
                targetCandleTime = targetCandleTime,
                direction1Min = SignalDirection.NO_TRADE,
                direction2Min = SignalDirection.NO_TRADE,
                confidence = 30,
                entryPrice = currentPrice,
                reasons = listOf("Flat volatility / chop detected. High risk.")
            )
        }

        val dominant = max(bullishScore, bearishScore)
        val diff = abs(bullishScore - bearishScore)
        val confidence = min(88, max(45, ((dominant / 5.3) * 65 + (diff / 5.3) * 35).toInt()))

        if (confidence < 65) {
            return SignalResult(
                id = "SIG-$nowMs",
                pairId = pairId,
                symbol = symbol,
                variant = variant,
                timestamp = nowMs,
                targetCandleTime = targetCandleTime,
                direction1Min = SignalDirection.NO_TRADE,
                direction2Min = SignalDirection.NO_TRADE,
                confidence = confidence,
                entryPrice = currentPrice,
                reasons = listOf("Confidence ($confidence%) below required 65% threshold.")
            )
        }

        val dir1M = if (bullishScore > bearishScore) SignalDirection.UP else SignalDirection.DOWN
        val dir2M = if (dir1M == SignalDirection.UP && ema21 > ema50) SignalDirection.UP else if (dir1M == SignalDirection.DOWN && ema21 < ema50) SignalDirection.DOWN else SignalDirection.NO_TRADE

        return SignalResult(
            id = "SIG-$nowMs",
            pairId = pairId,
            symbol = symbol,
            variant = variant,
            timestamp = nowMs,
            targetCandleTime = targetCandleTime,
            direction1Min = dir1M,
            direction2Min = dir2M,
            confidence = confidence,
            entryPrice = currentPrice,
            reasons = reasons
        )
    }
}
