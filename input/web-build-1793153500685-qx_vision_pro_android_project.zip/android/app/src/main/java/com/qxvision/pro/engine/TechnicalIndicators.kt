package com.qxvision.pro.engine

import com.qxvision.pro.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object TechnicalIndicators {

    fun calculateEMA(data: List<Double>, period: Int): List<Double> {
        if (data.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val result = mutableListOf<Double>()
        var currentEma = data.take(min(period, data.size)).average()

        for (i in data.indices) {
            if (i < period) {
                result.add(data[i])
            } else {
                currentEma = data[i] * k + currentEma * (1 - k)
                result.add(currentEma)
            }
        }
        return result
    }

    fun calculateRSI(closes: List<Double>, period: Int = 14): Double {
        if (closes.size <= period) return 50.0

        var gains = 0.0
        var losses = 0.0
        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) gains += diff else losses += abs(diff)
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until closes.size) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) {
                avgGain = (avgGain * (period - 1) + diff) / period
                avgLoss = (avgLoss * (period - 1)) / period
            } else {
                avgGain = (avgGain * (period - 1)) / period
                avgLoss = (avgLoss * (period - 1) + abs(diff)) / period
            }
        }

        if (avgGain == 0.0 && avgLoss == 0.0) return 50.0
        if (avgLoss == 0.0) return 100.0
        if (avgGain == 0.0) return 0.0

        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun calculateBollingerBands(closes: List<Double>, period: Int = 20, multiplier: Double = 2.0): Triple<Double, Double, Double> {
        if (closes.size < period) {
            val last = closes.lastOrNull() ?: 1.0
            return Triple(last * 1.002, last, last * 0.998)
        }
        val slice = closes.takeLast(period)
        val middle = slice.average()
        val variance = slice.sumOf { (it - middle) * (it - middle) } / period
        val stdDev = sqrt(variance)
        val upper = middle + multiplier * stdDev
        val lower = middle - multiplier * stdDev
        return Triple(upper, middle, lower)
    }

    fun calculateATR(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size < 2) return 0.0005
        val trList = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val c = candles[i]
            val p = candles[i - 1]
            val tr = max(c.high - c.low, max(abs(c.high - p.close), abs(c.low - p.close)))
            trList.add(tr)
        }
        return trList.takeLast(period).average()
    }
}
