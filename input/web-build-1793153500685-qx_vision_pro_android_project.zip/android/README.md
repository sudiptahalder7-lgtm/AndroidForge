# QX Vision Pro AI — Complete Android Application

Native Android Studio application for Quotex market analysis, featuring real-time 1M & 2M candlestick prediction, a system-wide draggable floating popup overlay, and background scanning via Android Foreground Services.

---

## 1. Verified QuotexPy API Audit Findings
- **Reverse-Engineered Engine.IO Protocol:** Quotex has no official public REST API. The uploaded `quotexpy` library communicates with `wss://ws2.qxbroker.com/socket.io/?EIO=3&transport=websocket`.
- **Android Incompatibility:** The original Python script relies on `undetected-chromedriver` (Selenium + Google Chrome desktop binary), which **cannot run** on the Android ART runtime.
- **Native Android Resolution:** This Android project replaces the Python dependency with high-performance native **OkHttp WebSockets** and an optional in-app secure `WebView` session token bridge.

---

## 2. Core Architecture & Features
1. **20 REAL & OTC Forex Pairs:**
   - Real: `GBP/USD`, `USD/JPY`, `USD/CHF`, `AUD/USD`, `USD/CAD`, `NZD/USD`, `EUR/GBP`, `EUR/JPY`, `EUR/AUD`, `GBP/JPY`
   - OTC: Corresponding 24/7 OTC synthetic broker feeds.
2. **Foreground Scanner Service:**
   - Persistent `NotificationCompat` with Start, Pause, Resume, and Stop controls.
   - Background execution prevents Android OS battery-saver killing.
3. **Draggable Floating WindowManager Overlay:**
   - Uses `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY`.
   - Smooth touch drag gestures with coordinates tracking and boundary limits.
   - Circular collapsed bubble & expandable HUD with countdown and signals.
4. **Final 7s & 1s Decision Engine:**
   - Initiates deep feature calculation at `T - 7s` of the 1-minute candle.
   - Emits finalized `UP`, `DOWN`, or `NO TRADE` signal at `T - 1s`.
5. **Strict Anti-Fabrication NO TRADE Logic:**
   - Stale data (>2s delay) triggers instant `NO TRADE`.
   - Missing candles (<30 history bars) triggers instant `NO TRADE`.
   - Conflicting indicators or flat volatility (Doji risk) triggers `NO TRADE`.
6. **Optional Screen Observation:**
   - Clear user consent dialog via Android `MediaProjectionManager`.

---

## 3. How to Build the APK in Android Studio

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or Ladybug (2024.2.1+)
- Android SDK 35 (Android 15) & SDK Build-Tools 35.0.0
- JDK 17 (Eclipse Temurin 17 or JetBrains Runtime 17)

### Build Steps
1. **Open Project:**
   Open the `android/` directory in Android Studio.
2. **Sync Gradle:**
   Allow Android Studio to download dependencies (OkHttp, Jetpack Compose, Coroutines).
3. **Run Unit Tests:**
   ```bash
   ./gradlew testDebugUnitTest
   ```
4. **Assemble Debug APK:**
   ```bash
   ./gradlew assembleDebug
   ```
   The APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

5. **Install on Device via ADB:**
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

### Permissions Setup on Device
- On first launch, tap **"Launch System Floating Overlay"** to grant `android.permission.SYSTEM_ALERT_WINDOW` in Android System Settings.
- For background notifications, allow `POST_NOTIFICATIONS` on Android 13+.
