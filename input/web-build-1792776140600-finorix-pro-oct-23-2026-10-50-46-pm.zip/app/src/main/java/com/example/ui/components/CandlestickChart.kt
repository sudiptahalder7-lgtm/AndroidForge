package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.Technicals
import com.example.model.Candle
import com.example.model.MarketPair
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    pair: MarketPair,
    candles: List<Candle>,
    technicals: Technicals,
    countdownSeconds: Int,
    modifier: Modifier = Modifier
) {
    var visibleCandleCount by remember { mutableStateOf(35) }
    var showEMA by remember { mutableStateOf(true) }

    val countdownFormatted = String.format(Locale.US, "%02d:%02d", countdownSeconds / 60, countdownSeconds % 60)
    val displayCandles = candles.takeLast(visibleCandleCount)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(16.dp))
            .padding(top = 10.dp, bottom = 8.dp)
            .testTag("candlestick_chart_container")
    ) {
        // Chart Header / Legend
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Technical indicators chips
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { showEMA = !showEMA }
                        .background(TerminalSurfaceVariant)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(ElectricCyan, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "EMA 9: ${formatPrice(technicals.ema9, pair.decimalPlaces)}",
                        color = ElectricCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(AmberGold, RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "RSI: ${technicals.rsi}",
                        color = if (technicals.rsi > 70) NeonRed else if (technicals.rsi < 30) NeonGreen else AmberGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Candle count toggles
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(25, 35, 50).forEach { count ->
                    Text(
                        text = "${count}C",
                        color = if (visibleCandleCount == count) ElectricCyan else TextDarkGray,
                        fontSize = 10.sp,
                        fontWeight = if (visibleCandleCount == count) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (visibleCandleCount == count) ElectricCyan.copy(alpha = 0.15f) else Color.Transparent)
                            .clickable { visibleCandleCount = count }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Main Chart Canvas with candles, grid, wicks, current price dashed line, and cyan badge
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .padding(horizontal = 8.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("chart_canvas")
            ) {
                if (displayCandles.isEmpty()) return@Canvas

                val chartWidth = size.width - 70.dp.toPx() // leave right margin for price scale
                val chartHeight = size.height

                // Compute min and max prices
                var minPrice = displayCandles.minOf { it.low }
                var maxPrice = displayCandles.maxOf { it.high }

                // Add margin padding to price range
                val priceRange = (maxPrice - minPrice).coerceAtLeast(pair.baseVolatility * 2)
                minPrice -= priceRange * 0.08
                maxPrice += priceRange * 0.08
                val effectiveRange = maxPrice - minPrice

                fun getY(price: Double): Float {
                    val normalized = (maxPrice - price) / effectiveRange
                    return (normalized * chartHeight).toFloat().coerceIn(0f, chartHeight)
                }

                // Draw Horizontal Grid Lines & Price Labels
                val gridStepCount = 5
                val gridPaint = android.graphics.Paint().apply {
                    color = android.graphics.Color.argb(140, 148, 163, 184)
                    textSize = 9.sp.toPx()
                    isAntiAlias = true
                    typeface = android.graphics.Typeface.MONOSPACE
                }

                for (i in 0..gridStepCount) {
                    val p = maxPrice - (i * (effectiveRange / gridStepCount))
                    val y = getY(p)

                    // Subtle horizontal grid line
                    drawLine(
                        color = Color(0x1A94A3B8),
                        start = Offset(0f, y),
                        end = Offset(chartWidth, y),
                        strokeWidth = 1f
                    )

                    // Y-axis price label on the right
                    drawContext.canvas.nativeCanvas.drawText(
                        formatPrice(p, pair.decimalPlaces),
                        chartWidth + 8.dp.toPx(),
                        y + 4.dp.toPx(),
                        gridPaint
                    )
                }

                // Candle widths and spacing
                val candleCount = displayCandles.size
                val slotWidth = chartWidth / candleCount
                val candleBodyWidth = (slotWidth * 0.68f).coerceAtLeast(3f)

                // EMA Line Path
                val emaPath = Path()
                var emaStarted = false
                val kEma = 2.0 / (9.0 + 1.0)
                var currentEma = displayCandles.first().close

                // Draw Candlesticks
                displayCandles.forEachIndexed { index, candle ->
                    val xCenter = (index * slotWidth) + (slotWidth / 2f)

                    val openY = getY(candle.open)
                    val closeY = getY(candle.close)
                    val highY = getY(candle.high)
                    val lowY = getY(candle.low)

                    val isBull = candle.isBullish
                    val candleColor = if (isBull) NeonGreen else NeonRed

                    // Draw Wick line
                    drawLine(
                        color = candleColor,
                        start = Offset(xCenter, highY),
                        end = Offset(xCenter, lowY),
                        strokeWidth = 1.8f
                    )

                    // Draw Candle Body
                    val bodyTop = min(openY, closeY)
                    val bodyBottom = max(openY, closeY)
                    val bodyHeight = (bodyBottom - bodyTop).coerceAtLeast(2f)

                    drawRect(
                        color = candleColor,
                        topLeft = Offset(xCenter - (candleBodyWidth / 2f), bodyTop),
                        size = Size(candleBodyWidth, bodyHeight)
                    )

                    // Update EMA path
                    currentEma = (candle.close * kEma) + (currentEma * (1 - kEma))
                    val emaY = getY(currentEma)
                    if (!emaStarted) {
                        emaPath.moveTo(xCenter, emaY)
                        emaStarted = true
                    } else {
                        emaPath.lineTo(xCenter, emaY)
                    }
                }

                // Draw EMA Line if enabled
                if (showEMA && emaStarted) {
                    drawPath(
                        path = emaPath,
                        color = ElectricCyan.copy(alpha = 0.85f),
                        style = Stroke(width = 2.2f)
                    )
                }

                // Draw Expiry Threshold Vertical Line (White dashed line as in screenshot!)
                val lastCandleX = ((candleCount - 1) * slotWidth) + (slotWidth / 2f)
                val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)

                drawLine(
                    color = Color.White.copy(alpha = 0.7f),
                    start = Offset(lastCandleX, 0f),
                    end = Offset(lastCandleX, chartHeight),
                    strokeWidth = 1.5f,
                    pathEffect = dashedEffect
                )

                // Current Price Horizontal Line (Dashed)
                val currentPrice = pair.currentPrice
                val currentPriceY = getY(currentPrice)

                drawLine(
                    color = Color.White.copy(alpha = 0.8f),
                    start = Offset(0f, currentPriceY),
                    end = Offset(chartWidth, currentPriceY),
                    strokeWidth = 1.5f,
                    pathEffect = dashedEffect
                )
            }

            // Overlay Badge for Current Price & Expiry Countdown (Matches screenshot cyan pill badge!)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 6.dp, end = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalSurfaceVariant)
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    // Countdown timer
                    Text(
                        text = countdownFormatted,
                        color = TextWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )

                    // Cyan Price Pill (Identical to screenshot!)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(ElectricCyan)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = formatPrice(pair.currentPrice, pair.decimalPlaces),
                            color = Color(0xFF090D14),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

private fun formatPrice(price: Double, decimals: Int): String {
    return String.format(Locale.US, "%.${decimals}f", price)
}
