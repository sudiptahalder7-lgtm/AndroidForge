package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OrderStatus
import com.example.model.SignalDirection
import com.example.model.TradeOrder
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeHistoryBottomSheet(
    activeOrders: List<TradeOrder>,
    tradeHistory: List<TradeOrder>,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    val totalCompleted = tradeHistory.size
    val wonCount = tradeHistory.count { it.status == OrderStatus.WON }
    val winRate = if (totalCompleted > 0) ((wonCount.toDouble() / totalCompleted) * 100).toInt() else 0
    val netProfit = tradeHistory.sumOf { it.profitOrLoss }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = TerminalSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 18.dp)
                .testTag("trade_history_bottom_sheet")
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.History, contentDescription = null, tint = ElectricCyan)
                    Column {
                        Text(
                            text = "TRADE AUDIT & HISTORY",
                            color = TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Quotex live execution records",
                            color = TextDarkGray,
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextGray)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Stats summary card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TerminalCard)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "TOTAL TRADES", color = TextDarkGray, fontSize = 10.sp)
                    Text(text = "$totalCompleted", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text(text = "WIN RATE", color = TextDarkGray, fontSize = 10.sp)
                    Text(
                        text = "$winRate%",
                        color = if (winRate >= 50) NeonGreen else NeonRed,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "NET PROFIT", color = TextDarkGray, fontSize = 10.sp)
                    Text(
                        text = "${if (netProfit >= 0) "+" else ""}$${String.format(Locale.US, "%.2f", netProfit)}",
                        color = if (netProfit >= 0) NeonGreen else NeonRed,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // List of Orders
            val allOrders = activeOrders + tradeHistory
            if (allOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "No trades executed yet.\nUse CALL/PUT buttons or let Auto-Bot execute.", color = TextDarkGray, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(allOrders) { order ->
                        val isCall = order.direction == SignalDirection.CALL_BUY
                        val statusColor = when (order.status) {
                            OrderStatus.ACTIVE -> AmberGold
                            OrderStatus.WON -> NeonGreen
                            OrderStatus.LOST -> NeonRed
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(TerminalCard)
                                .border(1.dp, TerminalBorder, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = order.pairSymbol, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isCall) "CALL" else "PUT",
                                        color = if (isCall) NeonGreen else NeonRed,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (order.isAutomated) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "AUTO",
                                            color = ElectricCyan,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.background(ElectricCyan.copy(alpha = 0.15f), RoundedCornerShape(3.dp)).padding(horizontal = 3.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${timeFormat.format(Date(order.entryTime))} • Stake: $${order.stakeAmount.toInt()}",
                                    color = TextDarkGray,
                                    fontSize = 11.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = order.status.name,
                                    color = statusColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = when (order.status) {
                                        OrderStatus.ACTIVE -> "IN PROGRESS..."
                                        OrderStatus.WON -> "+$${String.format(Locale.US, "%.2f", order.profitOrLoss)}"
                                        OrderStatus.LOST -> "-$${String.format(Locale.US, "%.2f", order.stakeAmount)}"
                                    },
                                    color = statusColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
