package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.QuotexConfig
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import java.util.Locale

@Composable
fun QuotexApiDialog(
    config: QuotexConfig,
    onSaveConfig: (QuotexConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var isDemo by remember { mutableStateOf(config.isDemoAccount) }
    var apiKey by remember { mutableStateOf(config.apiKey) }
    var autoTrade by remember { mutableStateOf(config.autoTradingEnabled) }
    var minConfidence by remember { mutableIntStateOf(config.minConfidenceThreshold) }
    var stakeAmount by remember { mutableDoubleStateOf(config.defaultStake) }
    var martingale by remember { mutableStateOf(config.martingaleEnabled) }
    var martingaleMultiplier by remember { mutableDoubleStateOf(config.martingaleMultiplier) }
    var maxMartingaleSteps by remember { mutableIntStateOf(config.maxMartingaleSteps) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("quotex_api_dialog"),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "QUOTEX API HUB",
                            color = TextWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Algorithmic execution & gateway configuration",
                            color = TextDarkGray,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextGray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Connection Status Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(TerminalCard)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(NeonGreen))
                            Column {
                                Text(text = config.serverName, color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(text = "WebSocket TLS 1.3 Active", color = TextDarkGray, fontSize = 10.sp)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(14.dp))
                            Text(text = "${config.pingMs}ms", color = NeonGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Account Type Switcher (Demo vs Real)
                Text(text = "ACCOUNT TRADING MODE", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isDemo) AmberGold else TerminalSurfaceVariant)
                            .clickable { isDemo = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "DEMO ($14,250.80)",
                            color = if (isDemo) Color(0xFF0B0E14) else TextWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isDemo) NeonGreen else TerminalSurfaceVariant)
                            .clickable { isDemo = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "REAL ACCOUNT",
                            color = if (!isDemo) Color(0xFF0B0E14) else TextWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // API Key Field
                Text(text = "QUOTEX API SECRET TOKEN", color = TextGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = TerminalBorder,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("quotex_api_key_field")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Algorithmic Strategy Settings
                Text(
                    text = "AUTOMATED EXECUTION STRATEGY",
                    color = ElectricCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Auto trade toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Auto-Execute 2M Signals", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "Orders fire automatically when confidence threshold is met", color = TextDarkGray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = autoTrade,
                        onCheckedChange = { autoTrade = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = NeonGreen, checkedThumbColor = Color.White)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Min confidence slider
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Min Signal Confidence", color = TextWhite, fontSize = 12.sp)
                        Text(text = "$minConfidence%", color = ElectricCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = minConfidence.toFloat(),
                        onValueChange = { minConfidence = it.toInt() },
                        valueRange = 75f..98f,
                        steps = 22,
                        colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Martingale risk management
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Martingale Recovery", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "Multiply stake by ${martingaleMultiplier}x after loss (max $maxMartingaleSteps steps)", color = TextDarkGray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = martingale,
                        onCheckedChange = { martingale = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = NeonGreen, checkedThumbColor = Color.White)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Save button
                Button(
                    onClick = {
                        onSaveConfig(
                            config.copy(
                                isDemoAccount = isDemo,
                                balance = if (isDemo) 14250.80 else 2480.50,
                                apiKey = apiKey,
                                autoTradingEnabled = autoTrade,
                                minConfidenceThreshold = minConfidence,
                                defaultStake = stakeAmount,
                                martingaleEnabled = martingale,
                                martingaleMultiplier = martingaleMultiplier,
                                maxMartingaleSteps = maxMartingaleSteps
                            )
                        )
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_quotex_config_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color(0xFF090D14)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "SAVE & CONNECT QUOTEX", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
