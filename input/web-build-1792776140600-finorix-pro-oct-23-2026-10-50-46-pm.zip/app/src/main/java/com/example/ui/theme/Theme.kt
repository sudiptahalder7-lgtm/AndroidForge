package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val TradingTerminalColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = TerminalBackground,
    primaryContainer = ElectricCyanBg,
    onPrimaryContainer = ElectricCyan,
    secondary = NeonGreen,
    onSecondary = TerminalBackground,
    secondaryContainer = NeonGreenBg,
    onSecondaryContainer = NeonGreen,
    tertiary = NeonRed,
    onTertiary = TextWhite,
    tertiaryContainer = NeonRedBg,
    onTertiaryContainer = NeonRed,
    background = TerminalBackground,
    onBackground = TextWhite,
    surface = TerminalSurface,
    onSurface = TextWhite,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextGray,
    outline = TerminalBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = TerminalBackground.toArgb()
                window.navigationBarColor = TerminalBackground.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = TradingTerminalColorScheme,
        typography = Typography,
        content = content
    )
}
