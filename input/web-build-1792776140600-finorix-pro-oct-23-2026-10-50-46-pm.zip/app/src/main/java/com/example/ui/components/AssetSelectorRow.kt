package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketPair
import com.example.model.TimeFrame
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun AssetSelectorRow(
    selectedPair: MarketPair,
    selectedTimeframe: TimeFrame,
    autoTradingEnabled: Boolean,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onOpenPairPicker: () -> Unit,
    onTimeframeSelected: (TimeFrame) -> Unit,
    onToggleAutoTrading: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var timeframeMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("asset_selector_container")
    ) {
        // Search Pill Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(TerminalSurfaceVariant)
                .border(1.dp, TerminalBorder, RoundedCornerShape(22.dp))
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = {
                        Text(
                            text = "Search currency, OTC, crypto...",
                            color = TextDarkGray,
                            fontSize = 13.sp
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("pair_search_input")
                )

                if (searchQuery.isNotEmpty()) {
                    IconButton(
                        onClick = { onSearchChange("") },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear Search",
                            tint = TextGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Asset Card (matching screenshot with icon, pair, timeframe and green toggle switch)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(TerminalCard)
                .border(1.dp, TerminalBorder, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Candlestick Icon Badge (white rounded square with mini candles)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White)
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(28.dp)) {
                        val w = size.width
                        val h = size.height

                        // Candle 1 (Red outline)
                        drawLine(
                            color = Color(0xFFEF4444),
                            start = Offset(w * 0.25f, h * 0.15f),
                            end = Offset(w * 0.25f, h * 0.85f),
                            strokeWidth = 2f
                        )
                        drawRect(
                            color = Color(0xFFEF4444),
                            topLeft = Offset(w * 0.15f, h * 0.35f),
                            size = Size(w * 0.2f, h * 0.35f)
                        )

                        // Candle 2 (Green outline/filled)
                        drawLine(
                            color = Color(0xFF10B981),
                            start = Offset(w * 0.7f, h * 0.1f),
                            end = Offset(w * 0.7f, h * 0.9f),
                            strokeWidth = 2f
                        )
                        drawRect(
                            color = Color(0xFF10B981),
                            topLeft = Offset(w * 0.6f, h * 0.25f),
                            size = Size(w * 0.2f, h * 0.45f)
                        )

                        // Horizontal baseline
                        drawLine(
                            color = Color(0xFFEF4444),
                            start = Offset(w * 0.1f, h * 0.9f),
                            end = Offset(w * 0.9f, h * 0.9f),
                            strokeWidth = 2.5f
                        )
                    }
                }

                // Pair Name & Timeframe Dropdown trigger
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onOpenPairPicker)
                            .testTag("pair_selector_dropdown")
                    ) {
                        Text(
                            text = selectedPair.symbol,
                            color = TextWhite,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Select Pair",
                            tint = TextGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Timeframe dropdown
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { timeframeMenuExpanded = true }
                                .padding(vertical = 2.dp)
                                .testTag("timeframe_selector")
                        ) {
                            Text(
                                text = "${selectedTimeframe.label} candles",
                                color = TextGray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "Timeframe",
                                tint = TextDarkGray,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = timeframeMenuExpanded,
                            onDismissRequest = { timeframeMenuExpanded = false },
                            modifier = Modifier.background(TerminalSurface)
                        ) {
                            TimeFrame.values().forEach { tf ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "${tf.label} candles",
                                            color = if (tf == selectedTimeframe) ElectricCyan else TextWhite,
                                            fontWeight = if (tf == selectedTimeframe) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        onTimeframeSelected(tf)
                                        timeframeMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Big Green Toggle Switch (Matches screenshot exactly!)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Switch(
                    checked = autoTradingEnabled,
                    onCheckedChange = onToggleAutoTrading,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = NeonGreen,
                        uncheckedThumbColor = TextGray,
                        uncheckedTrackColor = TerminalSurfaceVariant
                    ),
                    modifier = Modifier.testTag("auto_trading_toggle")
                )
            }
        }
    }
}
