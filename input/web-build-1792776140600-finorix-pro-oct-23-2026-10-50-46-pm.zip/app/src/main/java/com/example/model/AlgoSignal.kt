package com.example.model

enum class SignalDirection {
    CALL_BUY,
    PUT_SELL
}

enum class SignalStrength {
    NORMAL,
    HIGH,
    ULTRA
}

data class CandlePattern(
    val name: String,
    val direction: SignalDirection,
    val strength: SignalStrength,
    val description: String,
    val winProbability: Int // e.g. 94%
)

data class AlgoSignal(
    val id: String,
    val pairSymbol: String,
    val direction: SignalDirection,
    val timeframe: TimeFrame,
    val confidence: Int, // e.g. 94
    val patternName: String,
    val patternDescription: String,
    val entryPrice: Double,
    val suggestedExpirySeconds: Int,
    val timestamp: Long,
    val rsiValue: Double,
    val emaBias: String,
    val isAutoExecuted: Boolean = false
)

enum class OrderStatus {
    ACTIVE,
    WON,
    LOST
}

data class TradeOrder(
    val id: String,
    val pairSymbol: String,
    val direction: SignalDirection,
    val stakeAmount: Double,
    val entryPrice: Double,
    var exitPrice: Double? = null,
    val entryTime: Long,
    val expiryTime: Long,
    var status: OrderStatus = OrderStatus.ACTIVE,
    val payoutRate: Int = 92,
    var profitOrLoss: Double = 0.0,
    val isAutomated: Boolean = false,
    val patternTrigger: String? = null
)
