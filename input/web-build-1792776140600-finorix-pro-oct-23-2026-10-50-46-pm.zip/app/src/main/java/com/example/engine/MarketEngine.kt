package com.example.engine

import com.example.model.Candle
import com.example.model.MarketPair
import com.example.model.PairCategory
import com.example.model.TimeFrame
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class Technicals(
    val ema9: Double,
    val ema21: Double,
    val rsi: Double,
    val bbUpper: Double,
    val bbLower: Double,
    val bbMiddle: Double,
    val buyerSentimentPercent: Int = 68
)

class MarketEngine {
    private val random = Random()

    val availablePairs = listOf(
        MarketPair(
            symbol = "USD/COP OTC",
            name = "US Dollar / Colombian Peso OTC",
            category = PairCategory.FOREX_OTC,
            payoutPercentage = 92,
            currentPrice = 3213.90,
            priceChange24h = -0.42,
            decimalPlaces = 2,
            baseVolatility = 0.65
        ),
        MarketPair(
            symbol = "EUR/USD OTC",
            name = "Euro / US Dollar OTC",
            category = PairCategory.FOREX_OTC,
            payoutPercentage = 91,
            currentPrice = 1.08450,
            priceChange24h = 0.18,
            decimalPlaces = 5,
            baseVolatility = 0.00015
        ),
        MarketPair(
            symbol = "GBP/USD OTC",
            name = "British Pound / US Dollar OTC",
            category = PairCategory.FOREX_OTC,
            payoutPercentage = 89,
            currentPrice = 1.29820,
            priceChange24h = 0.35,
            decimalPlaces = 5,
            baseVolatility = 0.00020
        ),
        MarketPair(
            symbol = "USD/BRL OTC",
            name = "US Dollar / Brazilian Real OTC",
            category = PairCategory.FOREX_OTC,
            payoutPercentage = 93,
            currentPrice = 5.6820,
            priceChange24h = -0.15,
            decimalPlaces = 4,
            baseVolatility = 0.0012
        ),
        MarketPair(
            symbol = "BTC/USDT",
            name = "Bitcoin / Tether",
            category = PairCategory.CRYPTO,
            payoutPercentage = 88,
            currentPrice = 67840.50,
            priceChange24h = 2.45,
            decimalPlaces = 2,
            baseVolatility = 12.5
        ),
        MarketPair(
            symbol = "XAU/USD OTC",
            name = "Gold / US Dollar OTC",
            category = PairCategory.COMMODITIES,
            payoutPercentage = 95,
            currentPrice = 2735.40,
            priceChange24h = 0.88,
            decimalPlaces = 2,
            baseVolatility = 0.45
        )
    )

    private val _selectedPair = MutableStateFlow(availablePairs[0])
    val selectedPair: StateFlow<MarketPair> = _selectedPair.asStateFlow()

    private val _selectedTimeframe = MutableStateFlow(TimeFrame.MIN_2)
    val selectedTimeframe: StateFlow<TimeFrame> = _selectedTimeframe.asStateFlow()

    private val _candles = MutableStateFlow<List<Candle>>(emptyList())
    val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

    private val _technicals = MutableStateFlow(
        Technicals(
            ema9 = 3213.90,
            ema21 = 3213.90,
            rsi = 52.0,
            bbUpper = 3215.00,
            bbLower = 3212.80,
            bbMiddle = 3213.90
        )
    )
    val technicals: StateFlow<Technicals> = _technicals.asStateFlow()

    private val _candleTimeRemainingSeconds = MutableStateFlow(38)
    val candleTimeRemainingSeconds: StateFlow<Int> = _candleTimeRemainingSeconds.asStateFlow()

    init {
        generateInitialHistory(_selectedPair.value, _selectedTimeframe.value)
    }

    fun selectPair(symbol: String) {
        val found = availablePairs.find { it.symbol == symbol } ?: return
        _selectedPair.value = found
        generateInitialHistory(found, _selectedTimeframe.value)
    }

    fun selectTimeframe(tf: TimeFrame) {
        _selectedTimeframe.value = tf
        generateInitialHistory(_selectedPair.value, tf)
    }

    private fun generateInitialHistory(pair: MarketPair, tf: TimeFrame) {
        val count = 45
        val list = ArrayList<Candle>()
        var currentClose = pair.currentPrice
        val now = System.currentTimeMillis()
        val intervalMs = tf.seconds * 1000L

        // Generate backwards, then reverse
        for (i in count downTo 1) {
            val ts = now - (i * intervalMs)
            val delta = (random.nextGaussian() * pair.baseVolatility)
            val open = currentClose - delta
            val close = currentClose
            val high = max(open, close) + abs(random.nextGaussian() * pair.baseVolatility * 0.7)
            val low = min(open, close) - abs(random.nextGaussian() * pair.baseVolatility * 0.7)
            val vol = 100.0 + random.nextDouble() * 500.0
            list.add(
                Candle(
                    timestamp = ts,
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = vol,
                    isComplete = true
                )
            )
            currentClose = close + (random.nextGaussian() * pair.baseVolatility)
        }

        // Add current forming candle
        val activeTs = now
        val activeOpen = currentClose
        val activeClose = currentClose + (random.nextGaussian() * pair.baseVolatility * 0.3)
        val activeHigh = max(activeOpen, activeClose) + abs(random.nextGaussian() * pair.baseVolatility * 0.4)
        val activeLow = min(activeOpen, activeClose) - abs(random.nextGaussian() * pair.baseVolatility * 0.4)

        list.add(
            Candle(
                timestamp = activeTs,
                open = activeOpen,
                high = activeHigh,
                low = activeLow,
                close = activeClose,
                volume = 80.0,
                isComplete = false
            )
        )

        _candles.value = list
        updateCurrentPrice(activeClose)
        recalculateTechnicals()
    }

    fun onTick(): Candle {
        val currentList = _candles.value.toMutableList()
        val tf = _selectedTimeframe.value
        val pair = _selectedPair.value

        var remaining = _candleTimeRemainingSeconds.value - 1
        if (remaining <= 0) {
            remaining = tf.seconds
            // Finalize current candle and start new candle
            if (currentList.isNotEmpty()) {
                val last = currentList.removeAt(currentList.size - 1)
                currentList.add(last.copy(isComplete = true))

                // Start new active candle
                val newOpen = last.close
                val newCandle = Candle(
                    timestamp = System.currentTimeMillis(),
                    open = newOpen,
                    high = newOpen,
                    low = newOpen,
                    close = newOpen,
                    volume = 20.0,
                    isComplete = false
                )
                currentList.add(newCandle)
                if (currentList.size > 70) {
                    currentList.removeAt(0)
                }
            }
        }
        _candleTimeRemainingSeconds.value = remaining

        // Apply price fluctuation to current forming candle
        if (currentList.isNotEmpty()) {
            val active = currentList.removeAt(currentList.size - 1)
            val tickStep = random.nextGaussian() * (pair.baseVolatility * 0.25)
            val newClose = active.close + tickStep
            val newHigh = max(active.high, newClose)
            val newLow = min(active.low, newClose)
            val newVol = active.volume + abs(tickStep * 100)

            val updated = active.copy(
                high = newHigh,
                low = newLow,
                close = newClose,
                volume = newVol,
                isComplete = false
            )
            currentList.add(updated)
            _candles.value = currentList
            updateCurrentPrice(newClose)
            recalculateTechnicals()
            return updated
        }
        return Candle(System.currentTimeMillis(), pair.currentPrice, pair.currentPrice, pair.currentPrice, pair.currentPrice, 10.0)
    }

    private fun updateCurrentPrice(price: Double) {
        val cur = _selectedPair.value
        _selectedPair.value = cur.copy(currentPrice = price)
    }

    private fun recalculateTechnicals() {
        val list = _candles.value
        if (list.size < 21) return

        val closes = list.map { it.close }

        // EMA 9 & 21
        val ema9 = calculateEMA(closes, 9)
        val ema21 = calculateEMA(closes, 21)

        // RSI 14
        val rsi = calculateRSI(closes, 14)

        // Bollinger Bands 20
        val window = closes.takeLast(20)
        val mean = window.average()
        val variance = window.map { (it - mean) * (it - mean) }.average()
        val stdDev = sqrt(variance)
        val bbUpper = mean + (2 * stdDev)
        val bbLower = mean - (2 * stdDev)

        // Buyer sentiment
        val bullishCount = list.takeLast(10).count { it.isBullish }
        val buyerPercent = (bullishCount * 10).coerceIn(20, 85)

        _technicals.value = Technicals(
            ema9 = ema9,
            ema21 = ema21,
            rsi = (rsi * 10).toInt() / 10.0,
            bbUpper = bbUpper,
            bbLower = bbLower,
            bbMiddle = mean,
            buyerSentimentPercent = buyerPercent
        )
    }

    private fun calculateEMA(values: List<Double>, period: Int): Double {
        if (values.size < period) return values.lastOrNull() ?: 0.0
        val k = 2.0 / (period + 1.0)
        var ema = values.take(period).average()
        for (i in period until values.size) {
            ema = (values[i] * k) + (ema * (1 - k))
        }
        return ema
    }

    private fun calculateRSI(values: List<Double>, period: Int): Double {
        if (values.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0
        val recent = values.takeLast(period + 1)
        for (i in 1 until recent.size) {
            val diff = recent[i] - recent[i - 1]
            if (diff >= 0) gains += diff else losses += abs(diff)
        }
        val avgGain = gains / period
        val avgLoss = losses / period
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }
}
