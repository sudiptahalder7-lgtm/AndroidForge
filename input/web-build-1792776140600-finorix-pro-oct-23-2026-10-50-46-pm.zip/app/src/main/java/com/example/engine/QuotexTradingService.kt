package com.example.engine

import com.example.model.AlgoSignal
import com.example.model.OrderStatus
import com.example.model.QuotexConfig
import com.example.model.SignalDirection
import com.example.model.TradeOrder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class QuotexTradingService {
    private val _config = MutableStateFlow(QuotexConfig())
    val config: StateFlow<QuotexConfig> = _config.asStateFlow()

    private val _activeOrders = MutableStateFlow<List<TradeOrder>>(emptyList())
    val activeOrders: StateFlow<List<TradeOrder>> = _activeOrders.asStateFlow()

    private val _tradeHistory = MutableStateFlow<List<TradeOrder>>(emptyList())
    val tradeHistory: StateFlow<List<TradeOrder>> = _tradeHistory.asStateFlow()

    private var currentMartingaleStep = 0
    private var lastTradeLost = false

    fun updateConfig(updated: QuotexConfig) {
        _config.value = updated
    }

    fun toggleAutoTrading(enabled: Boolean) {
        _config.value = _config.value.copy(autoTradingEnabled = enabled)
    }

    fun toggleAccountType() {
        val current = _config.value
        val newIsDemo = !current.isDemoAccount
        val newBalance = if (newIsDemo) 14250.80 else 2480.50
        _config.value = current.copy(
            isDemoAccount = newIsDemo,
            balance = newBalance
        )
    }

    fun executeOrder(
        pairSymbol: String,
        direction: SignalDirection,
        currentPrice: Double,
        payoutRate: Int,
        durationSeconds: Int = 120,
        isAutomated: Boolean = false,
        patternTrigger: String? = null,
        customStake: Double? = null
    ): TradeOrder? {
        val conf = _config.value
        if (!conf.isConnected) return null

        // Determine stake with Martingale if active
        val baseStake = customStake ?: conf.defaultStake
        val actualStake = if (conf.martingaleEnabled && lastTradeLost && currentMartingaleStep < conf.maxMartingaleSteps) {
            baseStake * Math.pow(conf.martingaleMultiplier, currentMartingaleStep.toDouble())
        } else {
            baseStake
        }

        if (conf.balance < actualStake) {
            return null // Insufficient funds
        }

        // Deduct stake from balance
        _config.value = conf.copy(balance = conf.balance - actualStake)

        val now = System.currentTimeMillis()
        val order = TradeOrder(
            id = UUID.randomUUID().toString().take(8).uppercase(),
            pairSymbol = pairSymbol,
            direction = direction,
            stakeAmount = actualStake,
            entryPrice = currentPrice,
            entryTime = now,
            expiryTime = now + (durationSeconds * 1000L),
            status = OrderStatus.ACTIVE,
            payoutRate = payoutRate,
            isAutomated = isAutomated,
            patternTrigger = patternTrigger
        )

        _activeOrders.value = _activeOrders.value + order
        return order
    }

    fun onTickCheckOrders(currentPrice: Double, pairSymbol: String) {
        val now = System.currentTimeMillis()
        val active = _activeOrders.value.toMutableList()
        val completed = mutableListOf<TradeOrder>()

        val iterator = active.iterator()
        while (iterator.hasNext()) {
            val order = iterator.next()
            if (order.pairSymbol == pairSymbol && now >= order.expiryTime) {
                iterator.remove()
                // Resolve order
                order.exitPrice = currentPrice
                val isWon = when (order.direction) {
                    SignalDirection.CALL_BUY -> currentPrice > order.entryPrice
                    SignalDirection.PUT_SELL -> currentPrice < order.entryPrice
                }

                if (isWon) {
                    order.status = OrderStatus.WON
                    val profit = order.stakeAmount * (order.payoutRate / 100.0)
                    order.profitOrLoss = profit
                    // Credit balance: stake + profit
                    _config.value = _config.value.copy(balance = _config.value.balance + order.stakeAmount + profit)
                    lastTradeLost = false
                    currentMartingaleStep = 0
                } else {
                    order.status = OrderStatus.LOST
                    order.profitOrLoss = -order.stakeAmount
                    lastTradeLost = true
                    currentMartingaleStep++
                }
                completed.add(order)
            }
        }

        if (completed.isNotEmpty()) {
            _activeOrders.value = active
            _tradeHistory.value = completed + _tradeHistory.value
        }
    }
}
