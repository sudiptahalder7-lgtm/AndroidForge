package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TerminalBackground = Color(0xFF0B0E14)
val TerminalSurface = Color(0xFF121721)
val TerminalSurfaceVariant = Color(0xFF1A2230)
val TerminalCard = Color(0xFF141A26)
val TerminalBorder = Color(0xFF222C3D)

val NeonGreen = Color(0xFF00E676)
val NeonGreenDark = Color(0xFF00B248)
val NeonGreenBg = Color(0x1F00E676)

val NeonRed = Color(0xFFFF3D57)
val NeonRedDark = Color(0xFFD32F2F)
val NeonRedBg = Color(0x1FFF3D57)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanBg = Color(0x2400E5FF)

val AmberGold = Color(0xFFFFB300)
val AmberGoldBg = Color(0x24FFB300)

val TextWhite = Color(0xFFF8FAFC)
val TextGray = Color(0xFF94A3B8)
val TextDarkGray = Color(0xFF64748B)

// Window controls
val MacCloseRed = Color(0xFFFF5F56)
val MacMinYellow = Color(0xFFFFBD2E)
val MacMaxGreen = Color(0xFF27C93F)
