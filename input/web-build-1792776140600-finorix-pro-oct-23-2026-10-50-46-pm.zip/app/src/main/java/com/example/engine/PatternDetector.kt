package com.example.engine

import com.example.model.AlgoSignal
import com.example.model.Candle
import com.example.model.CandlePattern
import com.example.model.SignalDirection
import com.example.model.SignalStrength
import com.example.model.TimeFrame
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object PatternDetector {

    fun analyzeCandles(
        candles: List<Candle>,
        symbol: String,
        timeframe: TimeFrame,
        rsi: Double,
        ema9: Double,
        ema21: Double
    ): AlgoSignal? {
        if (candles.size < 5) return null

        val current = candles.last()
        val prev1 = candles[candles.size - 2]
        val prev2 = candles[candles.size - 3]
        val prev3 = candles[candles.size - 4]

        val tfPrefix = timeframe.label.uppercase()
        val currentPrice = current.close

        // 1. Shooting Star / Bearish Pin Bar (Rejection of higher prices)
        val isShootingStar = current.upperWick >= (current.bodyHeight * 1.8) &&
                current.lowerWick <= (current.bodyHeight * 0.5) &&
                current.bodyHeight > 0.00001 &&
                current.high > prev1.high

        if (isShootingStar && rsi > 60.0) {
            val confidence = if (rsi > 70.0 || ema9 < ema21) 94 else 88
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.PUT_SELL,
                timeframe = timeframe,
                confidence = confidence,
                patternName = "$tfPrefix Bearish Rejection Pin Bar",
                patternDescription = "Sharp upper wick rejection at resistance. Sellers dominant with RSI ($rsi).",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = if (ema9 < ema21) "Bearish Trend" else "Overextended Bull"
            )
        }

        // 2. Hammer / Bullish Pin Bar (Rejection of lower prices)
        val isHammer = current.lowerWick >= (current.bodyHeight * 1.8) &&
                current.upperWick <= (current.bodyHeight * 0.5) &&
                current.bodyHeight > 0.00001 &&
                current.low < prev1.low

        if (isHammer && rsi < 40.0) {
            val confidence = if (rsi < 30.0 || ema9 > ema21) 95 else 89
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.CALL_BUY,
                timeframe = timeframe,
                confidence = confidence,
                patternName = "$tfPrefix Bullish Liquidity Sweep & Hammer",
                patternDescription = "Buyers defended key low with strong absorption wick. RSI ($rsi).",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = if (ema9 > ema21) "Bullish Momentum" else "Oversold Bounce"
            )
        }

        // 3. Bearish Engulfing
        val isBearishEngulfing = !prev1.isBullish && current.close < current.open &&
                current.open >= prev1.close &&
                current.close <= prev1.open &&
                current.bodyHeight > prev1.bodyHeight * 1.1

        if (isBearishEngulfing && currentPrice < ema9) {
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.PUT_SELL,
                timeframe = timeframe,
                confidence = 92,
                patternName = "$tfPrefix Bearish Engulfing Formation",
                patternDescription = "Sellers completely wiped out previous buyers with impulse volume.",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = "Bearish EMA Crossover"
            )
        }

        // 4. Bullish Engulfing
        val isBullishEngulfing = !prev1.isBullish && current.close > current.open &&
                current.open <= prev1.close &&
                current.close >= prev1.open &&
                current.bodyHeight > prev1.bodyHeight * 1.1

        if (isBullishEngulfing && currentPrice > ema9) {
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.CALL_BUY,
                timeframe = timeframe,
                confidence = 93,
                patternName = "$tfPrefix Bullish Engulfing Breakout",
                patternDescription = "High conviction demand bar engulfing previous supply zone.",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = "Bullish Momentum Expansion"
            )
        }

        // 5. Evening Star (Bearish 3-candle reversal)
        val isEveningStar = prev2.isBullish &&
                abs(prev1.close - prev1.open) < (prev2.bodyHeight * 0.4) &&
                !current.isBullish &&
                current.close < (prev2.open + prev2.close) / 2

        if (isEveningStar) {
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.PUT_SELL,
                timeframe = timeframe,
                confidence = 96,
                patternName = "$tfPrefix Evening Star Institutional Exhaustion",
                patternDescription = "Exhaustion doji followed by decisive bearish confirmation breakdown.",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = "Structural Shift Downward"
            )
        }

        // 6. Morning Star (Bullish 3-candle reversal)
        val isMorningStar = !prev2.isBullish &&
                abs(prev1.close - prev1.open) < (prev2.bodyHeight * 0.4) &&
                current.isBullish &&
                current.close > (prev2.open + prev2.close) / 2

        if (isMorningStar) {
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.CALL_BUY,
                timeframe = timeframe,
                confidence = 96,
                patternName = "$tfPrefix Morning Star Institutional Reversal",
                patternDescription = "Indecision followed by aggressive upside impulse closing above 50% retracement.",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = "Structural Shift Upward"
            )
        }

        // 7. Three White Soldiers (Bullish Trend continuation)
        val isThreeWhiteSoldiers = prev2.isBullish && prev1.isBullish && current.isBullish &&
                current.close > prev1.close && prev1.close > prev2.close &&
                current.open > prev1.open && prev1.open > prev2.open

        if (isThreeWhiteSoldiers && rsi < 75.0) {
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.CALL_BUY,
                timeframe = timeframe,
                confidence = 90,
                patternName = "$tfPrefix Three White Soldiers Run",
                patternDescription = "Continuous algorithmic buying pressure pushing to consecutive fresh highs.",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = "Strong Bull Trend"
            )
        }

        // 8. Three Black Crows (Bearish Trend continuation)
        val isThreeBlackCrows = !prev2.isBullish && !prev1.isBullish && !current.isBullish &&
                current.close < prev1.close && prev1.close < prev2.close &&
                current.open < prev1.open && prev1.open < prev2.open

        if (isThreeBlackCrows && rsi > 25.0) {
            return AlgoSignal(
                id = UUID.randomUUID().toString(),
                pairSymbol = symbol,
                direction = SignalDirection.PUT_SELL,
                timeframe = timeframe,
                confidence = 90,
                patternName = "$tfPrefix Three Black Crows Cascade",
                patternDescription = "Continuous algorithmic sell-off breaking local dynamic supports.",
                entryPrice = currentPrice,
                suggestedExpirySeconds = timeframe.seconds,
                timestamp = System.currentTimeMillis(),
                rsiValue = rsi,
                emaBias = "Strong Bear Trend"
            )
        }

        return null
    }
}
