package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AssetSelectorRow
import com.example.ui.components.CandlestickChart
import com.example.ui.components.ExecutionPanel
import com.example.ui.components.FinorixTopBar
import com.example.ui.components.PairPickerBottomSheet
import com.example.ui.components.QuotexApiDialog
import com.example.ui.components.SignalCard
import com.example.ui.components.SignalsBottomSheet
import com.example.ui.components.TradeHistoryBottomSheet
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

@Composable
fun FinorixProScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedPair by viewModel.marketEngine.selectedPair.collectAsState()
    val selectedTimeframe by viewModel.marketEngine.selectedTimeframe.collectAsState()
    val candles by viewModel.marketEngine.candles.collectAsState()
    val technicals by viewModel.marketEngine.technicals.collectAsState()
    val countdownSeconds by viewModel.marketEngine.candleTimeRemainingSeconds.collectAsState()

    val quotexConfig by viewModel.quotexService.config.collectAsState()
    val activeOrders by viewModel.quotexService.activeOrders.collectAsState()
    val tradeHistory by viewModel.quotexService.tradeHistory.collectAsState()

    val latestSignal by viewModel.latestSignal.collectAsState()
    val signalsHistory by viewModel.signalsHistory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedStake by viewModel.selectedStake.collectAsState()

    val isPairPickerOpen by viewModel.isPairPickerOpen.collectAsState()
    val isQuotexSettingsOpen by viewModel.isQuotexSettingsOpen.collectAsState()
    val isSignalsSheetOpen by viewModel.isSignalsSheetOpen.collectAsState()
    val isHistorySheetOpen by viewModel.isHistorySheetOpen.collectAsState()

    val notificationMessage by viewModel.notificationMessage.collectAsState()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground),
        containerColor = TerminalBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            // Pro Navigation Dock
            TerminalBottomDock(
                signalCount = signalsHistory.size,
                activeOrderCount = activeOrders.size,
                onOpenPairs = { viewModel.openPairPicker(true) },
                onOpenSignals = { viewModel.openSignalsSheet(true) },
                onOpenSettings = { viewModel.openQuotexSettings(true) },
                onOpenHistory = { viewModel.openHistorySheet(true) },
                modifier = Modifier.navigationBarsPadding()
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .verticalScroll(rememberScrollState())
            ) {
                // Top Bar with macOS buttons, active indicator, FINORIX PRO branding and Quotex Wallet
                FinorixTopBar(
                    quotexConfig = quotexConfig,
                    onOpenQuotexSettings = { viewModel.openQuotexSettings(true) },
                    onToggleAccountType = { viewModel.toggleAccountType() }
                )

                // Search Bar + USD/COP OTC selector + Timeframe + Big Green Switch (matches screenshot)
                AssetSelectorRow(
                    selectedPair = selectedPair,
                    selectedTimeframe = selectedTimeframe,
                    autoTradingEnabled = quotexConfig.autoTradingEnabled,
                    searchQuery = searchQuery,
                    onSearchChange = { q ->
                        viewModel.setSearchQuery(q)
                        if (q.isNotEmpty()) {
                            viewModel.openPairPicker(true)
                        }
                    },
                    onOpenPairPicker = { viewModel.openPairPicker(true) },
                    onTimeframeSelected = { tf -> viewModel.selectTimeframe(tf) },
                    onToggleAutoTrading = { enabled -> viewModel.toggleAutoTrading(enabled) }
                )

                // Live Candlestick Chart (Matches screenshot with wicks, EMA, countdown 00:38, and cyan price badge)
                CandlestickChart(
                    pair = selectedPair,
                    candles = candles,
                    technicals = technicals,
                    countdownSeconds = countdownSeconds,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                // Algorithmic Signal Card (2-Minute candle formations, confidence score, and strategy notes)
                SignalCard(
                    signal = latestSignal,
                    isAutoTradingActive = quotexConfig.autoTradingEnabled,
                    onExecuteManual = { dir -> viewModel.executeManualTrade(dir) },
                    onViewAllSignals = { viewModel.openSignalsSheet(true) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                // High-Frequency Execution Panel (Stake selectors, Bulls/Bears sentiment meter, HIGHER / LOWER buttons)
                ExecutionPanel(
                    pair = selectedPair,
                    selectedStake = selectedStake,
                    buyerSentimentPercent = technicals.buyerSentimentPercent,
                    activeOrderCount = activeOrders.size,
                    onStakeSelected = { stake -> viewModel.setSelectedStake(stake) },
                    onExecuteTrade = { dir -> viewModel.executeManualTrade(dir) },
                    onViewHistory = { viewModel.openHistorySheet(true) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Notification Toast Banner
            AnimatedVisibility(
                visible = notificationMessage != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 8.dp, start = 16.dp, end = 16.dp)
            ) {
                notificationMessage?.let { msg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(ElectricCyan)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(18.dp))
                        Text(
                            text = msg,
                            color = Color(0xFF090D14),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // Modal Bottom Sheets and Dialogs
    if (isPairPickerOpen) {
        PairPickerBottomSheet(
            pairs = viewModel.marketEngine.availablePairs,
            selectedSymbol = selectedPair.symbol,
            onPairSelected = { symbol -> viewModel.selectPair(symbol) },
            onDismiss = { viewModel.openPairPicker(false) }
        )
    }

    if (isQuotexSettingsOpen) {
        QuotexApiDialog(
            config = quotexConfig,
            onSaveConfig = { cfg -> viewModel.updateQuotexConfig(cfg) },
            onDismiss = { viewModel.openQuotexSettings(false) }
        )
    }

    if (isSignalsSheetOpen) {
        SignalsBottomSheet(
            signals = signalsHistory,
            onExecuteSignal = { sig -> viewModel.executeManualTrade(sig.direction) },
            onDismiss = { viewModel.openSignalsSheet(false) }
        )
    }

    if (isHistorySheetOpen) {
        TradeHistoryBottomSheet(
            activeOrders = activeOrders,
            tradeHistory = tradeHistory,
            onDismiss = { viewModel.openHistorySheet(false) }
        )
    }
}

@Composable
private fun TerminalBottomDock(
    signalCount: Int,
    activeOrderCount: Int,
    onOpenPairs: () -> Unit,
    onOpenSignals: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder)
            .padding(vertical = 10.dp, horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        DockItem(
            icon = Icons.Default.CurrencyExchange,
            label = "Assets",
            onClick = onOpenPairs
        )

        DockItemWithBadge(
            icon = Icons.Default.Bolt,
            label = "2M Signals",
            badgeCount = signalCount,
            onClick = onOpenSignals
        )

        DockItemWithBadge(
            icon = Icons.Default.History,
            label = "Audit & Orders",
            badgeCount = activeOrderCount,
            badgeColor = NeonGreen,
            onClick = onOpenHistory
        )

        DockItem(
            icon = Icons.Default.Settings,
            label = "Quotex API",
            onClick = onOpenSettings
        )
    }
}

@Composable
private fun DockItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = TextGray, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = label, color = TextGray, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DockItemWithBadge(
    icon: ImageVector,
    label: String,
    badgeCount: Int,
    badgeColor: Color = ElectricCyan,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        if (badgeCount > 0) {
            BadgedBox(
                badge = {
                    Badge(containerColor = badgeColor) {
                        Text(text = "$badgeCount", color = Color(0xFF090D14), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            ) {
                Icon(imageVector = icon, contentDescription = label, tint = TextWhite, modifier = Modifier.size(20.dp))
            }
        } else {
            Icon(imageVector = icon, contentDescription = label, tint = TextGray, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = label, color = if (badgeCount > 0) TextWhite else TextGray, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}
