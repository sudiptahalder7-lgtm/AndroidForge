package com.example.model

enum class PairCategory {
    FOREX_OTC,
    CRYPTO,
    COMMODITIES
}

data class MarketPair(
    val symbol: String,
    val name: String,
    val category: PairCategory,
    val payoutPercentage: Int = 92,
    val currentPrice: Double,
    val priceChange24h: Double,
    val decimalPlaces: Int = 2,
    val baseVolatility: Double = 0.4
)

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val isComplete: Boolean = true
) {
    val isBullish: Boolean get() = close >= open
    val bodyHeight: Double get() = kotlin.math.abs(close - open)
    val totalHeight: Double get() = high - low
    val upperWick: Double get() = if (isBullish) high - close else high - open
    val lowerWick: Double get() = if (isBullish) open - low else close - low
}

enum class TimeFrame(val label: String, val seconds: Int) {
    SEC_15("15s", 15),
    SEC_30("30s", 30),
    MIN_1("1m", 60),
    MIN_2("2m", 120),
    MIN_5("5m", 300)
}
