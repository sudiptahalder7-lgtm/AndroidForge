package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.MarketEngine
import com.example.engine.PatternDetector
import com.example.engine.QuotexTradingService
import com.example.model.AlgoSignal
import com.example.model.MarketPair
import com.example.model.QuotexConfig
import com.example.model.SignalDirection
import com.example.model.TimeFrame
import com.example.model.TradeOrder
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    val marketEngine = MarketEngine()
    val quotexService = QuotexTradingService()

    private val _latestSignal = MutableStateFlow<AlgoSignal?>(null)
    val latestSignal: StateFlow<AlgoSignal?> = _latestSignal.asStateFlow()

    private val _signalsHistory = MutableStateFlow<List<AlgoSignal>>(emptyList())
    val signalsHistory: StateFlow<List<AlgoSignal>> = _signalsHistory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStake = MutableStateFlow(50.0)
    val selectedStake: StateFlow<Double> = _selectedStake.asStateFlow()

    private val _isPairPickerOpen = MutableStateFlow(false)
    val isPairPickerOpen: StateFlow<Boolean> = _isPairPickerOpen.asStateFlow()

    private val _isQuotexSettingsOpen = MutableStateFlow(false)
    val isQuotexSettingsOpen: StateFlow<Boolean> = _isQuotexSettingsOpen.asStateFlow()

    private val _isSignalsSheetOpen = MutableStateFlow(false)
    val isSignalsSheetOpen: StateFlow<Boolean> = _isSignalsSheetOpen.asStateFlow()

    private val _isHistorySheetOpen = MutableStateFlow(false)
    val isHistorySheetOpen: StateFlow<Boolean> = _isHistorySheetOpen.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    private var tickJob: Job? = null

    init {
        startTickEngine()
    }

    private fun startTickEngine() {
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val activeCandle = marketEngine.onTick()
                val currentPair = marketEngine.selectedPair.value
                val tf = marketEngine.selectedTimeframe.value
                val tech = marketEngine.technicals.value

                // Check active trade orders
                quotexService.onTickCheckOrders(activeCandle.close, currentPair.symbol)

                // Detect algorithmic patterns
                val candles = marketEngine.candles.value
                val detected = PatternDetector.analyzeCandles(
                    candles = candles,
                    symbol = currentPair.symbol,
                    timeframe = tf,
                    rsi = tech.rsi,
                    ema9 = tech.ema9,
                    ema21 = tech.ema21
                )

                if (detected != null) {
                    val prevSignal = _latestSignal.value
                    // Avoid duplicating identical signal every tick within 20s
                    val isNew = prevSignal == null ||
                            (System.currentTimeMillis() - prevSignal.timestamp > 15000L) ||
                            prevSignal.patternName != detected.patternName

                    if (isNew) {
                        _latestSignal.value = detected
                        _signalsHistory.value = listOf(detected) + _signalsHistory.value.take(40)

                        // If Quotex Auto-Trading is enabled, execute trade!
                        val conf = quotexService.config.value
                        if (conf.autoTradingEnabled && detected.confidence >= conf.minConfidenceThreshold) {
                            val executedOrder = quotexService.executeOrder(
                                pairSymbol = currentPair.symbol,
                                direction = detected.direction,
                                currentPrice = detected.entryPrice,
                                payoutRate = currentPair.payoutPercentage,
                                durationSeconds = detected.suggestedExpirySeconds,
                                isAutomated = true,
                                patternTrigger = detected.patternName
                            )
                            if (executedOrder != null) {
                                showNotification("AUTO-BOT: ${detected.direction.name} on ${currentPair.symbol} ($${executedOrder.stakeAmount})")
                            }
                        }
                    }
                }
            }
        }
    }

    fun selectPair(symbol: String) {
        marketEngine.selectPair(symbol)
        _isPairPickerOpen.value = false
    }

    fun selectTimeframe(tf: TimeFrame) {
        marketEngine.selectTimeframe(tf)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedStake(stake: Double) {
        _selectedStake.value = stake
    }

    fun toggleAutoTrading(enabled: Boolean) {
        quotexService.toggleAutoTrading(enabled)
        showNotification(if (enabled) "Algorithmic Auto-Execution ACTIVATED" else "Auto-Execution PAUSED")
    }

    fun toggleAccountType() {
        quotexService.toggleAccountType()
        val isDemo = quotexService.config.value.isDemoAccount
        showNotification(if (isDemo) "Switched to QUOTEX DEMO Account" else "Switched to QUOTEX REAL Account")
    }

    fun executeManualTrade(direction: SignalDirection) {
        val currentPair = marketEngine.selectedPair.value
        val stake = _selectedStake.value
        val tf = marketEngine.selectedTimeframe.value

        val order = quotexService.executeOrder(
            pairSymbol = currentPair.symbol,
            direction = direction,
            currentPrice = currentPair.currentPrice,
            payoutRate = currentPair.payoutPercentage,
            durationSeconds = tf.seconds,
            isAutomated = false,
            patternTrigger = _latestSignal.value?.patternName ?: "Manual Pro Execution",
            customStake = stake
        )

        if (order != null) {
            showNotification("${direction.name} order placed! ($$stake at ${currentPair.currentPrice})")
        } else {
            showNotification("Execution Failed: Check balance or connection")
        }
    }

    fun openPairPicker(open: Boolean) { _isPairPickerOpen.value = open }
    fun openQuotexSettings(open: Boolean) { _isQuotexSettingsOpen.value = open }
    fun openSignalsSheet(open: Boolean) { _isSignalsSheetOpen.value = open }
    fun openHistorySheet(open: Boolean) { _isHistorySheetOpen.value = open }

    fun updateQuotexConfig(config: QuotexConfig) {
        quotexService.updateConfig(config)
        showNotification("Quotex Configuration Saved")
    }

    fun clearNotification() {
        _notificationMessage.value = null
    }

    private fun showNotification(msg: String) {
        _notificationMessage.value = msg
        viewModelScope.launch {
            delay(3500)
            if (_notificationMessage.value == msg) {
                _notificationMessage.value = null
            }
        }
    }
}
