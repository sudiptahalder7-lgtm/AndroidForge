package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AlgoSignal
import com.example.model.SignalDirection
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanBg
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBg
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import java.util.Locale

@Composable
fun SignalCard(
    signal: AlgoSignal?,
    isAutoTradingActive: Boolean,
    onExecuteManual: (SignalDirection) -> Unit,
    onViewAllSignals: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TerminalCard)
            .border(
                1.dp,
                if (signal != null) {
                    if (signal.direction == SignalDirection.CALL_BUY) NeonGreen.copy(alpha = 0.5f) else NeonRed.copy(alpha = 0.5f)
                } else TerminalBorder,
                RoundedCornerShape(14.dp)
            )
            .padding(14.dp)
            .testTag("signal_card_container")
    ) {
        if (signal != null) {
            val isCall = signal.direction == SignalDirection.CALL_BUY
            val accentColor = if (isCall) NeonGreen else NeonRed
            val accentBg = if (isCall) NeonGreenBg else NeonRedBg

            Column {
                // Header: formation badge + view history link
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                        )
                        Text(
                            text = "${signal.timeframe.label.uppercase()} FORMATION DETECTED",
                            color = accentColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Text(
                        text = "History (${signal.confidence}%)",
                        color = ElectricCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable(onClick = onViewAllSignals)
                            .testTag("view_signals_history")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Direction and confidence banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentBg)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = if (isCall) "CALL" else "PUT",
                            tint = accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = if (isCall) "CALL (HIGHER / BUY)" else "PUT (LOWER / SELL)",
                                color = TextWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = signal.patternName,
                                color = TextGray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Win rate probability badge
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${signal.confidence}%",
                            color = accentColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Win Probability",
                            color = TextDarkGray,
                            fontSize = 9.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Pattern analysis description
                Text(
                    text = signal.patternDescription,
                    color = TextGray,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Parameters row: Entry, Expiry, Bias
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ParamPill(label = "Entry Ref", value = String.format(Locale.US, "%.2f", signal.entryPrice))
                    ParamPill(label = "Expiry", value = "${signal.suggestedExpirySeconds}s")
                    ParamPill(label = "RSI (14)", value = String.format(Locale.US, "%.1f", signal.rsiValue))
                    ParamPill(label = "Execution", value = if (isAutoTradingActive) "AUTO ARMED" else "MANUAL")
                }
            }
        } else {
            // Scanning idle state
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Radar,
                        contentDescription = "Scanning",
                        tint = ElectricCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Scanning 2-Minute Candle Formations...",
                        color = TextWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Algorithmic pattern recognition running on live OTC tick stream.",
                        color = TextDarkGray,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ParamPill(label: String, value: String) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = label, color = TextDarkGray, fontSize = 9.sp)
        Text(text = value, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
