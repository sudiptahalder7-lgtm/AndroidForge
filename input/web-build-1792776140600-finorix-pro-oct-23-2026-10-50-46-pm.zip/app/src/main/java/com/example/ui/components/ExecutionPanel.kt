package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketPair
import com.example.model.SignalDirection
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDark
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonRedDark
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalCard
import com.example.ui.theme.TerminalSurfaceVariant
import com.example.ui.theme.TextDarkGray
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import java.util.Locale

@Composable
fun ExecutionPanel(
    pair: MarketPair,
    selectedStake: Double,
    buyerSentimentPercent: Int,
    activeOrderCount: Int,
    onStakeSelected: (Double) -> Unit,
    onExecuteTrade: (SignalDirection) -> Unit,
    onViewHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stakeOptions = listOf(10.0, 25.0, 50.0, 100.0, 250.0)
    val potentialProfit = selectedStake * (pair.payoutPercentage / 100.0)
    val totalReturn = selectedStake + potentialProfit

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TerminalCard)
            .border(1.dp, TerminalBorder, RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("execution_panel_container")
    ) {
        // Stake Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "INVESTMENT STAKE",
                color = TextGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )

            if (activeOrderCount > 0) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onViewHistory)
                        .background(ElectricCyan.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "$activeOrderCount ACTIVE ORDER${if (activeOrderCount > 1) "S" else ""}",
                        color = ElectricCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Stake quick buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            stakeOptions.forEach { stake ->
                val isSelected = selectedStake == stake
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricCyan else TerminalSurfaceVariant)
                        .clickable { onStakeSelected(stake) }
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$${stake.toInt()}",
                        color = if (isSelected) Color(0xFF0B0E14) else TextWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Market Sentiment Indicator (Buyers vs Sellers)
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "BULLS $buyerSentimentPercent%",
                    color = NeonGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "BEARS ${100 - buyerSentimentPercent}%",
                    color = NeonRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .weight((buyerSentimentPercent / 100f).coerceIn(0.1f, 0.9f))
                        .height(4.dp)
                        .background(NeonGreen)
                )
                Box(
                    modifier = Modifier
                        .weight(((100 - buyerSentimentPercent) / 100f).coerceIn(0.1f, 0.9f))
                        .height(4.dp)
                        .background(NeonRed)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Two Big Execution Buttons: CALL (GREEN) & PUT (RED)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // CALL BUTTON
            Button(
                onClick = { onExecuteTrade(SignalDirection.CALL_BUY) },
                modifier = Modifier
                    .weight(1f)
                    .height(60.dp)
                    .testTag("call_buy_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonGreenDark,
                    contentColor = TextWhite
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "CALL",
                        tint = TextWhite,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "HIGHER",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextWhite
                        )
                        Text(
                            text = "+$${String.format(Locale.US, "%.1f", potentialProfit)} (${pair.payoutPercentage}%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD1FAE5)
                        )
                    }
                }
            }

            // PUT BUTTON
            Button(
                onClick = { onExecuteTrade(SignalDirection.PUT_SELL) },
                modifier = Modifier
                    .weight(1f)
                    .height(60.dp)
                    .testTag("put_sell_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonRedDark,
                    contentColor = TextWhite
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "PUT",
                        tint = TextWhite,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "LOWER",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextWhite
                        )
                        Text(
                            text = "+$${String.format(Locale.US, "%.1f", potentialProfit)} (${pair.payoutPercentage}%)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFE4E6)
                        )
                    }
                }
            }
        }
    }
}
