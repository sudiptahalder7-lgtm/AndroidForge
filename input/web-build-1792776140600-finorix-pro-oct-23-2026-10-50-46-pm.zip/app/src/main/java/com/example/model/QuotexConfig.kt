package com.example.model

data class QuotexConfig(
    val isConnected: Boolean = true,
    val isDemoAccount: Boolean = true,
    val balance: Double = 14250.80,
    val apiKey: String = "qx_live_sec_89a42f88e1c",
    val serverName: String = "London-OTC-Gateway-02",
    val pingMs: Int = 26,
    val autoTradingEnabled: Boolean = true,
    val minConfidenceThreshold: Int = 85,
    val defaultStake: Double = 50.0,
    val martingaleEnabled: Boolean = true,
    val martingaleMultiplier: Double = 2.0,
    val maxMartingaleSteps: Int = 2,
    val dailyProfitGoal: Double = 500.0,
    val dailyStopLoss: Double = 250.0,
    val preferredTimeframe: TimeFrame = TimeFrame.MIN_2
)
