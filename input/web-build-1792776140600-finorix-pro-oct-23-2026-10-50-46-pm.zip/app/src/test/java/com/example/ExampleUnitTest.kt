package com.example

import com.example.engine.MarketEngine
import com.example.engine.PatternDetector
import com.example.engine.QuotexTradingService
import com.example.model.Candle
import com.example.model.SignalDirection
import com.example.model.TimeFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testMarketEngineCandlesAndTicks() {
        val engine = MarketEngine()
        assertEquals("USD/COP OTC", engine.selectedPair.value.symbol)
        assertTrue(engine.candles.value.isNotEmpty())

        val tickCandle = engine.onTick()
        assertNotNull(tickCandle)
        assertTrue(tickCandle.high >= tickCandle.low)
    }

    @Test
    fun testShootingStarRejectionPatternDetection() {
        val candles = listOf(
            Candle(1000L, 3210.0, 3212.0, 3209.0, 3211.0, 100.0),
            Candle(2000L, 3211.0, 3213.0, 3210.5, 3212.5, 120.0),
            Candle(3000L, 3212.5, 3214.0, 3212.0, 3213.5, 150.0),
            Candle(4000L, 3213.5, 3215.0, 3213.0, 3214.5, 180.0),
            // Shooting star with long upper wick and negligible lower wick
            Candle(5000L, 3214.5, 3218.0, 3214.45, 3214.8, 250.0)
        )

        val signal = PatternDetector.analyzeCandles(
            candles = candles,
            symbol = "USD/COP OTC",
            timeframe = TimeFrame.MIN_2,
            rsi = 74.0,
            ema9 = 3213.0,
            ema21 = 3214.0
        )

        assertNotNull(signal)
        assertEquals(SignalDirection.PUT_SELL, signal?.direction)
        assertTrue(signal?.confidence ?: 0 >= 85)
    }

    @Test
    fun testQuotexTradingServiceExecutionAndMartingale() {
        val service = QuotexTradingService()
        val initialBalance = service.config.value.balance

        val order = service.executeOrder(
            pairSymbol = "USD/COP OTC",
            direction = SignalDirection.CALL_BUY,
            currentPrice = 3213.90,
            payoutRate = 92,
            durationSeconds = 1,
            customStake = 50.0
        )

        assertNotNull(order)
        assertEquals(1, service.activeOrders.value.size)
        assertEquals(initialBalance - 50.0, service.config.value.balance, 0.01)

        // Resolve order with higher price -> Win
        Thread.sleep(1100)
        service.onTickCheckOrders(3214.50, "USD/COP OTC")

        assertEquals(0, service.activeOrders.value.size)
        assertEquals(1, service.tradeHistory.value.size)
        val expectedProfit = 50.0 * 0.92
        assertEquals(initialBalance + expectedProfit, service.config.value.balance, 0.01)
    }
}
