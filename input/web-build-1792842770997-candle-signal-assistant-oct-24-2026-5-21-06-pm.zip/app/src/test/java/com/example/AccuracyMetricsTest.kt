package com.example

import com.example.model.AccuracyReport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AccuracyMetricsTest {

    @Test
    fun testUnvalidatedWhenSampleSizeBelowThreshold() {
        val report = AccuracyReport.calculate(
            total = 20,
            noSignalCount = 5,
            upPredictionsLabeled = 8,
            upCorrect = 6,
            downPredictionsLabeled = 5,
            downCorrect = 3,
            dojiCount = 2
        )

        // Labeled sample size = 8 + 5 = 13 < 30
        assertFalse(report.isStatisticallyValidated)
        assertNull(report.ciLowerPct)
        assertNull(report.ciUpperPct)
        assertEquals(13, report.labeledCount)
        assertEquals(9, report.correctDirectionalCount)
        assertEquals(75.0, report.coveragePct, 0.1) // 15 directional out of 20 = 75%
    }

    @Test
    fun testValidatedWithWilsonIntervalWhenSampleAtOrAbove30() {
        val report = AccuracyReport.calculate(
            total = 50,
            noSignalCount = 10,
            upPredictionsLabeled = 20,
            upCorrect = 14,
            downPredictionsLabeled = 20,
            downCorrect = 12,
            dojiCount = 0
        )

        // Directional labeled = 40 >= 30
        assertTrue(report.isStatisticallyValidated)
        assertNotNull(report.directionalAccuracyPct)
        assertEquals(65.0, report.directionalAccuracyPct!!, 0.1) // 26 / 40 = 65%

        // Wilson interval for p=0.65, n=40
        assertNotNull(report.ciLowerPct)
        assertNotNull(report.ciUpperPct)
        assertTrue(report.ciLowerPct!! in 49.0..52.0)
        assertTrue(report.ciUpperPct!! in 77.0..80.0)
        assertTrue(report.ciLowerPct!! < report.directionalAccuracyPct!!)
        assertTrue(report.ciUpperPct!! > report.directionalAccuracyPct!!)
    }

    @Test
    fun testDojiTreatedSeparately() {
        val report = AccuracyReport.calculate(
            total = 35,
            noSignalCount = 5,
            upPredictionsLabeled = 15,
            upCorrect = 10,
            downPredictionsLabeled = 15,
            downCorrect = 10,
            dojiCount = 5
        )

        assertEquals(5, report.dojiCount)
        assertEquals(30, report.labeledCount)
        assertEquals(20, report.correctDirectionalCount)
        assertEquals(10, report.incorrectDirectionalCount)
    }
}
