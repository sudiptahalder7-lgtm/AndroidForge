package com.example

import com.example.cv.ChartImageProcessor
import com.example.cv.SyntheticChartGenerator
import com.example.cv.SyntheticPattern
import com.example.model.CandleDirection
import com.example.model.DataQuality
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ChartImageProcessorTest {

    private val processor = ChartImageProcessor()

    @Test
    fun testSyntheticHammerPatternDetection() {
        val bitmap = SyntheticChartGenerator.generateChartBitmap(
            pattern = SyntheticPattern.BULLISH_HAMMER_AT_SUPPORT,
            width = 600,
            height = 400
        )

        val processed = processor.processBitmap(bitmap, com.example.model.ChartRegion(0f, 0f, 1f, 1f))

        assertEquals(DataQuality.GOOD, processed.dataQuality)
        assertTrue("Expected at least 4 candles, found ${processed.candles.size}", processed.candles.size >= 4)

        val lastCandle = processed.candles.last()
        assertTrue("Last candle should have high lower wick ratio: ${lastCandle.lowerWickRatio}", lastCandle.lowerWickRatio >= 0.40f)
    }

    @Test
    fun testSyntheticNoiseRejection() {
        val bitmap = SyntheticChartGenerator.generateChartBitmap(
            pattern = SyntheticPattern.AMBIGUOUS_NOISE,
            width = 600,
            height = 400
        )

        val processed = processor.processBitmap(bitmap)
        assertEquals(DataQuality.INVALID, processed.dataQuality)
        assertTrue(processed.candles.size < 3)
    }
}
