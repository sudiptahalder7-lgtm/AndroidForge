package com.example

import com.example.cv.ProcessedChart
import com.example.engine.SignalEngine
import com.example.model.AccuracyReport
import com.example.model.Candle
import com.example.model.CandleDirection
import com.example.model.DataQuality
import com.example.model.DeadlineStatus
import com.example.model.SignalDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SignalEngineTest {

    private val engine = SignalEngine()

    private fun createCandle(
        index: Int,
        direction: CandleDirection,
        bodyRatio: Float = 0.6f,
        upperWickRatio: Float = 0.2f,
        lowerWickRatio: Float = 0.2f,
        openY: Float = 100f,
        closeY: Float = 80f,
        highY: Float = 70f,
        lowY: Float = 110f
    ): Candle {
        return Candle(
            index = index,
            centerX = (index + 1) * 30f,
            openY = openY,
            highY = highY,
            lowY = lowY,
            closeY = closeY,
            bodyTop = minOf(openY, closeY),
            bodyBottom = maxOf(openY, closeY),
            wickTop = highY,
            wickBottom = lowY,
            direction = direction,
            bodyLength = kotlin.math.abs(closeY - openY),
            totalRange = lowY - highY,
            upperWick = minOf(openY, closeY) - highY,
            lowerWick = lowY - maxOf(openY, closeY),
            bodyToRangeRatio = bodyRatio,
            upperWickRatio = upperWickRatio,
            lowerWickRatio = lowerWickRatio
        )
    }

    @Test
    fun testBullishPinbarHammerGeneratesUpSignal() {
        val candles = listOf(
            createCandle(0, CandleDirection.BEARISH),
            createCandle(1, CandleDirection.BEARISH),
            createCandle(2, CandleDirection.BEARISH),
            // Hammer: lower wick >= 50%, small body <= 40%, upper wick <= 20%
            createCandle(
                index = 3,
                direction = CandleDirection.BULLISH,
                bodyRatio = 0.25f,
                upperWickRatio = 0.10f,
                lowerWickRatio = 0.65f,
                openY = 120f,
                closeY = 115f,
                highY = 113f,
                lowY = 140f
            )
        )

        val chart = ProcessedChart(
            candles = candles,
            supportLevelsY = listOf(140f),
            resistanceLevelsY = emptyList(),
            dataQuality = DataQuality.GOOD,
            diagnosticMessage = "OK"
        )

        val result = engine.evaluate(chart)
        assertEquals(SignalDecision.UP, result.signal)
        assertTrue(result.featureSummary.contains("Bullish pinbar"))
    }

    @Test
    fun testBearishShootingStarGeneratesDownSignal() {
        val candles = listOf(
            createCandle(0, CandleDirection.BULLISH),
            createCandle(1, CandleDirection.BULLISH),
            createCandle(2, CandleDirection.BULLISH),
            // Shooting Star: upper wick >= 50%, small body <= 40%, lower wick <= 20%
            createCandle(
                index = 3,
                direction = CandleDirection.BEARISH,
                bodyRatio = 0.25f,
                upperWickRatio = 0.65f,
                lowerWickRatio = 0.10f,
                openY = 60f,
                closeY = 65f,
                highY = 40f,
                lowY = 68f
            )
        )

        val chart = ProcessedChart(
            candles = candles,
            supportLevelsY = emptyList(),
            resistanceLevelsY = listOf(40f),
            dataQuality = DataQuality.GOOD,
            diagnosticMessage = "OK"
        )

        val result = engine.evaluate(chart)
        assertEquals(SignalDecision.DOWN, result.signal)
        assertTrue(result.featureSummary.contains("Bearish shooting star"))
    }

    @Test
    fun testDojiGeneratesNoSignal() {
        val candles = listOf(
            createCandle(0, CandleDirection.BULLISH),
            createCandle(1, CandleDirection.BEARISH),
            createCandle(2, CandleDirection.BULLISH),
            // Doji: bodyRatio <= 0.15f
            createCandle(
                index = 3,
                direction = CandleDirection.DOJI,
                bodyRatio = 0.08f,
                upperWickRatio = 0.46f,
                lowerWickRatio = 0.46f
            )
        )

        val chart = ProcessedChart(
            candles = candles,
            supportLevelsY = emptyList(),
            resistanceLevelsY = emptyList(),
            dataQuality = DataQuality.GOOD,
            diagnosticMessage = "OK"
        )

        val result = engine.evaluate(chart)
        assertEquals(SignalDecision.NO_SIGNAL, result.signal)
        assertTrue(result.featureSummary.contains("Doji indecision"))
    }

    @Test
    fun testConfidenceIsNullWhenUnvalidated() {
        val candles = listOf(
            createCandle(0, CandleDirection.BEARISH),
            createCandle(1, CandleDirection.BEARISH),
            createCandle(2, CandleDirection.BEARISH),
            createCandle(3, CandleDirection.BULLISH, bodyRatio = 0.25f, upperWickRatio = 0.10f, lowerWickRatio = 0.65f)
        )

        val chart = ProcessedChart(
            candles = candles,
            supportLevelsY = emptyList(),
            resistanceLevelsY = emptyList(),
            dataQuality = DataQuality.GOOD,
            diagnosticMessage = "OK"
        )

        // Null historical report -> must return null confidence ("Not validated")
        val result = engine.evaluate(chart, historicalAccuracyReport = null)
        assertNull(result.confidence)

        // Insufficient sample report (N=12 < 30) -> must still return null confidence
        val unvalidatedReport = AccuracyReport.calculate(
            total = 12,
            noSignalCount = 2,
            upPredictionsLabeled = 5,
            upCorrect = 4,
            downPredictionsLabeled = 5,
            downCorrect = 3,
            dojiCount = 0
        )
        val resultUnvalidated = engine.evaluate(chart, historicalAccuracyReport = unvalidatedReport)
        assertNull(resultUnvalidated.confidence)

        // Validated report (N=40 >= 30) -> confidence returned
        val validatedReport = AccuracyReport.calculate(
            total = 50,
            noSignalCount = 10,
            upPredictionsLabeled = 20,
            upCorrect = 14,
            downPredictionsLabeled = 20,
            downCorrect = 13,
            dojiCount = 0
        )
        val resultValidated = engine.evaluate(chart, historicalAccuracyReport = validatedReport)
        assertNotNull(resultValidated.confidence)
        assertEquals(0.675, resultValidated.confidence!!, 0.01)
    }

    @Test
    fun testLateDeadlineFlagged() {
        val candles = listOf(
            createCandle(0, CandleDirection.BEARISH),
            createCandle(1, CandleDirection.BEARISH),
            createCandle(2, CandleDirection.BEARISH),
            createCandle(3, CandleDirection.BULLISH, bodyRatio = 0.25f, upperWickRatio = 0.10f, lowerWickRatio = 0.65f)
        )

        val chart = ProcessedChart(
            candles = candles,
            supportLevelsY = emptyList(),
            resistanceLevelsY = emptyList(),
            dataQuality = DataQuality.GOOD,
            diagnosticMessage = "OK"
        )

        val result = engine.evaluate(chart, deadlineStatus = DeadlineStatus.LATE, latencyMs = 1350L)
        assertEquals(DeadlineStatus.LATE, result.deadlineStatus)
        assertTrue(result.featureSummary.startsWith("[LATE SIGNAL]"))
    }
}
