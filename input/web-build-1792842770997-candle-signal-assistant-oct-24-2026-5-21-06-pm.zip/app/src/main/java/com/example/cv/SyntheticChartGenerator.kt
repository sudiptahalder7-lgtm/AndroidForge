package com.example.cv

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min

enum class SyntheticPattern {
    BULLISH_HAMMER_AT_SUPPORT,
    BEARISH_SHOOTING_STAR_AT_RESISTANCE,
    BULLISH_ENGULFING,
    BEARISH_ENGULFING,
    DOJI_INDECISION,
    BULLISH_MOMENTUM_TREND,
    BEARISH_MOMENTUM_TREND,
    AMBIGUOUS_NOISE
}

/**
 * Generates synthetic Quotex-style 1-minute candlestick chart frames for offline testing,
 * algorithmic validation, and interactive lab exploration.
 */
object SyntheticChartGenerator {

    private const val DEFAULT_WIDTH = 720
    private const val DEFAULT_HEIGHT = 480

    fun generateChartBitmap(
        pattern: SyntheticPattern,
        width: Int = DEFAULT_WIDTH,
        height: Int = DEFAULT_HEIGHT
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Quotex Dark theme background
        val bgPaint = Paint().apply {
            color = Color.rgb(13, 17, 27) // #0D111B
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Subtle chart grid lines
        val gridPaint = Paint().apply {
            color = Color.argb(35, 255, 255, 255)
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        for (y in 50 until height step 60) {
            canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), gridPaint)
        }
        for (x in 60 until width step 80) {
            canvas.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), gridPaint)
        }

        if (pattern == SyntheticPattern.AMBIGUOUS_NOISE) {
            // Render non-chart noise
            val noisePaint = Paint().apply { color = Color.rgb(45, 55, 72) }
            canvas.drawCircle(width / 2f, height / 2f, 80f, noisePaint)
            return bitmap
        }

        // Paints for Bullish and Bearish candlesticks
        val bullColor = Color.rgb(0, 230, 118) // #00E676 vibrant green
        val bearColor = Color.rgb(255, 61, 113) // #FF3D71 vibrant red
        val wickBullPaint = Paint().apply {
            color = bullColor
            strokeWidth = 2.5f
            style = Paint.Style.STROKE
        }
        val wickBearPaint = Paint().apply {
            color = bearColor
            strokeWidth = 2.5f
            style = Paint.Style.STROKE
        }
        val bodyBullPaint = Paint().apply {
            color = bullColor
            style = Paint.Style.FILL
        }
        val bodyBearPaint = Paint().apply {
            color = bearColor
            style = Paint.Style.FILL
        }

        // Horizontal Key Level lines
        val supportY = height * 0.75f
        val resistanceY = height * 0.25f

        val supportPaint = Paint().apply {
            color = Color.argb(90, 100, 140, 180)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        val resistancePaint = Paint().apply {
            color = Color.argb(90, 100, 140, 180)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }

        if (pattern == SyntheticPattern.BULLISH_HAMMER_AT_SUPPORT) {
            canvas.drawLine(0f, supportY, width.toFloat(), supportY, supportPaint)
        } else if (pattern == SyntheticPattern.BEARISH_SHOOTING_STAR_AT_RESISTANCE) {
            canvas.drawLine(0f, resistanceY, width.toFloat(), resistanceY, resistancePaint)
        }

        // Candle data representation: (open, high, low, close)
        // High is smaller Y in canvas, Low is larger Y in canvas
        val candleSpecs: List<FloatArray> = when (pattern) {
            SyntheticPattern.BULLISH_HAMMER_AT_SUPPORT -> listOf(
                // 1. Bearish trend down into support
                floatArrayOf(height * 0.35f, height * 0.30f, height * 0.48f, height * 0.45f),
                floatArrayOf(height * 0.46f, height * 0.42f, height * 0.58f, height * 0.55f),
                floatArrayOf(height * 0.56f, height * 0.53f, height * 0.68f, height * 0.65f),
                floatArrayOf(height * 0.66f, height * 0.62f, height * 0.74f, height * 0.72f),
                // 5. Classic Hammer at Support: opens near 0.66, tests support at 0.78 with huge lower wick, closes at 0.64
                floatArrayOf(height * 0.67f, height * 0.63f, supportY + 15f, height * 0.64f)
            )

            SyntheticPattern.BEARISH_SHOOTING_STAR_AT_RESISTANCE -> listOf(
                // 1. Bullish trend up into resistance
                floatArrayOf(height * 0.65f, height * 0.52f, height * 0.68f, height * 0.55f),
                floatArrayOf(height * 0.54f, height * 0.42f, height * 0.57f, height * 0.45f),
                floatArrayOf(height * 0.44f, height * 0.32f, height * 0.46f, height * 0.35f),
                floatArrayOf(height * 0.34f, height * 0.24f, height * 0.36f, height * 0.26f),
                // 5. Shooting Star at Resistance: tests resistance at 0.22, long upper wick, closes near 0.34
                floatArrayOf(height * 0.30f, resistanceY - 20f, height * 0.37f, height * 0.35f)
            )

            SyntheticPattern.BULLISH_ENGULFING -> listOf(
                floatArrayOf(height * 0.45f, height * 0.40f, height * 0.55f, height * 0.52f),
                floatArrayOf(height * 0.53f, height * 0.48f, height * 0.62f, height * 0.60f),
                // Prior small red candle
                floatArrayOf(height * 0.61f, height * 0.58f, height * 0.67f, height * 0.66f),
                // Engulfing big green candle
                floatArrayOf(height * 0.68f, height * 0.45f, height * 0.70f, height * 0.47f)
            )

            SyntheticPattern.BEARISH_ENGULFING -> listOf(
                floatArrayOf(height * 0.55f, height * 0.45f, height * 0.60f, height * 0.48f),
                floatArrayOf(height * 0.47f, height * 0.38f, height * 0.50f, height * 0.40f),
                // Prior small green candle
                floatArrayOf(height * 0.39f, height * 0.32f, height * 0.42f, height * 0.34f),
                // Engulfing big red candle
                floatArrayOf(height * 0.33f, height * 0.31f, height * 0.58f, height * 0.55f)
            )

            SyntheticPattern.DOJI_INDECISION -> listOf(
                floatArrayOf(height * 0.50f, height * 0.44f, height * 0.56f, height * 0.52f),
                floatArrayOf(height * 0.52f, height * 0.46f, height * 0.58f, height * 0.50f),
                floatArrayOf(height * 0.50f, height * 0.42f, height * 0.60f, height * 0.54f),
                // Neutral Doji with huge symmetric wicks and microscopic body
                floatArrayOf(height * 0.50f, height * 0.30f, height * 0.70f, height * 0.502f)
            )

            SyntheticPattern.BULLISH_MOMENTUM_TREND -> listOf(
                floatArrayOf(height * 0.75f, height * 0.62f, height * 0.77f, height * 0.64f),
                floatArrayOf(height * 0.63f, height * 0.50f, height * 0.65f, height * 0.52f),
                floatArrayOf(height * 0.51f, height * 0.38f, height * 0.53f, height * 0.40f),
                floatArrayOf(height * 0.39f, height * 0.25f, height * 0.41f, height * 0.27f)
            )

            SyntheticPattern.BEARISH_MOMENTUM_TREND -> listOf(
                floatArrayOf(height * 0.25f, height * 0.23f, height * 0.38f, height * 0.36f),
                floatArrayOf(height * 0.37f, height * 0.35f, height * 0.50f, height * 0.48f),
                floatArrayOf(height * 0.49f, height * 0.47f, height * 0.62f, height * 0.60f),
                floatArrayOf(height * 0.61f, height * 0.59f, height * 0.74f, height * 0.72f)
            )

            SyntheticPattern.AMBIGUOUS_NOISE -> emptyList()
        }

        val totalCandles = candleSpecs.size
        val candleSpacing = width / (totalCandles + 1)
        val candleBodyWidth = candleSpacing * 0.45f

        for ((i, spec) in candleSpecs.withIndex()) {
            val cx = (i + 1) * candleSpacing.toFloat()
            val open = spec[0]
            val high = spec[1]
            val low = spec[2]
            val close = spec[3]

            val isBullish = close < open // Canvas Y is inverted: lower Y is higher price!
            val wickPaint = if (isBullish) wickBullPaint else wickBearPaint
            val bodyPaint = if (isBullish) bodyBullPaint else bodyBearPaint

            // Draw wick as a thin filled vertical rect (guarantees pixel rasterization across all engines)
            val wickHalfWidth = 1.5f
            canvas.drawRect(cx - wickHalfWidth, high, cx + wickHalfWidth, low, bodyPaint)

            // Draw body
            val top = min(open, close)
            val bottom = max(open, close)
            val left = cx - candleBodyWidth / 2f
            val right = cx + candleBodyWidth / 2f
            canvas.drawRect(left, top, right, bottom, bodyPaint)
        }

        return bitmap
    }
}
