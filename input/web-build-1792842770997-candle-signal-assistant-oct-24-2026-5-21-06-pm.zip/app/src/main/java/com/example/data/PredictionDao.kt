package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PredictionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(prediction: PredictionEntity)

    @Update
    suspend fun update(prediction: PredictionEntity)

    @Query("SELECT * FROM predictions ORDER BY timestamp DESC")
    fun getAllFlow(): Flow<List<PredictionEntity>>

    @Query("SELECT * FROM predictions ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<PredictionEntity>

    @Query("SELECT * FROM predictions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): PredictionEntity?

    @Query("UPDATE predictions SET actualOutcome = :outcome, isCorrect = :isCorrect WHERE id = :id")
    suspend fun updateOutcome(id: String, outcome: String, isCorrect: Boolean?)

    @Query("SELECT COUNT(*) FROM predictions")
    suspend fun getTotalCount(): Int

    @Query("SELECT COUNT(*) FROM predictions WHERE signal != 'NO_SIGNAL'")
    suspend fun getDirectionalCount(): Int

    @Query("SELECT COUNT(*) FROM predictions WHERE actualOutcome IS NOT NULL")
    suspend fun getLabeledCount(): Int

    @Query("SELECT COUNT(*) FROM predictions WHERE isCorrect = 1")
    suspend fun getCorrectCount(): Int

    @Query("DELETE FROM predictions")
    suspend fun clearAll()
}
