package com.example.service

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.example.cv.ChartImageProcessor
import com.example.cv.ProcessedChart
import com.example.cv.SyntheticChartGenerator
import com.example.cv.SyntheticPattern
import com.example.data.AppDatabase
import com.example.data.PredictionRepository
import com.example.engine.SignalEngine
import com.example.model.ChartRegion
import com.example.model.DataQuality
import com.example.model.DeadlineStatus
import com.example.model.SignalDecision
import com.example.model.SignalResult
import com.example.timing.CandleTimerScheduler
import com.example.timing.TimingState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Central singleton coordinating screen capture, timing triggers, image processing,
 * signal engine evaluation, Room persistence, and floating overlay updates.
 */
class SignalCoordinator private constructor(context: Context) {

    private val applicationContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val db = AppDatabase.getInstance(applicationContext)
    val repository = PredictionRepository(db.predictionDao())

    private val imageProcessor = ChartImageProcessor()
    private val signalEngine = SignalEngine()

    // Observables
    private val _isCaptureActive = MutableStateFlow(false)
    val isCaptureActive: StateFlow<Boolean> = _isCaptureActive.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    private val _currentResult = MutableStateFlow(
        SignalResult(
            signal = SignalDecision.NO_SIGNAL,
            confidence = null,
            featureSummary = "Ready for chart observation. Start capture or run simulation.",
            dataQuality = DataQuality.GOOD,
            deadlineStatus = DeadlineStatus.NOT_SCHEDULED,
            observedCandlesCount = 0,
            latencyMs = 0L
        )
    )
    val currentResult: StateFlow<SignalResult> = _currentResult.asStateFlow()

    private val _latestChart = MutableStateFlow<ProcessedChart?>(null)
    val latestChart: StateFlow<ProcessedChart?> = _latestChart.asStateFlow()

    private val _chartRegion = MutableStateFlow(ChartRegion())
    val chartRegion: StateFlow<ChartRegion> = _chartRegion.asStateFlow()

    // Candle Timing Scheduler
    val timerScheduler = CandleTimerScheduler(
        onTriggerFinalSampling = {
            triggerFinalWindowSampling()
        },
        onPublishDeadlineSignal = { deadlineStatus, latency ->
            publishDeadlineSignal(deadlineStatus, latency)
        }
    )
    val timingState: StateFlow<TimingState> = timerScheduler.timingState

    init {
        timerScheduler.start(scope)
    }

    fun setCaptureActive(active: Boolean) {
        _isCaptureActive.value = active
    }

    fun setOverlayActive(active: Boolean) {
        _isOverlayActive.value = active
    }

    fun updateChartRegion(region: ChartRegion) {
        _chartRegion.value = region
    }

    fun syncCandleTimer() {
        timerScheduler.syncWithCandleStart()
    }

    /**
     * Analyzes an incoming bitmap frame from MediaProjection or synthetic generator.
     */
    fun analyzeFrame(bitmap: Bitmap, deadlineStatus: DeadlineStatus = DeadlineStatus.ON_TIME) {
        scope.launch {
            val startTime = SystemClock.elapsedRealtime()
            val region = _chartRegion.value
            val processed = imageProcessor.processBitmap(bitmap, region)
            _latestChart.value = processed

            val accuracyReport = repository.computeAccuracyReport()
            val latency = SystemClock.elapsedRealtime() - startTime

            val result = signalEngine.evaluate(
                chart = processed,
                deadlineStatus = deadlineStatus,
                latencyMs = latency,
                historicalAccuracyReport = accuracyReport
            )

            _currentResult.value = result

            // Persist actionable signals or labeled opportunities into database
            if (result.signal != SignalDecision.NO_SIGNAL || processed.candles.isNotEmpty()) {
                repository.savePrediction(result)
            }
        }
    }

    /**
     * Executes synthetic simulation with a known pattern for testing and calibration.
     */
    fun runSyntheticTest(pattern: SyntheticPattern) {
        scope.launch {
            val syntheticBitmap = SyntheticChartGenerator.generateChartBitmap(pattern)
            analyzeFrame(syntheticBitmap, DeadlineStatus.ON_TIME)
        }
    }

    private fun triggerFinalWindowSampling() {
        // Called when remaining seconds enter 7s..2s window
        // In real capture mode, ScreenCaptureService pulls latest frame
        ScreenCaptureService.instance?.requestImmediateCapture()
    }

    private fun publishDeadlineSignal(deadlineStatus: DeadlineStatus, latency: Long) {
        // T-1s publication
        ScreenCaptureService.instance?.requestImmediateCapture(deadlineStatus)
    }

    companion object {
        @Volatile
        private var INSTANCE: SignalCoordinator? = null

        fun getInstance(context: Context): SignalCoordinator {
            return INSTANCE ?: synchronized(this) {
                val instance = SignalCoordinator(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
