package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import com.example.service.SignalCoordinator
import com.example.ui.screens.AccuracyLabScreen
import com.example.ui.screens.ChartLabScreen
import com.example.ui.screens.LiveAssistantScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CandleSignalAssistantTheme
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldBullish
import com.example.ui.theme.SlateLight

enum class AppTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    LIVE("Live Assistant", Icons.AutoMirrored.Filled.TrendingUp, Icons.AutoMirrored.Outlined.TrendingUp, "nav_tab_live"),
    CHART_LAB("Chart Lab", Icons.Filled.BugReport, Icons.Outlined.BugReport, "nav_tab_chart_lab"),
    ACCURACY_LAB("Accuracy Lab", Icons.Filled.Assessment, Icons.Outlined.Assessment, "nav_tab_accuracy_lab"),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_tab_settings")
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val coordinator = SignalCoordinator.getInstance(this)

        setContent {
            CandleSignalAssistantTheme {
                var selectedTab by remember { mutableStateOf(AppTab.LIVE) }

                // Back navigation handling: return to LIVE tab if in secondary tab
                BackHandler(enabled = selectedTab != AppTab.LIVE) {
                    selectedTab = AppTab.LIVE
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing),
                    containerColor = DarkObsidian,
                    bottomBar = {
                        NavigationBar(
                            containerColor = DarkSurface,
                            modifier = Modifier
                                .windowInsetsPadding(WindowInsets.navigationBars)
                                .testTag("main_bottom_nav")
                        ) {
                            AppTab.values().forEach { tab ->
                                val isSelected = selectedTab == tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { selectedTab = tab },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.title
                                        )
                                    },
                                    label = { Text(tab.title, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = EmeraldBullish,
                                        selectedTextColor = EmeraldBullish,
                                        indicatorColor = EmeraldBullish.copy(alpha = 0.15f),
                                        unselectedIconColor = SlateLight,
                                        unselectedTextColor = SlateLight
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    val contentModifier = Modifier.padding(innerPadding)
                    when (selectedTab) {
                        AppTab.LIVE -> LiveAssistantScreen(coordinator = coordinator, modifier = contentModifier)
                        AppTab.CHART_LAB -> ChartLabScreen(coordinator = coordinator, modifier = contentModifier)
                        AppTab.ACCURACY_LAB -> AccuracyLabScreen(coordinator = coordinator, modifier = contentModifier)
                        AppTab.SETTINGS -> SettingsScreen(modifier = contentModifier)
                    }
                }
            }
        }
    }
}
