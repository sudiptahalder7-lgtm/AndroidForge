package com.example.engine

/**
 * Tunable thresholds for rule-based 1-minute candlestick signal engine.
 */
data class StrategyConfig(
    val minCandleCount: Int = 4,
    val pinbarWickRatioThreshold: Float = 0.50f,
    val pinbarMaxOpposingWickRatio: Float = 0.20f,
    val pinbarMaxBodyRatio: Float = 0.40f,
    val engulfingMultiplier: Float = 1.15f,
    val momentumMinBodyRatio: Float = 0.65f,
    val keyLevelTolerancePx: Float = 25f,
    val lateToleranceMs: Long = 1200L
)
