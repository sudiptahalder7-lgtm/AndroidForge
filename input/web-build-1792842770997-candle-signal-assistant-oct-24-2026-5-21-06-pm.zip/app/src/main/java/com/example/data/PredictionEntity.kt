package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted record of every observed signal, latency, and user-labeled actual outcome.
 */
@Entity(tableName = "predictions")
data class PredictionEntity(
    @PrimaryKey
    val id: String,
    val timestamp: Long,
    val signal: String, // UP, DOWN, NO_SIGNAL
    val confidence: Double?, // null if unvalidated
    val featureSummary: String,
    val dataQuality: String, // GOOD, LIMITED, INVALID
    val deadlineStatus: String, // ON_TIME, LATE, MISSED
    val observedCandlesCount: Int,
    val latencyMs: Long,
    val strategyVersion: String,
    val actualOutcome: String? = null, // UP, DOWN, DOJI, null (PENDING)
    val isCorrect: Boolean? = null, // true if predicted == actualOutcome (null for NO_SIGNAL or PENDING)
    val sessionTag: String = "Default"
)
