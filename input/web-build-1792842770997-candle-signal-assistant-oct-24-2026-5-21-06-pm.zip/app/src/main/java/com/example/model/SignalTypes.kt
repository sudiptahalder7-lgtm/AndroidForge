package com.example.model

/**
 * Output signal decision for 1-minute candle.
 */
enum class SignalDecision {
    UP,
    DOWN,
    NO_SIGNAL
}

/**
 * Quality assessment of observed chart data.
 */
enum class DataQuality {
    GOOD,
    LIMITED,
    INVALID
}

/**
 * Timing compliance with the T-1s deadline.
 */
enum class DeadlineStatus {
    ON_TIME,
    LATE,
    MISSED,
    NOT_SCHEDULED
}

/**
 * Full result of a chart observation and signal evaluation cycle.
 */
data class SignalResult(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val signal: SignalDecision,
    val confidence: Double? = null, // null unless statistically validated with sufficient sample size
    val featureSummary: String,
    val dataQuality: DataQuality,
    val deadlineStatus: DeadlineStatus,
    val observedCandlesCount: Int,
    val latencyMs: Long,
    val modelVersion: String = "v1.2-rule-engine",
    val strategyVersion: String = "PA-WickRejection-v1",
    val detectedCandles: List<Candle> = emptyList(),
    val supportResistanceLevels: List<Float> = emptyList()
) {
    val isActionable: Boolean
        get() = signal != SignalDecision.NO_SIGNAL && dataQuality == DataQuality.GOOD
}
