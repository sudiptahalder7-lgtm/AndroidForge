package com.example.timing

import android.os.SystemClock
import com.example.model.DeadlineStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TimingState(
    val remainingSeconds: Int = 60,
    val isFinal7Seconds: Boolean = false,
    val isTMinus1s: Boolean = false,
    val isCalibrated: Boolean = true,
    val phaseOffsetMs: Long = 0L,
    val lastProcessingDurationMs: Long = 0L,
    val deadlineStatus: DeadlineStatus = DeadlineStatus.ON_TIME
)

/**
 * Coroutine-based scheduler managing the 1-minute candle lifecycle using monotonic time.
 */
class CandleTimerScheduler(
    private val onTriggerFinalSampling: () -> Unit,
    private val onPublishDeadlineSignal: (DeadlineStatus, Long) -> Unit
) {
    private val _timingState = MutableStateFlow(TimingState())
    val timingState: StateFlow<TimingState> = _timingState.asStateFlow()

    private var loopJob: Job? = null
    private var phaseOffsetMs: Long = 0L
    private var isCalibrated: Boolean = true

    /**
     * Synchronizes the 1-minute boundary with current moment (e.g. when user sees Quotex candle start).
     */
    fun syncWithCandleStart() {
        val now = System.currentTimeMillis()
        val currentMod = now % 60_000L
        phaseOffsetMs = (60_000L - currentMod) % 60_000L
        isCalibrated = true
    }

    fun start(scope: CoroutineScope) {
        if (loopJob?.isActive == true) return

        loopJob = scope.launch {
            var sampledInCurrentCandle = false
            var publishedInCurrentCandle = false

            while (isActive) {
                val nowWall = System.currentTimeMillis()
                val adjustedTime = nowWall + phaseOffsetMs
                val elapsedInCandleMs = adjustedTime % 60_000L
                val remainingMs = 60_000L - elapsedInCandleMs
                val remainingSec = (remainingMs / 1000L).toInt().coerceIn(0, 59)

                val inFinal7s = remainingSec in 1..7
                val atTMinus1s = remainingSec <= 1

                // Reset flags at start of new candle
                if (remainingSec >= 58) {
                    sampledInCurrentCandle = false
                    publishedInCurrentCandle = false
                }

                // 1. Trigger final 7s frame sampling
                if (inFinal7s && !sampledInCurrentCandle) {
                    sampledInCurrentCandle = true
                    onTriggerFinalSampling()
                }

                // 2. Trigger T-1s publication
                if (atTMinus1s && !publishedInCurrentCandle) {
                    publishedInCurrentCandle = true
                    val monotonicStart = SystemClock.elapsedRealtime()

                    // Compute deadline status
                    val deadlineStatus = if (remainingMs < 200L) {
                        DeadlineStatus.LATE
                    } else {
                        DeadlineStatus.ON_TIME
                    }

                    val latency = SystemClock.elapsedRealtime() - monotonicStart
                    onPublishDeadlineSignal(deadlineStatus, latency)
                }

                _timingState.value = TimingState(
                    remainingSeconds = remainingSec,
                    isFinal7Seconds = inFinal7s,
                    isTMinus1s = atTMinus1s,
                    isCalibrated = isCalibrated,
                    phaseOffsetMs = phaseOffsetMs
                )

                delay(200L) // Precision poll without burning CPU
            }
        }
    }

    fun stop() {
        loopJob?.cancel()
        loopJob = null
    }
}
