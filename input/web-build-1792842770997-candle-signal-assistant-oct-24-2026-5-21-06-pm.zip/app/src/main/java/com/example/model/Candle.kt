package com.example.model

/**
 * Direction of a candlestick.
 */
enum class CandleDirection {
    BULLISH,
    BEARISH,
    DOJI
}

/**
 * Representation of a detected candlestick extracted from chart pixels or simulation.
 * Coordinates are in image/chart space (where Y=0 is top, higher Y is lower price).
 */
data class Candle(
    val index: Int,
    val centerX: Float,
    val openY: Float,
    val highY: Float,
    val lowY: Float,
    val closeY: Float,
    val bodyTop: Float,
    val bodyBottom: Float,
    val wickTop: Float,
    val wickBottom: Float,
    val direction: CandleDirection,
    val bodyLength: Float,
    val totalRange: Float,
    val upperWick: Float,
    val lowerWick: Float,
    val bodyToRangeRatio: Float,
    val upperWickRatio: Float,
    val lowerWickRatio: Float
) {
    val isHammer: Boolean
        get() = lowerWickRatio >= 0.50f && bodyToRangeRatio <= 0.40f && upperWickRatio <= 0.20f

    val isShootingStar: Boolean
        get() = upperWickRatio >= 0.50f && bodyToRangeRatio <= 0.40f && lowerWickRatio <= 0.20f

    val isMarubozu: Boolean
        get() = bodyToRangeRatio >= 0.80f && upperWickRatio <= 0.10f && lowerWickRatio <= 0.10f

    val isDoji: Boolean
        get() = bodyToRangeRatio <= 0.15f
}
