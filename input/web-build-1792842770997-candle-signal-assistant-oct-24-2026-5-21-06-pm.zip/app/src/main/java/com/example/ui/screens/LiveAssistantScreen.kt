package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChartRegion
import com.example.model.DeadlineStatus
import com.example.model.SignalDecision
import com.example.service.FloatingOverlayService
import com.example.service.ScreenCaptureService
import com.example.service.SignalCoordinator
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldBullish
import com.example.ui.theme.RubyBearish
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateNeutral
import com.example.ui.theme.WhiteTextPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LiveAssistantScreen(
    coordinator: SignalCoordinator,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isCaptureActive by coordinator.isCaptureActive.collectAsState()
    val isOverlayActive by coordinator.isOverlayActive.collectAsState()
    val currentResult by coordinator.currentResult.collectAsState()
    val timingState by coordinator.timingState.collectAsState()
    val chartRegion by coordinator.chartRegion.collectAsState()

    var showCropAdjuster by remember { mutableStateOf(false) }

    // MediaProjection permission launcher
    val screenCaptureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { activityResult ->
        if (activityResult.resultCode == Activity.RESULT_OK && activityResult.data != null) {
            val metrics = context.resources.displayMetrics
            val serviceIntent = Intent(context, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, activityResult.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, activityResult.data)
                putExtra(ScreenCaptureService.EXTRA_WIDTH, metrics.widthPixels)
                putExtra(ScreenCaptureService.EXTRA_HEIGHT, metrics.heightPixels)
                putExtra(ScreenCaptureService.EXTRA_DENSITY, metrics.densityDpi)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkObsidian)
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Capture Status Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isCaptureActive) EmeraldBullish else SlateNeutral)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isCaptureActive) "Screen Observation Active" else "Observation Inactive",
                            color = WhiteTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (isCaptureActive) "Local MediaProjection stream" else "Ready to observe Quotex chart",
                            color = SlateLight,
                            fontSize = 12.sp
                        )
                    }
                }

                if (isOverlayActive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(EmeraldBullish.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "HUD ON",
                            color = EmeraldBullish,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 1-Minute Candle Timing Sequence Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AccessTime,
                            contentDescription = "Candle Timer",
                            tint = if (timingState.isFinal7Seconds) RubyBearish else EmeraldBullish,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "1-Minute Candle Lifecycle",
                            color = WhiteTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Sync clock button
                    OutlinedButton(
                        onClick = { coordinator.syncCandleTimer() },
                        modifier = Modifier.height(28.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Sync Candle Clock",
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sync Candle", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Progress bar of current 60s candle
                val progress = (60 - timingState.remainingSeconds) / 60f
                val progressColor by animateColorAsState(
                    targetValue = if (timingState.isFinal7Seconds) RubyBearish else EmeraldBullish,
                    label = "progressColor"
                )
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = progressColor,
                    trackColor = DarkSurfaceElevated,
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Countdown: ${timingState.remainingSeconds}s remaining",
                        color = if (timingState.isFinal7Seconds) RubyBearish else WhiteTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = if (timingState.isFinal7Seconds) FontWeight.Bold else FontWeight.Normal
                    )

                    val timingStage = when {
                        timingState.isTMinus1s -> "T-1s Signal Lock"
                        timingState.isFinal7Seconds -> "Final 7s Frame Sampling"
                        else -> "Standard Observation"
                    }
                    Text(
                        text = timingStage,
                        color = if (timingState.isFinal7Seconds) AmberWarning else SlateLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Probabilistic Signal Display Board
        val signalColor = when (currentResult.signal) {
            SignalDecision.UP -> EmeraldBullish
            SignalDecision.DOWN -> RubyBearish
            SignalDecision.NO_SIGNAL -> SlateNeutral
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("signal_display_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(2.dp, signalColor.copy(alpha = 0.8f)),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "LATEST 1-MINUTE SIGNAL",
                    color = SlateLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Big Signal Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(signalColor.copy(alpha = 0.22f))
                        .border(1.5.dp, signalColor, RoundedCornerShape(12.dp))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    val label = when (currentResult.signal) {
                        SignalDecision.UP -> "▲  UP / CALL"
                        SignalDecision.DOWN -> "▼  DOWN / PUT"
                        SignalDecision.NO_SIGNAL -> "■  NO SIGNAL"
                    }
                    Text(
                        text = label,
                        color = signalColor,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Confidence badge (strictly adhering to "not validated" rule)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Confidence: ",
                        color = SlateLight,
                        fontSize = 13.sp
                    )
                    val confText = if (currentResult.confidence != null) {
                        "${(currentResult.confidence!! * 100).toInt()}% (Calibrated N>=30)"
                    } else {
                        "Not validated"
                    }
                    Text(
                        text = confText,
                        color = if (currentResult.confidence != null) EmeraldBullish else AmberWarning,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Rationale text
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkObsidian)
                        .padding(12.dp)
                ) {
                    Text(
                        text = currentResult.featureSummary,
                        color = WhiteTextPrimary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Metadata row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(currentResult.timestamp))
                    Text(
                        text = "Time: $timeStr",
                        color = SlateLight,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "Candles: ${currentResult.observedCandlesCount}",
                        color = SlateLight,
                        fontSize = 11.sp
                    )
                    val deadlineBadge = when (currentResult.deadlineStatus) {
                        DeadlineStatus.ON_TIME -> "On-Time (${currentResult.latencyMs}ms)"
                        DeadlineStatus.LATE -> "LATE (${currentResult.latencyMs}ms)"
                        DeadlineStatus.MISSED -> "MISSED"
                        DeadlineStatus.NOT_SCHEDULED -> "${currentResult.latencyMs}ms"
                    }
                    Text(
                        text = deadlineBadge,
                        color = if (currentResult.deadlineStatus == DeadlineStatus.LATE) RubyBearish else SlateLight,
                        fontSize = 11.sp,
                        fontWeight = if (currentResult.deadlineStatus == DeadlineStatus.LATE) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // MediaProjection Toggle
            Button(
                onClick = {
                    if (isCaptureActive) {
                        val stopIntent = Intent(context, ScreenCaptureService::class.java).apply {
                            action = ScreenCaptureService.ACTION_STOP
                        }
                        context.startService(stopIntent)
                    } else {
                        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("toggle_screen_capture_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCaptureActive) RubyBearish else EmeraldBullish
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = if (isCaptureActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isCaptureActive) "Stop Capture" else "Start Capture",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            // Floating Overlay Toggle
            OutlinedButton(
                onClick = {
                    if (isOverlayActive) {
                        val stopIntent = Intent(context, FloatingOverlayService::class.java)
                        context.stopService(stopIntent)
                    } else {
                        if (Settings.canDrawOverlays(context)) {
                            val startIntent = Intent(context, FloatingOverlayService::class.java)
                            context.startService(startIntent)
                        } else {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("toggle_overlay_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Layers,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isOverlayActive) "Hide HUD" else "Floating HUD",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Manual Analysis button
        OutlinedButton(
            onClick = {
                if (isCaptureActive) {
                    ScreenCaptureService.instance?.requestImmediateCapture()
                } else {
                    coordinator.runSyntheticTest(com.example.cv.SyntheticPattern.BULLISH_HAMMER_AT_SUPPORT)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("analyze_now_button"),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Analyze Now",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isCaptureActive) "Analyze Current Screen Now" else "Run Live Test Simulation",
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Chart Region / Crop Calibration expander
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chart Region Calibration",
                        color = WhiteTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedButton(
                        onClick = { showCropAdjuster = !showCropAdjuster },
                        modifier = Modifier.height(28.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
                    ) {
                        Text(if (showCropAdjuster) "Hide" else "Adjust Crop", fontSize = 11.sp)
                    }
                }

                AnimatedVisibility(visible = showCropAdjuster) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        Text(
                            text = "Tune chart bounds to isolate Quotex candlestick area from brokerage UI headers:",
                            color = SlateLight,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Top crop slider
                        Text("Top Margin: ${(chartRegion.top * 100).toInt()}%", color = SlateLight, fontSize = 11.sp)
                        Slider(
                            value = chartRegion.top,
                            onValueChange = { coordinator.updateChartRegion(chartRegion.copy(top = it)) },
                            valueRange = 0.05f..0.40f
                        )

                        // Bottom crop slider
                        Text("Bottom Margin: ${(chartRegion.bottom * 100).toInt()}%", color = SlateLight, fontSize = 11.sp)
                        Slider(
                            value = chartRegion.bottom,
                            onValueChange = { coordinator.updateChartRegion(chartRegion.copy(bottom = it)) },
                            valueRange = 0.60f..0.95f
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Strict Policy & Safety Disclaimer
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated.copy(alpha = 0.5f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Safety Disclaimer",
                    tint = AmberWarning,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Signal-only mode. Never places trades, clicks buttons, or accesses account credentials. Operates 100% on-device with zero screenshot transmission. Past calibration does not guarantee future results.",
                    color = SlateLight,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
