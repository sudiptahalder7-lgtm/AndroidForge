package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cv.SyntheticPattern
import com.example.model.CandleDirection
import com.example.model.SignalDecision
import com.example.service.SignalCoordinator
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldBullish
import com.example.ui.theme.RubyBearish
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateNeutral
import com.example.ui.theme.WhiteTextPrimary

@Composable
fun ChartLabScreen(
    coordinator: SignalCoordinator,
    modifier: Modifier = Modifier
) {
    var selectedPattern by remember { mutableStateOf(SyntheticPattern.BULLISH_HAMMER_AT_SUPPORT) }
    val latestChart by coordinator.latestChart.collectAsState()
    val currentResult by coordinator.currentResult.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkObsidian)
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.BugReport,
                        contentDescription = "Test Lab",
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Chart CV & Algorithm Lab",
                        color = WhiteTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Test computer vision candlestick extraction, wick measurement, and rule decisions with synthetic or captured frames.",
                    color = SlateLight,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Pattern Selector Chips
        Text(
            text = "SELECT CANDLESTICK PATTERN:",
            color = SlateLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val patterns = listOf(
                SyntheticPattern.BULLISH_HAMMER_AT_SUPPORT to "Hammer at Support",
                SyntheticPattern.BEARISH_SHOOTING_STAR_AT_RESISTANCE to "Shooting Star (Res)",
                SyntheticPattern.BULLISH_ENGULFING to "Bullish Engulfing",
                SyntheticPattern.BEARISH_ENGULFING to "Bearish Engulfing",
                SyntheticPattern.DOJI_INDECISION to "Doji Indecision",
                SyntheticPattern.BULLISH_MOMENTUM_TREND to "Bullish Momentum",
                SyntheticPattern.BEARISH_MOMENTUM_TREND to "Bearish Momentum",
                SyntheticPattern.AMBIGUOUS_NOISE to "Ambiguous Noise"
            )

            patterns.forEach { (pattern, title) ->
                FilterChip(
                    selected = selectedPattern == pattern,
                    onClick = {
                        selectedPattern = pattern
                        coordinator.runSyntheticTest(pattern)
                    },
                    label = { Text(title, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                        selectedLabelColor = CyanAccent
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Trigger Run Button
        Button(
            onClick = { coordinator.runSyntheticTest(selectedPattern) },
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("run_lab_simulation_button"),
            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.Black,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Generate & Run CV Pipeline",
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Visual Canvas Chart Inspector
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "VISUAL CANDLE & S/R DETECTION",
                    color = SlateLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                val chart = latestChart
                val croppedBitmap = chart?.croppedBitmap

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.5f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0D111B))
                        .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (croppedBitmap != null) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Draw underlying bitmap
                            val imageBitmap = croppedBitmap.asImageBitmap()
                            drawImage(imageBitmap, dstSize = androidx.compose.ui.unit.IntSize(size.width.toInt(), size.height.toInt()))

                            // Scale factors
                            val scaleX = size.width / croppedBitmap.width.toFloat()
                            val scaleY = size.height / croppedBitmap.height.toFloat()

                            // Draw detected S/R levels
                            chart.supportLevelsY.forEach { y ->
                                val canvasY = y * scaleY
                                drawLine(
                                    color = EmeraldBullish,
                                    start = Offset(0f, canvasY),
                                    end = Offset(size.width, canvasY),
                                    strokeWidth = 2f
                                )
                            }
                            chart.resistanceLevelsY.forEach { y ->
                                val canvasY = y * scaleY
                                drawLine(
                                    color = RubyBearish,
                                    start = Offset(0f, canvasY),
                                    end = Offset(size.width, canvasY),
                                    strokeWidth = 2f
                                )
                            }

                            // Draw candle bounding boxes and wick indicators
                            chart.candles.forEach { candle ->
                                val boxColor = when (candle.direction) {
                                    CandleDirection.BULLISH -> EmeraldBullish
                                    CandleDirection.BEARISH -> RubyBearish
                                    CandleDirection.DOJI -> SlateNeutral
                                }

                                // Wick bounding line
                                drawLine(
                                    color = Color.Yellow,
                                    start = Offset(candle.centerX * scaleX, candle.wickTop * scaleY),
                                    end = Offset(candle.centerX * scaleX, candle.wickBottom * scaleY),
                                    strokeWidth = 2.5f
                                )

                                // Body bounding rect
                                val bodyTopY = candle.bodyTop * scaleY
                                val bodyBottomY = candle.bodyBottom * scaleY
                                val widthPx = 16.dp.toPx()
                                val leftX = candle.centerX * scaleX - widthPx / 2f

                                drawRect(
                                    color = boxColor,
                                    topLeft = Offset(leftX, bodyTopY),
                                    size = Size(widthPx, (bodyBottomY - bodyTopY).coerceAtLeast(2f)),
                                    style = Stroke(width = 2f)
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Tap 'Generate & Run CV Pipeline' to inspect",
                            color = SlateLight,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Candles Detected: ${chart?.candles?.size ?: 0}",
                        color = WhiteTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Quality: ${chart?.dataQuality?.name ?: "N/A"}",
                        color = if (chart?.dataQuality == com.example.model.DataQuality.GOOD) EmeraldBullish else SlateLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Extracted Candle Metrics Table
        if (latestChart != null && latestChart!!.candles.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "CANDLE FEATURE BREAKDOWN",
                        color = SlateLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    latestChart!!.candles.forEachIndexed { i, c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val dirColor = when (c.direction) {
                                CandleDirection.BULLISH -> EmeraldBullish
                                CandleDirection.BEARISH -> RubyBearish
                                CandleDirection.DOJI -> SlateNeutral
                            }
                            Text(
                                text = "#$i ${c.direction.name.take(4)}",
                                color = dirColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(70.dp)
                            )
                            Text(
                                text = "Body: ${(c.bodyToRangeRatio * 100).toInt()}%",
                                color = SlateLight,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "UpWick: ${(c.upperWickRatio * 100).toInt()}%",
                                color = SlateLight,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "LowWick: ${(c.lowerWickRatio * 100).toInt()}%",
                                color = SlateLight,
                                fontSize = 11.sp
                            )
                            val tag = when {
                                c.isHammer -> "Hammer"
                                c.isShootingStar -> "Star"
                                c.isMarubozu -> "Maru"
                                c.isDoji -> "Doji"
                                else -> "-"
                            }
                            Text(
                                text = tag,
                                color = CyanAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Signal Engine Output Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ENGINE DECISION RESULT",
                    color = SlateLight,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                val sigColor = when (currentResult.signal) {
                    SignalDecision.UP -> EmeraldBullish
                    SignalDecision.DOWN -> RubyBearish
                    SignalDecision.NO_SIGNAL -> SlateNeutral
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Decision: ${currentResult.signal.name}",
                        color = sigColor,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Latency: ${currentResult.latencyMs}ms",
                        color = SlateLight,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = currentResult.featureSummary,
                    color = WhiteTextPrimary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
