package com.example.model

/**
 * Normalized bounding box for chart region on screen (0.0f .. 1.0f).
 * Allows user to calibrate or auto-crop Quotex chart area excluding UI bars.
 */
data class ChartRegion(
    val left: Float = 0.0f,
    val top: Float = 0.05f,
    val right: Float = 1.0f,
    val bottom: Float = 0.95f
) {
    val width: Float get() = (right - left).coerceAtLeast(0.1f)
    val height: Float get() = (bottom - top).coerceAtLeast(0.1f)

    fun toPixelRect(bitmapWidth: Int, bitmapHeight: Int): android.graphics.Rect {
        val pxLeft = (left * bitmapWidth).toInt().coerceIn(0, bitmapWidth - 1)
        val pxTop = (top * bitmapHeight).toInt().coerceIn(0, bitmapHeight - 1)
        val pxRight = (right * bitmapWidth).toInt().coerceIn(pxLeft + 10, bitmapWidth)
        val pxBottom = (bottom * bitmapHeight).toInt().coerceIn(pxTop + 10, bitmapHeight)
        return android.graphics.Rect(pxLeft, pxTop, pxRight, pxBottom)
    }
}
