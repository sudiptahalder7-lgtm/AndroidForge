package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldBullish,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF064E3B),
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = CyanAccent,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = AmberWarning,
    onTertiary = Color.Black,
    error = RubyBearish,
    onError = Color.White,
    background = DarkObsidian,
    onBackground = WhiteTextPrimary,
    surface = DarkSurface,
    onSurface = WhiteTextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = SlateLight,
    outline = DarkSurfaceBorder,
    outlineVariant = Color(0xFF1E293B)
)

@Composable
fun CandleSignalAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
