package com.example.model

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Accuracy statistics calculated from labeled historical predictions.
 */
data class AccuracyReport(
    val totalPredictions: Int,
    val directionalPredictions: Int,
    val noSignalPredictions: Int,
    val labeledCount: Int,
    val correctDirectionalCount: Int,
    val incorrectDirectionalCount: Int,
    val dojiCount: Int,
    val directionalAccuracyPct: Double?, // null if labeledCount < minSampleSize
    val coveragePct: Double,
    val ciLowerPct: Double?,
    val ciUpperPct: Double?,
    val isStatisticallyValidated: Boolean
) {
    companion object {
        const val MIN_SAMPLES_FOR_VALIDATION = 30

        /**
         * Calculates directional accuracy and Wilson score 95% confidence interval.
         * (Wilson interval is standard for binomial proportions and handles small/moderate samples without normal approx skew).
         */
        fun calculate(
            total: Int,
            noSignalCount: Int,
            upPredictionsLabeled: Int,
            upCorrect: Int,
            downPredictionsLabeled: Int,
            downCorrect: Int,
            dojiCount: Int
        ): AccuracyReport {
            val directionalLabeled = upPredictionsLabeled + downPredictionsLabeled
            val correctTotal = upCorrect + downCorrect
            val incorrectTotal = directionalLabeled - correctTotal

            val coverage = if (total > 0) {
                ((total - noSignalCount).toDouble() / total.toDouble()) * 100.0
            } else 0.0

            if (directionalLabeled < MIN_SAMPLES_FOR_VALIDATION) {
                return AccuracyReport(
                    totalPredictions = total,
                    directionalPredictions = total - noSignalCount,
                    noSignalPredictions = noSignalCount,
                    labeledCount = directionalLabeled,
                    correctDirectionalCount = correctTotal,
                    incorrectDirectionalCount = incorrectTotal,
                    dojiCount = dojiCount,
                    directionalAccuracyPct = if (directionalLabeled > 0) (correctTotal.toDouble() / directionalLabeled) * 100.0 else null,
                    coveragePct = coverage,
                    ciLowerPct = null,
                    ciUpperPct = null,
                    isStatisticallyValidated = false
                )
            }

            val n = directionalLabeled.toDouble()
            val p = correctTotal.toDouble() / n
            val z = 1.96 // 95% confidence interval

            // Wilson score formula
            val denominator = 1.0 + (z * z) / n
            val center = (p + (z * z) / (2.0 * n)) / denominator
            val margin = (z * sqrt((p * (1.0 - p) / n) + ((z * z) / (4.0 * n * n)))) / denominator

            val lower = max(0.0, (center - margin) * 100.0)
            val upper = min(100.0, (center + margin) * 100.0)

            return AccuracyReport(
                totalPredictions = total,
                directionalPredictions = total - noSignalCount,
                noSignalPredictions = noSignalCount,
                labeledCount = directionalLabeled,
                correctDirectionalCount = correctTotal,
                incorrectDirectionalCount = incorrectTotal,
                dojiCount = dojiCount,
                directionalAccuracyPct = p * 100.0,
                coveragePct = coverage,
                ciLowerPct = lower,
                ciUpperPct = upper,
                isStatisticallyValidated = true
            )
        }
    }
}
