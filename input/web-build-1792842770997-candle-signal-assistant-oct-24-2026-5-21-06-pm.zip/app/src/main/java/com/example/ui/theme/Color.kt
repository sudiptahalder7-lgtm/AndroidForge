package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkObsidian = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkSurfaceBorder = Color(0xFF334155)

val EmeraldBullish = Color(0xFF10B981)
val EmeraldBullishGlow = Color(0xFF34D399)
val RubyBearish = Color(0xFFEF4444)
val RubyBearishGlow = Color(0xFFF87171)

val SlateNeutral = Color(0xFF64748B)
val SlateLight = Color(0xFF94A3B8)
val SlateTextSecondary = Color(0xFF94A3B8)
val WhiteTextPrimary = Color(0xFFF8FAFC)

val AmberWarning = Color(0xFFF59E0B)
val CyanAccent = Color(0xFF06B6D4)
val PurpleAccent = Color(0xFF8B5CF6)
