package com.example.ui.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeadlineStatus
import com.example.model.SignalDecision
import com.example.model.SignalResult
import com.example.timing.TimingState
import com.example.ui.theme.CandleSignalAssistantTheme
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.EmeraldBullish
import com.example.ui.theme.RubyBearish
import com.example.ui.theme.SlateLight
import com.example.ui.theme.SlateNeutral
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FloatingOverlayContent(
    result: SignalResult,
    timingState: TimingState,
    isCaptureActive: Boolean,
    onAnalyzeNow: () -> Unit,
    onToggleAnalysis: () -> Unit,
    onClose: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(true) }

    CandleSignalAssistantTheme {
        Surface(
            modifier = Modifier
                .width(280.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(16.dp))
                .testTag("floating_overlay_root"),
            color = DarkSurface.copy(alpha = 0.94f),
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // Drag handle & Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Status indicator light
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isCaptureActive) EmeraldBullish else SlateNeutral)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Signal HUD",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Countdown badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (timingState.isFinal7Seconds) RubyBearish.copy(alpha = 0.25f)
                                    else DarkObsidian
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${timingState.remainingSeconds}s",
                                color = if (timingState.isFinal7Seconds) RubyBearish else SlateLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Expand/collapse button
                        IconButton(
                            onClick = { isExpanded = !isExpanded },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isExpanded) "Collapse" else "Expand",
                                tint = SlateLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Close button
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close HUD",
                                tint = SlateLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Primary Signal Card
                val signalColor = when (result.signal) {
                    SignalDecision.UP -> EmeraldBullish
                    SignalDecision.DOWN -> RubyBearish
                    SignalDecision.NO_SIGNAL -> SlateNeutral
                }
                val signalLabel = when (result.signal) {
                    SignalDecision.UP -> "▲  UP / CALL"
                    SignalDecision.DOWN -> "▼  DOWN / PUT"
                    SignalDecision.NO_SIGNAL -> "■  NO SIGNAL"
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(signalColor.copy(alpha = 0.20f))
                        .border(1.5.dp, signalColor.copy(alpha = 0.8f), RoundedCornerShape(10.dp))
                        .padding(vertical = 10.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = signalLabel,
                            color = signalColor,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )

                        // Calibrated Confidence or Not validated requirement
                        val confidenceText = if (result.confidence != null) {
                            "Confidence: ${(result.confidence * 100).toInt()}%"
                        } else {
                            "Confidence: Not validated"
                        }
                        Text(
                            text = confidenceText,
                            color = SlateLight,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                // Expandable detailed section
                AnimatedVisibility(
                    visible = isExpanded,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        // Explanation
                        Text(
                            text = result.featureSummary,
                            color = SlateLight,
                            fontSize = 11.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 14.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Timing and Latency status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(result.timestamp))
                            Text(
                                text = "At: $timeStr",
                                color = SlateLight,
                                fontSize = 10.sp
                            )
                            val deadlineLabel = when (result.deadlineStatus) {
                                DeadlineStatus.ON_TIME -> "On-Time (${result.latencyMs}ms)"
                                DeadlineStatus.LATE -> "Late (${result.latencyMs}ms)"
                                DeadlineStatus.MISSED -> "Missed"
                                DeadlineStatus.NOT_SCHEDULED -> "${result.latencyMs}ms"
                            }
                            Text(
                                text = deadlineLabel,
                                color = if (result.deadlineStatus == DeadlineStatus.LATE) RubyBearish else SlateLight,
                                fontSize = 10.sp,
                                fontWeight = if (result.deadlineStatus == DeadlineStatus.LATE) FontWeight.Bold else FontWeight.Normal
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Controls Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onAnalyzeNow,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Analyze Now",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Analyze", fontSize = 11.sp)
                            }

                            Button(
                                onClick = onToggleAnalysis,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCaptureActive) RubyBearish else EmeraldBullish
                                ),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isCaptureActive) Icons.Default.Stop else Icons.Default.Refresh,
                                    contentDescription = if (isCaptureActive) "Stop" else "Start",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isCaptureActive) "Stop" else "Start", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
