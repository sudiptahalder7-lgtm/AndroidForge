package com.example.cv

import android.graphics.Bitmap
import android.graphics.Color
import com.example.model.Candle
import com.example.model.CandleDirection
import com.example.model.ChartRegion
import com.example.model.DataQuality
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Result of computer vision analysis of a chart frame.
 */
data class ProcessedChart(
    val candles: List<Candle>,
    val supportLevelsY: List<Float>,
    val resistanceLevelsY: List<Float>,
    val dataQuality: DataQuality,
    val diagnosticMessage: String,
    val croppedBitmap: Bitmap? = null
)

/**
 * High-performance, on-device computer vision engine for detecting candlesticks
 * and price levels from Android MediaProjection bitmaps without external dependencies.
 */
class ChartImageProcessor {

    /**
     * Analyzes the specified region of a captured bitmap.
     */
    fun processBitmap(source: Bitmap, region: ChartRegion = ChartRegion()): ProcessedChart {
        val rect = region.toPixelRect(source.width, source.height)
        val cropW = rect.width()
        val cropH = rect.height()

        if (cropW < 60 || cropH < 60) {
            return ProcessedChart(
                candles = emptyList(),
                supportLevelsY = emptyList(),
                resistanceLevelsY = emptyList(),
                dataQuality = DataQuality.INVALID,
                diagnosticMessage = "Chart region too small (${cropW}x${cropH}px). Check crop bounds."
            )
        }

        // Safe crop
        val cropped = try {
            Bitmap.createBitmap(source, rect.left, rect.top, cropW, cropH)
        } catch (e: Exception) {
            return ProcessedChart(
                candles = emptyList(),
                supportLevelsY = emptyList(),
                resistanceLevelsY = emptyList(),
                dataQuality = DataQuality.INVALID,
                diagnosticMessage = "Crop failed: ${e.message}"
            )
        }

        val pixels = IntArray(cropW * cropH)
        cropped.getPixels(pixels, 0, cropW, 0, 0, cropW, cropH)

        // Column-wise candle density scan
        // In Quotex 1m charts, candles have distinct green (bullish) or red (bearish) colors.
        val colBullishCounts = IntArray(cropW)
        val colBearishCounts = IntArray(cropW)
        val colMinY = IntArray(cropW) { cropH }
        val colMaxY = IntArray(cropW) { 0 }

        for (x in 0 until cropW) {
            for (y in 0 until cropH) {
                val color = pixels[y * cropW + x]
                val r = Color.red(color)
                val g = Color.green(color)
                val b = Color.blue(color)

                // Detect Bullish (Green dominant: e.g. #00C087, #26A69A, #10B981)
                val isBullish = (g > 100 && g > r + 30 && g > b + 20)
                // Detect Bearish (Red dominant: e.g. #EF4444, #FF4961, #E53935)
                val isBearish = (r > 100 && r > g + 30 && r > b + 20)

                // Detect Wick or body pixel
                if (isBullish) {
                    colBullishCounts[x]++
                    if (y < colMinY[x]) colMinY[x] = y
                    if (y > colMaxY[x]) colMaxY[x] = y
                } else if (isBearish) {
                    colBearishCounts[x]++
                    if (y < colMinY[x]) colMinY[x] = y
                    if (y > colMaxY[x]) colMaxY[x] = y
                } else {
                    // Check for thin grey/white/neutral wick pixel contrasting with dark background
                    val isBrightWick = (r > 130 && g > 130 && b > 130 && abs(r - g) < 25 && abs(g - b) < 25)
                    if (isBrightWick) {
                        if (y < colMinY[x]) colMinY[x] = y
                        if (y > colMaxY[x]) colMaxY[x] = y
                    }
                }
            }
        }

        // Group columns into candle clusters
        val candleClusters = mutableListOf<CandleCluster>()
        var inCluster = false
        var clusterStart = 0
        var clusterBullish = 0
        var clusterBearish = 0

        for (x in 0 until cropW) {
            val totalColored = colBullishCounts[x] + colBearishCounts[x]
            val hasActivity = totalColored >= 3 || (colMaxY[x] > colMinY[x] && (colMaxY[x] - colMinY[x]) >= 8)

            if (hasActivity) {
                if (!inCluster) {
                    inCluster = true
                    clusterStart = x
                    clusterBullish = 0
                    clusterBearish = 0
                }
                clusterBullish += colBullishCounts[x]
                clusterBearish += colBearishCounts[x]
            } else {
                if (inCluster) {
                    inCluster = false
                    val clusterWidth = x - clusterStart
                    if (clusterWidth >= 2 && clusterWidth <= cropW / 4) {
                        candleClusters.add(
                            CandleCluster(
                                startX = clusterStart,
                                endX = x,
                                bullishPixels = clusterBullish,
                                bearishPixels = clusterBearish
                            )
                        )
                    }
                }
            }
        }

        if (inCluster && (cropW - clusterStart) >= 2) {
            candleClusters.add(
                CandleCluster(
                    startX = clusterStart,
                    endX = cropW,
                    bullishPixels = clusterBullish,
                    bearishPixels = clusterBearish
                )
            )
        }

        // Filter and construct Candle objects
        val detectedCandles = mutableListOf<Candle>()
        for ((idx, cluster) in candleClusters.withIndex()) {
            val centerX = (cluster.startX + cluster.endX) / 2f

            // Find vertical bounds in this cluster
            var overallMinY = cropH.toFloat()
            var overallMaxY = 0f

            // Find body vertical bounds (where density is widest in cluster)
            val rowDensity = IntArray(cropH)
            var rowBullish = IntArray(cropH)
            var rowBearish = IntArray(cropH)

            for (cx in cluster.startX until cluster.endX) {
                for (cy in 0 until cropH) {
                    val color = pixels[cy * cropW + cx]
                    val r = Color.red(color)
                    val g = Color.green(color)
                    val b = Color.blue(color)

                    val isBull = (g > 100 && g > r + 30 && g > b + 20)
                    val isBear = (r > 100 && r > g + 30 && r > b + 20)
                    val isWick = (r > 130 && g > 130 && b > 130 && abs(r - g) < 25 && abs(g - b) < 25)

                    if (isBull || isBear || isWick) {
                        if (cy < overallMinY) overallMinY = cy.toFloat()
                        if (cy > overallMaxY) overallMaxY = cy.toFloat()
                    }
                    if (isBull) {
                        rowBullish[cy]++
                        rowDensity[cy]++
                    } else if (isBear) {
                        rowBearish[cy]++
                        rowDensity[cy]++
                    }
                }
            }

            if (overallMaxY - overallMinY < 6f) continue // Too small to be a candle

            // Find body top and bottom (rows with dense color)
            val clusterWidth = max(1, cluster.endX - cluster.startX)
            val bodyThreshold = max(2, (clusterWidth * 0.45).toInt())

            var bodyTop = overallMinY
            var bodyBottom = overallMaxY
            var foundBodyTop = false

            for (y in 0 until cropH) {
                if (rowDensity[y] >= bodyThreshold) {
                    if (!foundBodyTop) {
                        bodyTop = y.toFloat()
                        foundBodyTop = true
                    }
                    bodyBottom = y.toFloat()
                }
            }

            val direction = when {
                cluster.bullishPixels > cluster.bearishPixels * 1.3f -> CandleDirection.BULLISH
                cluster.bearishPixels > cluster.bullishPixels * 1.3f -> CandleDirection.BEARISH
                else -> CandleDirection.DOJI
            }

            val bodyLength = max(1f, bodyBottom - bodyTop)
            val totalRange = max(bodyLength, overallMaxY - overallMinY)
            val upperWick = max(0f, bodyTop - overallMinY)
            val lowerWick = max(0f, overallMaxY - bodyBottom)

            val openY = if (direction == CandleDirection.BULLISH) bodyBottom else bodyTop
            val closeY = if (direction == CandleDirection.BULLISH) bodyTop else bodyBottom

            detectedCandles.add(
                Candle(
                    index = idx,
                    centerX = centerX,
                    openY = openY,
                    highY = overallMinY,
                    lowY = overallMaxY,
                    closeY = closeY,
                    bodyTop = bodyTop,
                    bodyBottom = bodyBottom,
                    wickTop = overallMinY,
                    wickBottom = overallMaxY,
                    direction = direction,
                    bodyLength = bodyLength,
                    totalRange = totalRange,
                    upperWick = upperWick,
                    lowerWick = lowerWick,
                    bodyToRangeRatio = (bodyLength / totalRange).coerceIn(0f, 1f),
                    upperWickRatio = (upperWick / totalRange).coerceIn(0f, 1f),
                    lowerWickRatio = (lowerWick / totalRange).coerceIn(0f, 1f)
                )
            )
        }

        // Quality check
        val quality: DataQuality
        val message: String

        if (detectedCandles.size < 3) {
            quality = DataQuality.INVALID
            message = "Insufficient candle structures detected (${detectedCandles.size}). Verify chart is open and visible."
        } else if (detectedCandles.size < 5) {
            quality = DataQuality.LIMITED
            message = "Limited candle history detected (${detectedCandles.size} candles). Signal confidence restricted."
        } else {
            quality = DataQuality.GOOD
            message = "Extracted ${detectedCandles.size} clean 1-minute candles. Chart analysis active."
        }

        // Detect horizontal support & resistance price clusters
        val (supportLevels, resistanceLevels) = extractKeyLevels(detectedCandles, cropH.toFloat())

        return ProcessedChart(
            candles = detectedCandles,
            supportLevelsY = supportLevels,
            resistanceLevelsY = resistanceLevels,
            dataQuality = quality,
            diagnosticMessage = message,
            croppedBitmap = cropped
        )
    }

    private fun extractKeyLevels(candles: List<Candle>, height: Float): Pair<List<Float>, List<Float>> {
        if (candles.size < 3) return Pair(emptyList(), emptyList())

        // Resistance: clustering of highs (wickTop)
        val highs = candles.map { it.wickTop }.sorted()
        // Support: clustering of lows (wickBottom)
        val lows = candles.map { it.wickBottom }.sorted()

        val tolerance = height * 0.04f // 4% tolerance window
        val resistanceClusters = clusterLevels(highs, tolerance)
        val supportClusters = clusterLevels(lows, tolerance)

        return Pair(supportClusters, resistanceClusters)
    }

    private fun clusterLevels(values: List<Float>, tolerance: Float): List<Float> {
        val clusters = mutableListOf<Float>()
        var currentCluster = mutableListOf<Float>()

        for (v in values) {
            if (currentCluster.isEmpty()) {
                currentCluster.add(v)
            } else {
                val avg = currentCluster.average().toFloat()
                if (abs(v - avg) <= tolerance) {
                    currentCluster.add(v)
                } else {
                    if (currentCluster.size >= 2) {
                        clusters.add(currentCluster.average().toFloat())
                    }
                    currentCluster = mutableListOf(v)
                }
            }
        }
        if (currentCluster.size >= 2) {
            clusters.add(currentCluster.average().toFloat())
        }
        return clusters
    }

    private data class CandleCluster(
        val startX: Int,
        val endX: Int,
        val bullishPixels: Int,
        val bearishPixels: Int
    )
}
