package com.example.data

import com.example.model.AccuracyReport
import com.example.model.SignalDecision
import com.example.model.SignalResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class PredictionRepository(private val dao: PredictionDao) {

    val allPredictions: Flow<List<PredictionEntity>> = dao.getAllFlow()

    suspend fun savePrediction(result: SignalResult, sessionTag: String = "Live") = withContext(Dispatchers.IO) {
        val entity = PredictionEntity(
            id = result.id,
            timestamp = result.timestamp,
            signal = result.signal.name,
            confidence = result.confidence,
            featureSummary = result.featureSummary,
            dataQuality = result.dataQuality.name,
            deadlineStatus = result.deadlineStatus.name,
            observedCandlesCount = result.observedCandlesCount,
            latencyMs = result.latencyMs,
            strategyVersion = result.strategyVersion,
            sessionTag = sessionTag
        )
        dao.insert(entity)
    }

    suspend fun labelOutcome(id: String, outcome: String) = withContext(Dispatchers.IO) {
        val existing = dao.getById(id) ?: return@withContext
        val isCorrect = when {
            existing.signal == "NO_SIGNAL" -> null
            outcome == "DOJI" -> false
            existing.signal == outcome -> true
            else -> false
        }
        dao.updateOutcome(id, outcome, isCorrect)
    }

    suspend fun computeAccuracyReport(): AccuracyReport = withContext(Dispatchers.IO) {
        val list = dao.getRecent(1000)
        var total = list.size
        var noSignalCount = 0
        var upLabeled = 0
        var upCorrect = 0
        var downLabeled = 0
        var downCorrect = 0
        var dojiCount = 0

        for (item in list) {
            if (item.signal == "NO_SIGNAL") {
                noSignalCount++
                continue
            }
            val outcome = item.actualOutcome
            if (outcome != null) {
                if (outcome == "DOJI") {
                    dojiCount++
                }
                if (item.signal == "UP") {
                    upLabeled++
                    if (item.isCorrect == true) upCorrect++
                } else if (item.signal == "DOWN") {
                    downLabeled++
                    if (item.isCorrect == true) downCorrect++
                }
            }
        }

        AccuracyReport.calculate(
            total = total,
            noSignalCount = noSignalCount,
            upPredictionsLabeled = upLabeled,
            upCorrect = upCorrect,
            downPredictionsLabeled = downLabeled,
            downCorrect = downCorrect,
            dojiCount = dojiCount
        )
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        dao.clearAll()
    }
}
