package com.example.engine

import com.example.cv.ProcessedChart
import com.example.model.AccuracyReport
import com.example.model.Candle
import com.example.model.CandleDirection
import com.example.model.DataQuality
import com.example.model.DeadlineStatus
import com.example.model.SignalDecision
import com.example.model.SignalResult
import kotlin.math.abs

/**
 * Transparent, modular rule-based signal engine.
 * Never invents indicators without data; returns NO_SIGNAL on ambiguity.
 */
class SignalEngine(private val config: StrategyConfig = StrategyConfig()) {

    fun evaluate(
        chart: ProcessedChart,
        deadlineStatus: DeadlineStatus = DeadlineStatus.ON_TIME,
        latencyMs: Long = 0L,
        historicalAccuracyReport: AccuracyReport? = null
    ): SignalResult {
        // Guard 1: Invalid data quality
        if (chart.dataQuality == DataQuality.INVALID) {
            return SignalResult(
                signal = SignalDecision.NO_SIGNAL,
                confidence = null,
                featureSummary = "Chart invalid: ${chart.diagnosticMessage}",
                dataQuality = DataQuality.INVALID,
                deadlineStatus = deadlineStatus,
                observedCandlesCount = chart.candles.size,
                latencyMs = latencyMs,
                detectedCandles = chart.candles,
                supportResistanceLevels = chart.supportLevelsY + chart.resistanceLevelsY
            )
        }

        val candles = chart.candles
        if (candles.size < config.minCandleCount) {
            return SignalResult(
                signal = SignalDecision.NO_SIGNAL,
                confidence = null,
                featureSummary = "Insufficient candle history (${candles.size}/${config.minCandleCount}). Need visible price structure.",
                dataQuality = DataQuality.LIMITED,
                deadlineStatus = deadlineStatus,
                observedCandlesCount = candles.size,
                latencyMs = latencyMs,
                detectedCandles = candles,
                supportResistanceLevels = chart.supportLevelsY + chart.resistanceLevelsY
            )
        }

        val current = candles.last()
        val previous = candles[candles.size - 2]
        val antePrevious = candles.getOrNull(candles.size - 3)

        // Rule A: Doji indecision rejection
        if (current.isDoji) {
            return SignalResult(
                signal = SignalDecision.NO_SIGNAL,
                confidence = null,
                featureSummary = "Doji indecision candle (body ${(current.bodyToRangeRatio * 100).toInt()}% of range). No directional edge.",
                dataQuality = chart.dataQuality,
                deadlineStatus = deadlineStatus,
                observedCandlesCount = candles.size,
                latencyMs = latencyMs,
                detectedCandles = candles,
                supportResistanceLevels = chart.supportLevelsY + chart.resistanceLevelsY
            )
        }

        // Check proximity to Key Levels (support / resistance)
        val nearSupport = chart.supportLevelsY.any { abs(current.lowY - it) <= config.keyLevelTolerancePx || current.lowY >= it }
        val nearResistance = chart.resistanceLevelsY.any { abs(current.highY - it) <= config.keyLevelTolerancePx || current.highY <= it }

        var decision: SignalDecision = SignalDecision.NO_SIGNAL
        var rationale = ""

        // Rule B: Bullish Hammer / Pin Bar Rejection at Support
        if (current.lowerWickRatio >= config.pinbarWickRatioThreshold &&
            current.upperWickRatio <= config.pinbarMaxOpposingWickRatio &&
            current.bodyToRangeRatio <= config.pinbarMaxBodyRatio) {

            decision = SignalDecision.UP
            rationale = "Bullish pinbar rejection (lower wick ${(current.lowerWickRatio * 100).toInt()}%)" +
                    if (nearSupport) " at validated support level." else " against recent lows."
        }
        // Rule C: Bearish Shooting Star / Pin Bar Rejection at Resistance
        else if (current.upperWickRatio >= config.pinbarWickRatioThreshold &&
            current.lowerWickRatio <= config.pinbarMaxOpposingWickRatio &&
            current.bodyToRangeRatio <= config.pinbarMaxBodyRatio) {

            decision = SignalDecision.DOWN
            rationale = "Bearish shooting star rejection (upper wick ${(current.upperWickRatio * 100).toInt()}%)" +
                    if (nearResistance) " at validated resistance level." else " against recent highs."
        }
        // Rule D: Bullish Engulfing
        else if (previous.direction == CandleDirection.BEARISH &&
            current.direction == CandleDirection.BULLISH &&
            current.bodyLength >= previous.bodyLength * config.engulfingMultiplier &&
            current.closeY <= previous.openY && current.openY >= previous.closeY) {

            decision = SignalDecision.UP
            rationale = "Bullish engulfing pattern overcoming prior bearish candle body."
        }
        // Rule E: Bearish Engulfing
        else if (previous.direction == CandleDirection.BULLISH &&
            current.direction == CandleDirection.BEARISH &&
            current.bodyLength >= previous.bodyLength * config.engulfingMultiplier &&
            current.closeY >= previous.openY && current.openY <= previous.closeY) {

            decision = SignalDecision.DOWN
            rationale = "Bearish engulfing pattern overcoming prior bullish candle body."
        }
        // Rule F: Strong Bullish Momentum (3 consecutive green with high body ratio)
        else if (antePrevious != null &&
            antePrevious.direction == CandleDirection.BULLISH &&
            previous.direction == CandleDirection.BULLISH &&
            current.direction == CandleDirection.BULLISH &&
            current.bodyToRangeRatio >= config.momentumMinBodyRatio &&
            previous.bodyToRangeRatio >= config.momentumMinBodyRatio) {

            decision = SignalDecision.UP
            rationale = "Strong 3-candle bullish momentum continuation (body ratio ${(current.bodyToRangeRatio * 100).toInt()}%)."
        }
        // Rule G: Strong Bearish Momentum (3 consecutive red with high body ratio)
        else if (antePrevious != null &&
            antePrevious.direction == CandleDirection.BEARISH &&
            previous.direction == CandleDirection.BEARISH &&
            current.direction == CandleDirection.BEARISH &&
            current.bodyToRangeRatio >= config.momentumMinBodyRatio &&
            previous.bodyToRangeRatio >= config.momentumMinBodyRatio) {

            decision = SignalDecision.DOWN
            rationale = "Strong 3-candle bearish momentum continuation (body ratio ${(current.bodyToRangeRatio * 100).toInt()}%)."
        }
        else {
            decision = SignalDecision.NO_SIGNAL
            rationale = "Mixed price action. Wicks and bodies in equilibrium; no confirmed edge."
        }

        // Check deadline status prefix
        if (deadlineStatus == DeadlineStatus.LATE || deadlineStatus == DeadlineStatus.MISSED) {
            rationale = "[LATE SIGNAL] $rationale"
        }

        // Calibrated confidence score: only present when supported by representative validation data
        val validatedConfidence = if (decision != SignalDecision.NO_SIGNAL &&
            historicalAccuracyReport != null &&
            historicalAccuracyReport.isStatisticallyValidated &&
            historicalAccuracyReport.directionalAccuracyPct != null) {
            historicalAccuracyReport.directionalAccuracyPct / 100.0
        } else {
            null // Explicitly null: will display "Not validated" as required
        }

        return SignalResult(
            signal = decision,
            confidence = validatedConfidence,
            featureSummary = rationale,
            dataQuality = chart.dataQuality,
            deadlineStatus = deadlineStatus,
            observedCandlesCount = candles.size,
            latencyMs = latencyMs,
            detectedCandles = candles,
            supportResistanceLevels = chart.supportLevelsY + chart.resistanceLevelsY
        )
    }
}
