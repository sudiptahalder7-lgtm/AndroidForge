# Candle Signal Assistant for Android

A specialized 1-minute candlestick chart observation and probabilistic signal assistant built for Android 12+ (API 31–36) using Kotlin, Jetpack Compose, Android's official MediaProjection API, and WindowManager overlay HUD.

---

## 1. Core Principles & Safety

- **Signal-Only Operation**: The application provides probabilistic analytical signals (`UP`, `DOWN`, or `NO SIGNAL`). It **never** executes trades, enters stake amounts, clicks buttons, or automates brokerage actions.
- **Strict Device-Local Privacy**: Screen frames captured via MediaProjection are processed directly in volatile memory using local computer vision and discarded immediately. No screenshots, credentials, or personal data are transmitted to any cloud or AI service.
- **No Guaranteed Predictions**: Candlestick price action heuristics are inherently probabilistic. Confidence percentages are strictly marked as **"Not validated"** until at least 30 representative labeled out-of-sample outcomes are recorded in the local database, following Wilson score binomial confidence interval statistics.

---

## 2. Architecture & Modules

```
com.example/
├── MainActivity.kt               # Edge-to-edge entry point with M3 NavigationBar & BackHandler
├── model/
│   ├── Candle.kt                 # Candlestick metrics (OHLC, body ratio, upper/lower wick ratios)
│   ├── SignalTypes.kt            # SignalDecision (UP/DOWN/NO_SIGNAL), DataQuality, DeadlineStatus
│   ├── ChartRegion.kt            # Normalized bounding box for chart crop calibration
│   └── AccuracyMetrics.kt        # Statistical engine (Wilson score 95% CI, coverage, directional accuracy)
├── cv/
│   ├── ChartImageProcessor.kt    # On-device computer vision engine (candlestick & S/R level extraction)
│   └── SyntheticChartGenerator.kt# Test bench generating synthetic 1m charts for instant validation
├── engine/
│   ├── SignalEngine.kt           # Rule-based decision engine (Pinbars, Engulfing, Momentum, Dojis)
│   └── StrategyConfig.kt         # Tunable strategy thresholds (wick sizes, body ratios, latency cutoffs)
├── timing/
│   └── CandleTimerScheduler.kt   # Monotonic 60s lifecycle tracker, 7s sampling window, T-1s deadline
├── service/
│   ├── ScreenCaptureService.kt   # Foreground Service hosting MediaProjection & VirtualDisplay
│   ├── FloatingOverlayService.kt # Draggable WindowManager floating HUD view with Jetpack Compose
│   ├── OverlayLifecycleOwner.kt  # Custom LifecycleOwner hosting ComposeView in WindowManager
│   └── SignalCoordinator.kt      # Central mediator orchestrating capture, timing, persistence & UI
├── data/
│   ├── PredictionEntity.kt       # Room persistence entity
│   ├── PredictionDao.kt          # Room DAO
│   ├── AppDatabase.kt            # Local Room database
│   └── PredictionRepository.kt   # Persistence repository with accuracy reporting & outcome labeling
└── ui/
    ├── overlay/
    │   └── FloatingOverlayContent.kt # Draggable floating HUD composable
    ├── screens/
    │   ├── LiveAssistantScreen.kt    # Capture controls, timing monitor, signal board, crop calibrator
    │   ├── ChartLabScreen.kt         # Synthetic chart simulation bench & visual candle inspector
    │   ├── AccuracyLabScreen.kt      # Historical signal log, manual outcome labeling, Wilson CI stats
    │   └── SettingsScreen.kt         # Threshold sliders, permission checks, compliance notice
    └── theme/
        ├── Color.kt                  # Sleek dark fintech color palette (Emerald Bullish, Ruby Bearish)
        ├── Theme.kt                  # Material 3 dark color scheme
        └── Type.kt                   # Typography tokens
```

---

## 3. Permissions & Setup

The app requires standard Android system permissions declared in `AndroidManifest.xml`:

1. **`FOREGROUND_SERVICE` & `FOREGROUND_SERVICE_MEDIA_PROJECTION`**:
   - Required for maintaining the continuous screen capture session.
   - Triggers the official Android system consent dialog (`MediaProjectionManager.createScreenCaptureIntent()`).
2. **`SYSTEM_ALERT_WINDOW`** (`Settings.canDrawOverlays`):
   - Required for the compact, draggable floating HUD that sits over your chart while trading.
   - If not granted, the app provides a one-tap shortcut to `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`.
3. **`POST_NOTIFICATIONS`**:
   - Displays the persistent status notification with immediate "Stop Capture" control.

---

## 4. 1-Minute Timing Sequence

1. **Continuous Sync**: The timer tracks the 60-second cycle using monotonic clock time (`SystemClock.elapsedRealtime()`). The "Sync Candle" button aligns the cycle phase offset with Quotex.
2. **Final 7-Second Window**: When remaining time reaches `T-7s` to `T-2s`, the scheduler signals the capture service to accelerate frame collection.
3. **T-1s Publication**: At `T-1s`, the engine evaluates the latest extracted candle and publishes the signal.
4. **Deadline Verification**: If processing exceeds the deadline, the signal is explicitly tagged with `[LATE SIGNAL] (DeadlineStatus.LATE)` to prevent outdated execution.

---

## 5. How to Build & Run

### Building Debug APK

To assemble the debug APK in terminal:
```bash
gradle assembleDebug
```
The resulting APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

### Running Automated Tests

Run the local JVM unit and Robolectric tests:
```bash
gradle :app:testDebugUnitTest
```

---

## 6. Testing & Calibration

- Use the **Chart Lab** tab to generate and test all 8 candlestick patterns without needing another phone or active Quotex session.
- Use the **Accuracy Lab** tab to log live predictions and label candle outcomes (`UP`, `DOWN`, `DOJI`) to calibrate strategy performance and compute the 95% Wilson confidence interval.
