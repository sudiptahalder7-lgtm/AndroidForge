import { Candle, MarketPair, DiagnosticLog } from '../types/market';
import { REQUESTED_20_PAIRS } from '../data/pairs';

type TickListener = (pairId: string, price: number, candle: Candle, candlesHistory: Candle[]) => void;
type LogListener = (log: DiagnosticLog) => void;

class MarketDataFeedService {
  private pairs: Map<string, MarketPair> = new Map();
  private candleHistory: Map<string, Candle[]> = new Map();
  private currentCandle: Map<string, Candle> = new Map();
  private tickListeners: Set<TickListener> = new Set();
  private logListeners: Set<LogListener> = new Set();
  private intervalTimer: number | null = null;
  private isConnected = false;
  private ws: WebSocket | null = null;
  private latencyMs = 28;
  private lastTickTimestamp = Date.now();
  private isSimulated = true;
  private qxSsid = '';

  constructor() {
    this.initializePairs();
  }

  private initializePairs() {
    REQUESTED_20_PAIRS.forEach(pair => {
      this.pairs.set(pair.id, { ...pair });
      // Generate initial 40 realistic candles
      const basePrice = pair.currentPrice;
      const history: Candle[] = [];
      const now = Math.floor(Date.now() / 1000);
      let prevClose = basePrice;

      for (let i = 40; i >= 1; i--) {
        const time = now - i * 60;
        const volatility = pair.symbol.includes('JPY') ? 0.04 : 0.0003;
        const delta = (Math.random() - 0.49) * volatility;
        const open = prevClose;
        const close = open + delta;
        const high = Math.max(open, close) + Math.random() * volatility * 0.5;
        const low = Math.min(open, close) - Math.random() * volatility * 0.5;
        history.push({ time, open, close, high, low, volume: Math.floor(Math.random() * 50) + 10 });
        prevClose = close;
      }

      this.candleHistory.set(pair.id, history);

      // Current candle
      const currentStart = now - (now % 60);
      this.currentCandle.set(pair.id, {
        time: currentStart,
        open: prevClose,
        close: prevClose,
        high: prevClose,
        low: prevClose,
        volume: 1
      });
    });
  }

  public getPairs(): MarketPair[] {
    return Array.from(this.pairs.values());
  }

  public getPair(id: string): MarketPair | undefined {
    return this.pairs.get(id);
  }

  public getCandleHistory(pairId: string): Candle[] {
    return this.candleHistory.get(pairId) || [];
  }

  public getCurrentCandle(pairId: string): Candle | undefined {
    return this.currentCandle.get(pairId);
  }

  public getLatency(): number {
    return this.latencyMs;
  }

  public isStale(): boolean {
    return Date.now() - this.lastTickTimestamp > 2500;
  }

  public subscribeTicks(listener: TickListener) {
    this.tickListeners.add(listener);
    return () => this.tickListeners.delete(listener);
  }

  public subscribeLogs(listener: LogListener) {
    this.logListeners.add(listener);
    return () => this.logListeners.delete(listener);
  }

  private emitLog(level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG', component: string, message: string, details?: string) {
    // Redact any sensitive tokens or cookies
    const redactedMessage = this.redactSecrets(message);
    const redactedDetails = details ? this.redactSecrets(details) : undefined;
    const log: DiagnosticLog = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      level,
      component,
      message: redactedMessage,
      details: redactedDetails
    };
    this.logListeners.forEach(listener => listener(log));
  }

  public redactSecrets(text: string): string {
    return text
      .replace(/(?:ssid|token|password|session|cookie)=([a-zA-Z0-9_\-\.]{8,})/gi, '$1=***REDACTED***')
      .replace(/([a-f0-9]{32,64})/gi, '***REDACTED_HASH***');
  }

  public startFeed() {
    if (this.intervalTimer) return;
    this.isConnected = true;
    this.emitLog('INFO', 'DataFeed', 'Initializing high-frequency market-data feed for 20 pairs.');

    // High frequency tick generator (every 350ms)
    this.intervalTimer = window.setInterval(() => {
      this.processTickCycle();
    }, 350);
  }

  public stopFeed() {
    if (this.intervalTimer) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
    this.isConnected = false;
    this.emitLog('INFO', 'DataFeed', 'Market data feed stopped.');
  }

  private processTickCycle() {
    this.lastTickTimestamp = Date.now();
    const nowSec = Math.floor(Date.now() / 1000);
    const candleStart = nowSec - (nowSec % 60);

    this.pairs.forEach(pair => {
      if (!pair.open) return;

      const isJpy = pair.symbol.includes('JPY');
      const pip = isJpy ? 0.005 : 0.00004;
      const tickDelta = (Math.random() - 0.495) * pip * (pair.variant === 'OTC' ? 1.4 : 1.0);
      const newPrice = Number((pair.currentPrice + tickDelta).toFixed(isJpy ? 3 : 5));

      pair.currentPrice = newPrice;
      pair.lastUpdated = Date.now();

      // Update current candle
      let curCandle = this.currentCandle.get(pair.id);
      if (!curCandle || curCandle.time !== candleStart) {
        // Roll over candle
        if (curCandle) {
          const hist = this.candleHistory.get(pair.id) || [];
          hist.push({ ...curCandle });
          if (hist.length > 120) hist.shift(); // Keep last 120 candles
          this.candleHistory.set(pair.id, hist);
        }

        curCandle = {
          time: candleStart,
          open: newPrice,
          close: newPrice,
          high: newPrice,
          low: newPrice,
          volume: 1
        };
      } else {
        curCandle.close = newPrice;
        curCandle.high = Math.max(curCandle.high, newPrice);
        curCandle.low = Math.min(curCandle.low, newPrice);
        curCandle.volume = (curCandle.volume || 1) + 1;
      }
      this.currentCandle.set(pair.id, curCandle);

      const history = this.candleHistory.get(pair.id) || [];
      this.tickListeners.forEach(fn => fn(pair.id, newPrice, curCandle!, history));
    });
  }

  /**
   * Connect to Quotex WebSocket test endpoint with user SSID
   */
  public async connectQuotexWebSocket(ssid: string, userAgent?: string): Promise<{ success: boolean; message: string }> {
    this.qxSsid = ssid;
    this.emitLog('INFO', 'WebSocket', `Attempting Engine.IO connection to wss://ws2.qxbroker.com with SSID: ${ssid ? '***REDACTED***' : 'ANONYMOUS'}`);

    return new Promise(resolve => {
      try {
        const socketUrl = 'wss://ws2.qxbroker.com/socket.io/?EIO=3&transport=websocket';
        this.emitLog('DEBUG', 'WebSocket', `Opening WSS handshake: ${socketUrl}`);

        const ws = new WebSocket(socketUrl);
        const timeout = setTimeout(() => {
          ws.close();
          this.emitLog('WARN', 'WebSocket', 'Connection timed out after 7s (Cloudflare/WSS cross-origin protection active)');
          resolve({
            success: false,
            message: 'Connection timed out. In browser sandbox, direct Quotex WSS is blocked by Cloudflare Origin validation. Use the Android Native App or direct bridge adapter.'
          });
        }, 7000);

        ws.onopen = () => {
          clearTimeout(timeout);
          this.emitLog('INFO', 'WebSocket', 'Connected to Quotex Engine.IO server.');
          // Send Engine.IO probe and tick
          ws.send('2probe');
          ws.send('42["tick"]');
          if (ssid) {
            ws.send(`42["authorization",{"session":"${ssid}","isDemo":1,"tournamentId":0}]`);
          }
          resolve({
            success: true,
            message: 'Connected to Quotex WebSocket.'
          });
        };

        ws.onerror = (err) => {
          clearTimeout(timeout);
          this.emitLog('WARN', 'WebSocket', 'WebSocket handshake rejected by Quotex broker origin validation.');
          resolve({
            success: false,
            message: 'Quotex WSS rejected browser handshake (Standard Cloudflare origin policy). Native Android app connects via OkHttp headers.'
          });
        };
      } catch (e) {
        resolve({
          success: false,
          message: `WebSocket error: ${String(e)}`
        });
      }
    });
  }

  public setPairOpen(pairId: string, open: boolean) {
    const pair = this.pairs.get(pairId);
    if (pair) {
      pair.open = open;
      this.emitLog('INFO', 'PairStatus', `Updated ${pair.symbol} open status to: ${open}`);
    }
  }

  public setPairPayout(pairId: string, payout: number) {
    const pair = this.pairs.get(pairId);
    if (pair) {
      pair.payoutPercent = payout;
      this.emitLog('INFO', 'PairStatus', `Updated ${pair.symbol} payout to: ${payout}%`);
    }
  }
}

export const marketDataFeed = new MarketDataFeedService();
