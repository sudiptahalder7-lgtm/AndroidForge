export type AssetVariant = 'REAL' | 'OTC';

export interface MarketPair {
  id: string; // e.g. "GBPUSD" or "GBPUSD_otc"
  symbol: string; // e.g. "GBP/USD"
  variant: AssetVariant;
  quotexCode: number; // Internal Quotex code if known
  open: boolean;
  payoutPercent: number; // e.g. 87%
  currentPrice: number;
  priceChange24h: number; // percentage
  spread: number;
  lastUpdated: number; // timestamp in ms
}

export interface Candle {
  time: number; // seconds
  open: number;
  close: number;
  high: number;
  low: number;
  volume?: number;
}

export interface TechnicalIndicators {
  rsi: number; // 0-100
  ema9: number;
  ema21: number;
  ema50: number;
  macd: {
    macdLine: number;
    signalLine: number;
    histogram: number;
  };
  bollinger: {
    upper: number;
    middle: number;
    lower: number;
    bandwidth: number;
    percentB: number;
  };
  stochastic: {
    k: number;
    d: number;
  };
  atr: number;
  pattern: string; // e.g. "Bullish Engulfing", "Bearish Pin Bar", "Doji"
}

export type SignalDirection = 'UP' | 'DOWN' | 'NO_TRADE';

export interface SignalRationale {
  rule: string;
  weight: number;
  impact: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
}

export interface SignalResult {
  id: string;
  pairId: string;
  symbol: string;
  variant: AssetVariant;
  timestamp: number; // ms
  targetCandleTime: number; // expiration candle
  direction1Min: SignalDirection; // Next 1-minute direction
  direction2Min: SignalDirection; // Next 2-minute direction
  confidence: number; // 0-100%
  entryPrice: number;
  reasons: string[];
  rationales: SignalRationale[];
  indicators: TechnicalIndicators;
  outcome?: 'WIN' | 'LOSS' | 'REFUND' | 'PENDING';
  exitPrice?: number;
}

export type ScannerStatus = 'IDLE' | 'SCANNING' | 'PAUSED' | 'TRIGGERED' | 'LOCKED';

export interface PerformanceMetrics {
  totalSignals: number;
  wins: number;
  losses: number;
  refunds: number;
  winRate: number; // percentage
  profitFactor: number;
  brierScore: number;
  maxDrawdown: number;
  perPairWinRates: Record<string, { total: number; wins: number; winRate: number }>;
}

export interface DiagnosticLog {
  id: string;
  timestamp: number;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  component: string;
  message: string;
  details?: string;
}

export interface QuotexApiAuditFeature {
  id: string;
  name: string;
  category: 'API_VERIFICATION' | 'AUTHENTICATION' | 'DATA_FEED' | 'SIGNAL_ENGINE' | 'ANDROID_SYSTEM';
  status: 'PASS' | 'FAIL' | 'BLOCKED' | 'ADAPTED';
  verdictSummary: string;
  technicalDetails: string;
}
