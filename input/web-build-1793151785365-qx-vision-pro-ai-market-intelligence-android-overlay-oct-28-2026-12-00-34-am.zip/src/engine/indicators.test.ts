import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEMA,
  calculateRSI,
  calculateBollingerBands,
  calculateMACD,
  calculateStochastic,
  calculateATR,
  detectCandlePattern,
  evaluateSignalDirection,
  computeAllIndicators
} from './indicators';
import { Candle } from '../types/market';

test('calculateEMA computes smoothing accurately', () => {
  const data = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
  const ema = calculateEMA(data, 5);
  assert.equal(ema.length, data.length);
  // Last EMA value should be between average and latest
  assert.ok(ema[ema.length - 1] > 15 && ema[ema.length - 1] < 20);
});

test('calculateRSI returns 50 on flat, high on uptrend, low on downtrend', () => {
  const flat = [100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100];
  const rsiFlat = calculateRSI(flat, 14);
  assert.equal(rsiFlat, 50);

  const uptrend = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26];
  const rsiUp = calculateRSI(uptrend, 14);
  assert.ok(rsiUp > 80, `Expected RSI > 80, got ${rsiUp}`);

  const downtrend = [26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10];
  const rsiDown = calculateRSI(downtrend, 14);
  assert.ok(rsiDown < 20, `Expected RSI < 20, got ${rsiDown}`);
});

test('calculateBollingerBands creates symmetrical envelopes', () => {
  const closes = Array.from({ length: 30 }, (_, i) => 100 + Math.sin(i / 2) * 5);
  const bb = calculateBollingerBands(closes, 20, 2);
  assert.ok(bb.upper > bb.middle);
  assert.ok(bb.lower < bb.middle);
  assert.ok(bb.bandwidth > 0);
});

test('calculateMACD computes line and histogram', () => {
  const closes = Array.from({ length: 40 }, (_, i) => 1.2500 + i * 0.001);
  const macd = calculateMACD(closes, 12, 26, 9);
  assert.ok(typeof macd.macdLine === 'number');
  assert.ok(typeof macd.signalLine === 'number');
  assert.ok(typeof macd.histogram === 'number');
});

test('calculateStochastic handles price oscillation', () => {
  const candles: Candle[] = Array.from({ length: 25 }, (_, i) => ({
    time: 1700000000 + i * 60,
    open: 1.1000 + (i % 2 === 0 ? 0.001 : -0.001),
    close: 1.1000 + (i % 2 === 0 ? 0.002 : -0.002),
    high: 1.1000 + 0.005,
    low: 1.1000 - 0.005
  }));
  const stoch = calculateStochastic(candles, 14);
  assert.ok(stoch.k >= 0 && stoch.k <= 100);
  assert.ok(stoch.d >= 0 && stoch.d <= 100);
});

test('detectCandlePattern identifies patterns accurately', () => {
  const candles: Candle[] = [
    { time: 1, open: 1.100, close: 1.095, high: 1.101, low: 1.094 },
    { time: 2, open: 1.095, close: 1.090, high: 1.096, low: 1.089 },
    // Bullish engulfing: opens below prev close, closes above prev open
    { time: 3, open: 1.088, close: 1.098, high: 1.099, low: 1.087 }
  ];
  const pattern = detectCandlePattern(candles);
  assert.equal(pattern, 'Bullish Engulfing');
});

test('evaluateSignalDirection enforces NO_TRADE on stale or insufficient data', () => {
  // Case 1: Market Closed
  const closedRes = evaluateSignalDirection([], 5, false, false);
  assert.equal(closedRes.direction1M, 'NO_TRADE');
  assert.ok(closedRes.reasons[0].includes('closed'));

  // Case 2: Stale data
  const staleRes = evaluateSignalDirection([], 5, true, true);
  assert.equal(staleRes.direction1M, 'NO_TRADE');
  assert.ok(staleRes.reasons[0].includes('delay'));

  // Case 3: Insufficient candles (< 30)
  const shortCandles: Candle[] = Array.from({ length: 15 }, (_, i) => ({
    time: i,
    open: 1.0,
    close: 1.01,
    high: 1.02,
    low: 0.99
  }));
  const shortRes = evaluateSignalDirection(shortCandles, 5, false, true);
  assert.equal(shortRes.direction1M, 'NO_TRADE');
  assert.ok(shortRes.reasons[0].includes('Insufficient candle history'));
});

test('computeAllIndicators handles empty candles gracefully without throwing', () => {
  const result = computeAllIndicators([]);
  assert.equal(result.rsi, 50);
  assert.equal(result.ema9, 1.0);
  assert.equal(result.ema21, 1.0);
  assert.equal(result.ema50, 1.0);
  assert.equal(result.pattern, 'Standard Candle');
});

test('evaluateSignalDirection generates UP signal on strong bullish confluence', () => {
  // Generate 40 candles in consistent uptrend with pullback near lower BB
  const candles: Candle[] = Array.from({ length: 45 }, (_, i) => {
    const base = 1.2000 + i * 0.0008;
    return {
      time: 1700000000 + i * 60,
      open: base,
      close: base + 0.0006,
      high: base + 0.0009,
      low: base - 0.0001
    };
  });

  const res = evaluateSignalDirection(candles, 6, false, true);
  // Should recognize bullish bias or NO_TRADE if confidence not reached, but never fabricated
  assert.ok(['UP', 'NO_TRADE'].includes(res.direction1M));
  assert.ok(res.confidence >= 0 && res.confidence <= 100);
});
