import { Candle, TechnicalIndicators, SignalDirection, SignalRationale } from '../types/market';

/**
 * Calculates Exponential Moving Average (EMA)
 */
export function calculateEMA(data: number[], period: number): number[] {
  if (data.length === 0) return [];
  if (period <= 0) return [...data];

  const k = 2 / (period + 1);
  const emaArray: number[] = new Array(data.length);
  
  // Start with simple average for first period elements or initial value
  let sum = 0;
  const initialPeriod = Math.min(period, data.length);
  for (let i = 0; i < initialPeriod; i++) {
    sum += data[i];
  }
  let currentEma = sum / initialPeriod;
  emaArray[initialPeriod - 1] = currentEma;

  // Fill preceding with initial SMA
  for (let i = 0; i < initialPeriod - 1; i++) {
    emaArray[i] = data[i];
  }

  for (let i = initialPeriod; i < data.length; i++) {
    currentEma = data[i] * k + currentEma * (1 - k);
    emaArray[i] = currentEma;
  }

  return emaArray;
}

/**
 * Calculates Relative Strength Index (RSI, default 14)
 */
export function calculateRSI(closes: number[], period = 14): number {
  if (closes.length <= period) return 50.0; // Neutral default

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) {
      gains += diff;
    } else {
      losses += Math.abs(diff);
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) {
      avgGain = (avgGain * (period - 1) + diff) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(diff)) / period;
    }
  }

  if (avgGain === 0 && avgLoss === 0) {
    return 50.0;
  }
  if (avgLoss === 0) {
    return 100.0;
  }
  if (avgGain === 0) {
    return 0.0;
  }
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  return Number(rsi.toFixed(2));
}

/**
 * Calculates Bollinger Bands (default 20, 2)
 */
export function calculateBollingerBands(closes: number[], period = 20, multiplier = 2) {
  if (closes.length < period) {
    const last = closes[closes.length - 1] || 1.0;
    return { upper: last * 1.002, middle: last, lower: last * 0.998, bandwidth: 0.004, percentB: 50 };
  }

  const slice = closes.slice(-period);
  const sum = slice.reduce((a, b) => a + b, 0);
  const middle = sum / period;

  const variance = slice.reduce((acc, val) => acc + Math.pow(val - middle, 2), 0) / period;
  const stdDev = Math.sqrt(variance);

  const upper = middle + multiplier * stdDev;
  const lower = middle - multiplier * stdDev;
  const bandwidth = middle !== 0 ? (upper - lower) / middle : 0;
  const lastPrice = closes[closes.length - 1];
  const percentB = upper !== lower ? ((lastPrice - lower) / (upper - lower)) * 100 : 50;

  return {
    upper: Number(upper.toFixed(5)),
    middle: Number(middle.toFixed(5)),
    lower: Number(lower.toFixed(5)),
    bandwidth: Number(bandwidth.toFixed(5)),
    percentB: Number(percentB.toFixed(1))
  };
}

/**
 * Calculates Moving Average Convergence Divergence (MACD 12, 26, 9)
 */
export function calculateMACD(closes: number[], fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
  if (closes.length < slowPeriod) {
    return { macdLine: 0, signalLine: 0, histogram: 0 };
  }

  const fastEma = calculateEMA(closes, fastPeriod);
  const slowEma = calculateEMA(closes, slowPeriod);

  const macdLineSeries: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    macdLineSeries.push(fastEma[i] - slowEma[i]);
  }

  const signalLineSeries = calculateEMA(macdLineSeries, signalPeriod);
  const lastIndex = closes.length - 1;

  const macdLine = macdLineSeries[lastIndex];
  const signalLine = signalLineSeries[lastIndex];
  const histogram = macdLine - signalLine;

  return {
    macdLine: Number(macdLine.toFixed(6)),
    signalLine: Number(signalLine.toFixed(6)),
    histogram: Number(histogram.toFixed(6))
  };
}

/**
 * Calculates Stochastic Oscillator (%K, %D)
 */
export function calculateStochastic(candles: Candle[], period = 14, smoothK = 3, smoothD = 3) {
  if (candles.length < period) {
    return { k: 50, d: 50 };
  }

  const rawKList: number[] = [];
  for (let i = period - 1; i < candles.length; i++) {
    const window = candles.slice(i - period + 1, i + 1);
    let highestHigh = -Infinity;
    let lowestLow = Infinity;
    for (const c of window) {
      if (c.high > highestHigh) highestHigh = c.high;
      if (c.low < lowestLow) lowestLow = c.low;
    }
    const currentClose = candles[i].close;
    const diff = highestHigh - lowestLow;
    const rawK = diff > 0 ? ((currentClose - lowestLow) / diff) * 100 : 50;
    rawKList.push(rawK);
  }

  // Smooth K
  const smoothedKList: number[] = [];
  for (let i = smoothK - 1; i < rawKList.length; i++) {
    const kSlice = rawKList.slice(i - smoothK + 1, i + 1);
    const avgK = kSlice.reduce((a, b) => a + b, 0) / smoothK;
    smoothedKList.push(avgK);
  }

  // Smooth D
  let finalD = 50;
  if (smoothedKList.length >= smoothD) {
    const dSlice = smoothedKList.slice(-smoothD);
    finalD = dSlice.reduce((a, b) => a + b, 0) / smoothD;
  }

  const finalK = smoothedKList.length > 0 ? smoothedKList[smoothedKList.length - 1] : 50;

  return {
    k: Number(finalK.toFixed(1)),
    d: Number(finalD.toFixed(1))
  };
}

/**
 * Calculates Average True Range (ATR)
 */
export function calculateATR(candles: Candle[], period = 14): number {
  if (candles.length < 2) return 0.0005;

  const trValues: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const current = candles[i];
    const prev = candles[i - 1];
    const tr = Math.max(
      current.high - current.low,
      Math.abs(current.high - prev.close),
      Math.abs(current.low - prev.close)
    );
    trValues.push(tr);
  }

  if (trValues.length < period) {
    const avg = trValues.reduce((a, b) => a + b, 0) / trValues.length;
    return Number(avg.toFixed(6));
  }

  const slice = trValues.slice(-period);
  const atr = slice.reduce((a, b) => a + b, 0) / period;
  return Number(atr.toFixed(6));
}

/**
 * Detects candlestick formation patterns on last 2-3 candles
 */
export function detectCandlePattern(candles: Candle[]): string {
  if (candles.length < 3) return 'Standard Candle';

  const c1 = candles[candles.length - 3];
  const c2 = candles[candles.length - 2];
  const c3 = candles[candles.length - 1]; // Latest formed/forming

  const body3 = Math.abs(c3.close - c3.open);
  const range3 = c3.high - c3.low;
  const isC3Green = c3.close > c3.open;

  // Doji
  if (range3 > 0 && body3 / range3 < 0.1) {
    return 'Doji (Indecision)';
  }

  // Hammer / Bullish Pin Bar
  const lowerShadow3 = isC3Green ? c3.open - c3.low : c3.close - c3.low;
  const upperShadow3 = isC3Green ? c3.high - c3.close : c3.high - c3.open;
  if (range3 > 0 && lowerShadow3 > body3 * 2 && upperShadow3 < body3 * 0.5) {
    return 'Bullish Pin Bar / Hammer';
  }

  // Shooting Star / Bearish Pin Bar
  if (range3 > 0 && upperShadow3 > body3 * 2 && lowerShadow3 < body3 * 0.5) {
    return 'Bearish Pin Bar / Shooting Star';
  }

  // Bullish Engulfing
  if (c2.close < c2.open && c3.close > c3.open && c3.close > c2.open && c3.open < c2.close) {
    return 'Bullish Engulfing';
  }

  // Bearish Engulfing
  if (c2.close > c2.open && c3.close < c3.open && c3.close < c2.open && c3.open > c2.close) {
    return 'Bearish Engulfing';
  }

  // Three White Soldiers (approx)
  if (c1.close > c1.open && c2.close > c2.open && c3.close > c3.open && c3.close > c2.close && c2.close > c1.close) {
    return 'Three White Soldiers';
  }

  // Three Black Crows
  if (c1.close < c1.open && c2.close < c2.open && c3.close < c3.open && c3.close < c2.close && c2.close < c1.close) {
    return 'Three Black Crows';
  }

  return isC3Green ? 'Normal Bullish' : 'Normal Bearish';
}

/**
 * Computes the full suite of technical indicators
 */
export function computeAllIndicators(candles: Candle[]): TechnicalIndicators {
  if (!candles || candles.length === 0) {
    return {
      rsi: 50,
      ema9: 1.0,
      ema21: 1.0,
      ema50: 1.0,
      macd: { macdLine: 0, signalLine: 0, histogram: 0 },
      bollinger: { upper: 1.002, middle: 1.0, lower: 0.998, bandwidth: 0.004, percentB: 50 },
      stochastic: { k: 50, d: 50 },
      atr: 0.0005,
      pattern: 'Standard Candle'
    };
  }

  const closes = candles.map(c => c.close);
  const defaultClose = closes[closes.length - 1] ?? 1.0;
  const rsi = calculateRSI(closes, 14);
  const ema9 = calculateEMA(closes, 9).slice(-1)[0] ?? defaultClose;
  const ema21 = calculateEMA(closes, 21).slice(-1)[0] ?? defaultClose;
  const ema50 = calculateEMA(closes, 50).slice(-1)[0] ?? defaultClose;
  const macd = calculateMACD(closes);
  const bollinger = calculateBollingerBands(closes);
  const stochastic = calculateStochastic(candles);
  const atr = calculateATR(candles);
  const pattern = detectCandlePattern(candles);

  return {
    rsi,
    ema9: Number((ema9 ?? defaultClose).toFixed(5)),
    ema21: Number((ema21 ?? defaultClose).toFixed(5)),
    ema50: Number((ema50 ?? defaultClose).toFixed(5)),
    macd,
    bollinger,
    stochastic,
    atr,
    pattern
  };
}

/**
 * Evaluates the 1-Minute and 2-Minute signal directions with strict rules:
 * - Minimum 30 valid historical candles
 * - Strict NO TRADE on missing, stale (>2s), choppy or conflicting conditions
 * - Requires at least 65% calibrated confidence
 */
export function evaluateSignalDirection(
  candles: Candle[],
  secondsRemaining: number,
  isDataStale: boolean,
  marketOpen: boolean
): {
  direction1M: SignalDirection;
  direction2M: SignalDirection;
  confidence: number;
  reasons: string[];
  rationales: SignalRationale[];
} {
  const rationales: SignalRationale[] = [];
  const reasons: string[] = [];

  // Safety checks - rule 10 & 13
  if (!marketOpen) {
    return {
      direction1M: 'NO_TRADE',
      direction2M: 'NO_TRADE',
      confidence: 0,
      reasons: ['Market closed for this asset variant. Zero trading.'],
      rationales: [{ rule: 'Market Status', weight: 1.0, impact: 'NEUTRAL' }]
    };
  }

  if (isDataStale) {
    return {
      direction1M: 'NO_TRADE',
      direction2M: 'NO_TRADE',
      confidence: 0,
      reasons: ['Data feed delay > 2s detected. Stale tick safety triggered.'],
      rationales: [{ rule: 'Feed Latency Threshold', weight: 1.0, impact: 'NEUTRAL' }]
    };
  }

  if (candles.length < 30) {
    return {
      direction1M: 'NO_TRADE',
      direction2M: 'NO_TRADE',
      confidence: 0,
      reasons: [`Insufficient candle history (${candles.length}/30 required).`],
      rationales: [{ rule: 'Sample Size Safeguard', weight: 1.0, impact: 'NEUTRAL' }]
    };
  }

  const indicators = computeAllIndicators(candles);
  const lastClose = candles[candles.length - 1].close;

  let bullishScore = 0;
  let bearishScore = 0;
  let totalWeight = 0;

  // 1. EMA Alignment (Weight: 2.0)
  totalWeight += 2.0;
  if (indicators.ema9 > indicators.ema21 && indicators.ema21 > indicators.ema50) {
    bullishScore += 2.0;
    rationales.push({ rule: 'EMA Triple Stack (9 > 21 > 50)', weight: 2.0, impact: 'BULLISH' });
    reasons.push('EMA Stack aligned upward (9 > 21 > 50)');
  } else if (indicators.ema9 < indicators.ema21 && indicators.ema21 < indicators.ema50) {
    bearishScore += 2.0;
    rationales.push({ rule: 'EMA Triple Stack (9 < 21 < 50)', weight: 2.0, impact: 'BEARISH' });
    reasons.push('EMA Stack aligned downward (9 < 21 < 50)');
  } else {
    rationales.push({ rule: 'EMA Alignment Neutral/Entangled', weight: 1.0, impact: 'NEUTRAL' });
  }

  // 2. RSI Momentum & Overbought/Oversold (Weight: 1.8)
  totalWeight += 1.8;
  if (indicators.rsi < 30) {
    bullishScore += 1.8;
    rationales.push({ rule: 'RSI Oversold (< 30)', weight: 1.8, impact: 'BULLISH' });
    reasons.push(`RSI deeply oversold at ${indicators.rsi}`);
  } else if (indicators.rsi > 70) {
    bearishScore += 1.8;
    rationales.push({ rule: 'RSI Overbought (> 70)', weight: 1.8, impact: 'BEARISH' });
    reasons.push(`RSI deeply overbought at ${indicators.rsi}`);
  } else if (indicators.rsi >= 55) {
    bullishScore += 1.0;
    rationales.push({ rule: 'RSI Above Median Momentum', weight: 1.0, impact: 'BULLISH' });
  } else if (indicators.rsi <= 45) {
    bearishScore += 1.0;
    rationales.push({ rule: 'RSI Below Median Momentum', weight: 1.0, impact: 'BEARISH' });
  }

  // 3. MACD Histogram & Cross (Weight: 1.5)
  totalWeight += 1.5;
  if (indicators.macd.histogram > 0 && indicators.macd.macdLine > indicators.macd.signalLine) {
    bullishScore += 1.5;
    rationales.push({ rule: 'MACD Positive Divergence', weight: 1.5, impact: 'BULLISH' });
    reasons.push('MACD histogram positive with bullish crossover');
  } else if (indicators.macd.histogram < 0 && indicators.macd.macdLine < indicators.macd.signalLine) {
    bearishScore += 1.5;
    rationales.push({ rule: 'MACD Negative Divergence', weight: 1.5, impact: 'BEARISH' });
    reasons.push('MACD histogram negative with bearish crossover');
  }

  // 4. Bollinger Bands (Weight: 1.5)
  totalWeight += 1.5;
  if (lastClose <= indicators.bollinger.lower) {
    bullishScore += 1.5;
    rationales.push({ rule: 'Lower Bollinger Band Tag', weight: 1.5, impact: 'BULLISH' });
    reasons.push('Price touching or piercing lower Bollinger Band');
  } else if (lastClose >= indicators.bollinger.upper) {
    bearishScore += 1.5;
    rationales.push({ rule: 'Upper Bollinger Band Tag', weight: 1.5, impact: 'BEARISH' });
    reasons.push('Price touching or piercing upper Bollinger Band');
  }

  // 5. Stochastic (Weight: 1.2)
  totalWeight += 1.2;
  if (indicators.stochastic.k < 20 && indicators.stochastic.k > indicators.stochastic.d) {
    bullishScore += 1.2;
    rationales.push({ rule: 'Stochastic Oversold Golden Cross', weight: 1.2, impact: 'BULLISH' });
    reasons.push('Stochastic %K crossed above %D below 20');
  } else if (indicators.stochastic.k > 80 && indicators.stochastic.k < indicators.stochastic.d) {
    bearishScore += 1.2;
    rationales.push({ rule: 'Stochastic Overbought Death Cross', weight: 1.2, impact: 'BEARISH' });
    reasons.push('Stochastic %K crossed below %D above 80');
  }

  // 6. Candlestick Pattern (Weight: 1.5)
  totalWeight += 1.5;
  if (indicators.pattern.includes('Bullish')) {
    bullishScore += 1.5;
    rationales.push({ rule: `Pattern: ${indicators.pattern}`, weight: 1.5, impact: 'BULLISH' });
    reasons.push(`Recognized ${indicators.pattern}`);
  } else if (indicators.pattern.includes('Bearish')) {
    bearishScore += 1.5;
    rationales.push({ rule: `Pattern: ${indicators.pattern}`, weight: 1.5, impact: 'BEARISH' });
    reasons.push(`Recognized ${indicators.pattern}`);
  } else if (indicators.pattern.includes('Doji')) {
    // Doji indicates indecision, penalize both
    rationales.push({ rule: 'Doji / Low Volatility Chop', weight: 1.5, impact: 'NEUTRAL' });
    reasons.push('Doji detected: Market in equilibrium/indecision');
  }

  // Conflict detection: If both bullish and bearish scores are high, it's conflicting signals -> NO TRADE
  const conflictRatio = Math.min(bullishScore, bearishScore) / Math.max(bullishScore, bearishScore || 1);
  if (conflictRatio > 0.65 && (bullishScore + bearishScore) > 3.0) {
    return {
      direction1M: 'NO_TRADE',
      direction2M: 'NO_TRADE',
      confidence: 45,
      reasons: ['Conflicting signals detected across indicators (trend vs oscillator conflict).'],
      rationales
    };
  }

  // Volatility check: If ATR is near 0, flat market
  if (indicators.atr < 0.00005) {
    return {
      direction1M: 'NO_TRADE',
      direction2M: 'NO_TRADE',
      confidence: 30,
      reasons: ['Zero volatility / flat consolidation. High risk of broker slip.'],
      rationales
    };
  }

  // Confidence computation
  const dominantScore = Math.max(bullishScore, bearishScore);
  const netDominance = Math.abs(bullishScore - bearishScore);
  const rawConfidence = (dominantScore / totalWeight) * 70 + (netDominance / totalWeight) * 30;
  // Calibrated conservative confidence (capped realistically between 50% and 88%)
  const calibratedConfidence = Math.min(88, Math.max(48, Math.round(rawConfidence)));

  // Minimum threshold is 65% for trade issuance
  if (calibratedConfidence < 65) {
    return {
      direction1M: 'NO_TRADE',
      direction2M: 'NO_TRADE',
      confidence: calibratedConfidence,
      reasons: [`Confidence (${calibratedConfidence}%) below required threshold (65%).`],
      rationales
    };
  }

  const isBullish = bullishScore > bearishScore;
  const direction1M: SignalDirection = isBullish ? 'UP' : 'DOWN';

  // For 2-Minute Candle: Check if Higher-Timeframe/EMA 50 supports continuation
  let direction2M: SignalDirection = 'NO_TRADE';
  if (isBullish && indicators.ema21 > indicators.ema50 && indicators.macd.histogram >= 0) {
    direction2M = 'UP';
  } else if (!isBullish && indicators.ema21 < indicators.ema50 && indicators.macd.histogram <= 0) {
    direction2M = 'DOWN';
  } else {
    direction2M = 'NO_TRADE'; // 2M trend not strongly established
  }

  return {
    direction1M,
    direction2M,
    confidence: calibratedConfidence,
    reasons,
    rationales
  };
}
