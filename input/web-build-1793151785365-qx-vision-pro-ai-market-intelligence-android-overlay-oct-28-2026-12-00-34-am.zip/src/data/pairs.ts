import { MarketPair } from '../types/market';

export const REQUESTED_20_PAIRS: MarketPair[] = [
  // 1 & 2: GBP/USD
  {
    id: 'GBPUSD',
    symbol: 'GBP/USD',
    variant: 'REAL',
    quotexCode: 56,
    open: true,
    payoutPercent: 84,
    currentPrice: 1.29854,
    priceChange24h: 0.18,
    spread: 0.00012,
    lastUpdated: Date.now()
  },
  {
    id: 'GBPUSD_otc',
    symbol: 'GBP/USD (OTC)',
    variant: 'OTC',
    quotexCode: 956,
    open: true,
    payoutPercent: 89,
    currentPrice: 1.29910,
    priceChange24h: 0.32,
    spread: 0.00018,
    lastUpdated: Date.now()
  },

  // 3 & 4: USD/JPY
  {
    id: 'USDJPY',
    symbol: 'USD/JPY',
    variant: 'REAL',
    quotexCode: 63,
    open: true,
    payoutPercent: 82,
    currentPrice: 153.420,
    priceChange24h: -0.25,
    spread: 0.015,
    lastUpdated: Date.now()
  },
  {
    id: 'USDJPY_otc',
    symbol: 'USD/JPY (OTC)',
    variant: 'OTC',
    quotexCode: 93,
    open: true,
    payoutPercent: 91,
    currentPrice: 153.510,
    priceChange24h: -0.19,
    spread: 0.022,
    lastUpdated: Date.now()
  },

  // 5 & 6: USD/CHF
  {
    id: 'USDCHF',
    symbol: 'USD/CHF',
    variant: 'REAL',
    quotexCode: 62,
    open: true,
    payoutPercent: 80,
    currentPrice: 0.88415,
    priceChange24h: 0.08,
    spread: 0.00014,
    lastUpdated: Date.now()
  },
  {
    id: 'USDCHF_otc',
    symbol: 'USD/CHF (OTC)',
    variant: 'OTC',
    quotexCode: 92,
    open: true,
    payoutPercent: 88,
    currentPrice: 0.88462,
    priceChange24h: 0.12,
    spread: 0.00019,
    lastUpdated: Date.now()
  },

  // 7 & 8: AUD/USD
  {
    id: 'AUDUSD',
    symbol: 'AUD/USD',
    variant: 'REAL',
    quotexCode: 40,
    open: true,
    payoutPercent: 81,
    currentPrice: 0.65820,
    priceChange24h: -0.42,
    spread: 0.00011,
    lastUpdated: Date.now()
  },
  {
    id: 'AUDUSD_otc',
    symbol: 'AUD/USD (OTC)',
    variant: 'OTC',
    quotexCode: 71,
    open: true,
    payoutPercent: 90,
    currentPrice: 0.65890,
    priceChange24h: -0.35,
    spread: 0.00016,
    lastUpdated: Date.now()
  },

  // 9 & 10: USD/CAD
  {
    id: 'USDCAD',
    symbol: 'USD/CAD',
    variant: 'REAL',
    quotexCode: 61,
    open: true,
    payoutPercent: 83,
    currentPrice: 1.39120,
    priceChange24h: 0.15,
    spread: 0.00015,
    lastUpdated: Date.now()
  },
  {
    id: 'USDCAD_otc',
    symbol: 'USD/CAD (OTC)',
    variant: 'OTC',
    quotexCode: 91,
    open: true,
    payoutPercent: 89,
    currentPrice: 1.39185,
    priceChange24h: 0.22,
    spread: 0.00021,
    lastUpdated: Date.now()
  },

  // 11 & 12: NZD/USD
  {
    id: 'NZDUSD',
    symbol: 'NZD/USD',
    variant: 'REAL',
    quotexCode: 60,
    open: true,
    payoutPercent: 78,
    currentPrice: 0.59740,
    priceChange24h: -0.31,
    spread: 0.00018,
    lastUpdated: Date.now()
  },
  {
    id: 'NZDUSD_otc',
    symbol: 'NZD/USD (OTC)',
    variant: 'OTC',
    quotexCode: 90,
    open: true,
    payoutPercent: 87,
    currentPrice: 0.59795,
    priceChange24h: -0.28,
    spread: 0.00024,
    lastUpdated: Date.now()
  },

  // 13 & 14: EUR/GBP
  {
    id: 'EURGBP',
    symbol: 'EUR/GBP',
    variant: 'REAL',
    quotexCode: 47,
    open: true,
    payoutPercent: 85,
    currentPrice: 0.83410,
    priceChange24h: -0.11,
    spread: 0.00013,
    lastUpdated: Date.now()
  },
  {
    id: 'EURGBP_otc',
    symbol: 'EUR/GBP (OTC)',
    variant: 'OTC',
    quotexCode: 78,
    open: true,
    payoutPercent: 92,
    currentPrice: 0.83445,
    priceChange24h: -0.06,
    spread: 0.00017,
    lastUpdated: Date.now()
  },

  // 15 & 16: EUR/JPY
  {
    id: 'EURJPY',
    symbol: 'EUR/JPY',
    variant: 'REAL',
    quotexCode: 48,
    open: true,
    payoutPercent: 82,
    currentPrice: 166.240,
    priceChange24h: -0.34,
    spread: 0.016,
    lastUpdated: Date.now()
  },
  {
    id: 'EURJPY_otc',
    symbol: 'EUR/JPY (OTC)',
    variant: 'OTC',
    quotexCode: 79,
    open: true,
    payoutPercent: 90,
    currentPrice: 166.380,
    priceChange24h: -0.29,
    spread: 0.024,
    lastUpdated: Date.now()
  },

  // 17 & 18: EUR/AUD
  {
    id: 'EURAUD',
    symbol: 'EUR/AUD',
    variant: 'REAL',
    quotexCode: 44,
    open: true,
    payoutPercent: 79,
    currentPrice: 1.64250,
    priceChange24h: 0.28,
    spread: 0.00019,
    lastUpdated: Date.now()
  },
  {
    id: 'EURAUD_otc',
    symbol: 'EUR/AUD (OTC)',
    variant: 'OTC',
    quotexCode: 944,
    open: true,
    payoutPercent: 88,
    currentPrice: 1.64320,
    priceChange24h: 0.35,
    spread: 0.00026,
    lastUpdated: Date.now()
  },

  // 19 & 20: GBP/JPY
  {
    id: 'GBPJPY',
    symbol: 'GBP/JPY',
    variant: 'REAL',
    quotexCode: 54,
    open: true,
    payoutPercent: 83,
    currentPrice: 199.280,
    priceChange24h: -0.09,
    spread: 0.021,
    lastUpdated: Date.now()
  },
  {
    id: 'GBPJPY_otc',
    symbol: 'GBP/JPY (OTC)',
    variant: 'OTC',
    quotexCode: 84,
    open: true,
    payoutPercent: 93,
    currentPrice: 199.410,
    priceChange24h: -0.04,
    spread: 0.029,
    lastUpdated: Date.now()
  }
];

export function checkMarketAvailability(pair: MarketPair): {
  isAvailable: boolean;
  statusLabel: 'OPEN' | 'CLOSED' | 'VOLATILITY_HALT';
  reason?: string;
} {
  if (!pair.open) {
    return {
      isAvailable: false,
      statusLabel: 'CLOSED',
      reason: 'Market session inactive on broker'
    };
  }

  // If payout is below 70%, it is considered unfavorable / degraded
  if (pair.payoutPercent < 70) {
    return {
      isAvailable: false,
      statusLabel: 'VOLATILITY_HALT',
      reason: `Payout ${pair.payoutPercent}% below trading threshold (70%)`
    };
  }

  return {
    isAvailable: true,
    statusLabel: 'OPEN'
  };
}
