import React, { useState } from 'react';
import { MarketPair } from '../types/market';
import { CheckCircle2, XCircle, TrendingUp, TrendingDown, Target, ShieldCheck } from 'lucide-react';

interface MarketDataGridProps {
  pairs: MarketPair[];
  activePairId: string;
  onSelectPair: (id: string) => void;
  onTogglePairStatus: (id: string, open: boolean) => void;
}

export const MarketDataGrid: React.FC<MarketDataGridProps> = ({
  pairs,
  activePairId,
  onSelectPair,
  onTogglePairStatus
}) => {
  const [filter, setFilter] = useState<'ALL' | 'REAL' | 'OTC'>('ALL');
  const [search, setSearch] = useState<string>('');

  const filteredPairs = pairs.filter(p => {
    if (filter !== 'ALL' && p.variant !== filter) return false;
    if (search && !p.symbol.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 backdrop-blur-md shadow-xl flex flex-col h-full">
      {/* Header and filters */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>20 Monitored Quotex Pairs</span>
            <span className="text-xs font-mono font-normal px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              REAL + OTC SYNTHETICS
            </span>
          </h3>
          <p className="text-xs text-slate-400">
            Real-time verification of availability, broker payouts, and tick latency.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Variant Filter Tabs */}
          <div className="flex rounded-lg bg-slate-950 p-1 border border-slate-800 text-xs font-mono">
            <button
              onClick={() => setFilter('ALL')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                filter === 'ALL'
                  ? 'bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              ALL (20)
            </button>
            <button
              onClick={() => setFilter('REAL')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                filter === 'REAL'
                  ? 'bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              REAL (10)
            </button>
            <button
              onClick={() => setFilter('OTC')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                filter === 'OTC'
                  ? 'bg-cyan-500/20 text-cyan-400 font-bold border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              OTC (10)
            </button>
          </div>
        </div>
      </div>

      {/* Grid of pairs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 overflow-y-auto max-h-[460px] pr-1">
        {filteredPairs.map(pair => {
          const isSelected = pair.id === activePairId;
          const isPositive = pair.priceChange24h >= 0;

          return (
            <div
              key={pair.id}
              onClick={() => onSelectPair(pair.id)}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer relative group ${
                isSelected
                  ? 'bg-emerald-950/30 border-emerald-500/60 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500/30'
                  : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/70'
              }`}
            >
              {/* Top row: Symbol and Variant */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-black font-mono text-slate-100">
                    {pair.symbol}
                  </span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                      pair.variant === 'OTC'
                        ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {pair.variant}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  {pair.open ? (
                    <span className="flex items-center text-[10px] font-mono font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      {pair.payoutPercent}%
                    </span>
                  ) : (
                    <span className="flex items-center text-[10px] font-mono font-semibold text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20">
                      <XCircle className="w-3 h-3 mr-1" />
                      CLOSED
                    </span>
                  )}
                </div>
              </div>

              {/* Middle row: Live price and 24h change */}
              <div className="flex items-baseline justify-between mb-2.5">
                <div className="text-lg font-bold font-mono tracking-tight text-slate-100">
                  {pair.currentPrice}
                </div>
                <div
                  className={`text-xs font-mono font-semibold flex items-center ${
                    isPositive ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isPositive ? <TrendingUp className="w-3.5 h-3.5 mr-0.5" /> : <TrendingDown className="w-3.5 h-3.5 mr-0.5" />}
                  {isPositive ? '+' : ''}{pair.priceChange24h}%
                </div>
              </div>

              {/* Bottom row: Spread & Target Action */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400">
                <span>Spread: {pair.spread}</span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onTogglePairStatus(pair.id, !pair.open);
                    }}
                    className="hover:text-slate-200 underline text-[9px]"
                    title="Simulate Market Session Open/Close"
                  >
                    {pair.open ? 'Set Closed' : 'Set Open'}
                  </button>

                  {isSelected ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                      <ShieldCheck className="w-3 h-3" /> ACTIVE
                    </span>
                  ) : (
                    <span className="text-slate-500 group-hover:text-slate-300 flex items-center gap-0.5">
                      <Target className="w-3 h-3" /> Focus
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
