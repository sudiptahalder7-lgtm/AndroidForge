import React, { useState } from 'react';
import { SignalResult } from '../types/market';
import { Download, History, ArrowUpRight, ArrowDownRight, MinusCircle, Info } from 'lucide-react';

interface SignalHistoryTableProps {
  signals: SignalResult[];
  onExportCsv: () => void;
}

export const SignalHistoryTable: React.FC<SignalHistoryTableProps> = ({
  signals,
  onExportCsv
}) => {
  const [selectedSignal, setSelectedSignal] = useState<SignalResult | null>(null);

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 backdrop-blur-md shadow-xl flex flex-col space-y-4">
      {/* Header and CSV Export Button */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-emerald-400" />
          <div>
            <h3 className="text-base font-bold text-slate-100">
              Signal Execution History
            </h3>
            <p className="text-xs text-slate-400">
              Complete historical record of triggered inference signals, timing, and outcomes.
            </p>
          </div>
        </div>

        <button
          onClick={onExportCsv}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono font-semibold text-slate-200 transition-colors shadow-sm"
          title="Export Signal Logs to CSV"
        >
          <Download className="w-3.5 h-3.5" />
          <span>EXPORT CSV</span>
        </button>
      </div>

      {/* Signals Table */}
      <div className="overflow-x-auto max-h-[380px]">
        <table className="w-full text-left text-xs font-mono">
          <thead className="sticky top-0 bg-slate-900 border-b border-slate-800 text-slate-400 z-10">
            <tr>
              <th className="py-2.5 px-3">Time</th>
              <th className="py-2.5 px-3">Asset</th>
              <th className="py-2.5 px-3">Direction (1M)</th>
              <th className="py-2.5 px-3">2M Trend</th>
              <th className="py-2.5 px-3">Entry</th>
              <th className="py-2.5 px-3">Exit</th>
              <th className="py-2.5 px-3">Confidence</th>
              <th className="py-2.5 px-3">Outcome</th>
              <th className="py-2.5 px-3">Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-200">
            {signals.map(s => {
              const isUp = s.direction1Min === 'UP';
              const isDown = s.direction1Min === 'DOWN';
              const isNoTrade = s.direction1Min === 'NO_TRADE';

              return (
                <tr key={s.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                    {new Date(s.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="font-bold text-slate-100">{s.symbol}</span>
                    <span className="text-[10px] text-slate-500 ml-1.5">({s.variant})</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    {isUp && (
                      <span className="inline-flex items-center gap-1 font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                        <ArrowUpRight className="w-3.5 h-3.5" /> UP (CALL)
                      </span>
                    )}
                    {isDown && (
                      <span className="inline-flex items-center gap-1 font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30">
                        <ArrowDownRight className="w-3.5 h-3.5" /> DOWN (PUT)
                      </span>
                    )}
                    {isNoTrade && (
                      <span className="inline-flex items-center gap-1 font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                        <MinusCircle className="w-3.5 h-3.5" /> NO TRADE
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">
                    {s.direction2Min}
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-300">
                    {s.entryPrice}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">
                    {s.exitPrice ?? '—'}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="font-bold text-emerald-400">{s.confidence}%</span>
                  </td>
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    {s.outcome === 'WIN' && (
                      <span className="px-2 py-0.5 rounded font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                        WIN
                      </span>
                    )}
                    {s.outcome === 'LOSS' && (
                      <span className="px-2 py-0.5 rounded font-black bg-rose-500/20 text-rose-400 border border-rose-500/40">
                        LOSS
                      </span>
                    )}
                    {s.outcome === 'REFUND' && (
                      <span className="px-2 py-0.5 rounded font-black bg-slate-800 text-slate-300 border border-slate-700">
                        TIE
                      </span>
                    )}
                    {s.outcome === 'PENDING' && (
                      <span className="px-2 py-0.5 rounded font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/40 animate-pulse">
                        PENDING
                      </span>
                    )}
                    {!s.outcome && isNoTrade && (
                      <span className="text-slate-500 text-[10px]">VETOED</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    <button
                      onClick={() => setSelectedSignal(s)}
                      className="p-1 rounded text-slate-400 hover:text-emerald-400 hover:bg-slate-800"
                      title="View Rationale and Technical Indicators"
                    >
                      <Info className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Rationale Modal */}
      {selectedSignal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4 text-slate-100 font-sans">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h4 className="text-sm font-bold font-mono text-emerald-400">
                  {selectedSignal.id} — {selectedSignal.symbol}
                </h4>
                <p className="text-xs text-slate-400 font-mono">
                  Timestamp: {new Date(selectedSignal.timestamp).toISOString()}
                </p>
              </div>
              <button
                onClick={() => setSelectedSignal(null)}
                className="text-slate-400 hover:text-white px-2 py-1 text-sm font-mono"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="grid grid-cols-2 gap-2 p-3 rounded-lg bg-slate-950 border border-slate-800">
                <div>RSI (14): <span className="text-emerald-400">{selectedSignal.indicators.rsi}</span></div>
                <div>Pattern: <span className="text-emerald-400">{selectedSignal.indicators.pattern}</span></div>
                <div>EMA 9: <span className="text-slate-300">{selectedSignal.indicators.ema9}</span></div>
                <div>EMA 21: <span className="text-slate-300">{selectedSignal.indicators.ema21}</span></div>
                <div>MACD Hist: <span className="text-slate-300">{selectedSignal.indicators.macd.histogram}</span></div>
                <div>ATR: <span className="text-slate-300">{selectedSignal.indicators.atr}</span></div>
              </div>

              <div>
                <div className="text-[10px] uppercase text-slate-400 font-bold mb-1">
                  Synthesized Decision Rationale:
                </div>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {selectedSignal.reasons.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setSelectedSignal(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono font-semibold text-slate-200"
              >
                CLOSE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
