import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Minimize2,
  Maximize2,
  Play,
  Pause,
  ArrowUpCircle,
  ArrowDownCircle,
  AlertCircle,
  GripHorizontal,
  Layers,
  ChevronDown
} from 'lucide-react';
import { ScannerStatus, SignalResult, MarketPair } from '../types/market';

interface FloatingOverlaySimulatorProps {
  status: ScannerStatus;
  pairs: MarketPair[];
  activePairId: string;
  onSelectPair: (id: string) => void;
  onStartScanner: () => void;
  onPauseScanner: () => void;
  onResumeScanner: () => void;
  onStopScanner: () => void;
  latestSignal: SignalResult | null;
}

export const FloatingOverlaySimulator: React.FC<FloatingOverlaySimulatorProps> = ({
  status,
  pairs,
  activePairId,
  onSelectPair,
  onStartScanner,
  onPauseScanner,
  onResumeScanner,
  onStopScanner,
  latestSignal
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 24, y: 120 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragRef = useRef<{ startX: number; startY: number; posX: number; posY: number }>({
    startX: 0,
    startY: 0,
    posX: 24,
    posY: 120
  });

  const [secondsRemaining, setSecondsRemaining] = useState<number>(60 - new Date().getSeconds());

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining(60 - new Date().getSeconds());
    }, 250);
    return () => clearInterval(timer);
  }, []);

  const activePair = pairs.find(p => p.id === activePairId) || pairs[0];

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    const newX = Math.max(10, Math.min(window.innerWidth - (isExpanded ? 320 : 90), dragRef.current.posX + dx));
    const newY = Math.max(70, Math.min(window.innerHeight - (isExpanded ? 360 : 90), dragRef.current.posY + dy));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // Ignore
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-semibold shadow-2xl transition-all border border-emerald-400/40 hover:scale-105"
      >
        <Layers className="w-4 h-4" />
        <span>RELAUNCH OVERLAY</span>
      </button>
    );
  }

  // COLLAPSED ROUND FLOATING BADGE (Matches Android Floating Bubble)
  if (!isExpanded) {
    return (
      <div
        style={{ left: `${position.x}px`, top: `${position.y}px` }}
        className="fixed z-50 select-none touch-none transition-shadow"
      >
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="relative w-18 h-18 rounded-full bg-slate-950/95 border-2 border-emerald-500/60 shadow-[0_10px_35px_rgba(0,0,0,0.8)] backdrop-blur-xl flex flex-col items-center justify-center cursor-grab active:cursor-grabbing hover:border-emerald-400 transition-all p-1"
        >
          {/* Signal Indicator Rim */}
          <div
            className={`absolute -inset-1 rounded-full pointer-events-none opacity-80 ${
              latestSignal?.direction1Min === 'UP'
                ? 'ring-2 ring-emerald-400 animate-pulse'
                : latestSignal?.direction1Min === 'DOWN'
                ? 'ring-2 ring-rose-400 animate-pulse'
                : 'ring-1 ring-slate-700'
            }`}
          />

          <div className="text-[10px] font-mono font-bold text-slate-300 truncate max-w-[60px] text-center">
            {activePair.symbol.split('/')[0]}
          </div>

          <div className="text-xs font-extrabold font-mono text-emerald-400">
            {secondsRemaining}s
          </div>

          <div className="text-[9px] font-mono font-bold">
            {latestSignal?.direction1Min === 'UP' ? (
              <span className="text-emerald-400 flex items-center">▲ UP</span>
            ) : latestSignal?.direction1Min === 'DOWN' ? (
              <span className="text-rose-400 flex items-center">▼ DWN</span>
            ) : (
              <span className="text-slate-500">HOLD</span>
            )}
          </div>

          <button
            onClick={() => setIsExpanded(true)}
            className="absolute -top-1 -right-1 p-1 rounded-full bg-slate-800 border border-slate-600 text-slate-300 hover:text-white"
            title="Expand Floating Overlay"
          >
            <Maximize2 className="w-2.5 h-2.5" />
          </button>
        </div>
      </div>
    );
  }

  // EXPANDED SYSTEM-WIDE OVERLAY WINDOW
  return (
    <div
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
      className="fixed z-50 w-76 sm:w-80 select-none touch-none shadow-[0_20px_50px_rgba(0,0,0,0.85)] rounded-2xl bg-slate-950/95 border border-slate-700/80 backdrop-blur-2xl text-slate-100 overflow-hidden font-sans"
    >
      {/* Draggable Title Bar */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="flex items-center justify-between px-3.5 py-2.5 bg-slate-900/90 border-b border-slate-800 cursor-grab active:cursor-grabbing"
      >
        <div className="flex items-center gap-2">
          <GripHorizontal className="w-4 h-4 text-slate-500" />
          <span className="text-xs font-bold font-mono tracking-wider text-emerald-400 uppercase flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            QX OVERLAY PRO
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsExpanded(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800/80 transition-colors"
            title="Collapse to Floating Bubble"
          >
            <Minimize2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
            title="Close Overlay"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Overlay Body */}
      <div className="p-4 space-y-3">
        {/* Pair selector dropdown */}
        <div className="relative">
          <label className="text-[10px] font-mono uppercase text-slate-400 tracking-wider block mb-1">
            Active Market Asset
          </label>
          <div className="relative">
            <select
              value={activePairId}
              onChange={e => onSelectPair(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700/90 rounded-lg px-3 py-1.5 text-xs font-mono font-semibold text-slate-200 focus:outline-none focus:border-emerald-500 appearance-none pr-8 cursor-pointer"
            >
              {pairs.map(p => {
                const cleanName = p.symbol.includes('(') ? p.symbol : `${p.symbol} (${p.variant})`;
                return (
                  <option key={p.id} value={p.id}>
                    {cleanName} — {p.open ? `${p.payoutPercent}%` : 'CLOSED'}
                  </option>
                );
              })}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2.5 top-2 pointer-events-none" />
          </div>
        </div>

        {/* Live Candle Countdown & Price Ticker */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
          <div>
            <div className="text-[10px] font-mono text-slate-400 uppercase">Broker Rate</div>
            <div className="text-base font-extrabold font-mono text-slate-100">
              {activePair.currentPrice}
            </div>
          </div>

          <div className="text-right">
            <div className="text-[10px] font-mono text-slate-400 uppercase">M1 Expiry In</div>
            <div
              className={`text-base font-extrabold font-mono ${
                secondsRemaining <= 7 ? 'text-amber-400 animate-pulse' : 'text-emerald-400'
              }`}
            >
              {secondsRemaining}s
            </div>
          </div>
        </div>

        {/* Real-Time Signal Card */}
        <div
          className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
            latestSignal?.direction1Min === 'UP'
              ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
              : latestSignal?.direction1Min === 'DOWN'
              ? 'bg-rose-500/10 border-rose-500/40 text-rose-300'
              : 'bg-slate-900/70 border-slate-800 text-slate-300'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {latestSignal?.direction1Min === 'UP' ? (
              <ArrowUpCircle className="w-7 h-7 text-emerald-400" />
            ) : latestSignal?.direction1Min === 'DOWN' ? (
              <ArrowDownCircle className="w-7 h-7 text-rose-400" />
            ) : (
              <AlertCircle className="w-7 h-7 text-amber-400" />
            )}

            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                1-Min Prediction
              </div>
              <div className="text-lg font-black font-mono">
                {latestSignal ? latestSignal.direction1Min : 'NO SIGNAL YET'}
              </div>
            </div>
          </div>

          {latestSignal && (
            <div className="text-right">
              <div className="text-[10px] font-mono text-slate-400">Confidence</div>
              <div className="text-sm font-bold font-mono text-emerald-400">
                {latestSignal.confidence}%
              </div>
            </div>
          )}
        </div>

        {/* 2-Candle Continuation Badge */}
        {latestSignal && (
          <div className="flex items-center justify-between px-2 text-[10px] font-mono text-slate-400">
            <span>2-Candle Trend:</span>
            <span
              className={`font-bold ${
                latestSignal.direction2Min === 'UP'
                  ? 'text-emerald-400'
                  : latestSignal.direction2Min === 'DOWN'
                  ? 'text-rose-400'
                  : 'text-slate-500'
              }`}
            >
              {latestSignal.direction2Min}
            </span>
          </div>
        )}

        {/* Service Controls (Start, Pause, Resume, Stop) */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          {status === 'SCANNING' ? (
            <>
              <button
                onClick={onPauseScanner}
                className="py-1.5 px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300 font-mono text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>PAUSE SCAN</span>
              </button>
              <button
                onClick={onStopScanner}
                className="py-1.5 px-3 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 text-rose-300 font-mono text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
                <span>STOP SERVICE</span>
              </button>
            </>
          ) : status === 'PAUSED' ? (
            <>
              <button
                onClick={onResumeScanner}
                className="py-1.5 px-3 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 font-mono text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Play className="w-3.5 h-3.5" />
                <span>RESUME</span>
              </button>
              <button
                onClick={onStopScanner}
                className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 font-mono text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <X className="w-3.5 h-3.5" />
                <span>STOP</span>
              </button>
            </>
          ) : (
            <button
              onClick={onStartScanner}
              className="col-span-2 py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>START FOREGROUND SERVICE</span>
            </button>
          )}
        </div>

        {/* Android Native Permission status badge */}
        <div className="pt-1 flex items-center justify-between text-[9px] font-mono text-slate-500 border-t border-slate-800">
          <span>SYSTEM_ALERT_WINDOW</span>
          <span className="text-emerald-400 font-bold">GRANTED</span>
        </div>
      </div>
    </div>
  );
};
