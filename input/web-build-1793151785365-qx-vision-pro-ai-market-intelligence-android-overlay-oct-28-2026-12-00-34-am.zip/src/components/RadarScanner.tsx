import React, { useEffect, useState, useMemo } from 'react';
import { Volume2, VolumeX, Radio, Compass } from 'lucide-react';
import { MarketPair, ScannerStatus, SignalResult } from '../types/market';
import { soundFx } from '../services/audioSynthesizer';

interface RadarScannerProps {
  status: ScannerStatus;
  pairs: MarketPair[];
  activePairId: string;
  onSelectPair: (pairId: string) => void;
  latestSignal: SignalResult | null;
}

export const RadarScanner: React.FC<RadarScannerProps> = ({
  status,
  pairs,
  activePairId,
  onSelectPair,
  latestSignal
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60 - new Date().getSeconds());
  const [soundActive, setSoundActive] = useState<boolean>(false);

  useEffect(() => {
    const timer = setInterval(() => {
      const sec = new Date().getSeconds();
      setSecondsRemaining(60 - sec);
    }, 250);
    return () => clearInterval(timer);
  }, []);

  const toggleSound = () => {
    const next = !soundActive;
    setSoundActive(next);
    soundFx.setSoundEnabled(next);
    if (next) soundFx.playRadarPing();
  };

  const activePair = useMemo(() => {
    return pairs.find(p => p.id === activePairId) || pairs[0];
  }, [pairs, activePairId]);

  // Position pairs radially around radar
  const blips = useMemo(() => {
    return pairs.slice(0, 16).map((pair, index) => {
      const angle = (index / 16) * 2 * Math.PI - Math.PI / 2;
      const radius = 32 + (index % 3) * 16; // % from center
      const x = 50 + radius * Math.cos(angle);
      const y = 50 + radius * Math.sin(angle);
      return { pair, x, y };
    });
  }, [pairs]);

  const isFinal7s = secondsRemaining <= 7 && secondsRemaining > 1;
  const isFinal1s = secondsRemaining === 1;

  return (
    <div className="relative flex flex-col items-center justify-center p-6 bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md shadow-2xl overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(16,185,129,0.06),transparent_70%)] pointer-events-none" />

      {/* Header controls */}
      <div className="w-full flex items-center justify-between mb-4 z-10">
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <Radio className={`w-5 h-5 ${status === 'SCANNING' ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
            {status === 'SCANNING' && (
              <span className="absolute -inset-1 rounded-full bg-emerald-400/20 animate-ping" />
            )}
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-200 tracking-wide uppercase flex items-center gap-1.5">
              Quantum Radar Engine
              <span className="text-[10px] font-mono font-normal px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                1M CANDLE
              </span>
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              Target: <span className="text-emerald-300 font-semibold">{activePair?.symbol}</span> ({activePair?.variant})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className={`p-2 rounded-lg border text-xs font-mono transition-all flex items-center gap-1.5 ${
              soundActive
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400 shadow-sm shadow-emerald-500/10'
                : 'bg-slate-800/80 border-slate-700/60 text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle Synthesized Audio Chimes"
          >
            {soundActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{soundActive ? 'SFX ON' : 'SFX MUTED'}</span>
          </button>
        </div>
      </div>

      {/* Main Radar Screen */}
      <div className="relative w-72 h-72 sm:w-80 sm:h-80 rounded-full border-2 border-emerald-500/30 bg-slate-950/90 shadow-[inset_0_0_50px_rgba(16,185,129,0.08)] flex items-center justify-center overflow-hidden my-2">
        {/* Radar concentric range circles */}
        <div className="absolute inset-4 rounded-full border border-emerald-500/15" />
        <div className="absolute inset-14 rounded-full border border-emerald-500/20" />
        <div className="absolute inset-24 rounded-full border border-emerald-500/25" />
        <div className="absolute inset-32 rounded-full border border-emerald-500/30" />

        {/* Crosshair lines */}
        <div className="absolute w-full h-[1px] bg-emerald-500/20" />
        <div className="absolute h-full w-[1px] bg-emerald-500/20" />

        {/* Compass markings */}
        <span className="absolute top-2 text-[9px] font-mono text-emerald-500/40">N 000°</span>
        <span className="absolute bottom-2 text-[9px] font-mono text-emerald-500/40">S 180°</span>
        <span className="absolute left-2 text-[9px] font-mono text-emerald-500/40">W 270°</span>
        <span className="absolute right-2 text-[9px] font-mono text-emerald-500/40">E 090°</span>

        {/* Rotating Radar Sweep Arm */}
        {status === 'SCANNING' && (
          <div className="absolute inset-0 animate-radar-sweep pointer-events-none origin-center">
            <div
              className="w-1/2 h-1/2 origin-bottom-right"
              style={{
                background: 'conic-gradient(from 0deg, rgba(16, 185, 129, 0.4) 0deg, transparent 65deg)',
                borderRight: '2px solid rgba(52, 211, 153, 0.8)'
              }}
            />
          </div>
        )}

        {/* Sonar pulse wave when in final 7s */}
        {isFinal7s && (
          <div className="absolute inset-16 rounded-full border-2 border-amber-400/60 animate-sonar pointer-events-none" />
        )}

        {/* Blips */}
        {blips.map(({ pair, x, y }) => {
          const isSelected = pair.id === activePairId;
          return (
            <button
              key={pair.id}
              onClick={() => onSelectPair(pair.id)}
              className={`absolute -translate-x-1/2 -translate-y-1/2 p-1 group z-20 transition-all ${
                isSelected ? 'scale-125 z-30' : 'hover:scale-110 opacity-70 hover:opacity-100'
              }`}
              style={{ left: `${x}%`, top: `${y}%` }}
              title={`${pair.symbol} - ${pair.open ? 'OPEN' : 'CLOSED'} (${pair.payoutPercent}%)`}
            >
              <div className="relative">
                <span
                  className={`block w-2.5 h-2.5 rounded-full ${
                    isSelected
                      ? 'bg-emerald-400 ring-4 ring-emerald-400/30'
                      : pair.variant === 'OTC'
                      ? 'bg-cyan-400'
                      : 'bg-emerald-500'
                  }`}
                />
                {isSelected && (
                  <span className="absolute -inset-1 rounded-full bg-emerald-400 animate-ping opacity-75" />
                )}
                {/* Tooltip on hover */}
                <div className="hidden group-hover:block absolute bottom-4 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-[9px] font-mono text-white whitespace-nowrap shadow-lg">
                  {pair.symbol}
                </div>
              </div>
            </button>
          );
        })}

        {/* Center HUD / Countdown core */}
        <div className="relative z-20 flex flex-col items-center justify-center w-28 h-28 rounded-full bg-slate-950/95 border border-slate-800 shadow-xl backdrop-blur-md">
          <div className="text-[10px] font-mono uppercase text-slate-400 tracking-wider">
            {isFinal1s ? 'SIGNAL LOCK' : isFinal7s ? 'DEEP INFER' : 'EXPIRY IN'}
          </div>

          <div
            className={`text-3xl font-extrabold font-mono tracking-tighter ${
              isFinal1s
                ? 'text-emerald-400 animate-bounce'
                : isFinal7s
                ? 'text-amber-400 animate-pulse'
                : 'text-slate-100'
            }`}
          >
            {String(secondsRemaining).padStart(2, '0')}s
          </div>

          <div className="text-[9px] font-mono text-slate-500 flex items-center gap-1">
            <Compass className="w-3 h-3 text-emerald-400" />
            <span>M1 SYNC</span>
          </div>
        </div>
      </div>

      {/* Footer Radar Status Bar */}
      <div className="w-full mt-4 flex items-center justify-between text-xs font-mono text-slate-400 border-t border-slate-800/80 pt-3 z-10">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>REAL ({pairs.filter(p => p.variant === 'REAL').length})</span>
          <span className="w-2 h-2 rounded-full bg-cyan-400 ml-2" />
          <span>OTC ({pairs.filter(p => p.variant === 'OTC').length})</span>
        </div>

        <div>
          {latestSignal ? (
            <span
              className={`px-2 py-0.5 rounded font-bold ${
                latestSignal.direction1Min === 'UP'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                  : latestSignal.direction1Min === 'DOWN'
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              }`}
            >
              LAST: {latestSignal.direction1Min} ({latestSignal.confidence}%)
            </span>
          ) : (
            <span className="text-slate-500">NO RECENT SIGNALS</span>
          )}
        </div>
      </div>
    </div>
  );
};
