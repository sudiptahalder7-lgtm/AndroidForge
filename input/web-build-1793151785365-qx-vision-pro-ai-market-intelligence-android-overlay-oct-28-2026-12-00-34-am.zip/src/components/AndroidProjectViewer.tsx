import React, { useState } from 'react';
import {
  Folder,
  FileText,
  FileCode,
  Download,
  Copy,
  Check,
  Smartphone,
  ShieldCheck,
  Terminal,
  ExternalLink
} from 'lucide-react';

interface AndroidFile {
  name: string;
  path: string;
  lang: string;
  category: 'Service' | 'Engine' | 'UI' | 'Data' | 'Config' | 'Test';
  content: string;
}

const ANDROID_FILES: AndroidFile[] = [
  {
    name: 'FloatingOverlayService.kt',
    path: 'android/app/src/main/java/com/qxvision/pro/service/FloatingOverlayService.kt',
    lang: 'kotlin',
    category: 'Service',
    content: `package com.qxvision.pro.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/**
 * System-wide draggable floating popup overlay service.
 * Uses WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY with real drag coordinates.
 */
class FloatingOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 200
        }

        setupOverlayViews()
    }

    private fun setupOverlayViews() {
        overlayView?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params?.x ?: 0
                    initialY = params?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params?.x = initialX + (event.rawX - initialTouchX).toInt()
                    params?.y = initialY + (event.rawY - initialTouchY).toInt()
                    params?.let { windowManager?.updateViewLayout(overlayView, it) }
                    true
                }
                else -> false
            }
        }
    }
}`
  },
  {
    name: 'ForegroundScannerService.kt',
    path: 'android/app/src/main/java/com/qxvision/pro/service/ForegroundScannerService.kt',
    lang: 'kotlin',
    category: 'Service',
    content: `package com.qxvision.pro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class ForegroundScannerService : Service() {
    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var isScanning = false
    private var isPaused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startScanning()
            ACTION_PAUSE -> pauseScanning()
            ACTION_RESUME -> resumeScanning()
            ACTION_STOP -> stopScanning()
        }
        return START_STICKY
    }

    private fun startScanning() {
        isScanning = true
        isPaused = false
        val notification = buildNotification("Radar Scanning Active", "Monitoring 20 REAL/OTC pairs at 1-sec intervals")
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(title: String, content: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("QX Vision Pro: $title")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }
}`
  },
  {
    name: 'QuotexWebSocketClient.kt',
    path: 'android/app/src/main/java/com/qxvision/pro/data/QuotexWebSocketClient.kt',
    lang: 'kotlin',
    category: 'Data',
    content: `package com.qxvision.pro.data

import com.qxvision.pro.model.Candle
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Native Android OkHttp WebSocket Client for Quotex Engine.IO protocol.
 * Replaces Python/Selenium desktop dependencies with pure native Android networking.
 */
class QuotexWebSocketClient(
    private val ssid: String? = null,
    private val onMessageCallback: (String) -> Unit
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(10, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()

    fun connect() {
        val request = Request.Builder()
            .url("wss://ws2.qxbroker.com/socket.io/?EIO=3&transport=websocket")
            .addHeader("Origin", "https://qxbroker.com")
            .build()

        client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                ws.send("2probe")
                ws.send("42[\\"tick\\"]")
                if (!ssid.isNullOrEmpty()) {
                    val authPayload = JSONObject().apply {
                        put("session", ssid)
                        put("isDemo", 1)
                    }
                    ws.send("42[\\"authorization\\",$authPayload]")
                }
            }
        })
    }
}`
  },
  {
    name: 'SignalEngine.kt',
    path: 'android/app/src/main/java/com/qxvision/pro/engine/SignalEngine.kt',
    lang: 'kotlin',
    category: 'Engine',
    content: `package com.qxvision.pro.engine

import com.qxvision.pro.model.SignalDirection
import com.qxvision.pro.model.SignalResult

object SignalEngine {
    fun evaluate(...): SignalResult {
        // Enforces strict NO TRADE for stale data, low volatility, or conflicting indicators
        if (isStale || candles.size < 30) {
            return SignalResult(direction1Min = SignalDirection.NO_TRADE, confidence = 0)
        }
        // Confluence evaluation
        ...
    }
}`
  },
  {
    name: 'AndroidManifest.xml',
    path: 'android/app/src/main/AndroidManifest.xml',
    lang: 'xml',
    category: 'Config',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    ...
</manifest>`
  },
  {
    name: 'README.md',
    path: 'android/README.md',
    lang: 'markdown',
    category: 'Config',
    content: `# QX Vision Pro AI — Complete Android Application

Native Android Studio application for Quotex market analysis, featuring real-time 1M & 2M candlestick prediction, a system-wide draggable floating popup overlay, and background scanning via Android Foreground Services.

### Build Steps
1. Open android/ directory in Android Studio.
2. Sync Gradle dependencies.
3. Run unit tests: ./gradlew testDebugUnitTest
4. Assemble Debug APK: ./gradlew assembleDebug
`
  }
];

export const AndroidProjectViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 backdrop-blur-md shadow-xl space-y-4">
      {/* Header and Download Button */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span>Android Studio Kotlin Codebase</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                GRADLE 8.7 • KOTLIN 2.0 • SDK 35
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Complete source code ready to build in Android Studio with zero Python desktop dependencies.
            </p>
          </div>
        </div>

        <a
          href="/qx_vision_pro_android_project.zip"
          download="qx_vision_pro_android_project.zip"
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold shadow-lg shadow-emerald-500/20 transition-all hover:scale-102"
        >
          <Download className="w-4 h-4" />
          <span>DOWNLOAD COMPLETE ANDROID PROJECT (.ZIP)</span>
        </a>
      </div>

      {/* File Explorer & Code Viewer */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Left file tree */}
        <div className="md:col-span-4 space-y-1 font-mono text-xs max-h-[380px] overflow-y-auto pr-1">
          <div className="text-[10px] uppercase text-slate-400 font-bold px-2 py-1 flex items-center gap-1.5">
            <Folder className="w-3.5 h-3.5 text-emerald-400" />
            <span>android/app/src/main/</span>
          </div>

          {ANDROID_FILES.map(file => {
            const isSelected = file.name === selectedFile.name;
            return (
              <button
                key={file.name}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between transition-all ${
                  isSelected
                    ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-bold shadow-sm'
                    : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  {file.name.endsWith('.kt') ? (
                    <FileCode className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                  <span className="truncate">{file.name}</span>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                  {file.category}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right code preview */}
        <div className="md:col-span-8 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col font-mono text-xs">
          <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-slate-400">
            <span className="text-slate-300 truncate max-w-xs">{selectedFile.path}</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-emerald-400 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED' : 'COPY CODE'}</span>
            </button>
          </div>

          <pre className="p-4 overflow-x-auto text-[11px] text-slate-300 leading-relaxed max-h-[340px] overflow-y-auto">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>

      {/* Android Build Instructions Footer */}
      <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-mono">
        <div className="flex items-center gap-2 text-slate-300">
          <Terminal className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Quick Build Command:</span>
          <code className="bg-slate-900 px-2 py-0.5 rounded text-emerald-400 border border-slate-800">
            ./gradlew assembleDebug
          </code>
        </div>
        <div className="text-slate-400 text-[11px]">
          Output: <span className="text-slate-200">app/build/outputs/apk/debug/app-debug.apk</span>
        </div>
      </div>
    </div>
  );
};
