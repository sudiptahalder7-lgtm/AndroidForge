import React, { useState } from 'react';
import { QUOTEX_API_AUDIT_REPORT, FEATURE_COMPLIANCE_MATRIX } from '../data/apiAudit';
import { DiagnosticLog } from '../types/market';
import { marketDataFeed } from '../services/marketDataFeed';
import {
  FileCode,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Terminal,
  Send,
  Lock,
  X
} from 'lucide-react';

interface ApiDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: DiagnosticLog[];
}

export const ApiDiagnosticsModal: React.FC<ApiDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  logs
}) => {
  const [activeTab, setActiveTab] = useState<'AUDIT' | 'COMPLIANCE' | 'TESTER' | 'LOGS'>('AUDIT');
  const [testSsid, setTestSsid] = useState<string>('');
  const [testStatus, setTestStatus] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestStatus('Initiating Engine.IO WebSocket handshake...');
    const res = await marketDataFeed.connectQuotexWebSocket(testSsid);
    setIsTesting(false);
    setTestStatus(res.message);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-slate-950 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-slate-100 font-sans">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <FileCode className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold font-mono text-slate-100 flex items-center gap-2">
                QuotexPy API Diagnostic Audit & Compatibility Report
              </h2>
              <p className="text-xs text-slate-400">
                Direct verification of uploaded ZIP codebase (qxbroker package) and Android ART limitations.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-900/50 px-6 gap-2 text-xs font-mono">
          <button
            onClick={() => setActiveTab('AUDIT')}
            className={`py-3 px-3 border-b-2 font-bold transition-colors ${
              activeTab === 'AUDIT'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            ZIP SOURCE AUDIT
          </button>
          <button
            onClick={() => setActiveTab('COMPLIANCE')}
            className={`py-3 px-3 border-b-2 font-bold transition-colors ${
              activeTab === 'COMPLIANCE'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            14-FEATURE COMPLIANCE MATRIX
          </button>
          <button
            onClick={() => setActiveTab('TESTER')}
            className={`py-3 px-3 border-b-2 font-bold transition-colors ${
              activeTab === 'TESTER'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            LIVE WEBSOCKET TESTER
          </button>
          <button
            onClick={() => setActiveTab('LOGS')}
            className={`py-3 px-3 border-b-2 font-bold transition-colors ${
              activeTab === 'LOGS'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            DIAGNOSTIC LOGS ({logs.length})
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs">
          {/* TAB 1: AUDIT FINDINGS */}
          {activeTab === 'AUDIT' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200">
                <div className="flex items-center gap-2 font-bold font-mono text-sm mb-1 text-amber-300">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  VERIFIED DIAGNOSIS: UNOFFICIAL REVERSE-ENGINEERED LIBRARY
                </div>
                <p className="leading-relaxed text-xs">
                  The uploaded package <code className="bg-slate-900 px-1 py-0.5 rounded text-amber-300 font-mono">quotexpy</code> is <strong>NOT an official API</strong>. There is no official Quotex REST API. It connects directly to internal broker WebSockets (<code className="font-mono text-xs text-amber-300">wss://ws2.qxbroker.com/socket.io/?EIO=3&transport=websocket</code>) using undocumented Socket.IO Engine.IO frames.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {QUOTEX_API_AUDIT_REPORT.keyFindings.map((finding, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                    <h4 className="font-mono font-bold text-emerald-400 text-xs">
                      {finding.title}
                    </h4>
                    <p className="text-slate-300 leading-relaxed font-sans text-xs">
                      {finding.description}
                    </p>
                  </div>
                ))}
              </div>

              {/* Verified Methods from inspecting source */}
              <div className="space-y-2">
                <h4 className="font-mono font-bold text-slate-200 uppercase tracking-wider text-xs">
                  Verified QuotexPy Python Methods & Protocol Frames
                </h4>
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 font-mono text-[11px] space-y-1 text-slate-300">
                  <div><span className="text-emerald-400">api.connect():</span> Initializes WebSocketApp thread and TLS v1.2 session</div>
                  <div><span className="text-emerald-400">api.send_ssid(ssid):</span> Dispatches <code className="text-cyan-300">42["authorization", &#123;"session": ssid, "isDemo": 1&#125;]</code></div>
                  <div><span className="text-emerald-400">api.get_candles(asset, ...):</span> Dispatches <code className="text-cyan-300">42["history/load", &#123;asset, index, offset, period: 60&#125;]</code></div>
                  <div><span className="text-emerald-400">api.subscribe_realtime_candle():</span> Dispatches <code className="text-cyan-300">42["depth/follow", asset]</code> and <code className="text-cyan-300">42["instruments/update"]</code></div>
                  <div><span className="text-emerald-400">api.get_instruments():</span> Dispatches <code className="text-cyan-300">42["instruments/list"]</code> to query payouts & open status</div>
                  <div><span className="text-rose-400">login.py (FATAL ON ANDROID):</span> Relies on <code className="text-rose-300">undetected_chromedriver</code> desktop Chrome browser automation</div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 14-FEATURE COMPLIANCE MATRIX */}
          {activeTab === 'COMPLIANCE' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-400 mb-2">
                Status summary for all 14 project requirements with strict verification against actual capabilities:
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400">
                      <th className="py-2 px-3">Req ID</th>
                      <th className="py-2 px-3">Requirement</th>
                      <th className="py-2 px-3">Verdict</th>
                      <th className="py-2 px-3">Verified Implementation & Architecture</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-200">
                    {FEATURE_COMPLIANCE_MATRIX.map(feat => (
                      <tr key={feat.id} className="hover:bg-slate-900/60">
                        <td className="py-2.5 px-3 font-bold text-slate-400">{feat.id}</td>
                        <td className="py-2.5 px-3 font-semibold text-slate-100">{feat.name}</td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          {feat.status === 'PASS' && (
                            <span className="inline-flex items-center gap-1 font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                              <CheckCircle2 className="w-3.5 h-3.5" /> PASS
                            </span>
                          )}
                          {feat.status === 'FAIL' && (
                            <span className="inline-flex items-center gap-1 font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30">
                              <XCircle className="w-3.5 h-3.5" /> FAIL
                            </span>
                          )}
                          {feat.status === 'BLOCKED' && (
                            <span className="inline-flex items-center gap-1 font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                              <AlertTriangle className="w-3.5 h-3.5" /> BLOCKED
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-slate-300 font-sans text-xs">
                          {feat.technicalDetails}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: LIVE WEBSOCKET TESTER */}
          {activeTab === 'TESTER' && (
            <div className="space-y-4 font-mono">
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                  <Terminal className="w-4 h-4" />
                  Quotex Engine.IO WSS Handshake Test
                </h4>
                <p className="text-xs text-slate-300 font-sans">
                  Test the direct WebSocket connection to Quotex server (<code className="text-emerald-400">wss://ws2.qxbroker.com/socket.io/?EIO=3&transport=websocket</code>). You can provide an optional Session SSID or run an anonymous heartbeat test.
                </p>

                <div className="space-y-2">
                  <label className="text-[11px] text-slate-400 block flex items-center gap-1">
                    <Lock className="w-3 h-3 text-emerald-400" />
                    Session Token / SSID (Optional, automatically redacted from logs)
                  </label>
                  <input
                    type="password"
                    value={testSsid}
                    onChange={e => setTestSsid(e.target.value)}
                    placeholder="Enter Quotex SSID or leave empty for anonymous ping"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <button
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-lg shadow-emerald-500/20"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isTesting ? 'CONNECTING...' : 'RUN WEBSOCKET DIAGNOSTIC'}</span>
                </button>

                {testStatus && (
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300">
                    <span className="text-emerald-400 font-bold">Result: </span>
                    {testStatus}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: REDACTED DIAGNOSTIC LOGS */}
          {activeTab === 'LOGS' && (
            <div className="space-y-3 font-mono">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Secret Redaction: Active (<code className="text-emerald-400">***REDACTED***</code> applied to all session keys)</span>
                <span>Buffer: {logs.length} events</span>
              </div>
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 max-h-[360px] overflow-y-auto space-y-1.5 text-[11px]">
                {logs.length === 0 ? (
                  <div className="text-slate-600">No logs captured yet.</div>
                ) : (
                  logs.map(log => (
                    <div key={log.id} className="flex items-start gap-2 leading-relaxed">
                      <span className="text-slate-500 shrink-0">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                      <span
                        className={`font-bold shrink-0 ${
                          log.level === 'ERROR'
                            ? 'text-rose-400'
                            : log.level === 'WARN'
                            ? 'text-amber-400'
                            : log.level === 'DEBUG'
                            ? 'text-slate-500'
                            : 'text-emerald-400'
                        }`}
                      >
                        [{log.level}]
                      </span>
                      <span className="text-cyan-400 shrink-0">[{log.component}]</span>
                      <span className="text-slate-300 break-all">{log.message}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-900/90 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>QuotexPy Forensic Audit Confirmed</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold"
          >
            DISMISS
          </button>
        </div>
      </div>
    </div>
  );
};
