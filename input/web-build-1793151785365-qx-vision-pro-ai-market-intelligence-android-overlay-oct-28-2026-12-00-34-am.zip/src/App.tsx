import React, { useState, useEffect } from 'react';
import { MarketPair, ScannerStatus, SignalResult, DiagnosticLog } from './types/market';
import { marketDataFeed } from './services/marketDataFeed';
import { signalEngine } from './engine/signalEngine';
import { RadarScanner } from './components/RadarScanner';
import { FloatingOverlaySimulator } from './components/FloatingOverlaySimulator';
import { MarketDataGrid } from './components/MarketDataGrid';
import { SignalAnalytics } from './components/SignalAnalytics';
import { SignalHistoryTable } from './components/SignalHistoryTable';
import { ApiDiagnosticsModal } from './components/ApiDiagnosticsModal';
import { AndroidProjectViewer } from './components/AndroidProjectViewer';
import {
  Play,
  Pause,
  StopCircle,
  FileSearch,
  Wifi,
  Shield,
  Layers,
  Sparkles,
  Smartphone,
  Gauge,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';

export default function App() {
  const [pairs, setPairs] = useState<MarketPair[]>(marketDataFeed.getPairs());
  const [activePairId, setActivePairId] = useState<string>(signalEngine.getSelectedPairId());
  const [status, setStatus] = useState<ScannerStatus>(signalEngine.getStatus());
  const [signals, setSignals] = useState<SignalResult[]>(signalEngine.getSignals());
  const [latestSignal, setLatestSignal] = useState<SignalResult | null>(signals[0] || null);
  const [logs, setLogs] = useState<DiagnosticLog[]>([]);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState<boolean>(false);
  const [latency, setLatency] = useState<number>(28);

  useEffect(() => {
    // Start market feed automatically
    marketDataFeed.startFeed();

    // Subscribe to market ticks
    const unsubTicks = marketDataFeed.subscribeTicks(() => {
      setPairs([...marketDataFeed.getPairs()]);
      setLatency(marketDataFeed.getLatency());
    });

    // Subscribe to signals
    const unsubSignals = signalEngine.subscribeSignals(newSig => {
      setSignals(signalEngine.getSignals());
      setLatestSignal(newSig);
    });

    // Subscribe to status changes
    const unsubStatus = signalEngine.subscribeStatus(newStatus => {
      setStatus(newStatus);
    });

    // Subscribe to diagnostic logs
    const unsubLogs = marketDataFeed.subscribeLogs(log => {
      setLogs(prev => [log, ...prev].slice(0, 100));
    });

    return () => {
      unsubTicks();
      unsubSignals();
      unsubStatus();
      unsubLogs();
    };
  }, []);

  const handleSelectPair = (pairId: string) => {
    setActivePairId(pairId);
    signalEngine.setSelectedPairId(pairId);
  };

  const handleTogglePairStatus = (pairId: string, open: boolean) => {
    marketDataFeed.setPairOpen(pairId, open);
    setPairs([...marketDataFeed.getPairs()]);
  };

  const handleExportCsv = () => {
    const csvContent = signalEngine.exportCsv();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `qx_vision_pro_signals_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activePair = pairs.find(p => p.id === activePairId) || pairs[0];
  const metrics = signalEngine.getPerformanceMetrics();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-950/90 border-b border-slate-800/80 backdrop-blur-xl px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-extrabold font-mono tracking-tight text-white flex items-center gap-1.5">
                  <span>QX VISION PRO AI</span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    ANDROID & CLOUD ENGINE
                  </span>
                </h1>
              </div>
              <p className="text-[11px] font-mono text-slate-400">
                Quotex 20 Pairs Quantitative Analysis • Real & OTC Synthetics
              </p>
            </div>
          </div>

          {/* Center Status Indicators */}
          <div className="flex items-center gap-3 text-xs font-mono">
            {/* Feed Latency */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              <span>{latency}ms</span>
            </div>

            {/* Service Status */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-slate-900 border border-slate-800">
              <span
                className={`w-2 h-2 rounded-full ${
                  status === 'SCANNING'
                    ? 'bg-emerald-400 animate-ping'
                    : status === 'PAUSED'
                    ? 'bg-amber-400'
                    : 'bg-slate-500'
                }`}
              />
              <span className="font-bold text-slate-200">{status}</span>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2">
            {/* Start / Pause / Resume / Stop Controls */}
            {status === 'SCANNING' ? (
              <>
                <button
                  onClick={() => signalEngine.pauseScanner()}
                  className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300 font-mono text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Pause className="w-3.5 h-3.5" />
                  <span>PAUSE</span>
                </button>
                <button
                  onClick={() => signalEngine.stopScanner()}
                  className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 text-rose-300 font-mono text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <StopCircle className="w-3.5 h-3.5" />
                  <span>STOP</span>
                </button>
              </>
            ) : status === 'PAUSED' ? (
              <>
                <button
                  onClick={() => signalEngine.resumeScanner()}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 font-mono text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>RESUME</span>
                </button>
                <button
                  onClick={() => signalEngine.stopScanner()}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 font-mono text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <StopCircle className="w-3.5 h-3.5" />
                  <span>STOP</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => signalEngine.startScanner()}
                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-mono text-xs font-bold flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20 hover:scale-102"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>START SCANNER</span>
              </button>
            )}

            {/* API Diagnostic Audit Button */}
            <button
              onClick={() => setIsAuditModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono text-slate-200 font-semibold flex items-center gap-1.5 transition-colors"
              title="Inspect QuotexPy API Diagnostic Audit & Compatibility"
            >
              <FileSearch className="w-3.5 h-3.5 text-cyan-400" />
              <span>API AUDIT</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-6 flex-1">
        {/* Top Feature Highlights: Final 7s / 1s Countdown Rule Banner */}
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 font-mono text-xs text-slate-300">
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong className="text-emerald-300 font-bold">Rule 8 Strict Timing Protocol:</strong> Deep feature synthesis executes during final 7 seconds (T-7s). Final UP/DOWN/NO TRADE emission latches at T-1s before candle close.
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              Single-Emission Latch
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
              NO Late Signals
            </span>
          </div>
        </div>

        {/* Primary Screen: Radar Scanner (Left) & Active Pair Deep Focus (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Radar Scanner View */}
          <div className="lg:col-span-5 flex flex-col">
            <RadarScanner
              status={status}
              pairs={pairs}
              activePairId={activePairId}
              onSelectPair={handleSelectPair}
              latestSignal={latestSignal}
            />
          </div>

          {/* Active Asset Deep Telemetry & Technical Confluence */}
          <div className="lg:col-span-7 flex flex-col justify-between bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl space-y-5">
            {/* Asset Header */}
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-black font-mono text-slate-100">
                    {activePair.symbol}
                  </span>
                  <span
                    className={`text-xs font-mono font-bold px-2 py-0.5 rounded uppercase ${
                      activePair.variant === 'OTC'
                        ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30'
                        : 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {activePair.variant} BROKER FEED
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Broker ID: #{activePair.quotexCode} • Payout: <span className="text-emerald-400 font-bold">{activePair.payoutPercent}%</span> • Spread: {activePair.spread}
                </p>
              </div>

              <div className="text-right font-mono">
                <div className="text-xs text-slate-400">Live Quotex Rate</div>
                <div className="text-2xl font-black text-slate-100">
                  {activePair.currentPrice}
                </div>
                <div className={`text-xs font-bold ${activePair.priceChange24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {activePair.priceChange24h >= 0 ? '+' : ''}{activePair.priceChange24h}% (24h)
                </div>
              </div>
            </div>

            {/* Real-time Indicator Gauge Cards */}
            {latestSignal && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">RSI (14-Period)</div>
                  <div className="text-base font-extrabold font-mono text-emerald-400 mt-0.5">
                    {latestSignal.indicators.rsi}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">
                    {latestSignal.indicators.rsi > 70 ? 'Overbought' : latestSignal.indicators.rsi < 30 ? 'Oversold' : 'Balanced'}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">EMA 9 / 21 Stack</div>
                  <div className="text-base font-extrabold font-mono text-slate-200 mt-0.5">
                    {latestSignal.indicators.ema9 > latestSignal.indicators.ema21 ? 'BULLISH STACK' : 'BEARISH STACK'}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">
                    9: {latestSignal.indicators.ema9} | 21: {latestSignal.indicators.ema21}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">MACD Histogram</div>
                  <div className="text-base font-extrabold font-mono text-cyan-400 mt-0.5">
                    {latestSignal.indicators.macd.histogram}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">
                    Signal: {latestSignal.indicators.macd.signalLine}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">Bollinger Bandwidth</div>
                  <div className="text-base font-extrabold font-mono text-indigo-400 mt-0.5">
                    {latestSignal.indicators.bollinger.bandwidth}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">
                    %B: {latestSignal.indicators.bollinger.percentB}%
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">Candle Formation</div>
                  <div className="text-sm font-extrabold font-mono text-amber-300 mt-1 truncate">
                    {latestSignal.indicators.pattern}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">
                    Volatility ATR: {latestSignal.indicators.atr}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">2-Candle Bias</div>
                  <div className="text-base font-extrabold font-mono text-emerald-400 mt-0.5">
                    {latestSignal.direction2Min}
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">
                    Timeframe: M2 continuation
                  </div>
                </div>
              </div>
            )}

            {/* Latest Signal Rationale Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/90 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400 uppercase tracking-wider font-bold">
                  Rule Confluence & Voting Matrix
                </span>
                <span className="text-emerald-400 font-bold">
                  Confidence: {latestSignal ? latestSignal.confidence : 0}%
                </span>
              </div>

              <div className="space-y-1 font-mono text-xs text-slate-300">
                {latestSignal?.reasons.map((r, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>{r}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 20 Monitored Pairs Matrix */}
        <section>
          <MarketDataGrid
            pairs={pairs}
            activePairId={activePairId}
            onSelectPair={handleSelectPair}
            onTogglePairStatus={handleTogglePairStatus}
          />
        </section>

        {/* Walk-Forward Statistical Validation & Calibration */}
        <section>
          <SignalAnalytics metrics={metrics} />
        </section>

        {/* Signal Execution History & CSV Export */}
        <section>
          <SignalHistoryTable
            signals={signals}
            onExportCsv={handleExportCsv}
          />
        </section>

        {/* Android Studio Kotlin Project Explorer & ZIP Exporter */}
        <section>
          <AndroidProjectViewer />
        </section>
      </main>

      {/* Interactive System Floating Overlay Simulator (Draggable anywhere on screen) */}
      <FloatingOverlaySimulator
        status={status}
        pairs={pairs}
        activePairId={activePairId}
        onSelectPair={handleSelectPair}
        onStartScanner={() => signalEngine.startScanner()}
        onPauseScanner={() => signalEngine.pauseScanner()}
        onResumeScanner={() => signalEngine.resumeScanner()}
        onStopScanner={() => signalEngine.stopScanner()}
        latestSignal={latestSignal}
      />

      {/* QuotexPy API Diagnostic Audit Modal */}
      <ApiDiagnosticsModal
        isOpen={isAuditModalOpen}
        onClose={() => setIsAuditModalOpen(false)}
        logs={logs}
      />
    </div>
  );
}
