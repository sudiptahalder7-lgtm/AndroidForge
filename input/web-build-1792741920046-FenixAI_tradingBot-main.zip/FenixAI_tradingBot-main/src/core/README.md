# src/core

Funcionalidades core
