import { useState, useCallback, useRef, useEffect } from 'react';
import { API_CONFIG, ERROR_MESSAGES } from '@/lib/api-config';
import { getAuthToken } from '@/lib/auth';
import { toast } from 'sonner';

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  headers?: Record<string, string>;
  body?: unknown;
  showNotification?: boolean;
  token?: string;
}

interface UseApiState<T> {
  data: T | null;
  loading: boolean;
  error: Error | null;
}

function resolveSameOriginApiUrl(path: string): string {
  const base = API_CONFIG.baseURL || window.location.origin;
  const resolved = new URL(path, base);
  if (resolved.origin !== window.location.origin) {
    throw new Error('Cross-origin API destinations are not permitted');
  }
  return `${resolved.pathname}${resolved.search}`;
}

/**
 * Custom hook for making API requests with error handling and retry logic
 */
export const useApi = <T = unknown,>(
  url: string,
  options: RequestOptions = {}
): UseApiState<T> & { refetch: () => Promise<void> } => {
  const [state, setState] = useState<UseApiState<T>>({
    data: null,
    loading: false,
    error: null,
  });

  const attemptsRef = useRef(0);
  const abortControllerRef = useRef<AbortController | null>(null);

  const fetchData = useCallback(async (): Promise<void> => {
    // Cancel previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();
    setState((prev) => ({ ...prev, loading: true, error: null }));

    try {
      const fullUrl = resolveSameOriginApiUrl(url);

      const headers: Record<string, string> = {
        ...API_CONFIG.defaultHeaders,
        ...options.headers,
      };

      // Add authorization token if available
      const token = options.token || getAuthToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch(fullUrl, {
        method: options.method || 'GET',
        headers,
        body: options.body ? JSON.stringify(options.body) : undefined,
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage =
          errorData.error ||
          ERROR_MESSAGES[`HTTP_${response.status}` as keyof typeof ERROR_MESSAGES] ||
          ERROR_MESSAGES.UNKNOWN_ERROR;

        throw new Error(errorMessage);
      }

      const data = await response.json();
      setState({ data, loading: false, error: null });
      attemptsRef.current = 0;
    } catch (error: unknown) {
      // Ignore abort errors
      if (error instanceof Error && error.name === 'AbortError') {
        return;
      }

      // Retry logic for network errors and server errors
      const shouldRetry =
        attemptsRef.current < API_CONFIG.retries &&
        (error instanceof Error && (error.message === ERROR_MESSAGES.NETWORK_ERROR ||
          error.message === ERROR_MESSAGES.TIMEOUT_ERROR));

      if (shouldRetry) {
        attemptsRef.current += 1;
        setTimeout(
          () => fetchData(),
          API_CONFIG.retryDelay * Math.pow(2, attemptsRef.current - 1)
        );
        return;
      }

      const appError = error instanceof Error ? error : new Error(ERROR_MESSAGES.UNKNOWN_ERROR);
      setState({ data: null, loading: false, error: appError });

      if (options.showNotification) {
        toast.error(appError.message);
      }
    }
  }, [url, options]);

  useEffect(() => {
    if (options.method === 'GET' || !options.method) {
      fetchData();
    }

    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [url, fetchData, options.method]);

  const refetch = useCallback(async (): Promise<void> => {
    attemptsRef.current = 0;
    await fetchData();
  }, [fetchData]);

  return {
    ...state,
    refetch,
  };
};

/**
 * Mutation hook for POST, PUT, DELETE requests
 */
export const useApiMutation = <T = unknown,>() => {
  const [state, setState] = useState<UseApiState<T> & { isLoading: boolean }>({
    data: null,
    loading: false,
    isLoading: false,
    error: null,
  });

  const abortControllerRef = useRef<AbortController | null>(null);

  const mutate = useCallback(
    async (
      url: string,
      options: RequestOptions = {}
    ): Promise<T | null> => {
      // Cancel previous request
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }

      abortControllerRef.current = new AbortController();
      setState((prev) => ({ ...prev, loading: true, isLoading: true, error: null }));

      try {
        const fullUrl = resolveSameOriginApiUrl(url);

        const headers: Record<string, string> = {
          ...API_CONFIG.defaultHeaders,
          ...options.headers,
        };

        // Add authorization token if available
        const token = options.token || getAuthToken();
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }

        const response = await fetch(fullUrl, {
          method: options.method || 'POST',
          headers,
          body: options.body ? JSON.stringify(options.body) : undefined,
          signal: abortControllerRef.current.signal,
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          const errorMessage =
            errorData.error ||
            ERROR_MESSAGES[`HTTP_${response.status}` as keyof typeof ERROR_MESSAGES] ||
            ERROR_MESSAGES.UNKNOWN_ERROR;

          throw new Error(errorMessage);
        }

        const data = await response.json();
        setState({ data, loading: false, isLoading: false, error: null });

        if (options.showNotification) {
          toast.success('Operation successful!');
        }

        return data;
      } catch (error: unknown) {
        // Ignore abort errors
        if (error instanceof Error && error.name === 'AbortError') {
          return null;
        }

        const appError = error instanceof Error ? error : new Error(ERROR_MESSAGES.UNKNOWN_ERROR);
        setState({ data: null, loading: false, isLoading: false, error: appError });

        if (options.showNotification) {
          toast.error(appError.message);
        }

        throw appError;
      }
    },
    []
  );

  const reset = useCallback(() => {
    setState({
      data: null,
      loading: false,
      isLoading: false,
      error: null,
    });
  }, []);

  return {
    ...state,
    mutate,
    reset,
  };
};
