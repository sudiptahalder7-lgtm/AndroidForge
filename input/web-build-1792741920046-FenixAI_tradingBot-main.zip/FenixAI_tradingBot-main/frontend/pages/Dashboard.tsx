import React, { useEffect, useState } from 'react';
import { animate } from 'animejs';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  Brain,
  Clock,
  RefreshCw,
  Zap,
  Shield
} from 'lucide-react';
import { useSystemStore } from '@/stores/systemStore';
import { useAgentStore } from '@/stores/agentStore';
import { formatCurrency, formatPercentage } from '@/lib/utils';
import { MetricCard } from '@/components/MetricCard';
import { SystemStatusChart } from '@/components/SystemStatusChart';
import { AgentPerformanceChart } from '@/components/AgentPerformanceChart';
import { MarketOverview } from '@/components/MarketOverview';
import { RecentTrades } from '@/components/RecentTrades';
import { RecentAlerts } from '@/components/RecentAlerts';
import { useNavigate } from '@/lib/router';
import { authHeaders } from '@/lib/auth';

interface PortfolioData {
  totalValue: number;
  change24h: number;
  changePercent: number;
  positions: number;
}

interface MarketPrice {
  symbol: string;
  price: number;
  change_24h: number;
}

export function Dashboard() {
  const navigate = useNavigate();
  const {
    metrics,
    alerts,
    engineConfig,
    fetchSystemStatus,
    fetchEngineConfig,
    fetchAlerts,
  } = useSystemStore();
  const { agents, scorecards, fetchAgents, fetchScorecards } = useAgentStore();

  // Real data states
  const [portfolio, setPortfolio] = useState<PortfolioData>({
    totalValue: 0,
    change24h: 0,
    changePercent: 0,
    positions: 0
  });
  const [marketPrice, setMarketPrice] = useState<MarketPrice | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  // Fetch real data on mount
  useEffect(() => {
    fetchDashboardData();
    fetchAgents();
    fetchScorecards();
    fetchSystemStatus();
    fetchEngineConfig();
    fetchAlerts();

    // Anime.js entry animation
    animate('.animate-card', {
      translateY: [20, 0],
      opacity: [0, 1],
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      delay: (_el: any, i: number) => i * 100,
      easing: 'easeOutExpo',
      duration: 800
    });

    // Refresh every 30 seconds
    const interval = setInterval(() => {
      fetchDashboardData();
      fetchSystemStatus();
    }, 30000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true);

      // Fetch positions AND real balance from Binance
      const [positionsRes, marketRes, balanceRes] = await Promise.all([
        fetch('/api/trading/positions', { headers: authHeaders() }),
        fetch('/api/trading/market', { headers: authHeaders() }),
        fetch('/api/trading/balance', { headers: authHeaders() })
      ]);

      // Get real account balance from Binance
      let realBalance = 0;
      if (balanceRes.ok) {
        const balanceData = await balanceRes.json();
        realBalance = balanceData.total_usdt || 0;
      }

      if (positionsRes.ok) {
        const posData = await positionsRes.json();
        const positions = posData.positions || [];

        // Calculate portfolio metrics from real balance + positions
        const positionsValue = positions.reduce((sum: number, pos: Record<string, unknown>) => {
          return sum + ((pos.quantity as number) * (pos.current_price as number));
        }, 0);

        const unrealizedPnl = positions.reduce((sum: number, pos: Record<string, unknown>) => {
          return sum + ((pos.unrealized_pnl as number) || 0);
        }, 0);

        const totalValue = realBalance + positionsValue;

        setPortfolio({
          totalValue,
          change24h: unrealizedPnl,
          changePercent: totalValue > 0 ? (unrealizedPnl / totalValue) * 100 : 0,
          positions: positions.length
        });
      }

      if (marketRes.ok) {
        const marketData = await marketRes.json();
        setMarketPrice(marketData);
      }

      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Calculate agent metrics
  const activeAgents = agents.filter(agent => agent.status === 'active').length;
  const totalAgents = agents.length || 6;
  const avgAccuracy = scorecards.length > 0
    ? scorecards.reduce((sum, card) => sum + card.accuracy, 0) / scorecards.length
    : 0.78;

  // Get recent alerts
  const recentAlerts = alerts.slice(0, 5);
  const baseAsset = (marketPrice?.symbol || engineConfig?.symbol || '')
    .replace(/(USDT|USDC|BUSD|USD)$/i, '')
    .toUpperCase();
  const knownAssetIcons: Record<string, string> = { BTC: '₿', ETH: 'Ξ', SOL: '◎' };
  const assetIcon = knownAssetIcons[baseAsset] || baseAsset.slice(0, 1) || '•';

  return (
    <div className="space-y-8 p-1">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold text-gray-900 tracking-tight">
            Dashboard <span className="text-gradient">Pro</span>
          </h1>
          <p className="text-gray-500 mt-2">Real-time market intelligence & agent status.</p>
        </div>
        <div className="flex items-center space-x-3 bg-white p-2 rounded-xl border border-gray-200 shadow-sm">
          <button
            onClick={fetchDashboardData}
            className="p-2 hover:bg-gray-100 rounded-lg transition-all duration-200 text-blue-600"
            disabled={isLoading}
            title="Refresh data"
          >
            <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <div className="flex items-center space-x-2 text-sm text-gray-500 px-2 border-l border-gray-200">
            <Clock className="w-4 h-4" />
            <span>Updated: {lastUpdate.toLocaleTimeString()}</span>
          </div>
        </div>
      </div>

      {/* Trading Mode Banner */}
      {engineConfig && (
        <div className={`rounded-2xl p-4 border shadow-sm flex items-center justify-between ${
          engineConfig.paper_trading
            ? 'bg-amber-50 border-amber-200'
            : 'bg-red-50 border-red-300'
        }`}>
          <div className="flex items-center space-x-3">
            <div className={`px-3 py-1 rounded-full text-sm font-bold uppercase tracking-wider ${
              engineConfig.paper_trading
                ? 'bg-amber-200 text-amber-800'
                : 'bg-red-200 text-red-800'
            }`}>
              {engineConfig.paper_trading ? '⚠️ Paper Trading' : '🔴 LIVE TRADING'}
            </div>
            <div className="text-sm text-gray-600">
              <span className="font-semibold">{engineConfig.symbol}</span>
              <span className="mx-2 text-gray-400">·</span>
              <span>{engineConfig.timeframe}</span>
              <span className="mx-2 text-gray-400">·</span>
              <span>{engineConfig.paper_trading ? 'Testnet' : 'Binance Real'}</span>
            </div>
          </div>
          {!engineConfig.paper_trading && (
            <div className="text-xs text-red-600 font-medium">
              ⚡ Real money at risk
            </div>
          )}
        </div>
      )}

      {/* Market Price Banner */}
      {marketPrice && (
        <div className="bg-white rounded-2xl p-6 relative overflow-hidden group border border-gray-200 shadow-sm">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl -mr-16 -mt-16 transition-all duration-700 group-hover:bg-blue-500/10"></div>

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-orange-100 rounded-xl">
                <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white font-bold">{assetIcon}</div>
              </div>
              <div>
                <p className="text-gray-500 text-sm font-medium tracking-wider">{marketPrice.symbol}</p>
                <div className="text-4xl font-bold text-gray-900 tracking-tight mt-1">
                  {formatCurrency(marketPrice.price)}
                </div>
              </div>
            </div>

            <div className={`flex items-center px-4 py-2 rounded-xl border ${marketPrice.change_24h >= 0 ? 'bg-green-50 border-green-200 text-green-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
              {marketPrice.change_24h >= 0 ? <TrendingUp className="w-6 h-6 mr-2" /> : <TrendingDown className="w-6 h-6 mr-2" />}
              <span className="text-2xl font-bold">{Math.abs(marketPrice.change_24h).toFixed(2)}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Portfolio Value"
          value={formatCurrency(portfolio.totalValue)}
          change={portfolio.changePercent}
          changeType={portfolio.changePercent >= 0 ? 'positive' : 'negative'}
          icon={DollarSign}
          className="animate-card"
        />

        <MetricCard
          title="Active Agents"
          value={`${activeAgents}/${totalAgents}`}
          subtitle="AI Agents Running"
          change={activeAgents}
          changeType="positive"
          icon={Brain}
          className="animate-card"
        />

        <MetricCard
          title="System Health"
          value={metrics?.cpu ? `${metrics.cpu.toFixed(1)}%` : 'N/A'}
          subtitle="CPU Usage"
          change={metrics?.cpu ? metrics.cpu - 50 : 0}
          changeType={metrics?.cpu && metrics.cpu < 80 ? 'positive' : 'negative'}
          icon={Activity}
          className="animate-card"
        />

        <MetricCard
          title="Agent Accuracy"
          value={formatPercentage(avgAccuracy)}
          subtitle="Avg Win Rate"
          change={avgAccuracy - 75}
          changeType={avgAccuracy >= 75 ? 'positive' : 'negative'}
          icon={Zap}
          className="animate-card"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-8">
          {/* Market Overview */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm animate-card">
            <h3 className="text-xl font-semibold mb-6 flex items-center text-gray-900">
              <Activity className="w-5 h-5 mr-2 text-blue-600" />
              Market Overview
            </h3>
            <MarketOverview />
          </div>

          {/* System & Agents Chart Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm animate-card">
              <h3 className="text-lg font-semibold mb-4 text-gray-900">System Load</h3>
              <div className="h-[200px]">
                <SystemStatusChart />
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm animate-card">
              <h3 className="text-lg font-semibold mb-4 text-gray-900">Agent Performance</h3>
              <div className="h-[200px]">
                <AgentPerformanceChart />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-8">
          {/* Quick Actions */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm animate-card">
            <h3 className="text-lg font-semibold mb-4 text-gray-900">Quick Actions</h3>
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => navigate('/trading')}
                className="w-full text-left p-4 bg-blue-50 border border-blue-200 rounded-xl hover:bg-blue-100 transition-all group"
              >
                <div className="font-semibold text-blue-700 group-hover:text-blue-800 flex items-center">
                  <DollarSign className="w-4 h-4 mr-2" /> New Order
                </div>
                <div className="text-xs text-blue-500 mt-1">Execute manual trade</div>
              </button>

              <button
                type="button"
                onClick={() => navigate('/agents')}
                className="w-full text-left p-4 bg-emerald-50 border border-emerald-200 rounded-xl hover:bg-emerald-100 transition-all group"
              >
                <div className="font-semibold text-emerald-700 group-hover:text-emerald-800 flex items-center">
                  <Brain className="w-4 h-4 mr-2" /> View Agents
                </div>
                <div className="text-xs text-emerald-500 mt-1">Check AI reasoning</div>
              </button>

              <button
                type="button"
                onClick={() => navigate('/system')}
                className="w-full text-left p-4 bg-purple-50 border border-purple-200 rounded-xl hover:bg-purple-100 transition-all group"
              >
                <div className="font-semibold text-purple-700 group-hover:text-purple-800 flex items-center">
                  <Shield className="w-4 h-4 mr-2" /> System Health
                </div>
                <div className="text-xs text-purple-500 mt-1">Monitor infrastructure</div>
              </button>
            </div>
          </div>

          {/* Recent Alerts */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Recent Alerts</h3>
              <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">{recentAlerts.length} new</span>
            </div>
            <RecentAlerts alerts={recentAlerts} />
          </div>

          {/* Recent Trades */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <h3 className="text-lg font-semibold mb-4 text-gray-900">Recent Trades</h3>
            <RecentTrades />
          </div>
        </div>
      </div>
    </div>
  );
}
