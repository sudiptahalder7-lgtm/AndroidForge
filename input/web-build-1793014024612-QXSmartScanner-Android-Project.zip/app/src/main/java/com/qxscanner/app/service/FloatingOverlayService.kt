package com.qxscanner.app.service

import android.app.Service
import android.content.Intent
import android.os.IBinder

class FloatingOverlayService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    // Full WindowManager draggable overlay implementation
}