# Native Android integration status

This Python/Kivy project provides an in-app animated scanner, candle-boundary countdown, API connection attempt, candle normalization, and a conservative signal engine.

**Not implemented by this Python project:** system-wide floating overlay above other apps, MediaProjection screen capture, and a native Android foreground service that continues scanning after the app is swiped away. These require Android-native components/permissions and cannot be truthfully described as active just because a Kivy UI exists. This project does not silently capture other apps' screens and does not place trades.

The supplied QuotexPy source is a community/unofficial library. Its upstream implementation imports browser/host-specific components (including `undetected_chromedriver` and `psutil`) in its login path; therefore an Android build may fail or API login may not work on-device even if Python syntax/tests pass. The workflow attempts a build and uploads an APK only if one is actually produced. A successful build must be confirmed from the GitHub Actions run and then the APK must be tested on a real device.
