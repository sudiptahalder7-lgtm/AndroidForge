"""Read-only signal helpers. Supports the documented QuotexPy candle layout.
QuotexPy candle arrays: [timestamp, open, close, high, low]. Unknown schemas fail closed.
"""
from __future__ import annotations
from typing import Any


def _num(v):
    try:
        x = float(v)
        return x if x == x and abs(x) != float('inf') else None
    except (TypeError, ValueError):
        return None


def normalize_candles(raw: Any):
    if not isinstance(raw, (list, tuple)):
        return []
    out = []
    for item in raw:
        if isinstance(item, dict):
            vals = [_num(item.get(k)) for k in ('open', 'high', 'low', 'close')]
            if any(v is None for v in vals):
                continue
            o, h, l, c = vals
        elif isinstance(item, (list, tuple)) and len(item) >= 5:
            # Exact upstream QuotexPy Candle.candle_* property ordering.
            _, ov, cv, hv, lv = item[:5]
            o, h, l, c = _num(ov), _num(hv), _num(lv), _num(cv)
            if any(v is None for v in (o, h, l, c)):
                continue
        else:
            continue
        if h < max(o, c, l) or l > min(o, c, h):
            continue
        out.append({'open': o, 'high': h, 'low': l, 'close': c})
    return out


def decide_signal(raw: Any):
    candles = normalize_candles(raw)
    if len(candles) < 20:
        return 'NO TRADE', f'যাচাইকৃত candle মাত্র {len(candles)}টি; কমপক্ষে ২০টি দরকার'
    closes = [x['close'] for x in candles[-20:]]
    bodies = [x['close'] - x['open'] for x in candles[-5:]]
    if any(x == 0 for x in bodies[-3:]):
        return 'NO TRADE', 'সাম্প্রতিক candle flat; পরিষ্কার দিক নেই'
    momentum = closes[-1] - closes[-4]
    trend = closes[-1] - (sum(closes) / len(closes))
    scale = max(abs(closes[-1]) * 1e-7, 1e-12)
    if momentum > scale and trend > scale and all(x > 0 for x in bodies[-3:]):
        return 'UP', 'Momentum ও recent candle direction একমত; নিশ্চিত পূর্বাভাস নয়'
    if momentum < -scale and trend < -scale and all(x < 0 for x in bodies[-3:]):
        return 'DOWN', 'Momentum ও recent candle direction একমত; নিশ্চিত পূর্বাভাস নয়'
    return 'NO TRADE', 'দিক/মোমেন্টাম একমত নয় বা edge অপর্যাপ্ত'
