import unittest
from signal_engine import normalize_candles, decide_signal

class SignalEngineTests(unittest.TestCase):
    def test_unknown_array_schema_fails_closed(self):
        self.assertEqual(decide_signal([[1,2,3,4]]*25)[0], 'NO TRADE')
    def test_insufficient_data_fails_closed(self):
        self.assertEqual(decide_signal([])[0], 'NO TRADE')
    def test_valid_ohlc_normalizes(self):
        raw=[{'open':1,'high':2,'low':0.5,'close':1.5} for _ in range(20)]
        self.assertEqual(len(normalize_candles(raw)),20)
        self.assertIn(decide_signal(raw)[0], ('UP','DOWN','NO TRADE'))

if __name__=='__main__': unittest.main()

class QuotexPyArraySchemaTests(unittest.TestCase):
    def test_documented_array_layout(self):
        # [timestamp, open, close, high, low]
        raw = [[i, 1.0 + i * 0.01, 1.01 + i * 0.01, 1.02 + i * 0.01, 0.99 + i * 0.01] for i in range(25)]
        self.assertEqual(len(normalize_candles(raw)), 25)
