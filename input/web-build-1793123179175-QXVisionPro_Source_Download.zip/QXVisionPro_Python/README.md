# QX Vision Pro — Python/Kivy source

An experimental read-only market-analysis UI for Android-first packaging. Includes an animated in-app scanner, IST/local device clock countdown to the next minute boundary, REAL/OTC pair selector (10 base pairs in each mode), QuotexPy connection/candle-fetch attempt, OHLC normalization, conservative UP/DOWN/NO TRADE logic, and a GitHub Actions Buildozer workflow.

## Build from a phone

1. Upload this ZIP's contents to a GitHub repository (extract it first).
2. Open **Actions**, choose **QX Vision Pro Android Build**, and press **Run workflow**.
3. Wait for the run to finish. Download `qxvisionpro-debug-apk` only if an APK artifact exists. If the build fails, open the failed step log; do not assume an APK exists.

## Important limits

- This is source code, not a prebuilt/verified APK.
- The API source supplied by the user is a community QuotexPy wrapper, not verified official API access. Login and candle data are not validated against a live account.
- QuotexPy's browser/host-specific dependencies may not run on Android; the workflow can fail until dependencies or API transport are adapted.
- The countdown and scanner are in-app only. System-wide overlay, Android foreground service, and MediaProjection screen capture are not implemented in this Python-only package.
- Signals are heuristic, not reliable predictions. Insufficient or unknown candle data returns NO TRADE. No trade execution is implemented.
- Never hard-code account credentials or commit them to GitHub.

## Tests

`python -m unittest discover -s tests -v`

## Included upstream source

`third_party/quotexpy/` is copied from the uploaded archive. License is retained in `third_party/QUOTEXPY_LICENSE.txt`.
