[app]
title = QX Vision Pro
package.name = qxvisionpro
package.domain = org.qxvisionpro
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,txt,md,yml
source.exclude_dirs = .git,__pycache__,tests
version = 0.2.0
requirements = python3,kivy,requests,urllib3,certifi,pytz,websockets,websocket-client,requests-toolbelt
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 35
android.minapi = 23
android.archs = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
