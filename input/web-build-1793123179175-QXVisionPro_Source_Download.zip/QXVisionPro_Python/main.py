"""QX Vision Pro: Python/Kivy read-only market-analysis prototype."""
import os, sys, asyncio, threading, time
from datetime import datetime
ROOT = os.path.dirname(os.path.abspath(__file__))
THIRD_PARTY = os.path.join(ROOT, 'third_party')
if os.path.isdir(THIRD_PARTY): sys.path.insert(0, THIRD_PARTY)
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.animation import Animation
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.progressbar import ProgressBar
from kivy.utils import get_color_from_hex
from signal_engine import decide_signal

BASE_PAIRS = ['GBP/USD','USD/JPY','USD/CHF','AUD/USD','USD/CAD','NZD/USD','EUR/GBP','EUR/JPY','EUR/AUD','GBP/JPY']
PAIRS = [(p,'REAL') for p in BASE_PAIRS] + [(p,'OTC') for p in BASE_PAIRS]
BG='#080D18'; PANEL='#121D30'; TEXT='#EAF0FF'; MUTED='#8B9BB4'; BLUE='#2452A4'; GREEN='#245A48'; RED='#6B3038'; GOLD='#D8A85C'

def color(h): return get_color_from_hex(h)
def make_label(text, size=14, c=TEXT, **kw): return Label(text=text, font_size=f'{size}sp', color=color(c), **kw)

class QXVisionApp(App):
    title='QX Vision Pro'
    def build(self):
        Window.clearcolor=color(BG); self.client=None; self.scan_event=None; self.scanning=False; self.busy=False; self.last_signal='NO TRADE'; self.last_boundary=None; self.last_fetch=0
        root=BoxLayout(orientation='vertical', padding=dp(14), spacing=dp(8))
        root.add_widget(make_label('[b]QX VISION PRO[/b]',24,TEXT,markup=True,size_hint_y=None,height=dp(40)))
        root.add_widget(make_label('LIVE CANDLE ANALYSIS • READ-ONLY • IST',10,MUTED,size_hint_y=None,height=dp(20)))
        self.pair_spinner=Spinner(text='GBP/USD • REAL',values=[f'{p} • {m}' for p,m in PAIRS],size_hint_y=None,height=dp(44),background_color=color(PANEL))
        root.add_widget(self.pair_spinner)
        credentials=BoxLayout(size_hint_y=None,height=dp(44),spacing=dp(6))
        self.email=TextInput(hint_text='Quotex email (optional)',multiline=False,background_color=color(PANEL),foreground_color=color(TEXT))
        self.password=TextInput(hint_text='Password',multiline=False,password=True,background_color=color(PANEL),foreground_color=color(TEXT))
        credentials.add_widget(self.email); credentials.add_widget(self.password); root.add_widget(credentials)
        buttons=BoxLayout(size_hint_y=None,height=dp(44),spacing=dp(6))
        self.connect_btn=Button(text='Connect API',background_color=color(GREEN)); self.start_btn=Button(text='▶ Start Scan',background_color=color(BLUE)); self.stop_btn=Button(text='■ Stop',background_color=color(RED))
        self.connect_btn.bind(on_release=self.connect_api); self.start_btn.bind(on_release=self.start_scan); self.stop_btn.bind(on_release=self.stop_scan)
        for b in (self.connect_btn,self.start_btn,self.stop_btn): buttons.add_widget(b)
        root.add_widget(buttons)
        self.scan_label=make_label('◉ SCANNER IDLE',15,GOLD,size_hint_y=None,height=dp(32)); root.add_widget(self.scan_label)
        self.progress=ProgressBar(max=100,value=0,size_hint_y=None,height=dp(10)); root.add_widget(self.progress)
        self.countdown=make_label('Next 1-minute boundary: --:--',12,MUTED,size_hint_y=None,height=dp(24)); root.add_widget(self.countdown)
        self.result=make_label('[b]NO TRADE[/b]',26,GOLD,markup=True,size_hint_y=None,height=dp(56)); root.add_widget(self.result)
        self.overlay_card=BoxLayout(orientation='vertical',padding=dp(8),spacing=dp(2),size_hint_y=None,height=dp(72))
        self.overlay_card.add_widget(make_label('[b]SIGNAL OVERLAY • IN-APP[/b]',11,BLUE,markup=True))
        self.overlay_signal=make_label('NO TRADE • 1M',16,GOLD,size_hint_y=None,height=dp(30)); self.overlay_card.add_widget(self.overlay_signal)
        root.add_widget(self.overlay_card)
        self.details=make_label('Connect to the unofficial API, then Start Scan.\nNo live data is assumed until received.',12,TEXT,halign='left',valign='top'); self.details.bind(size=lambda w,v:setattr(w,'text_size',v)); root.add_widget(self.details)
        self.log=make_label('Ready • no trades are ever placed automatically',10,MUTED,halign='left',valign='top',size_hint_y=None,height=dp(44)); root.add_widget(self.log)
        root.add_widget(make_label('Experimental probability-based analysis. No guaranteed accuracy. API is unofficial; Android compatibility is unverified.',10,GOLD,size_hint_y=None,height=dp(48)))
        Clock.schedule_interval(self.tick,0.2)
        return root

    def _run_bg(self,coro,callback):
        def worker():
            try: result=asyncio.run(coro)
            except Exception as exc: result=(False,f'{type(exc).__name__}: {exc}')
            Clock.schedule_once(lambda _dt: callback(result),0)
        threading.Thread(target=worker,daemon=True).start()

    def connect_api(self,*_):
        email,password=self.email.text.strip(),self.password.text
        if not email or not password: self.log.text='Enter credentials. This prototype does not save them.'; return
        self.log.text='Connecting to community QuotexPy (unofficial)…'; self.connect_btn.disabled=True
        async def task():
            from quotexpy import Quotex
            c=Quotex(email,password); ok=await asyncio.wait_for(c.connect(), timeout=20.0)
            if ok:
                try: await asyncio.wait_for(c.get_instruments(), timeout=15.0)
                except Exception as exc: return False, f'Connected but instrument list failed: {exc}'
                return True,c
            return False,'Connection was not accepted'
        def done(r):
            self.connect_btn.disabled=False
            if r[0]: self.client=r[1]; self.log.text='API connected. Check selected asset before scanning.'
            else: self.log.text='API connection failed: '+str(r[1])
        self._run_bg(task(),done)

    def start_scan(self,*_):
        if self.scanning: return
        self.scanning=True; self.scan_label.text='◉ SCANNING • animated'; self.log.text='Scanner started; waiting for verified API data.'
        self.anim=Animation(opacity=0.35,duration=0.45)+Animation(opacity=1,duration=0.45); self.anim.repeat=True; self.anim.start(self.scan_label)
        self.scan_event=Clock.schedule_interval(self.scan_tick,0.25)

    def stop_scan(self,*_):
        self.scanning=False
        if self.scan_event: self.scan_event.cancel(); self.scan_event=None
        try: self.anim.cancel(self.scan_label)
        except Exception: pass
        self.scan_label.opacity=1; self.scan_label.text='◉ SCANNER STOPPED'; self.progress.value=0; self.log.text='Stopped. No trade was placed.'

    def tick(self,_dt):
        now=time.time(); remain=60-int(now%60)
        self.countdown.text=f'Next 1-minute boundary: {remain:02d}s • IST {datetime.now().astimezone().strftime("%H:%M:%S")}'
        self.progress.value=(now%60)/60*100

    def scan_tick(self,_dt):
        # Trigger analysis once per minute near candle boundary; fetch may be unsupported on Android.
        now=time.time(); remain=60-(now%60)
        # Trigger once per boundary in the final seven seconds; do not loop-fetch.
        boundary=int(now//60)
        if remain <= 7 and self.last_boundary != boundary and not self.busy:
            self.last_boundary=boundary
            if self.client is not None: self.analyze()
            else:
                self.result.text='[b]NO TRADE[/b]'; self.details.text='API not connected; no verified candle data.'

    def analyze(self,*_):
        if self.busy: return
        if self.client is None or not getattr(self.client,'is_connected',False):
            self.result.text='[b]NO TRADE[/b]'; self.details.text='API disconnected or not connected.'; return
        pairmode=self.pair_spinner.text.split(' • ')
        if len(pairmode)!=2: return
        pair,mode=pairmode
        try:
            candidates=(pair, pair+' (OTC)', pair.replace('/','')) if mode=='REAL' else (pair+' (OTC)', pair+'_otc', pair+' OTC')
            asset=next((x for x in candidates if self.client.check_asset(x)),None)
        except Exception: asset=None
        if not asset:
            self.result.text='[b]NO TRADE[/b]'; self.details.text=f'API did not confirm exact asset: {pair} {mode}'; return
        self.busy=True; self.scan_label.text='◉ FETCHING CANDLES…'
        async def task():
            # Prevent upstream's unbounded candle wait from blocking forever.
            candles=await asyncio.wait_for(self.client.get_candles(asset,1200,60), timeout=12.0)
            return True,candles
        def done(r):
            self.busy=False
            if not r[0]: signal,reason='NO TRADE',str(r[1])
            else: signal,reason=decide_signal(r[1])
            self.last_signal=signal; self.result.text=f'[b]{signal}[/b]'; self.overlay_signal.text=f'{signal} • 1M'; self.details.text=f'PAIR: {asset} • {mode}\nTIMEFRAME: 1 minute\n{reason}\nUpdated: {datetime.now().astimezone().strftime("%H:%M:%S %Z")}'
            self.log.text='Signal is a heuristic, not a reliable promise. No automatic trade.'
            self.scan_label.text='◉ SCANNING • READY' if self.scanning else '◉ ANALYSIS COMPLETE'
        self._run_bg(task(),done)

    def on_stop(self):
        self.stop_scan()
        try:
            if self.client: self.client.close()
        except Exception: pass

if __name__=='__main__': QXVisionApp().run()
