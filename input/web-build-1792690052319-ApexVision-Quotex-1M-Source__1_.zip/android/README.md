# ApexVision AI — Quotex 1-Minute Screen Analyzer
## Native Android Project (Kotlin + Jetpack Compose + Material 3 + Room DB)

ApexVision AI is a production-minded native Android application designed to analyze the visible Quotex trading chart and generate an informational directional signal for **only the immediately following 1-minute candle**.

> **CRITICAL DISCLAIMER:**  
> ApexVision AI is an informational technical chart analyzer. It calculates visible candlestick wicks, momentum, and support/resistance zones. It **never** promises guaranteed profits or accuracy, and it does **not** execute trades or automate clicks on Quotex. All signals are strictly probabilistic.

---

## 📱 How to Build the Debug APK from an Android Phone (100% Free, No Computer Needed)

You do **not** need a laptop or PC. You can build the genuine debug APK in the cloud using GitHub Actions for free:

### Step 1: Download the Source ZIP
1. Download `ApexVision-Quotex-1M-Source.zip` from the top header of the web companion app.
2. The file is saved to your Android phone's **Downloads** folder.

### Step 2: Extract the Files on Your Phone
1. Install **ZArchiver** (free from Google Play Store).
2. Open ZArchiver, go to `Download`, tap `ApexVision-Quotex-1M-Source.zip`, and tap **Extract here**.

### Step 3: Create a Free GitHub Repository on Mobile
1. Open [github.com](https://github.com) in Chrome on your Android phone and sign in (or create a free account).
2. Tap the **`+`** icon in the top right $\to$ tap **New repository**.
3. Repository name: `apexvision-quotex`.
4. Choose **Public** or **Private** (both work with GitHub Actions free minutes) $\to$ tap **Create repository**.

### Step 4: Upload the Android Project to GitHub
1. On your newly created repo page, tap **"uploading an existing file"** or tap **Add file** $\to$ **Upload files**.
2. Select all files from the extracted `android` folder (or the root project with `.github/workflows/build-apk.yml`).
3. Tap **Commit changes**.

### Step 5: Download the Compiled APK Artifact
1. Tap the **Actions** tab on your GitHub repository.
2. You will see the **"Build Android Debug APK"** workflow running automatically.
3. The cloud build installs JDK 17, Android SDK 35, and runs `./gradlew assembleDebug` (~3 minutes).
4. When the checkmark turns green (Build Succeeded), tap the workflow run.
5. Under **Artifacts** at the bottom, tap **`ApexVision-Quotex-1M-Debug-APK`**.
6. A zip containing `app-debug.apk` will download to your phone. Extract and tap to install!

---

## 🛠 Architecture & Component Reference

| Layer | Component | Description |
|---|---|---|
| **Floating UI** | `QuotexFloatingOverlayService.kt` | Uses Android `SYSTEM_ALERT_WINDOW` (`TYPE_APPLICATION_OVERLAY`) with full touch drag listener over Quotex. |
| **Compose View** | `FloatingOverlayView.kt` | Displays live 1m candle countdown, glowing neon indicator (UP / DOWN / NO TRADE / MISSED), minimize pill, and rationale. |
| **Screen Capture** | `ScreenCaptureService.kt` | Android `MediaProjection` foreground service with `VirtualDisplay` and `ImageReader` grabbing frames strictly during final 7s (:53-:59). Never stores screenshots to disk. |
| **Candle Timing** | `CandleTimingManager.kt` | Monotonic clock tracking 1-minute intervals, final 7s evaluation window (:53-:59), deadline validation (:59 target), and auto-expiration. |
| **Local Vision Engine** | `LocalPriceActionEngine.kt` | 100% offline computer vision analyzing green/red pixel ratios, rejection wicks at support/resistance, and momentum. |
| **Remote Vision Engine** | `GeminiVisionEngine.kt` | Optional Google Gemini 2.5 Flash model integration using user-supplied API key (stored in private SharedPreferences). Strict 3.5s timeout. |
| **Room Database** | `ApexDatabase.kt` / `SignalHistoryDao.kt` | SQLite persistence for signals and closed-candle outcome verification. |
| **Accuracy Tracking** | `SignalHistoryRepository.kt` | Mathematical formula: `Accuracy = Wins / (Wins + Losses) * 100`. Strictly excludes NO_TRADE, unverified, and missed signals. |

---

## ⚙️ Building via Command Line (Local Machine or Terminal)

If you have a terminal or laptop:
```bash
cd android
chmod +x gradlew
./gradlew assembleDebug
```
The output APK is located at:
`android/app/build/outputs/apk/debug/app-debug.apk`

To run unit tests:
```bash
./gradlew test
```
