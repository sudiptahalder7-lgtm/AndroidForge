package com.apexvision.quotex.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalHistoryDao {

    @Query("SELECT * FROM signal_history ORDER BY timestamp DESC")
    fun getAllSignals(): Flow<List<SignalHistoryEntity>>

    @Query("SELECT * FROM signal_history WHERE outcome IN ('WIN', 'LOSS') ORDER BY timestamp DESC")
    fun getVerifiedDirectionalSignals(): Flow<List<SignalHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(signal: SignalHistoryEntity)

    @Update
    suspend fun update(signal: SignalHistoryEntity)

    @Delete
    suspend fun delete(signal: SignalHistoryEntity)

    @Query("DELETE FROM signal_history")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM signal_history WHERE outcome = 'WIN'")
    suspend fun getWinCount(): Int

    @Query("SELECT COUNT(*) FROM signal_history WHERE outcome = 'LOSS'")
    suspend fun getLossCount(): Int

    @Query("SELECT COUNT(*) FROM signal_history WHERE outcome IN ('WIN', 'LOSS')")
    suspend fun getTotalVerifiedCount(): Int
}
