package com.apexvision.quotex.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexvision.quotex.model.TradeSignal
import com.apexvision.quotex.timing.CandleTimingManager

@Composable
fun FloatingOverlayView(
    timingManager: CandleTimingManager,
    isScanning: Boolean,
    isMinimized: Boolean,
    onToggleScan: () -> Unit,
    onToggleMinimize: () -> Unit,
    onClose: () -> Unit
) {
    val timingState by timingManager.timingState.collectAsState()
    val activeSignal = timingState.activeSignal
    val signal = activeSignal?.signal ?: TradeSignal.IDLE
    val secondsRemaining = timingState.secondsRemainingInCandle

    if (isMinimized) {
        // Compact Draggable Pill / Bubble
        CompactFloatingBubble(
            signal = signal,
            secondsRemaining = secondsRemaining,
            isScanning = isScanning,
            onExpand = onToggleMinimize
        )
    } else {
        // Full Floating Card
        Surface(
            color = Color(0xFA090D16),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF1E293B)),
            shadowElevation = 16.dp,
            modifier = Modifier
                .width(230.dp)
                .padding(6.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(10.dp)
            ) {
                // Header Bar with Drag Handle, Title & Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(if (isScanning) Color(0xFF00E676) else Color(0xFF64748B), CircleShape)
                        )
                        Text(
                            text = "ApexVision AI",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "1M",
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            modifier = Modifier
                                .background(Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onToggleMinimize, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = "Minimize",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Glowing Signal Circle (Pulsing neon)
                GlowingSignalPuck(signal = signal)

                Spacer(modifier = Modifier.height(6.dp))

                // Candle Countdown
                val formattedSec = if (secondsRemaining < 10) "0$secondsRemaining" else "$secondsRemaining"
                Text(
                    text = "Candle ends in: 00:$formattedSec",
                    color = if (secondsRemaining in 1..7) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                // Current Analysis Status
                Text(
                    text = timingState.statusText,
                    color = Color(0xFF94A3B8),
                    fontSize = 9.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 11.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )

                // Signal Reasoning or Probabilistic Rationale
                if (activeSignal != null && signal != TradeSignal.IDLE) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activeSignal.reasoningSummary,
                        color = Color(0xFFE2E8F0),
                        fontSize = 9.sp,
                        lineHeight = 12.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Confidence: ${activeSignal.confidenceEstimate}% (Probabilistic, not guaranteed)",
                        color = Color(0xFFA1A1AA),
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scan / Stop Control Button
                Button(
                    onClick = onToggleScan,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isScanning) Color(0xFF1E293B) else Color(0xFF00E676)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = if (isScanning) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = if (isScanning) Color(0xFFEF4444) else Color(0xFF090D16),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isScanning) "Stop Scan" else "Start Scan",
                        color = if (isScanning) Color.White else Color(0xFF090D16),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CompactFloatingBubble(
    signal: TradeSignal,
    secondsRemaining: Int,
    isScanning: Boolean,
    onExpand: () -> Unit
) {
    val (glowColor, solidColor, text) = when (signal) {
        TradeSignal.UP -> Triple(Color(0xFF00E676), Color(0xFF00C853), "UP")
        TradeSignal.DOWN -> Triple(Color(0xFFFF1744), Color(0xFFD50000), "DOWN")
        TradeSignal.NO_TRADE -> Triple(Color(0xFF64748B), Color(0xFF475569), "HOLD")
        TradeSignal.MISSED_SIGNAL -> Triple(Color(0xFFF59E0B), Color(0xFFD97706), "LATE")
        TradeSignal.IDLE -> Triple(Color(0xFF334155), Color(0xFF1E293B), "${secondsRemaining}s")
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(solidColor)
            .border(2.dp, glowColor, CircleShape)
            .clickable { onExpand() }
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = text,
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
            if (signal != TradeSignal.IDLE) {
                Text(
                    text = "${secondsRemaining}s",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun GlowingSignalPuck(signal: TradeSignal) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val (glowColor, solidColor, text) = when (signal) {
        TradeSignal.UP -> Triple(Color(0xFF00E676), Color(0xFF00C853), "UP")
        TradeSignal.DOWN -> Triple(Color(0xFFFF1744), Color(0xFFD50000), "DOWN")
        TradeSignal.NO_TRADE -> Triple(Color(0xFF64748B), Color(0xFF475569), "NO TRADE")
        TradeSignal.MISSED_SIGNAL -> Triple(Color(0xFFF59E0B), Color(0xFFD97706), "MISSED")
        TradeSignal.IDLE -> Triple(Color(0xFF334155), Color(0xFF1E293B), "READY")
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(68.dp)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glowColor.copy(alpha = 0.55f), Color.Transparent),
                        radius = size.minDimension / 1.1f * pulseScale
                    )
                )
            }
            .border(2.dp, glowColor.copy(alpha = 0.85f), CircleShape)
            .background(solidColor, CircleShape)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = if (text.length > 5) 10.sp else 14.sp,
            textAlign = TextAlign.Center
        )
    }
}
