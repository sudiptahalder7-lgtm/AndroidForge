package com.apexvision.quotex.timing

import android.os.SystemClock
import com.apexvision.quotex.model.SignalResult
import com.apexvision.quotex.model.TradeSignal
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CandleTimingState(
    val secondsRemainingInCandle: Int = 60,
    val currentCandleEpochSecond: Long = 0,
    val isEvaluationWindowOpen: Boolean = false, // True during :53 - :59 (final 7s)
    val targetCandleLabel: String = "",
    val activeSignal: SignalResult? = null,
    val statusText: String = "Monitoring 1m candle formation..."
)

/**
 * Manages 1-minute candle boundaries, monotonic elapsed time, evaluation windows,
 * deadline enforcement (:59 target), and automatic signal expiration.
 */
class CandleTimingManager(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {

    private val _timingState = MutableStateFlow(CandleTimingState())
    val timingState: StateFlow<CandleTimingState> = _timingState.asStateFlow()

    private var tickerJob: Job? = null
    private var activeSignalCandleEpoch: Long? = null

    // Callback when final 7 seconds window (:53 - :59) opens
    var onTriggerEvaluation: ((secondsRemaining: Int) -> Unit)? = null

    // Track whether evaluation has already been triggered for the current candle
    private var evaluatedForCurrentCandle: Boolean = false

    fun start() {
        if (tickerJob?.isActive == true) return

        tickerJob = scope.launch {
            while (isActive) {
                updateTiming()
                delay(200) // 5Hz polling ensures timely :53 detection
            }
        }
    }

    fun stop() {
        tickerJob?.cancel()
        tickerJob = null
    }

    private fun updateTiming() {
        val nowMillis = System.currentTimeMillis()
        val currentSecOfMinute = ((nowMillis / 1000) % 60).toInt()
        val remaining = 60 - currentSecOfMinute
        val secondsRemaining = if (remaining == 0) 60 else remaining

        // 1-minute candle boundary: start of current candle in seconds
        val currentCandleEpoch = (nowMillis / 60000) * 60

        // Reset evaluation trigger flag on candle rollover
        if (secondsRemaining > 15 && evaluatedForCurrentCandle) {
            evaluatedForCurrentCandle = false
        }

        // Final 7 seconds window: secondsRemaining in 1..7 (i.e. :53 to :59)
        val inEvalWindow = secondsRemaining in 1..7

        // Check if existing active signal has expired (its target 1-minute candle is over)
        var currentSignal = _timingState.value.activeSignal
        if (activeSignalCandleEpoch != null) {
            val targetExpiryEpoch = activeSignalCandleEpoch!! + 60
            if ((nowMillis / 1000) >= targetExpiryEpoch) {
                // Signal for the past candle has expired
                currentSignal = null
                activeSignalCandleEpoch = null
            }
        }

        val targetMinuteEpoch = (currentCandleEpoch + 60) * 1000
        val targetLabel = "Next 1m (${java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(targetMinuteEpoch)})"

        var status = when {
            inEvalWindow -> "Final 7s Window (:53-:59) - Analyzing Candlestick..."
            currentSignal != null && currentSignal.signal != TradeSignal.IDLE -> "Signal Active for Current 1m Candle"
            else -> "Monitoring 1m candle formation... Window opens at :53"
        }

        _timingState.value = CandleTimingState(
            secondsRemainingInCandle = secondsRemaining,
            currentCandleEpochSecond = currentCandleEpoch,
            isEvaluationWindowOpen = inEvalWindow,
            targetCandleLabel = targetLabel,
            activeSignal = currentSignal,
            statusText = status
        )

        // Trigger evaluation once when entering final 7 seconds
        if (inEvalWindow && !evaluatedForCurrentCandle) {
            evaluatedForCurrentCandle = true
            onTriggerEvaluation?.invoke(secondsRemaining)
        }
    }

    /**
     * Verifies that the analysis completed before the :59.500 rollover deadline.
     * If the analysis finished late, flags as MISSED_SIGNAL.
     */
    fun validateAndPublishSignal(
        rawSignal: SignalResult,
        analysisStartTimeMonotonic: Long
    ): SignalResult {
        val elapsedDurationMs = SystemClock.elapsedRealtime() - analysisStartTimeMonotonic
        val nowSec = ((System.currentTimeMillis() / 1000) % 60).toInt()

        // Rollover happened or latency exceeded window
        val isLate = nowSec == 0 || (nowSec in 1..10 && _timingState.value.isEvaluationWindowOpen)

        val finalSignal = if (isLate) {
            rawSignal.copy(
                signal = TradeSignal.MISSED_SIGNAL,
                timingValid = false,
                status = "MISSED_DEADLINE",
                reasoningSummary = "Analysis completed after candle rollover (:00). Signal suppressed to prevent stale execution."
            )
        } else {
            rawSignal.copy(
                timingValid = true,
                status = "SIGNAL_READY"
            )
        }

        // Set target candle epoch for automatic expiration
        val nextCandleEpoch = ((System.currentTimeMillis() / 60000) + 1) * 60
        activeSignalCandleEpoch = nextCandleEpoch

        _timingState.value = _timingState.value.copy(
            activeSignal = finalSignal,
            statusText = if (isLate) "Missed Deadline" else "Signal Ready for Next 1m Candle"
        )

        return finalSignal
    }

    fun clearActiveSignal() {
        _timingState.value = _timingState.value.copy(activeSignal = null)
        activeSignalCandleEpoch = null
    }
}
