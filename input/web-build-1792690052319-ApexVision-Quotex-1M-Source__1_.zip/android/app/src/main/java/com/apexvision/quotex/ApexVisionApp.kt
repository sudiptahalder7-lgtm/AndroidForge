package com.apexvision.quotex

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.apexvision.quotex.data.local.ApexDatabase
import com.apexvision.quotex.data.repository.SignalHistoryRepository

class ApexVisionApp : Application() {

    lateinit var database: ApexDatabase
        private set

    lateinit var repository: SignalHistoryRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = ApexDatabase.getInstance(this)
        repository = SignalHistoryRepository(database.signalHistoryDao())

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val overlayChannel = NotificationChannel(
                "apex_overlay_channel",
                getString(R.string.channel_overlay_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_overlay_desc)
            }

            val captureChannel = NotificationChannel(
                "apex_capture_channel",
                getString(R.string.channel_capture_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_capture_desc)
            }

            manager.createNotificationChannel(overlayChannel)
            manager.createNotificationChannel(captureChannel)
        }
    }

    companion object {
        lateinit var instance: ApexVisionApp
            private set
    }
}
