package com.apexvision.quotex.data.repository

import com.apexvision.quotex.data.local.SignalHistoryDao
import com.apexvision.quotex.data.local.SignalHistoryEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class VerifiedAccuracyStats(
    val totalLogged: Int,
    val wins: Int,
    val losses: Int,
    val totalVerifiedDirectional: Int,
    val skipped: Int,
    val missedDeadlines: Int,
    val pending: Int,
    val accuracyPercentage: Double?,
    val hasSufficientData: Boolean
)

class SignalHistoryRepository(private val dao: SignalHistoryDao) {

    val allSignals: Flow<List<SignalHistoryEntity>> = dao.getAllSignals()

    val accuracyStats: Flow<VerifiedAccuracyStats> = allSignals.map { list ->
        var wins = 0
        var losses = 0
        var skipped = 0
        var missed = 0
        var pending = 0

        for (sig in list) {
            when (sig.outcome) {
                "WIN" -> wins++
                "LOSS" -> losses++
                "SKIPPED" -> skipped++
                "MISSED_DEADLINE" -> missed++
                else -> pending++
            }
        }

        val totalVerified = wins + losses
        val percentage = if (totalVerified > 0) {
            (wins.toDouble() / totalVerified.toDouble()) * 100.0
        } else {
            null
        }

        // Must have at least 5 verified directional signals before declaring a performance baseline
        val hasSufficient = totalVerified >= 5

        VerifiedAccuracyStats(
            totalLogged = list.size,
            wins = wins,
            losses = losses,
            totalVerifiedDirectional = totalVerified,
            skipped = skipped,
            missedDeadlines = missed,
            pending = pending,
            accuracyPercentage = percentage,
            hasSufficientData = hasSufficient
        )
    }

    suspend fun recordSignal(entity: SignalHistoryEntity) {
        dao.insert(entity)
    }

    suspend fun updateOutcome(id: String, outcome: String, candleColor: String? = null) {
        // Find existing record and update
        // (Dao allows update or custom query)
    }

    suspend fun updateEntity(entity: SignalHistoryEntity) {
        dao.update(entity)
    }

    suspend fun deleteSignal(entity: SignalHistoryEntity) {
        dao.delete(entity)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
