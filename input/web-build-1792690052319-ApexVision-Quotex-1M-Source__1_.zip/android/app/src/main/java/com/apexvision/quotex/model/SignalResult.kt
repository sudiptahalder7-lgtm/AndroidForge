package com.apexvision.quotex.model

/**
 * Standard signal states for 1-minute Quotex candle analysis.
 */
enum class TradeSignal {
    UP,             // Possible upward movement (CALL / Green)
    DOWN,           // Possible downward movement (PUT / Red)
    NO_TRADE,       // Insufficient evidence, flat doji, or excessive uncertainty
    MISSED_SIGNAL,  // Screen capture, timing, network, or deadline failure
    IDLE            // Waiting for evaluation window (:53 - :59)
}

/**
 * Verified outcome recorded strictly from the closed candle.
 */
enum class VerifiedOutcome {
    WIN,              // Direction was correct
    LOSS,             // Direction was incorrect
    SKIPPED,          // NO_TRADE or market indecision
    MISSED_DEADLINE,  // Signal arrived after candle rollover (:00)
    PENDING           // Awaiting closure of the target 1-minute candle
}

/**
 * Structured, validated signal output model.
 */
data class SignalResult(
    val signal: TradeSignal,
    val timestamp: Long = System.currentTimeMillis(),
    val targetCandle: String,
    val confidenceEstimate: Int,
    val reasoningSummary: String,
    val inputQuality: String = "HIGH",
    val timingValid: Boolean = true,
    val status: String = "ANALYSIS_COMPLETE",
    val assetPair: String = "EUR/USD (Quotex)",
    val timeframe: String = "1m",
    val latencyMs: Long = 0,
    val patternDetected: String = "Price Action Analysis",
    val supportLevel: String = "--",
    val resistanceLevel: String = "--"
) {
    /**
     * Clear explanation that confidence is probabilistic and not guaranteed accuracy.
     */
    val probabilisticDisclaimer: String
        get() = "Probabilistic estimation based on visible candlestick wicks. Does not guarantee market movements."
}
