package com.apexvision.quotex.engine

import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Base64
import com.apexvision.quotex.model.SignalResult
import com.apexvision.quotex.model.TradeSignal
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Remote AI Vision Engine using Google Gemini Vision.
 * Requires user's own API key stored in private SharedPreferences (never hardcoded).
 * Strictly validates responses and fails safe to NO_TRADE upon network or timeout errors.
 */
class GeminiVisionEngine(
    private val apiKeyProvider: () -> String?,
    private val fallbackEngine: ChartAnalysisEngine = LocalPriceActionEngine()
) : ChartAnalysisEngine {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3500, TimeUnit.MILLISECONDS)
        .readTimeout(3500, TimeUnit.MILLISECONDS)
        .writeTimeout(3500, TimeUnit.MILLISECONDS)
        .build()

    private val gson = Gson()

    override suspend fun analyzeChart(bitmap: Bitmap, secondsRemaining: Int): SignalResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider()?.trim()
        val startTime = SystemClock.elapsedRealtime()

        // If no user API key is configured, seamlessly use the 100% offline Local Engine
        if (apiKey.isNullOrEmpty()) {
            return@withContext fallbackEngine.analyzeChart(bitmap, secondsRemaining)
        }

        try {
            // Compress bitmap to low-bandwidth JPEG
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            val imageBytes = outputStream.toByteArray()
            val base64Image = Base64.encodeToString(imageBytes, Base64.NO_WRAP)

            val prompt = """
                You are ApexVision AI, an informational technical chart analyzer for visible 1-minute binary options candlesticks on Quotex.
                Analyze the provided chart image for ONLY the single next 1-minute candle.
                Rules:
                1. Inspect the rightmost forming 1m candle, upper/lower wicks, rejection off visible support/resistance, and short-term momentum.
                2. If there is a clear rejection wick at support or bullish momentum, signal UP.
                3. If there is a clear rejection wick at resistance or bearish momentum, signal DOWN.
                4. If the candle is a flat doji, indecisive, blurry, or contradictory, signal NO_TRADE.
                5. Do NOT promise guaranteed profits. Be probabilistic.
                Return strictly JSON with keys:
                {
                  "signal": "UP" | "DOWN" | "NO_TRADE",
                  "confidence": <integer between 40 and 90>,
                  "pattern": "<brief pattern name>",
                  "rationale": "<1-2 sentences strictly observing visible wicks>",
                  "support": "<price level or visible zone>",
                  "resistance": "<price level or visible zone>"
                }
            """.trimIndent()

            val requestBodyJson = JsonObject().apply {
                val contents = com.google.gson.JsonArray()
                val contentObj = JsonObject()
                val parts = com.google.gson.JsonArray()

                // Text part
                val textPart = JsonObject().apply { addProperty("text", prompt) }
                parts.add(textPart)

                // Inline data part (image)
                val imagePart = JsonObject().apply {
                    val inlineData = JsonObject().apply {
                        addProperty("mime_type", "image/jpeg")
                        addProperty("data", base64Image)
                    }
                    add("inline_data", inlineData)
                }
                parts.add(imagePart)

                contentObj.add("parts", parts)
                contents.add(contentObj)
                add("contents", contents)

                // System instruction / generation config
                val genConfig = JsonObject().apply {
                    addProperty("response_mime_type", "application/json")
                    addProperty("temperature", 0.2)
                }
                add("generationConfig", genConfig)
            }

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody.isNullOrEmpty()) {
                // Fail-safe to local analysis on API errors
                val localResult = fallbackEngine.analyzeChart(bitmap, secondsRemaining)
                return@withContext localResult.copy(
                    reasoningSummary = "[Gemini API Unavailable, fallback to local CV]: ${localResult.reasoningSummary}"
                )
            }

            // Parse response
            val parsedResponse = gson.fromJson(responseBody, JsonObject::class.java)
            val candidates = parsedResponse.getAsJsonArray("candidates")
            if (candidates == null || candidates.size() == 0) {
                return@withContext fallbackEngine.analyzeChart(bitmap, secondsRemaining)
            }

            val candidate = candidates.get(0).asJsonObject
            val content = candidate.getAsJsonObject("content")
            val parts = content.getAsJsonArray("parts")
            val rawJsonText = parts.get(0).asJsonObject.get("text").asString

            val modelOutput = gson.fromJson(rawJsonText, JsonObject::class.java)
            val signalStr = modelOutput.get("signal")?.asString?.uppercase() ?: "NO_TRADE"
            val signal = when (signalStr) {
                "UP" -> TradeSignal.UP
                "DOWN" -> TradeSignal.DOWN
                else -> TradeSignal.NO_TRADE
            }

            val confidence = modelOutput.get("confidence")?.asInt ?: 50
            val pattern = modelOutput.get("pattern")?.asString ?: "1m Wick Analysis"
            val rationale = modelOutput.get("rationale")?.asString ?: "Probabilistic 1m price action assessment."
            val support = modelOutput.get("support")?.asString ?: "--"
            val resistance = modelOutput.get("resistance")?.asString ?: "--"

            val latency = SystemClock.elapsedRealtime() - startTime

            SignalResult(
                signal = signal,
                targetCandle = getTargetCandleLabel(),
                confidenceEstimate = confidence,
                reasoningSummary = rationale,
                inputQuality = "HIGH_AI_GROUNDED",
                timingValid = true,
                status = "GEMINI_INFERENCE_COMPLETE",
                patternDetected = pattern,
                supportLevel = support,
                resistanceLevel = resistance,
                latencyMs = latency
            )
        } catch (e: Exception) {
            // Never crash, gracefully fallback to local price action engine
            val fallback = fallbackEngine.analyzeChart(bitmap, secondsRemaining)
            fallback.copy(
                reasoningSummary = "[Network/Timeout - Local Engine]: ${fallback.reasoningSummary}"
            )
        }
    }

    private fun getTargetCandleLabel(): String {
        val nextMinuteMillis = ((System.currentTimeMillis() / 60000) + 1) * 60000
        val sdf = SimpleDateFormat("HH:mm", Locale.US)
        return "Next 1m (${sdf.format(Date(nextMinuteMillis))})"
    }
}
