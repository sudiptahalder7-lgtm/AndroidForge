package com.apexvision.quotex

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexvision.quotex.capture.ScreenCaptureService
import com.apexvision.quotex.data.local.SignalHistoryEntity
import com.apexvision.quotex.model.TradeSignal
import com.apexvision.quotex.overlay.QuotexFloatingOverlayService
import com.apexvision.quotex.ui.GlowingSignalPuck
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ApexVisionAppTheme {
                MainAppScaffold(this)
            }
        }
    }
}

@Composable
fun ApexVisionAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF070A12),
            surface = Color(0xFF090D16),
            primary = Color(0xFF00E676),
            secondary = Color(0xFF38BDF8),
            error = Color(0xFFFF1744)
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(activity: Activity) {
    var selectedTab by remember { mutableStateOf(0) }
    var hasOverlayPermission by remember { mutableStateOf(checkOverlayPermission(activity)) }
    var hasCapturePermission by remember { mutableStateOf(false) }

    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPermission = checkOverlayPermission(activity)
    }

    val capturePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            hasCapturePermission = true
            val serviceIntent = Intent(activity, ScreenCaptureService::class.java)
            activity.startService(serviceIntent)
        }
    }

    // 1-minute candle countdown loop
    var secondsRemaining by remember { mutableStateOf(60) }
    LaunchedEffect(Unit) {
        while (true) {
            val nowSec = ((System.currentTimeMillis() / 1000) % 60).toInt()
            val rem = 60 - nowSec
            secondsRemaining = if (rem == 0) 60 else rem
            delay(250)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF00E676)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚡", fontSize = 16.sp)
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("ApexVision AI", fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
                                Text(
                                    "Quotex 1M",
                                    fontSize = 9.sp,
                                    color = Color(0xFF38BDF8),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .background(Color(0xFF0284C7).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                            Text("Next 1-Minute Candle Analyzer", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090D16))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF090D16)) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.PlayArrow, contentDescription = null) },
                    label = { Text("Scanner", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Layers, contentDescription = null) },
                    label = { Text("Overlay", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("AI Engine", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text("Accuracy", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Download, contentDescription = null) },
                    label = { Text("Build APK", fontSize = 10.sp) }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070A12))
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> ScannerTab(
                    activity = activity,
                    secondsRemaining = secondsRemaining,
                    hasOverlayPermission = hasOverlayPermission,
                    onRequestOverlay = { requestOverlayPermission(activity, overlayPermissionLauncher) },
                    hasCapturePermission = hasCapturePermission,
                    onRequestCapture = {
                        val mgr = activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        capturePermissionLauncher.launch(mgr.createScreenCaptureIntent())
                    }
                )
                1 -> OverlaySettingsTab(activity = activity)
                2 -> EngineSettingsTab(activity = activity)
                3 -> AccuracyHistoryTab()
                4 -> PhoneBuildGuideTab()
            }
        }
    }
}

@Composable
fun ScannerTab(
    activity: Activity,
    secondsRemaining: Int,
    hasOverlayPermission: Boolean,
    onRequestOverlay: () -> Unit,
    hasCapturePermission: Boolean,
    onRequestCapture: () -> Unit
) {
    var isOverlayRunning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Safety Banner
        Surface(
            color = Color(0xFF881337).copy(alpha = 0.25f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF43F5E).copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFB7185), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Informational directional signal for the NEXT 1-MINUTE CANDLE ONLY. Does NOT automate trades or execute orders on Quotex.",
                    fontSize = 10.sp,
                    color = Color(0xFFFECDD3),
                    lineHeight = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live 1m Candle Status
        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("CURRENT 1-MINUTE CANDLE", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                GlowingSignalPuck(signal = if (secondsRemaining in 1..7) TradeSignal.UP else TradeSignal.IDLE)
                Spacer(modifier = Modifier.height(8.dp))
                val formattedSec = if (secondsRemaining < 10) "0$secondsRemaining" else "$secondsRemaining"
                Text(
                    text = "00:$formattedSec",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = if (secondsRemaining in 1..7) Color(0xFFF59E0B) else Color(0xFF38BDF8)
                )
                Text(
                    text = if (secondsRemaining in 1..7) "Final 7s Evaluation Window Active" else "Forming candle... Window opens at :53",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Permissions Checklist Card
        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("REQUIRED PERMISSIONS", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

                // Overlay Permission Item
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("1. Floating Window Overlay", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Allows indicator over Quotex chart", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    if (hasOverlayPermission) {
                        Text("GRANTED", color = Color(0xFF00E676), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Button(
                            onClick = onRequestOverlay,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Grant", color = Color(0xFF090D16), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                // MediaProjection Permission Item
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("2. Screen Capture Consent", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Frame grab during final 7s (:53-:59)", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    if (hasCapturePermission) {
                        Text("ACTIVE", color = Color(0xFF00E676), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Button(
                            onClick = onRequestCapture,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Allow", color = Color(0xFF090D16), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Start / Stop Overlay Service
        Button(
            onClick = {
                if (!hasOverlayPermission) {
                    onRequestOverlay()
                    return@Button
                }
                val intent = Intent(activity, QuotexFloatingOverlayService::class.java)
                if (isOverlayRunning) {
                    activity.stopService(intent)
                    isOverlayRunning = false
                } else {
                    activity.startService(intent)
                    isOverlayRunning = true
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isOverlayRunning) Color(0xFFEF4444) else Color(0xFF00E676)
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(
                imageVector = if (isOverlayRunning) Icons.Default.Stop else Icons.Default.Layers,
                contentDescription = null,
                tint = if (isOverlayRunning) Color.White else Color(0xFF090D16)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isOverlayRunning) "Stop Floating Overlay" else "Launch Quotex Floating Overlay",
                color = if (isOverlayRunning) Color.White else Color(0xFF090D16),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun OverlaySettingsTab(activity: Activity) {
    var soundEnabled by remember { mutableStateOf(true) }
    var hapticFeedback by remember { mutableStateOf(true) }
    var compactOnStart by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("OVERLAY CONTROLS & BEHAVIOR", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Audio Signal Chime", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("High chime for UP, low tone for DOWN", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it })
                }

                HorizontalDivider(color = Color(0xFF1E293B))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Haptic Vibration Cue", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Vibrate phone when signal is validated at :59", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    Switch(checked = hapticFeedback, onCheckedChange = { hapticFeedback = it })
                }

                HorizontalDivider(color = Color(0xFF1E293B))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Start in Compact Bubble Mode", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Collapses to small draggable circular pill", fontSize = 10.sp, color = Color(0xFF64748B))
                    }
                    Switch(checked = compactOnStart, onCheckedChange = { compactOnStart = it })
                }
            }
        }
    }
}

@Composable
fun EngineSettingsTab(activity: Activity) {
    val prefs = activity.getSharedPreferences("apex_engine_prefs", Context.MODE_PRIVATE)
    var selectedEngine by remember { mutableStateOf(prefs.getString("engine_type", "LOCAL") ?: "LOCAL") }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var saveFeedback by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("CHART ANALYSIS ENGINE", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

        // Option 1: Local Engine (Default)
        Surface(
            color = if (selectedEngine == "LOCAL") Color(0xFF0F172A) else Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                if (selectedEngine == "LOCAL") Color(0xFF00E676) else Color(0xFF1E293B)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    selectedEngine = "LOCAL"
                    prefs.edit().putString("engine_type", "LOCAL").apply()
                }
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Local Price Action Computer Vision", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                    Text("RECOMMENDED", fontSize = 9.sp, color = Color(0xFF00E676), fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "100% offline, zero network latency, zero API costs. Computes green/red pixel ratios, rejection wicks at support/resistance, and 4-candle momentum directly in device memory.",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        }

        // Option 2: Gemini Vision
        Surface(
            color = if (selectedEngine == "GEMINI") Color(0xFF0F172A) else Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                if (selectedEngine == "GEMINI") Color(0xFF38BDF8) else Color(0xFF1E293B)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    selectedEngine = "GEMINI"
                    prefs.edit().putString("engine_type", "GEMINI").apply()
                }
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Google Gemini Vision Model (Optional)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Sends cropped chart frame to Gemini 2.5 Flash for multimodal reasoning. Requires your own Gemini API key. Strict 3.5s timeout prevents missing the candle deadline.",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )

                if (selectedEngine == "GEMINI") {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text("Gemini API Key (Stored Locally)", fontSize = 11.sp) },
                        placeholder = { Text("AIzaSy...", fontSize = 11.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            prefs.edit().putString("gemini_key", apiKey.trim()).apply()
                            saveFeedback = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8))
                    ) {
                        Text(if (saveFeedback) "Saved in Private SharedPreferences" else "Save Key", color = Color(0xFF090D16), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AccuracyHistoryTab() {
    val app = ApexVisionApp.instance
    val allSignalsFlow = remember { app.repository.allSignals }
    val accuracyStatsFlow = remember { app.repository.accuracyStats }

    val signals by allSignalsFlow.collectAsState(initial = emptyList())
    val stats by accuracyStatsFlow.collectAsState(initial = null)
    val coroutineScope = rememberCoroutineScope()

    var showClearDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Accuracy Card
            Surface(
                color = Color(0xFF090D16),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("VERIFIED OUTCOME ACCURACY", fontSize = 10.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showClearDialog = true }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear History", tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val accText = if (stats != null && stats!!.accuracyPercentage != null) {
                        "${stats!!.accuracyPercentage!!.toInt()}%"
                    } else {
                        "--"
                    }

                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(accText, fontSize = 36.sp, fontWeight = FontWeight.Black, color = Color(0xFF00E676))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (stats?.hasSufficientData == true) "Verified Win Rate" else "Awaiting sufficient sample (min 5)",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatPill("Wins", "${stats?.wins ?: 0}", Color(0xFF00E676))
                        StatPill("Losses", "${stats?.losses ?: 0}", Color(0xFFFF1744))
                        StatPill("Skipped", "${stats?.skipped ?: 0}", Color(0xFF64748B))
                        StatPill("Logged", "${signals.size}", Color(0xFF38BDF8))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Accuracy = Wins / (Wins + Losses) × 100. NO TRADE and unverified signals are strictly excluded from calculation.",
                        fontSize = 9.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
        }

        item {
            Text("HISTORICAL 1-MINUTE SIGNALS", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)
        }

        if (signals.isEmpty()) {
            item {
                Surface(
                    color = Color(0xFF090D16),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "No 1-minute signals recorded yet. Start scanning on Quotex.",
                        color = Color(0xFF64748B),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        } else {
            items(signals, key = { it.id }) { item ->
                SignalHistoryRow(
                    entity = item,
                    onMarkWin = {
                        coroutineScope.launch {
                            app.repository.updateEntity(item.copy(outcome = "WIN", actualNextCandle = "GREEN"))
                        }
                    },
                    onMarkLoss = {
                        coroutineScope.launch {
                            app.repository.updateEntity(item.copy(outcome = "LOSS", actualNextCandle = "RED"))
                        }
                    },
                    onDelete = {
                        coroutineScope.launch {
                            app.repository.deleteSignal(item)
                        }
                    }
                )
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear All Signal History?", color = Color.White) },
            text = { Text("This will permanently delete all recorded signals and reset verified accuracy tracking.", color = Color(0xFF94A3B8)) },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch { app.repository.clearAll() }
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF090D16)
        )
    }
}

@Composable
fun RowScope.StatPill(label: String, value: String, color: Color) {
    Surface(
        color = Color(0xFF070A12),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.weight(1f)
    ) {
        Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, fontSize = 9.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
fun SignalHistoryRow(
    entity: SignalHistoryEntity,
    onMarkWin: () -> Unit,
    onMarkLoss: () -> Unit,
    onDelete: () -> Unit
) {
    val signalColor = when (entity.signal) {
        "UP" -> Color(0xFF00E676)
        "DOWN" -> Color(0xFFFF1744)
        "NO_TRADE" -> Color(0xFF64748B)
        else -> Color(0xFFF59E0B)
    }

    Surface(
        color = Color(0xFF090D16),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = entity.signal,
                        color = signalColor,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                    Text(
                        text = entity.targetCandle,
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp
                    )
                }

                Text(
                    text = "${entity.timeStr}",
                    color = Color(0xFF64748B),
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = entity.rationale, color = Color(0xFFCBD5E1), fontSize = 10.sp, lineHeight = 13.sp)

            Spacer(modifier = Modifier.height(6.dp))

            // Outcome Verification Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val outcomeColor = when (entity.outcome) {
                    "WIN" -> Color(0xFF00E676)
                    "LOSS" -> Color(0xFFFF1744)
                    "SKIPPED" -> Color(0xFF64748B)
                    "MISSED_DEADLINE" -> Color(0xFFF59E0B)
                    else -> Color(0xFF38BDF8)
                }
                Text(
                    text = "OUTCOME: ${entity.outcome}",
                    color = outcomeColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )

                if (entity.outcome == "PENDING") {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = onMarkWin,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676).copy(alpha = 0.2f)),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Win", color = Color(0xFF00E676), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onMarkLoss,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF1744).copy(alpha = 0.2f)),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Loss", color = Color(0xFFFF1744), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PhoneBuildGuideTab() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("PHONE-ONLY CLOUD APK BUILD GUIDE", fontSize = 11.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold)

        Surface(
            color = Color(0xFF090D16),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "You do not need a computer or laptop! Use free GitHub Actions to build your debug APK in 3 minutes:",
                    fontSize = 11.sp,
                    color = Color.White
                )

                GuideStep(
                    number = "1",
                    title = "Download the Complete Source ZIP",
                    desc = "Use the Download button in the top bar to save 'ApexVision-Quotex-1M-Source.zip' directly to your Android Downloads folder."
                )

                GuideStep(
                    number = "2",
                    title = "Create a Free GitHub Repository",
                    desc = "Open github.com in Chrome on your phone. Tap '+' -> 'New repository' -> Name it 'apexvision-quotex' -> Set to Private or Public."
                )

                GuideStep(
                    number = "3",
                    title = "Upload the Project Files",
                    desc = "Tap 'Add file' -> 'Upload files'. Upload the unzipped android project files (including gradle wrapper and .github/workflows/build-apk.yml)."
                )

                GuideStep(
                    number = "4",
                    title = "Download APK from 'Actions' Tab",
                    desc = "GitHub automatically starts the 'Build Android Debug APK' workflow. After ~3 minutes, tap 'ApexVision-Quotex-1M-Debug-APK' under Artifacts to download and install!"
                )
            }
        }
    }
}

@Composable
fun GuideStep(number: String, title: String, desc: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .background(Color(0xFF00E676), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = Color(0xFF090D16), fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
        Column {
            Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
            Text(desc, color = Color(0xFF94A3B8), fontSize = 10.sp, lineHeight = 13.sp)
        }
    }
}

private fun checkOverlayPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else {
        true
    }
}

private fun requestOverlayPermission(
    context: Context,
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        launcher.launch(intent)
    }
}
