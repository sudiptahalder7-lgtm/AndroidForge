package com.apexvision.quotex.engine

import android.graphics.Bitmap
import com.apexvision.quotex.model.SignalResult

/**
 * Replaceable analysis-engine interface supporting local computer vision
 * and optional remote AI vision models.
 */
interface ChartAnalysisEngine {
    /**
     * Analyzes the visible Quotex chart frame.
     * @param bitmap Screen capture frame cropped to visible chart region
     * @param secondsRemaining Current candle seconds remaining (:53 - :59)
     * @return Validated structured SignalResult
     */
    suspend fun analyzeChart(bitmap: Bitmap, secondsRemaining: Int): SignalResult
}
