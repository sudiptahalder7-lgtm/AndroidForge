package com.apexvision.quotex.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Room entity recording every generated signal and its verified outcome.
 */
@Entity(tableName = "signal_history")
data class SignalHistoryEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val dateStr: String,
    val timeStr: String,
    val targetCandle: String,
    val asset: String = "EUR/USD (Quotex)",
    val timeframe: String = "1m",
    val signal: String, // "UP", "DOWN", "NO_TRADE", "MISSED_SIGNAL"
    val confidence: Int,
    val rationale: String,
    val pattern: String,
    val support: String = "--",
    val resistance: String = "--",
    val latencyMs: Long = 0,
    val timingValid: Boolean = true,
    val outcome: String = "PENDING", // "WIN", "LOSS", "SKIPPED", "MISSED_DEADLINE", "PENDING"
    val actualNextCandle: String? = null, // "GREEN", "RED", "DOJI"
    val verifiedAt: Long? = null
)
