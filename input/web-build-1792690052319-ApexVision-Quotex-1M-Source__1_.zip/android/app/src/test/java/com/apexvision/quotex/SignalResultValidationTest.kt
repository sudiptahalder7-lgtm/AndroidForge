package com.apexvision.quotex

import com.apexvision.quotex.model.SignalResult
import com.apexvision.quotex.model.TradeSignal
import org.junit.Assert.*
import org.junit.Test

class SignalResultValidationTest {

    @Test
    fun testValidSignalProperties() {
        val result = SignalResult(
            signal = TradeSignal.UP,
            targetCandle = "Next 1m (14:30)",
            confidenceEstimate = 82,
            reasoningSummary = "Strong lower wick rejection at support zone.",
            inputQuality = "HIGH",
            timingValid = true,
            status = "ANALYSIS_COMPLETE",
            patternDetected = "Hammer Rejection"
        )

        assertEquals(TradeSignal.UP, result.signal)
        assertTrue("Confidence must be between 0 and 100", result.confidenceEstimate in 0..100)
        assertTrue("Rationale must not be empty", result.reasoningSummary.isNotBlank())
        assertTrue("Disclaimer must be present", result.probabilisticDisclaimer.contains("Does not guarantee"))
    }

    @Test
    fun testNoTradeBehaviorOnAmbiguity() {
        val noTradeResult = SignalResult(
            signal = TradeSignal.NO_TRADE,
            targetCandle = "Next 1m (14:31)",
            confidenceEstimate = 45,
            reasoningSummary = "Doji formation with balanced wicks. Conviction is low.",
            inputQuality = "OPTIMAL",
            timingValid = true,
            status = "ANALYSIS_COMPLETE"
        )

        assertEquals(TradeSignal.NO_TRADE, noTradeResult.signal)
        assertTrue(noTradeResult.confidenceEstimate < 60)
    }
}
