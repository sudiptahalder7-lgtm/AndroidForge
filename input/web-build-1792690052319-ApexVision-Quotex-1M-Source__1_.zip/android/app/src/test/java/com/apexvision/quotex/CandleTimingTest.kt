package com.apexvision.quotex

import com.apexvision.quotex.model.SignalResult
import com.apexvision.quotex.model.TradeSignal
import org.junit.Assert.*
import org.junit.Test

class CandleTimingTest {

    @Test
    fun testOneMinuteCandleBoundaryAndSecondsRemaining() {
        // Test that any given epoch millisecond computes the correct remaining seconds in the 60s candle
        val fixedMillis = 1700000053000L // Ends with :53 (53rd second)
        val secOfMinute = ((fixedMillis / 1000) % 60).toInt()
        assertEquals(53, secOfMinute)

        val remaining = 60 - secOfMinute
        assertEquals(7, remaining)

        // At :53, we are exactly in the final 7 seconds window
        val inEvaluationWindow = remaining in 1..7
        assertTrue("At :53, inEvaluationWindow should be true", inEvaluationWindow)
    }

    @Test
    fun testEvaluationWindowBounds() {
        // :52 has 8 seconds remaining -> window should NOT be open yet
        val remainingAt52 = 60 - 52
        assertFalse(remainingAt52 in 1..7)

        // :53 has 7 seconds remaining -> window OPEN
        val remainingAt53 = 60 - 53
        assertTrue(remainingAt53 in 1..7)

        // :59 has 1 second remaining -> window OPEN (final deadline approaching)
        val remainingAt59 = 60 - 59
        assertTrue(remainingAt59 in 1..7)

        // :00 (rollover) has 60 seconds remaining -> window CLOSED for new candle
        val remainingAt00 = 60 - 0
        assertFalse(remainingAt00 in 1..7)
    }

    @Test
    fun testSignalExpiresWhenCandleEnds() {
        val candleStartEpoch = 1700000000L // 00 seconds
        val candleExpiryEpoch = candleStartEpoch + 60 // 60 seconds later

        val nowBeforeExpiry = 1700000045L
        assertFalse("Signal should not expire before target candle ends", nowBeforeExpiry >= candleExpiryEpoch)

        val nowAfterExpiry = 1700000061L
        assertTrue("Signal must expire once target candle ends", nowAfterExpiry >= candleExpiryEpoch)
    }

    @Test
    fun testLateAnalysisSuppressionAsMissedSignal() {
        val rawSignal = SignalResult(
            signal = TradeSignal.UP,
            targetCandle = "Next 1m (12:00)",
            confidenceEstimate = 85,
            reasoningSummary = "Hammer rejection at support",
            timingValid = true,
            status = "ANALYSIS_COMPLETE"
        )

        // Simulate late delivery: arrived after :00 rollover
        val isLate = true
        val finalSignal = if (isLate) {
            rawSignal.copy(
                signal = TradeSignal.MISSED_SIGNAL,
                timingValid = false,
                status = "MISSED_DEADLINE",
                reasoningSummary = "Analysis completed after candle rollover (:00). Signal suppressed to prevent stale execution."
            )
        } else {
            rawSignal
        }

        assertEquals(TradeSignal.MISSED_SIGNAL, finalSignal.signal)
        assertFalse(finalSignal.timingValid)
        assertEquals("MISSED_DEADLINE", finalSignal.status)
    }
}
