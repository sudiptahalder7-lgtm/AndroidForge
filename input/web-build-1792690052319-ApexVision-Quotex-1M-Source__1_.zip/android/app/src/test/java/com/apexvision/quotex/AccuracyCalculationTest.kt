package com.apexvision.quotex

import org.junit.Assert.*
import org.junit.Test

class AccuracyCalculationTest {

    @Test
    fun testAccuracyFormulaExcludesNoTradeAndUnverified() {
        // Sample scenario:
        // 8 Wins, 2 Losses, 5 NO_TRADE (SKIPPED), 3 PENDING, 1 MISSED_DEADLINE
        val wins = 8
        val losses = 2
        val skipped = 5
        val pending = 3
        val missed = 1

        val totalLogged = wins + losses + skipped + pending + missed
        assertEquals(19, totalLogged)

        // Strictly eligible verified directional signals:
        val totalVerified = wins + losses
        assertEquals(10, totalVerified)

        val accuracy = (wins.toDouble() / totalVerified.toDouble()) * 100.0
        assertEquals(80.0, accuracy, 0.001)
    }

    @Test
    fun testZeroEvaluatedSignalsReturnsNullOrZeroWithoutNaN() {
        val wins = 0
        val losses = 0
        val totalVerified = wins + losses

        val accuracy = if (totalVerified > 0) {
            (wins.toDouble() / totalVerified.toDouble()) * 100.0
        } else {
            null
        }

        assertNull("With zero evaluated signals, accuracy percentage must be null (no division by zero)", accuracy)
    }

    @Test
    fun testSampleThresholdRequirement() {
        // Less than 5 samples should flag hasSufficientData as false
        val lowSampleWins = 2
        val lowSampleLosses = 1
        val lowSampleTotal = lowSampleWins + lowSampleLosses
        val hasSufficientDataLow = lowSampleTotal >= 5
        assertFalse("3 signals should not be considered sufficient data", hasSufficientDataLow)

        val sufficientWins = 5
        val sufficientLosses = 2
        val sufficientTotal = sufficientWins + sufficientLosses
        val hasSufficientDataHigh = sufficientTotal >= 5
        assertTrue("7 signals should satisfy the 5-sample threshold", hasSufficientDataHigh)
    }
}
