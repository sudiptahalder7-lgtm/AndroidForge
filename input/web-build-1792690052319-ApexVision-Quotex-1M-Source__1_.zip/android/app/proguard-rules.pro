# Proguard rules for ApexVision Quotex 1M
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
-keep class com.apexvision.quotex.model.** { *; }
-keep class com.apexvision.quotex.data.local.** { *; }
