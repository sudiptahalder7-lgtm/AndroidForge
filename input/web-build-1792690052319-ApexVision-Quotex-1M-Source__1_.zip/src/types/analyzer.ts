export type TradeSignal = 'UP' | 'DOWN' | 'NO_TRADE' | 'MISSED_SIGNAL';

export type SignalOutcome = 'PENDING' | 'WIN' | 'LOSS' | 'SKIPPED' | 'MISSED_DEADLINE' | 'INVALIDATED';

export type MarketTrend = 'BULLISH' | 'BEARISH' | 'RANGING' | 'UNCLEAR';

export interface CandleAnalysisDetails {
  candleColor: 'GREEN' | 'RED' | 'DOJI';
  bodySize: string; // e.g. "Medium bullish expansion"
  upperWick: string; // e.g. "Long rejection tail at resistance"
  lowerWick: string; // e.g. "Small absorption wick"
  last7SecondsBehavior: string; // e.g. "Sharp upward push followed by supply rejection"
  observedLevel: string; // e.g. "Quotex round number 1.08500"
}

export interface ChartAnalysisResult {
  chartDetected: boolean;
  assetOrPair?: string;
  timeframe: string; // "1m"
  candleIndex?: string; // e.g. "Next Candle :00-:01"
  trend: MarketTrend;
  suggestedSignal: TradeSignal;
  pattern: string;
  supportLevel?: string;
  resistanceLevel?: string;
  confidenceScore: number;
  rationale: string;
  candleDetails?: CandleAnalysisDetails;
  observedConfluence?: string;
  riskFactors?: string;
  disclaimer?: string;
  simulated?: boolean;
  latencyMs?: number;
  deliveryTimestamp?: number;
  isExpired?: boolean;
}

export interface SignalRecord {
  id: string;
  timestamp: number;
  dateStr: string;
  timeStr: string;
  candleTargetTime: string; // e.g. "12:04:00 - 12:05:00"
  asset: string;
  timeframe: string;
  signal: TradeSignal;
  pattern: string;
  confidence: number;
  rationale: string;
  support: string;
  resistance: string;
  last7sAction?: string;
  latencyMs?: number;
  outcome: SignalOutcome;
  notes?: string;
  resolvedAt?: number;
  actualNextCandle?: 'GREEN' | 'RED' | 'DOJI';
}

export interface AccuracyStats {
  totalLogged: number;
  totalEvaluated: number;
  wins: number;
  losses: number;
  skipped: number;
  missedDeadlines: number;
  pending: number;
  winRate: number | null; // null if 0 evaluated
}

export interface SampleChartPreset {
  id: string;
  title: string;
  pair: string;
  timeframe: string;
  description: string;
  expectedBias: TradeSignal;
  secondsRemaining: number;
  dataUrl: string;
}
