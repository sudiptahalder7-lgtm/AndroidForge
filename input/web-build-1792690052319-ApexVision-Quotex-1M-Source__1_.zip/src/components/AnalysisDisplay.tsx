import React from 'react';
import { ChartAnalysisResult } from '../types/analyzer';
import {
  TrendingUp,
  TrendingDown,
  Layers,
  AlertTriangle,
  ShieldAlert,
  Info,
  Clock,
  CheckCircle,
  AlertOctagon,
  Eye,
} from 'lucide-react';

interface AnalysisDisplayProps {
  analysis: ChartAnalysisResult;
  onRecordSignal?: () => void;
  isSaved?: boolean;
}

export const AnalysisDisplay: React.FC<AnalysisDisplayProps> = ({
  analysis,
  onRecordSignal,
  isSaved = false,
}) => {
  const isUp = analysis.suggestedSignal === 'UP';
  const isDown = analysis.suggestedSignal === 'DOWN';
  const isNoTrade = analysis.suggestedSignal === 'NO_TRADE';
  const isMissed = analysis.suggestedSignal === 'MISSED_SIGNAL';

  if (!analysis.chartDetected) {
    return (
      <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-center">
        <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto mb-2" />
        <h4 className="text-sm font-bold text-amber-300">No Valid 1-Minute Candlestick Chart Detected</h4>
        <p className="text-xs text-amber-200/80 mt-1">
          {analysis.rationale ||
            'Please ensure the screenshot clearly displays 1-minute financial candlesticks with visible wicks and price levels.'}
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Primary Pattern & 1-Minute Target Card */}
      <div className="rounded-2xl border border-slate-700/80 bg-slate-900/90 p-4 shadow-xl">
        <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                1-Minute Candle Forecast
              </span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                Next 60s Candle Only
              </span>
            </div>
            <h3 className="text-base font-extrabold text-white mt-0.5">
              {analysis.pattern}
            </h3>
          </div>

          <div
            className={`px-2.5 py-1 rounded-lg font-mono font-black text-xs flex items-center gap-1 shrink-0 ${
              isUp
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : isDown
                ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                : isNoTrade
                ? 'bg-slate-700/40 text-slate-300 border border-slate-600/40'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
            }`}
          >
            {isUp ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : isDown ? (
              <TrendingDown className="w-3.5 h-3.5" />
            ) : isNoTrade ? (
              <Layers className="w-3.5 h-3.5" />
            ) : (
              <AlertOctagon className="w-3.5 h-3.5" />
            )}
            <span>{analysis.suggestedSignal}</span>
          </div>
        </div>

        {/* Detailed 1-Minute Candlestick Inspection Breakdown */}
        {analysis.candleDetails && (
          <div className="my-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="text-[11px] font-bold text-slate-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span>Current Candle Geometry (Final 7s Inspection):</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                {analysis.candleDetails.candleColor} Body
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px]">
              <div className="p-2 rounded bg-slate-900 border border-slate-800/80">
                <span className="text-slate-400 block uppercase">Upper Shadow Wick:</span>
                <span className="text-slate-200 font-medium">{analysis.candleDetails.upperWick}</span>
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800/80">
                <span className="text-slate-400 block uppercase">Lower Shadow Wick:</span>
                <span className="text-slate-200 font-medium">{analysis.candleDetails.lowerWick}</span>
              </div>
            </div>

            <div className="p-2 rounded bg-slate-900 border border-slate-800/80 text-[10px]">
              <span className="text-slate-400 block uppercase">Observed Final 7s Behavior:</span>
              <span className="text-cyan-300 font-medium">{analysis.candleDetails.last7SecondsBehavior}</span>
            </div>
          </div>
        )}

        {/* Key Levels & Structural Info */}
        <div className="grid grid-cols-2 gap-2 my-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-medium">
              Support Level
            </span>
            <span className="font-semibold text-slate-300 mt-0.5 block truncate font-mono">
              {analysis.supportLevel || '1.08450'}
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-medium">
              Resistance Level
            </span>
            <span className="font-semibold text-slate-300 mt-0.5 block truncate font-mono">
              {analysis.resistanceLevel || '1.08500'}
            </span>
          </div>
        </div>

        {/* Action Rationale */}
        <div className="space-y-2 text-xs border-t border-slate-800/80 pt-3">
          <div>
            <div className="text-[11px] font-bold text-slate-300 flex items-center gap-1 mb-1">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>Next 1-Minute Candle Bias:</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60 font-sans">
              {analysis.rationale}
            </p>
          </div>

          {analysis.latencyMs !== undefined && (
            <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-cyan-400" />
                <span>Analysis Latency: <strong className="text-slate-200">{analysis.latencyMs}ms</strong></span>
              </span>
              <span className={analysis.isExpired ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                {analysis.isExpired ? '⚠️ LATE (MISSED CANDLE ROLLOVER)' : '✓ ON TIME (DELIVERED BEFORE ROLLOVER)'}
              </span>
            </div>
          )}
        </div>

        {/* Record Signal Button */}
        {onRecordSignal && (
          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
            <div className="text-[11px] text-slate-400">
              Log prediction for next candle outcome validation:
            </div>
            <button
              onClick={onRecordSignal}
              disabled={isSaved}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                isSaved
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 active:scale-95'
              }`}
            >
              {isSaved ? (
                <>
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Logged</span>
                </>
              ) : (
                <>
                  <span>Track Next Candle</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Safety & Timing Disclosure */}
      <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-[11px] text-rose-200/90 flex items-start gap-2 leading-relaxed">
        <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
        <div>
          <strong className="font-bold text-rose-300">1-Minute Candle Rules:</strong> Predictions apply strictly to the single next 60-second candle. Does not execute trades automatically. If network lag causes signal delivery after the candle begins, always skip the trade.
        </div>
      </div>
    </div>
  );
};
