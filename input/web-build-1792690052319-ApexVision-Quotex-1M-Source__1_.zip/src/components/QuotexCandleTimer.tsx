import React, { useEffect, useState } from 'react';
import { Clock, Zap, RefreshCw, AlertTriangle, ShieldCheck } from 'lucide-react';

interface QuotexCandleTimerProps {
  onFinal7SecondsWindow?: (secondsRemaining: number) => void;
  autoTriggerFinal7s?: boolean;
  onToggleAutoTrigger?: () => void;
}

export const QuotexCandleTimer: React.FC<QuotexCandleTimerProps> = ({
  onFinal7SecondsWindow,
  autoTriggerFinal7s = false,
  onToggleAutoTrigger,
}) => {
  const [offsetSec, setOffsetSec] = useState<number>(0);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60);
  const [candleProgress, setCandleProgress] = useState<number>(0);
  const [hasTriggeredThisCycle, setHasTriggeredThisCycle] = useState<boolean>(false);

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const currentSeconds = (now.getSeconds() + offsetSec + 60) % 60;
      const currentMillis = now.getMilliseconds();
      const remaining = 60 - currentSeconds;
      const progress = ((currentSeconds + currentMillis / 1000) / 60) * 100;

      setSecondsRemaining(remaining === 0 ? 60 : remaining);
      setCandleProgress(progress);

      // Final 7-second window trigger (between 7s and 5s left in candle)
      if (remaining <= 7 && remaining >= 1) {
        if (!hasTriggeredThisCycle && autoTriggerFinal7s) {
          setHasTriggeredThisCycle(true);
          onFinal7SecondsWindow?.(remaining);
        }
      } else if (remaining > 15) {
        // Reset trigger flag for the next cycle
        setHasTriggeredThisCycle(false);
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 200);
    return () => clearInterval(interval);
  }, [offsetSec, hasTriggeredThisCycle, autoTriggerFinal7s, onFinal7SecondsWindow]);

  const isFinal7s = secondsRemaining <= 7 && secondsRemaining >= 1;
  const isTargetEntry = secondsRemaining === 1;

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-3 shadow-lg">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Clock className={`w-4 h-4 ${isFinal7s ? 'text-amber-400 animate-pulse' : 'text-cyan-400'}`} />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
            1-Min Quotex Candle Timer
          </span>
        </div>

        <div className="flex items-center gap-1">
          {onToggleAutoTrigger && (
            <button
              onClick={onToggleAutoTrigger}
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold transition-all flex items-center gap-1 ${
                autoTriggerFinal7s
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
              title="Auto trigger analysis during final 7s of candle"
            >
              <Zap className="w-2.5 h-2.5" />
              <span>{autoTriggerFinal7s ? 'Auto-Trigger: 7s' : 'Manual Trigger'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar & Countdown Number */}
      <div className="flex items-center gap-3">
        <div className="flex-1">
          <div className="flex items-center justify-between text-[11px] font-mono mb-1">
            <span className="text-slate-400">Current Candle Time</span>
            <span
              className={`font-black ${
                isTargetEntry
                  ? 'text-emerald-400 text-xs animate-bounce'
                  : isFinal7s
                  ? 'text-amber-400 text-xs'
                  : 'text-slate-200'
              }`}
            >
              00:{secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining} left
            </span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
            <div
              className={`h-full transition-all duration-200 ${
                isTargetEntry
                  ? 'bg-emerald-400 shadow-md shadow-emerald-400/50'
                  : isFinal7s
                  ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-500'
              }`}
              style={{ width: `${candleProgress}%` }}
            />
          </div>
        </div>

        {/* Sync Offset Controls */}
        <div className="flex items-center gap-0.5 bg-slate-950 p-1 rounded-lg border border-slate-800 shrink-0">
          <button
            onClick={() => setOffsetSec((prev) => (prev - 1 + 60) % 60)}
            className="w-5 h-5 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-mono font-bold flex items-center justify-center"
            title="Minus 1s"
          >
            -
          </button>
          <span className="text-[10px] font-mono text-slate-300 px-1" title="Quotex Clock Offset">
            {offsetSec >= 0 ? `+${offsetSec}s` : `${offsetSec}s`}
          </span>
          <button
            onClick={() => setOffsetSec((prev) => (prev + 1) % 60)}
            className="w-5 h-5 rounded hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-mono font-bold flex items-center justify-center"
            title="Plus 1s"
          >
            +
          </button>
        </div>
      </div>

      {/* Stage Badge Banner */}
      <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
        {isTargetEntry ? (
          <span className="text-emerald-400 font-bold flex items-center gap-1 font-mono">
            <span>🎯 TARGET ENTRY (1s Before Next Candle Starts)</span>
          </span>
        ) : isFinal7s ? (
          <span className="text-amber-400 font-bold flex items-center gap-1 font-mono animate-pulse">
            <span>🔥 FINAL 7s WINDOW: Scanning Current Wick & Impulse</span>
          </span>
        ) : (
          <span className="text-slate-400 flex items-center gap-1 font-mono">
            <span>Forming Candle ({60 - secondsRemaining}s elapsed) • Window opens at :53</span>
          </span>
        )}

        <span className="text-slate-500 text-[9px] font-mono">
          Strict 1m Expiry
        </span>
      </div>
    </div>
  );
};
