import React, { useRef, useState } from 'react';
import { Camera, Image as ImageIcon, Sparkles, X, CheckCircle2, Monitor, AlertCircle } from 'lucide-react';
import { getQuotex1mPresets } from '../data/sampleCharts';
import { SampleChartPreset } from '../types/analyzer';

interface ChartUploaderProps {
  selectedImage: string | null;
  onImageSelected: (dataUrl: string, presetName?: string) => void;
  onClearImage: () => void;
  isAnalyzing: boolean;
  onAnalyze: (candleSeconds?: number) => void;
  secondsRemaining: number;
}

export const ChartUploader: React.FC<ChartUploaderProps> = ({
  selectedImage,
  onImageSelected,
  onClearImage,
  isAnalyzing,
  onAnalyze,
  secondsRemaining,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const quotexPresets = getQuotex1mPresets();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        if (typeof evt.target?.result === 'string') {
          onImageSelected(evt.target.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        if (typeof evt.target?.result === 'string') {
          onImageSelected(evt.target.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Browser Screen Capture API (Web alternative to Android MediaProjection)
  const handleCaptureScreen = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const track = stream.getVideoTracks()[0];
        const imageCapture = (window as any).ImageCapture ? new (window as any).ImageCapture(track) : null;

        if (imageCapture) {
          const bitmap = await imageCapture.grabFrame();
          const canvas = document.createElement('canvas');
          canvas.width = bitmap.width;
          canvas.height = bitmap.height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(bitmap, 0, 0);
          const dataUrl = canvas.toDataURL('image/png');
          track.stop();
          onImageSelected(dataUrl, 'Live Quotex Window');
        } else {
          // Fallback: render video frame into canvas
          const video = document.createElement('video');
          video.srcObject = stream;
          video.play();
          video.onloadedmetadata = () => {
            setTimeout(() => {
              const canvas = document.createElement('canvas');
              canvas.width = video.videoWidth || 680;
              canvas.height = video.videoHeight || 380;
              const ctx = canvas.getContext('2d');
              ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);
              const dataUrl = canvas.toDataURL('image/png');
              track.stop();
              onImageSelected(dataUrl, 'Live Quotex Window');
            }, 300);
          };
        }
      } else {
        alert('DisplayMedia is not supported in this browser. Please use the Upload button.');
      }
    } catch (err: any) {
      console.warn('Screen capture cancelled or unavailable:', err);
    }
  };

  const isFinal7s = secondsRemaining <= 7 && secondsRemaining >= 1;

  return (
    <div className="flex flex-col gap-3">
      {/* Upload Zone */}
      {!selectedImage ? (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-all duration-200 ${
            dragActive
              ? 'border-cyan-400 bg-cyan-950/20 scale-[0.99]'
              : 'border-slate-700/80 hover:border-slate-500 bg-slate-900/60 active:scale-[0.99]'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />

          <div className="flex flex-col items-center justify-center gap-2">
            <div className="w-11 h-11 rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center text-cyan-400 shadow-md">
              <Camera className="w-5 h-5" />
            </div>

            <div>
              <div className="text-xs font-bold text-slate-200">
                Tap to Import Quotex 1m Screenshot
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">
                Capture the forming candle during the final 7 seconds
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-[9px] text-slate-400 mt-0.5 font-mono">
              <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-cyan-300">1M Candles</span>
              <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-amber-300">:53-:59 Window</span>
              <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-emerald-300">:01s Target</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-slate-950/90 shadow-xl">
          <div className="relative max-h-52 overflow-hidden flex items-center justify-center bg-black/40">
            <img
              src={selectedImage}
              alt="1m Quotex Chart Frame"
              className="w-full object-contain max-h-52 select-none"
            />
            {/* Top overlay badge */}
            <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded-md bg-slate-900/90 border border-slate-700 text-[10px] font-medium text-slate-300 backdrop-blur-sm">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>1m Frame Loaded</span>
            </div>
            {/* Remove button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onClearImage();
              }}
              disabled={isAnalyzing}
              className="absolute top-2 right-2 w-7 h-7 rounded-full bg-slate-900/90 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
              title="Change Image"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-2.5 bg-slate-900/95 flex items-center justify-between border-t border-slate-800">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isAnalyzing}
              className="text-xs text-slate-400 hover:text-slate-200 underline font-medium"
            >
              Replace Frame
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />

            <button
              onClick={() => onAnalyze(secondsRemaining)}
              disabled={isAnalyzing}
              className={`px-3.5 py-1.5 rounded-xl font-black text-xs shadow-lg flex items-center gap-1.5 transition-all disabled:opacity-50 ${
                isFinal7s
                  ? 'bg-gradient-to-r from-amber-400 to-emerald-400 text-slate-950 shadow-emerald-500/25 animate-pulse'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-cyan-500/20 active:scale-95'
              }`}
            >
              {isAnalyzing ? (
                <>
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>Scanning Final 7s...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Analyze Next 1m ({secondsRemaining}s)</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Screen Capture button for browser tab testing */}
      <div className="flex items-center gap-2">
        <button
          onClick={handleCaptureScreen}
          disabled={isAnalyzing}
          className="flex-1 py-1.5 px-2.5 rounded-xl border border-slate-800 bg-slate-900/80 hover:bg-slate-800 text-[11px] text-slate-300 font-medium flex items-center justify-center gap-1.5 transition-all active:scale-95"
        >
          <Monitor className="w-3.5 h-3.5 text-cyan-400" />
          <span>Capture Live Screen / Window</span>
        </button>
      </div>

      {/* 1-Minute Quotex Presets with 7-Second Rejection States */}
      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Quotex 1M Test Presets (Final 7s States)
          </span>
          <span className="text-[9px] text-cyan-400 font-mono">1-Tap Load</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {quotexPresets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => onImageSelected(preset.dataUrl, preset.pair)}
              disabled={isAnalyzing}
              className="flex items-center gap-2 p-2 rounded-xl border border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 active:scale-95 transition-all text-left text-xs text-slate-300 hover:border-slate-700"
            >
              <div
                className={`w-2 h-7 rounded-full shrink-0 ${
                  preset.expectedBias === 'UP'
                    ? 'bg-emerald-500'
                    : preset.expectedBias === 'DOWN'
                    ? 'bg-rose-500'
                    : preset.expectedBias === 'NO_TRADE'
                    ? 'bg-slate-500'
                    : 'bg-amber-500'
                }`}
              />
              <div className="overflow-hidden">
                <div className="font-semibold text-[11px] text-slate-200 truncate">
                  {preset.pair}
                </div>
                <div className="text-[9px] text-slate-400 truncate">
                  {preset.expectedBias === 'UP'
                    ? 'Hammer 7s Rejection'
                    : preset.expectedBias === 'DOWN'
                    ? 'Star 7s Resistance'
                    : preset.expectedBias === 'NO_TRADE'
                    ? 'Flat Doji (No Trade)'
                    : 'Late Rollover (Expired)'}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
