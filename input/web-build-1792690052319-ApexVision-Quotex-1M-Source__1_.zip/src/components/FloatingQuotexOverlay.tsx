import React, { useState } from 'react';
import { TradeSignal, ChartAnalysisResult } from '../types/analyzer';
import { GlowingIndicator } from './GlowingIndicator';
import { X, Minimize2, Maximize2, ShieldAlert, Sparkles, Clock, Move } from 'lucide-react';

interface FloatingQuotexOverlayProps {
  signal: TradeSignal | 'IDLE';
  analysisResult: ChartAnalysisResult | null;
  secondsRemaining: number;
  isAnalyzing: boolean;
  onClose: () => void;
  onTriggerAnalysis: () => void;
}

export const FloatingQuotexOverlay: React.FC<FloatingQuotexOverlayProps> = ({
  signal,
  analysisResult,
  secondsRemaining,
  isAnalyzing,
  onClose,
  onTriggerAnalysis,
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState<'top-right' | 'bottom-right' | 'center-right'>('bottom-right');

  const isUp = signal === 'UP';
  const isDown = signal === 'DOWN';
  const isNoTrade = signal === 'NO_TRADE';
  const isMissed = signal === 'MISSED_SIGNAL';

  const positionClasses = {
    'top-right': 'top-14 right-3',
    'center-right': 'top-1/3 right-3',
    'bottom-right': 'bottom-16 right-3',
  };

  if (isMinimized) {
    return (
      <div
        onClick={() => setIsMinimized(false)}
        className={`fixed ${positionClasses[position]} z-50 cursor-pointer p-2 rounded-full bg-slate-900/95 border-2 shadow-2xl backdrop-blur-md flex items-center justify-center transition-all active:scale-95 ${
          isUp
            ? 'border-emerald-400 text-emerald-400 shadow-emerald-500/30'
            : isDown
            ? 'border-rose-400 text-rose-400 shadow-rose-500/30'
            : isNoTrade
            ? 'border-slate-500 text-slate-300'
            : isMissed
            ? 'border-amber-400 text-amber-300'
            : 'border-cyan-500 text-cyan-300'
        }`}
        title="Tap to expand Quotex Floating Overlay"
      >
        <div className="w-12 h-12 rounded-full flex flex-col items-center justify-center text-center">
          <span className="text-[11px] font-black font-mono leading-none">
            {signal === 'IDLE' ? '1M' : signal}
          </span>
          <span className="text-[9px] font-mono text-slate-300 mt-0.5">
            :{secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`fixed ${positionClasses[position]} z-50 w-72 rounded-3xl bg-slate-900/95 border-2 shadow-2xl backdrop-blur-xl p-3.5 transition-all text-slate-100 ${
        isUp
          ? 'border-emerald-500/80 shadow-emerald-500/25'
          : isDown
          ? 'border-rose-500/80 shadow-rose-500/25'
          : isNoTrade
          ? 'border-slate-600/80 shadow-slate-500/20'
          : isMissed
          ? 'border-amber-500/80 shadow-amber-500/25'
          : 'border-cyan-500/60 shadow-cyan-500/20'
      }`}
    >
      {/* Overlay Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-extrabold text-[11px] tracking-tight text-white uppercase font-mono">
            Quotex 1M Overlay
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              const positions: ('top-right' | 'center-right' | 'bottom-right')[] = [
                'top-right',
                'center-right',
                'bottom-right',
              ];
              const nextIndex = (positions.indexOf(position) + 1) % positions.length;
              setPosition(positions[nextIndex]);
            }}
            className="p-1 rounded text-slate-400 hover:text-white"
            title="Dock position"
          >
            <Move className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 rounded text-slate-400 hover:text-white"
            title="Minimize to Floating Bubble"
          >
            <Minimize2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-rose-400"
            title="Close Overlay"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Signal Circular Indicator */}
      <div className="py-2 flex flex-col items-center">
        <GlowingIndicator
          signal={signal}
          confidence={analysisResult?.confidenceScore}
          isAnalyzing={isAnalyzing}
          secondsRemaining={secondsRemaining}
          latencyMs={analysisResult?.latencyMs}
          size="compact"
        />

        {/* Real-time Status & Expiry */}
        <div className="text-center mt-1">
          <div className="text-xs font-black font-mono">
            {isAnalyzing ? (
              <span className="text-cyan-400 animate-pulse">EVALUATING FINAL 7s...</span>
            ) : isUp ? (
              <span className="text-emerald-400">NEXT 1M: CALL / UP ▲</span>
            ) : isDown ? (
              <span className="text-rose-400">NEXT 1M: PUT / DOWN ▼</span>
            ) : isNoTrade ? (
              <span className="text-slate-300">NEXT 1M: NO TRADE (HOLD)</span>
            ) : isMissed ? (
              <span className="text-amber-400">MISSED SIGNAL (EXPIRED)</span>
            ) : (
              <span className="text-slate-400">READY FOR 7s WINDOW</span>
            )}
          </div>

          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
            Candle closes in: <strong className="text-white">00:{secondsRemaining < 10 ? `0${secondsRemaining}` : secondsRemaining}</strong>
          </div>
        </div>
      </div>

      {/* Brief Rationale / Explanation */}
      {analysisResult && (
        <div className="mt-1 p-2 rounded-xl bg-slate-950/80 border border-slate-800 text-[10px] leading-snug">
          <div className="text-slate-300 font-semibold truncate mb-0.5">
            {analysisResult.pattern}
          </div>
          <p className="text-slate-400 line-clamp-2">
            {analysisResult.rationale}
          </p>
        </div>
      )}

      {/* Action / Trigger & Safe Notice */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between gap-1">
        <button
          onClick={onTriggerAnalysis}
          disabled={isAnalyzing}
          className="flex-1 py-1 px-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 font-bold text-[10px] flex items-center justify-center gap-1 shadow-md transition-all active:scale-95 disabled:opacity-50"
        >
          <Sparkles className="w-3 h-3" />
          <span>{isAnalyzing ? 'Scanning...' : 'Trigger 7s Scan'}</span>
        </button>

        <span className="text-[8px] text-slate-500 text-right uppercase tracking-wider font-mono">
          Manual Entry Only
        </span>
      </div>
    </div>
  );
};
