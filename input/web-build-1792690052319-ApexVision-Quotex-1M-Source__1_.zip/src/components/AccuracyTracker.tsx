import React from 'react';
import { AccuracyStats } from '../types/analyzer';
import { Award, CheckCircle2, XCircle, Clock, ShieldCheck, AlertOctagon, MinusCircle } from 'lucide-react';

interface AccuracyTrackerProps {
  stats: AccuracyStats;
}

export const AccuracyTracker: React.FC<AccuracyTrackerProps> = ({ stats }) => {
  return (
    <div className="rounded-2xl border border-slate-700/80 bg-slate-900/90 p-4 shadow-xl">
      {/* Title & Verification Badge */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            1-Minute Candle Outcome Validation
          </h3>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full font-medium">
          <ShieldCheck className="w-3 h-3" />
          <span>Closed Candle Only</span>
        </div>
      </div>

      {/* 5-Metric Responsive Grid */}
      <div className="grid grid-cols-5 gap-1.5 text-center">
        {/* Measured Win Rate */}
        <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col items-center justify-center">
          <div
            className={`text-base sm:text-lg font-black font-mono ${
              stats.winRate === null
                ? 'text-slate-400'
                : stats.winRate >= 60
                ? 'text-emerald-400'
                : stats.winRate >= 50
                ? 'text-amber-400'
                : 'text-rose-400'
            }`}
          >
            {stats.winRate !== null ? `${stats.winRate}%` : '--%'}
          </div>
          <div className="text-[8px] sm:text-[9px] uppercase tracking-wider text-slate-400 font-semibold mt-0.5 truncate">
            Win Rate
          </div>
        </div>

        {/* Wins */}
        <div className="p-2 rounded-xl bg-emerald-950/20 border border-emerald-900/40 flex flex-col items-center justify-center">
          <div className="text-base sm:text-lg font-black font-mono text-emerald-400">
            {stats.wins}
          </div>
          <div className="text-[8px] sm:text-[9px] uppercase tracking-wider text-emerald-400/80 font-semibold mt-0.5 flex items-center gap-0.5 truncate">
            <CheckCircle2 className="w-2.5 h-2.5" />
            <span>Wins</span>
          </div>
        </div>

        {/* Losses */}
        <div className="p-2 rounded-xl bg-rose-950/20 border border-rose-900/40 flex flex-col items-center justify-center">
          <div className="text-base sm:text-lg font-black font-mono text-rose-400">
            {stats.losses}
          </div>
          <div className="text-[8px] sm:text-[9px] uppercase tracking-wider text-rose-400/80 font-semibold mt-0.5 flex items-center gap-0.5 truncate">
            <XCircle className="w-2.5 h-2.5" />
            <span>Losses</span>
          </div>
        </div>

        {/* Skipped / No Trade */}
        <div className="p-2 rounded-xl bg-slate-950/40 border border-slate-800 flex flex-col items-center justify-center">
          <div className="text-base sm:text-lg font-black font-mono text-slate-300">
            {stats.skipped}
          </div>
          <div className="text-[8px] sm:text-[9px] uppercase tracking-wider text-slate-400 font-semibold mt-0.5 flex items-center gap-0.5 truncate">
            <MinusCircle className="w-2.5 h-2.5" />
            <span>Skipped</span>
          </div>
        </div>

        {/* Missed Deadlines */}
        <div className="p-2 rounded-xl bg-amber-950/20 border border-amber-900/40 flex flex-col items-center justify-center">
          <div className="text-base sm:text-lg font-black font-mono text-amber-400">
            {stats.missedDeadlines}
          </div>
          <div className="text-[8px] sm:text-[9px] uppercase tracking-wider text-amber-400/80 font-semibold mt-0.5 flex items-center gap-0.5 truncate">
            <AlertOctagon className="w-2.5 h-2.5" />
            <span>Late</span>
          </div>
        </div>
      </div>

      {/* Validation Methodology Note */}
      <div className="mt-3 p-2 rounded-xl bg-slate-950/50 border border-slate-800/80 text-[10px] text-slate-400 flex items-start gap-1.5 leading-tight">
        <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <span className="text-slate-300 font-medium">Outcome Tracking:</span> Compare the prediction (UP / DOWN) only after the target 1-minute candle closes (60 seconds later). Signals delivered late (missed deadline) are tracked as Late and excluded from win rate.
        </div>
      </div>
    </div>
  );
};
