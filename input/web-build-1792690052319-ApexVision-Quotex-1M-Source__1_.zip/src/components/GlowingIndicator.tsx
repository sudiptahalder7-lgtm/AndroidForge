import React from 'react';
import { TradeSignal } from '../types/analyzer';
import { ArrowUpRight, ArrowDownRight, Minus, AlertOctagon, Sparkles, Clock } from 'lucide-react';

interface GlowingIndicatorProps {
  signal: TradeSignal | 'IDLE';
  confidence?: number;
  isAnalyzing?: boolean;
  secondsRemaining?: number;
  latencyMs?: number;
  size?: 'normal' | 'large' | 'compact';
}

export const GlowingIndicator: React.FC<GlowingIndicatorProps> = ({
  signal,
  confidence,
  isAnalyzing = false,
  secondsRemaining,
  latencyMs,
  size = 'normal',
}) => {
  const isUp = signal === 'UP';
  const isDown = signal === 'DOWN';
  const isNoTrade = signal === 'NO_TRADE';
  const isMissed = signal === 'MISSED_SIGNAL';
  const isIdle = signal === 'IDLE';

  const diameter =
    size === 'compact'
      ? 'w-20 h-20'
      : size === 'large'
      ? 'w-36 h-36'
      : 'w-28 h-28';

  return (
    <div className="relative flex flex-col items-center justify-center py-1">
      {/* Outer Glow Halo */}
      <div className="relative flex items-center justify-center">
        <div
          className={`absolute rounded-full transition-all duration-700 pointer-events-none ${
            isUp
              ? 'w-44 h-44 bg-emerald-500/25 blur-2xl animate-pulse'
              : isDown
              ? 'w-44 h-44 bg-rose-500/25 blur-2xl animate-pulse'
              : isNoTrade
              ? 'w-36 h-36 bg-slate-500/20 blur-xl'
              : isMissed
              ? 'w-36 h-36 bg-amber-500/20 blur-xl'
              : 'w-32 h-32 bg-cyan-500/5 blur-md'
          }`}
        />

        {/* Pulsing circular badge */}
        <div
          className={`relative ${diameter} rounded-full flex flex-col items-center justify-center transition-all duration-500 shadow-2xl select-none ${
            isAnalyzing
              ? 'bg-slate-900 border-2 border-cyan-400 text-cyan-300 animate-spin-slow'
              : isUp
              ? 'bg-gradient-to-br from-emerald-400 to-green-600 border-4 border-emerald-100 text-slate-950 glow-signal-up'
              : isDown
              ? 'bg-gradient-to-br from-rose-500 to-red-600 border-4 border-rose-200 text-white glow-signal-down'
              : isNoTrade
              ? 'bg-gradient-to-br from-slate-600 to-slate-800 border-4 border-slate-400 text-slate-100 shadow-lg'
              : isMissed
              ? 'bg-gradient-to-br from-amber-600/90 to-amber-900 border-4 border-amber-300 text-amber-100 shadow-lg'
              : 'bg-slate-900/90 border-2 border-slate-700 text-slate-400 shadow-inner'
          }`}
        >
          {isAnalyzing ? (
            <div className="flex flex-col items-center">
              <Sparkles className="w-7 h-7 animate-spin text-cyan-400" />
              <span className="text-[9px] font-bold tracking-wider mt-1 font-mono uppercase text-cyan-200">
                FINAL 7s
              </span>
            </div>
          ) : isUp ? (
            <div className="flex flex-col items-center text-center">
              <ArrowUpRight className="w-8 h-8 stroke-[3] -mb-1 drop-shadow-sm text-slate-950" />
              <span className="text-xl font-black tracking-tight leading-none text-slate-950 font-mono">
                UP
              </span>
              <span className="text-[8px] font-extrabold tracking-widest uppercase text-slate-950">
                NEXT 1M GREEN
              </span>
            </div>
          ) : isDown ? (
            <div className="flex flex-col items-center text-center">
              <ArrowDownRight className="w-8 h-8 stroke-[3] -mb-1 drop-shadow-sm text-white" />
              <span className="text-xl font-black tracking-tight leading-none text-white font-mono">
                DOWN
              </span>
              <span className="text-[8px] font-extrabold tracking-widest uppercase text-white">
                NEXT 1M RED
              </span>
            </div>
          ) : isNoTrade ? (
            <div className="flex flex-col items-center text-center">
              <Minus className="w-7 h-7 stroke-[3] -mb-0.5 text-slate-200" />
              <span className="text-base font-black tracking-tight leading-none text-slate-100 font-mono">
                NO TRADE
              </span>
              <span className="text-[8px] font-bold tracking-widest uppercase text-slate-300">
                INDECISION
              </span>
            </div>
          ) : isMissed ? (
            <div className="flex flex-col items-center text-center px-1">
              <AlertOctagon className="w-6 h-6 stroke-[2.5] text-amber-200 mb-0.5" />
              <span className="text-[11px] font-black tracking-tight leading-tight text-amber-100 font-mono">
                MISSED
              </span>
              <span className="text-[7px] font-bold tracking-wider uppercase text-amber-200">
                EXPIRED
              </span>
            </div>
          ) : (
            <div className="flex flex-col items-center text-center">
              <span className="text-xs font-bold tracking-wider uppercase text-slate-400 font-mono">
                STANDBY
              </span>
              <span className="text-[8px] text-slate-500 mt-0.5">NEXT 1M</span>
            </div>
          )}
        </div>
      </div>

      {/* Latency & Confidence info */}
      <div className="flex items-center gap-2 mt-2.5">
        {confidence !== undefined && !isIdle && !isAnalyzing && !isMissed && (
          <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900/90 border border-slate-700/80 text-[11px]">
            <span
              className="w-1.5 h-1.5 rounded-full animate-ping"
              style={{
                backgroundColor: isUp ? '#00e676' : isDown ? '#ff1744' : '#94a3b8',
              }}
            />
            <span className="text-slate-400 font-medium">Confidence:</span>
            <span
              className="font-bold font-mono"
              style={{
                color: isUp ? '#00e676' : isDown ? '#ff5252' : '#cbd5e1',
              }}
            >
              {confidence}%
            </span>
          </div>
        )}

        {latencyMs !== undefined && (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-[10px] text-slate-400 font-mono">
            <Clock className="w-3 h-3 text-cyan-400" />
            <span>{latencyMs}ms</span>
          </div>
        )}
      </div>
    </div>
  );
};
