import React, { useState } from 'react';
import { Smartphone, Copy, Check, Code2, BookOpen, Layers, ShieldCheck, X, Zap, Clock, ShieldAlert } from 'lucide-react';

interface AndroidBlueprintModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidBlueprintModal: React.FC<AndroidBlueprintModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'overlay' | 'capture' | 'testplan' | 'matrix'>('overlay');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const codeSnippets = {
    overlay: `// QuotexFloatingOverlayService.kt
package com.apexvision.quotex.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.*
import com.apexvision.quotex.ui.FloatingOverlayView

/**
 * Foreground Service rendering a draggable circular floating overlay
 * on top of the Quotex trading application using SYSTEM_ALERT_WINDOW.
 */
class QuotexFloatingOverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showFloatingBubble()
    }

    private fun showFloatingBubble() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 200
        }

        overlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@QuotexFloatingOverlayService)
            setViewTreeSavedStateRegistryOwner(this@QuotexFloatingOverlayService)
            setContent {
                FloatingOverlayView(
                    onDismiss = { stopSelf() }
                )
            }
        }

        windowManager.addView(overlayView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        overlayView?.let { windowManager.removeView(it) }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`,

    capture: `// ScreenCaptureService.kt
package com.apexvision.quotex.capture

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream

/**
 * Android MediaProjection Service for capturing the final 7 seconds of 1m candles.
 * Requires user consent via MediaProjectionManager.createScreenCaptureIntent().
 */
class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("DATA") ?: return START_NOT_STICKY

        val mpManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)

        setupVirtualDisplay()
        start7SecondCandleLoop()
        return START_STICKY
    }

    private fun setupVirtualDisplay() {
        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "QuotexCapture",
            metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
    }

    private fun start7SecondCandleLoop() {
        scope.launch {
            while (isActive) {
                val nowSeconds = (System.currentTimeMillis() / 1000) % 60
                // Trigger screen inspection at :53 of every minute (7s remaining)
                if (nowSeconds == 53L) {
                    captureCurrentFrameAndAnalyze()
                    delay(8000) // Sleep past candle boundary to avoid re-trigger
                }
                delay(200)
            }
        }
    }

    private suspend fun captureCurrentFrameAndAnalyze() {
        val image = imageReader?.acquireLatestImage() ?: return
        val planes = image.planes
        val buffer = planes[0].buffer
        val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(buffer)
        image.close()

        // Compress and transmit to Gemini Vision API
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 75, stream)
        val jpegBytes = stream.toByteArray()

        // Target: Deliver signal to FloatingOverlay by :59 (1 second before rollover)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`,

    testplan: `// TIMING & RELIABILITY BENCHMARK TEST PLAN
===================================================================
Target Workflow: 1-Minute Quotex Candlestick Scalping
===================================================================

Phase 1: Synchronization & Clock Drift
1. Connect to Network Time Protocol (NTP) to eliminate system clock drift.
2. Synchronize overlay countdown with Quotex broker server time.
   - Threshold: Drift must be < 250ms.
   - Fallback: If drift > 500ms, display "UNVERIFIED TIMING" warning.

Phase 2: Final 7-Second Analysis Window
- Trigger Time: :53.00s of current 1m candle (7 seconds remaining).
- Capture Frame: Bitmap grabbed via VirtualDisplay at :53.20s.
- Network Roundtrip (Gemini 3.8 Flash): ~600ms - 900ms.
- Delivery Deadline: Must reach client before :59.00s.

Phase 3: The 1-Second Pre-Rollover Target
- Target Delivery: :58.80s - :59.20s (approx 1s before next candle).
- Display: Glow green (UP) or red (DOWN) or gray (NO TRADE).

Phase 4: Late Arrival & Missed Deadline Protocol (FAIL-SAFE)
- Rule: If response arrives at >= 00:00.00s (post-rollover):
  -> SUPPRESS TRADE SIGNAL.
  -> Display "MISSED SIGNAL - EXPIRED".
  -> Log as MISSED_DEADLINE in outcome tracker.
  -> Never display stale predictions on already-opened candles.`,

    matrix: `// CAPABILITY MATRIX: WEB PROTOTYPE vs NATIVE ANDROID
===================================================================
Feature                  Web Prototype (This App)  Native Android (Kotlin)
-------------------------------------------------------------------
1m Candle Countdown      ✅ Yes (Local / Synced)   ✅ Yes (NTP Synced)
Final 7s Inspection      ✅ Yes (Sim / Live)       ✅ Yes (MediaProjection)
Floating Overlay         ✅ Yes (In-app sim)       ✅ Yes (SYSTEM_ALERT_WINDOW)
Draw Over Quotex App     ❌ No (Browser Sandbox)   ✅ Yes (Draw over any app)
Background Frame Grab    ❌ No (Requires Prompts)  ✅ Yes (VirtualDisplay)
Next Candle Outcome Log  ✅ Yes (LocalStorage)     ✅ Yes (Room SQLite)
Zero Auto-Execution      ✅ Enforced               ✅ Enforced (Play Policy)
===================================================================`
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-fade-in">
      <div className="w-full max-w-xl max-h-[90vh] bg-slate-900 border border-slate-700 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Native Android Architecture (1M Quotex)</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono">
                  Kotlin + Overlay
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Separation of web prototype vs Android-only permissions & timing test plan
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 p-1.5 gap-1 text-xs">
          {[
            { id: 'overlay', label: 'Floating Service', icon: Layers },
            { id: 'capture', label: 'Screen Capture', icon: Zap },
            { id: 'testplan', label: 'Timing Test Plan', icon: Clock },
            { id: 'matrix', label: 'Web vs Android', icon: ShieldCheck },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 py-1.5 px-2 rounded-lg font-medium flex items-center justify-center gap-1.5 transition-all text-[11px] ${
                  activeTab === tab.id
                    ? 'bg-slate-800 text-cyan-400 shadow-sm border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Snippet & Explanation */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 font-mono">
              {activeTab === 'overlay'
                ? 'QuotexFloatingOverlayService.kt (SYSTEM_ALERT_WINDOW)'
                : activeTab === 'capture'
                ? 'ScreenCaptureService.kt (MediaProjection 7s Loop)'
                : activeTab === 'testplan'
                ? 'TIMING_RELIABILITY_TEST_PLAN.md'
                : 'CAPABILITY_MATRIX.txt'}
            </span>
            <button
              onClick={() => handleCopy(codeSnippets[activeTab], activeTab)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              {copiedKey === activeTab ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 leading-relaxed overflow-x-auto select-text">
            <code>{codeSnippets[activeTab]}</code>
          </pre>

          {/* Android Permissions Breakdown */}
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
            <div className="font-bold text-slate-200 flex items-center gap-1.5 text-[11px]">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>Android Permissions & Policy Requirements:</span>
            </div>
            <ul className="space-y-1.5 text-slate-400 text-[11px] list-disc list-inside">
              <li>
                <strong className="text-slate-300">Overlay Permission:</strong> Requires user to grant <code className="text-cyan-300">Settings.ACTION_MANAGE_OVERLAY_PERMISSION</code> so the indicator floats over Quotex.
              </li>
              <li>
                <strong className="text-slate-300">Screen Capture Intent:</strong> User must tap 'Start Now' once per session via <code className="text-cyan-300">MediaProjectionManager.createScreenCaptureIntent()</code>.
              </li>
              <li>
                <strong className="text-slate-300">Google Play Policy:</strong> Categorize strictly as <em>Chart Pattern Reader</em>. Under no circumstances include automated clickers or broker API bridge code.
              </li>
            </ul>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/90 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors"
          >
            Close Blueprint
          </button>
        </div>
      </div>
    </div>
  );
};
