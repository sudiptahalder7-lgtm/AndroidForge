import React, { useState } from 'react';
import { SignalRecord, SignalOutcome } from '../types/analyzer';
import {
  History,
  TrendingUp,
  TrendingDown,
  Layers,
  CheckCircle,
  XCircle,
  Clock,
  Trash2,
  ChevronDown,
  ChevronUp,
  AlertOctagon,
  MinusCircle,
} from 'lucide-react';

interface SignalHistoryProps {
  signals: SignalRecord[];
  onUpdateOutcome: (id: string, outcome: SignalOutcome, actualColor?: 'GREEN' | 'RED' | 'DOJI') => void;
  onDeleteSignal: (id: string) => void;
  onClearAll: () => void;
}

export const SignalHistory: React.FC<SignalHistoryProps> = ({
  signals,
  onUpdateOutcome,
  onDeleteSignal,
  onClearAll,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'WIN' | 'LOSS' | 'LATE'>('ALL');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredSignals = signals.filter((s) => {
    if (filter === 'ALL') return true;
    if (filter === 'PENDING') return s.outcome === 'PENDING';
    if (filter === 'WIN') return s.outcome === 'WIN';
    if (filter === 'LOSS') return s.outcome === 'LOSS';
    if (filter === 'LATE') return s.outcome === 'MISSED_DEADLINE' || s.signal === 'MISSED_SIGNAL';
    return true;
  });

  return (
    <div className="rounded-2xl border border-slate-700/80 bg-slate-900/90 p-4 shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            1-Min Signal Log ({signals.length})
          </h3>
        </div>

        {signals.length > 0 && (
          <button
            onClick={onClearAll}
            className="text-[10px] text-slate-500 hover:text-rose-400 transition-colors flex items-center gap-1"
            title="Clear all records"
          >
            <Trash2 className="w-3 h-3" />
            <span>Clear</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-950/70 border border-slate-800 mb-3 text-[10px]">
        {(['ALL', 'PENDING', 'WIN', 'LOSS', 'LATE'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`flex-1 py-1 rounded-lg font-semibold transition-all text-center ${
              filter === tab
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab === 'ALL'
              ? 'All'
              : tab === 'PENDING'
              ? 'Pending'
              : tab === 'WIN'
              ? 'Wins'
              : tab === 'LOSS'
              ? 'Losses'
              : 'Late'}
          </button>
        ))}
      </div>

      {/* Signal List */}
      {filteredSignals.length === 0 ? (
        <div className="py-8 text-center text-slate-500 text-xs">
          No {filter.toLowerCase()} signals recorded yet. Capture or trigger 1m candle analysis during the final 7s window.
        </div>
      ) : (
        <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
          {filteredSignals.map((item) => {
            const isUp = item.signal === 'UP';
            const isDown = item.signal === 'DOWN';
            const isNoTrade = item.signal === 'NO_TRADE';
            const isMissed = item.signal === 'MISSED_SIGNAL' || item.outcome === 'MISSED_DEADLINE';
            const isExpanded = expandedId === item.id;

            return (
              <div
                key={item.id}
                className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 transition-all hover:border-slate-700/80"
              >
                {/* Main Row */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 overflow-hidden">
                    {/* Signal icon badge */}
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 font-bold font-mono text-xs ${
                        isUp
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : isDown
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : isNoTrade
                          ? 'bg-slate-700/30 text-slate-300 border border-slate-600/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {isUp ? 'UP' : isDown ? 'DOWN' : isNoTrade ? 'SKIP' : 'LATE'}
                    </div>

                    <div className="overflow-hidden">
                      <div className="font-semibold text-xs text-slate-200 truncate flex items-center gap-1.5">
                        <span>{item.pattern}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1.5 mt-0.5 truncate">
                        <span>{item.asset}</span>
                        <span>•</span>
                        <span>{item.timeStr}</span>
                        <span>•</span>
                        <span className="text-cyan-400">{item.candleTargetTime}</span>
                        {item.latencyMs !== undefined && (
                          <span className="text-slate-500">({item.latencyMs}ms)</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Outcome Tag or Action Buttons */}
                  <div className="shrink-0 flex items-center gap-1">
                    {item.outcome === 'PENDING' ? (
                      <div className="flex items-center gap-1">
                        {item.signal === 'UP' ? (
                          <>
                            <button
                              onClick={() => onUpdateOutcome(item.id, 'WIN', 'GREEN')}
                              className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-[9px] flex items-center gap-0.5 active:scale-95 transition-all"
                              title="Next candle closed Green (Win)"
                            >
                              <CheckCircle className="w-2.5 h-2.5" />
                              <span>Closed Green (Win)</span>
                            </button>
                            <button
                              onClick={() => onUpdateOutcome(item.id, 'LOSS', 'RED')}
                              className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-[9px] flex items-center gap-0.5 active:scale-95 transition-all"
                              title="Next candle closed Red (Loss)"
                            >
                              <XCircle className="w-2.5 h-2.5" />
                              <span>Closed Red (Loss)</span>
                            </button>
                          </>
                        ) : item.signal === 'DOWN' ? (
                          <>
                            <button
                              onClick={() => onUpdateOutcome(item.id, 'WIN', 'RED')}
                              className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-[9px] flex items-center gap-0.5 active:scale-95 transition-all"
                              title="Next candle closed Red (Win)"
                            >
                              <CheckCircle className="w-2.5 h-2.5" />
                              <span>Closed Red (Win)</span>
                            </button>
                            <button
                              onClick={() => onUpdateOutcome(item.id, 'LOSS', 'GREEN')}
                              className="px-2 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-[9px] flex items-center gap-0.5 active:scale-95 transition-all"
                              title="Next candle closed Green (Loss)"
                            >
                              <XCircle className="w-2.5 h-2.5" />
                              <span>Closed Green (Loss)</span>
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => onUpdateOutcome(item.id, 'SKIPPED', 'DOJI')}
                            className="px-2 py-1 rounded bg-slate-700 text-slate-200 font-bold text-[9px] active:scale-95 transition-all"
                          >
                            Mark Skipped
                          </button>
                        )}
                      </div>
                    ) : item.outcome === 'WIN' ? (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-bold font-mono text-[9px] flex items-center gap-1">
                        <CheckCircle className="w-2.5 h-2.5" />
                        <span>WIN</span>
                      </span>
                    ) : item.outcome === 'LOSS' ? (
                      <span className="px-2 py-0.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-400 font-bold font-mono text-[9px] flex items-center gap-1">
                        <XCircle className="w-2.5 h-2.5" />
                        <span>LOSS</span>
                      </span>
                    ) : item.outcome === 'MISSED_DEADLINE' ? (
                      <span className="px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold font-mono text-[9px] flex items-center gap-1">
                        <AlertOctagon className="w-2.5 h-2.5" />
                        <span>LATE EXPIRED</span>
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-bold font-mono text-[9px]">
                        SKIPPED
                      </span>
                    )}

                    {/* Expand toggle */}
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : item.id)}
                      className="p-1 rounded text-slate-400 hover:text-white"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="mt-2.5 pt-2.5 border-t border-slate-800/80 text-[11px] space-y-1.5 text-slate-300">
                    <p className="text-slate-400 leading-relaxed italic">
                      "{item.rationale}"
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-[10px] pt-1">
                      <div className="text-slate-400">
                        Target Interval: <span className="text-cyan-300 font-mono">{item.candleTargetTime}</span>
                      </div>
                      <div className="text-slate-400">
                        Observed S/R: <span className="text-slate-200 font-mono">{item.support} / {item.resistance}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="text-[10px] text-slate-500 font-mono">
                        Captured: {item.dateStr} {item.timeStr}
                      </div>
                      <button
                        onClick={() => onDeleteSignal(item.id)}
                        className="text-slate-500 hover:text-rose-400 text-[10px] flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
