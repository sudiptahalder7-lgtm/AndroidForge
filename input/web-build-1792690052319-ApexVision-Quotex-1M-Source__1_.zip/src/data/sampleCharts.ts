import { SampleChartPreset } from '../types/analyzer';

// Helper to draw realistic 1-minute Quotex candlestick charts with 60s countdown and round levels
function generateQuotex1mChart(
  scenario: 'bullish_hammer_7s' | 'bearish_star_7s' | 'flat_doji_chop' | 'late_rollover'
): string {
  if (typeof document === 'undefined') return '';
  const canvas = document.createElement('canvas');
  canvas.width = 680;
  canvas.height = 380;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background - Quotex signature deep slate dark theme
  const grad = ctx.createLinearGradient(0, 0, 0, 380);
  grad.addColorStop(0, '#0c1322');
  grad.addColorStop(1, '#070b14');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 680, 380);

  // Subtle grid
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
  ctx.lineWidth = 1;
  for (let x = 40; x < 680; x += 45) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 340);
    ctx.stroke();
  }
  for (let y = 30; y < 340; y += 35) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(680, y);
    ctx.stroke();
  }

  // Quotex Header & Pair details
  ctx.fillStyle = '#f1f5f9';
  ctx.font = 'bold 13px JetBrains Mono, monospace';
  const pairTitle =
    scenario === 'bullish_hammer_7s'
      ? 'EUR/USD • 1M • Quotex Live'
      : scenario === 'bearish_star_7s'
      ? 'USD/JPY • 1M • Quotex Live'
      : scenario === 'flat_doji_chop'
      ? 'GBP/USD • 1M • Quotex Live'
      : 'BTC/USDT • 1M • Quotex Live';
  ctx.fillText(pairTitle, 20, 24);

  // Payout badge
  ctx.fillStyle = '#00e676';
  ctx.font = 'bold 11px system-ui';
  ctx.fillText('+89% Payout', 235, 24);

  // Quotex Round Psychological Level line
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
  ctx.setLineDash([3, 3]);
  const roundLineY = scenario === 'bearish_star_7s' ? 95 : 240;
  ctx.beginPath();
  ctx.moveTo(30, roundLineY);
  ctx.lineTo(660, roundLineY);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.fillStyle = '#38bdf8';
  ctx.font = '10px JetBrains Mono, monospace';
  const roundPrice = scenario === 'bearish_star_7s' ? '155.000 [Round Level]' : '1.08500 [Round Support]';
  ctx.fillText(roundPrice, 510, roundLineY - 5);

  // Candle rendering loop (24 historical candles + 1 current forming candle)
  const numCandles = 22;
  const candleWidth = 14;
  const gap = 12;
  const startX = 35;

  let price = 170;

  for (let i = 0; i < numCandles; i++) {
    const isCurrent = i === numCandles - 1;
    const x = startX + i * (candleWidth + gap);

    let open = price;
    let delta = (Math.sin(i * 0.8) * 8) + (Math.random() - 0.48) * 10;

    if (isCurrent) {
      if (scenario === 'bullish_hammer_7s') {
        // Hammer: open high, dipped low in middle, rejected in last 7s up
        open = 210;
        const close = 205; // green body
        const low = 265; // long lower wick (60px)
        const high = 202; // tiny upper wick
        drawCandle(ctx, x, candleWidth, open, close, high, low, true, true);
        continue;
      } else if (scenario === 'bearish_star_7s') {
        // Shooting star: open low, spiked into round level, slammed down in last 7s
        open = 115;
        const close = 125; // red body
        const high = 85; // long upper rejection wick hitting round level
        const low = 128; // small lower wick
        drawCandle(ctx, x, candleWidth, open, close, high, low, false, true);
        continue;
      } else if (scenario === 'flat_doji_chop') {
        // Flat doji
        open = 180;
        const close = 181;
        const high = 172;
        const low = 189;
        drawCandle(ctx, x, candleWidth, open, close, high, low, false, true);
        continue;
      } else {
        // Late rollover
        open = 160;
        const close = 145;
        const high = 140;
        const low = 165;
        drawCandle(ctx, x, candleWidth, open, close, high, low, true, true);
        continue;
      }
    }

    let close = open - delta;
    close = Math.max(70, Math.min(290, close));
    const isGreen = close < open;
    const high = Math.min(open, close) - (Math.random() * 6 + 2);
    const low = Math.max(open, close) + (Math.random() * 6 + 2);

    drawCandle(ctx, x, candleWidth, open, close, high, low, isGreen, false);
    price = close;
  }

  // Draw current candle highlight beacon
  const currentX = startX + (numCandles - 1) * (candleWidth + gap);
  ctx.strokeStyle = '#38bdf8';
  ctx.lineWidth = 1;
  ctx.setLineDash([2, 2]);
  ctx.strokeRect(currentX - 5, 45, candleWidth + 10, 270);
  ctx.setLineDash([]);

  // Tag indicating countdown position
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(currentX - 25, 320, 64, 18);
  ctx.strokeStyle = '#38bdf8';
  ctx.strokeRect(currentX - 25, 320, 64, 18);

  ctx.fillStyle = '#38bdf8';
  ctx.font = 'bold 9px JetBrains Mono, monospace';
  const timerTag =
    scenario === 'late_rollover'
      ? '00:01 LATE'
      : scenario === 'flat_doji_chop'
      ? '00:05 7s'
      : '00:06 7s';
  ctx.fillText(timerTag, currentX - 20, 332);

  // Quotex Timer overlay badge
  ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
  ctx.fillRect(490, 10, 175, 28);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.strokeRect(490, 10, 175, 28);

  ctx.fillStyle = '#f87171';
  ctx.font = 'bold 11px JetBrains Mono, monospace';
  ctx.fillText('⏳ 1M CANDLE CLOSE', 500, 28);

  return canvas.toDataURL('image/png');
}

function drawCandle(
  ctx: CanvasRenderingContext2D,
  x: number,
  width: number,
  open: number,
  close: number,
  high: number,
  low: number,
  isGreen: boolean,
  isFocus: boolean
) {
  const color = isGreen ? '#00e676' : '#ff1744';

  // Wick
  ctx.strokeStyle = color;
  ctx.lineWidth = isFocus ? 1.8 : 1.2;
  ctx.beginPath();
  ctx.moveTo(x + width / 2, high);
  ctx.lineTo(x + width / 2, low);
  ctx.stroke();

  // Body
  ctx.fillStyle = color;
  const top = Math.min(open, close);
  const height = Math.max(3, Math.abs(close - open));
  ctx.fillRect(x, top, width, height);

  if (isFocus) {
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.strokeRect(x, top, width, height);
  }
}

export function getQuotex1mPresets(): SampleChartPreset[] {
  return [
    {
      id: 'quotex-hammer-up',
      title: 'EUR/USD 1m Hammer (Support 7s Rejection)',
      pair: 'EUR/USD',
      timeframe: '1m',
      description: 'Long lower wick formed in final 7s at round level 1.08500. Clear next-candle UP expectation.',
      expectedBias: 'UP',
      secondsRemaining: 6,
      dataUrl: generateQuotex1mChart('bullish_hammer_7s'),
    },
    {
      id: 'quotex-star-down',
      title: 'USD/JPY 1m Star (Resistance 7s Slam)',
      pair: 'USD/JPY',
      timeframe: '1m',
      description: 'Upper rejection tail at round 155.000 ceiling. Exhaustion wick in final 7s -> next-candle DOWN.',
      expectedBias: 'DOWN',
      secondsRemaining: 6,
      dataUrl: generateQuotex1mChart('bearish_star_7s'),
    },
    {
      id: 'quotex-doji-notrade',
      title: 'GBP/USD 1m Flat Doji (Indecision)',
      pair: 'GBP/USD',
      timeframe: '1m',
      description: 'Thin body with no directional breakout in last 7s. Insufficient evidence -> NO TRADE.',
      expectedBias: 'NO_TRADE',
      secondsRemaining: 5,
      dataUrl: generateQuotex1mChart('flat_doji_chop'),
    },
    {
      id: 'quotex-late-missed',
      title: 'BTC/USDT 1m Late Rollover (Missed Deadline)',
      pair: 'BTC/USDT',
      timeframe: '1m',
      description: 'Frame delivered past 00:00 rollover. Marked as MISSED SIGNAL to prevent stale entries.',
      expectedBias: 'MISSED_SIGNAL',
      secondsRemaining: 0,
      dataUrl: generateQuotex1mChart('late_rollover'),
    },
  ];
}
