# ApexVision AI — Quotex 1-Minute Screen Analyzer

ApexVision AI is a production-minded native Android application designed to analyze the visible Quotex trading chart and generate an informational directional signal for **only the immediately following 1-minute candle**.

> **CRITICAL DISCLAIMER:**  
> ApexVision AI is an informational technical chart analyzer. It calculates visible candlestick wicks, momentum, and support/resistance zones. It **never** promises guaranteed profits or accuracy, and it does **not** execute trades or automate clicks on Quotex. All signals are strictly probabilistic.

---

## 📱 How to Build the Debug APK from an Android Phone (100% Free, No Computer Needed)

You do **not** need a laptop or PC. You can build the genuine debug APK in the cloud using GitHub Actions for free:

### Step 1: Download the Source ZIP
1. Download `ApexVision-Quotex-1M-Source.zip` from the web app interface.
2. The file is saved to your Android phone's **Downloads** folder.

### Step 2: Extract the Files on Your Phone
1. Install **ZArchiver** (free from Google Play Store).
2. Open ZArchiver, go to `Download`, tap `ApexVision-Quotex-1M-Source.zip`, and tap **Extract here**.

### Step 3: Create a Free GitHub Repository on Mobile
1. Open [github.com](https://github.com) in Chrome on your Android phone and sign in (or create a free account).
2. Tap the **`+`** icon in the top right $\to$ tap **New repository**.
3. Repository name: `apexvision-quotex`.
4. Choose **Public** or **Private** $\to$ tap **Create repository**.

### Step 4: Upload the Android Project to GitHub
1. On your newly created repo page, tap **"uploading an existing file"** or tap **Add file** $\to$ **Upload files**.
2. Select all files from the extracted `android` folder (or root folder including `.github/workflows/build-apk.yml`).
3. Tap **Commit changes**.

### Step 5: Download the Compiled APK Artifact
1. Tap the **Actions** tab on your GitHub repository.
2. The **"Build Android Debug APK"** workflow will start automatically.
3. The cloud build installs JDK 17, Android SDK 35, and runs `./gradlew assembleDebug` (~3 minutes).
4. When the checkmark turns green, tap the workflow run.
5. Under **Artifacts** at the bottom, tap **`ApexVision-Quotex-1M-Debug-APK`**.
6. A zip containing `app-debug.apk` will download to your phone. Extract and tap to install!

---

## 🛠 Key Features

- **Floating Overlay over Quotex:** Movable, draggable compact floating panel using Android's `SYSTEM_ALERT_WINDOW` (`TYPE_APPLICATION_OVERLAY`).
- **Screen Capture via MediaProjection:** Explicit user-approved frame capture during final 7s (:53-:59) of the 1m candle.
- **1-Minute Candle Timing:** Monotonic clock, ~1s pre-rollover deadline (:59 target), auto-expiration when candle ends, and MISSED SIGNAL fail-safe.
- **Local Computer Vision & Price Action:** 100% offline detection of rejection wicks, candlestick bodies, support/resistance, and momentum.
- **Optional Gemini Vision Integration:** Multimodal reasoning with user-entered API key stored in private SharedPreferences.
- **Room Database Outcome Verification:** Tracks every logged signal and calculates verified accuracy: `Accuracy = Wins / (Wins + Losses) * 100`. Excludes NO_TRADE and unverified.
