package com.apexvision.quotex.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class TradeSignal { UP, DOWN, NO_TRADE, MISSED_SIGNAL, IDLE }

@Composable
fun FloatingOverlayView(
    onDismiss: () -> Unit
) {
    var signal by remember { mutableStateOf(TradeSignal.IDLE) }
    var secondsRemaining by remember { mutableStateOf(60) }
    var rationale by remember { mutableStateOf("Monitoring 1m candle formation...") }

    // Synchronize 1-minute candle clock
    LaunchedEffect(Unit) {
        while (true) {
            val nowSec = (System.currentTimeMillis() / 1000) % 60
            val rem = (60 - nowSec).toInt()
            secondsRemaining = if (rem == 0) 60 else rem

            // At final 7 seconds (:53), trigger 1m candle evaluation
            if (secondsRemaining in 1..7) {
                if (signal == TradeSignal.IDLE) {
                    // Simulating AI vision inference on current wick rejection
                    signal = TradeSignal.UP
                    rationale = "Long lower wick rejection at support. Expect next 1m green."
                }
            } else if (secondsRemaining > 15) {
                signal = TradeSignal.IDLE
                rationale = "Forming candle. Next 7s window opens at :53."
            }

            delay(250)
        }
    }

    Surface(
        color = Color(0xEE090D16),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF1E293B)),
        shadowElevation = 16.dp,
        modifier = Modifier.width(220.dp).padding(8.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quotex 1M",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp
                )
                Text(
                    text = "Close",
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp,
                    modifier = Modifier.clickable { onDismiss() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Glowing Indicator
            CompactGlowCircle(signal = signal)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Candle ends in: 00:${if (secondsRemaining < 10) "0$secondsRemaining" else "$secondsRemaining"}",
                color = Color(0xFF38BDF8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = rationale,
                color = Color(0xFFCBD5E1),
                fontSize = 9.sp,
                lineHeight = 12.sp
            )
        }
    }
}

@Composable
fun CompactGlowCircle(signal: TradeSignal) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val (glowColor, solidColor, text) = when (signal) {
        TradeSignal.UP -> Triple(Color(0xFF00E676), Color(0xFF00C853), "UP")
        TradeSignal.DOWN -> Triple(Color(0xFFFF1744), Color(0xFFD50000), "DOWN")
        TradeSignal.NO_TRADE -> Triple(Color(0xFF64748B), Color(0xFF475569), "HOLD")
        TradeSignal.MISSED_SIGNAL -> Triple(Color(0xFFF59E0B), Color(0xFFD97706), "LATE")
        TradeSignal.IDLE -> Triple(Color(0xFF334155), Color(0xFF1E293B), "READY")
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(72.dp)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(glowColor.copy(alpha = 0.55f), Color.Transparent),
                        radius = size.minDimension / 1.1f * pulseScale
                    )
                )
            }
            .border(2.5.dp, glowColor.copy(alpha = 0.85f), CircleShape)
            .background(solidColor, CircleShape)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp
        )
    }
}
