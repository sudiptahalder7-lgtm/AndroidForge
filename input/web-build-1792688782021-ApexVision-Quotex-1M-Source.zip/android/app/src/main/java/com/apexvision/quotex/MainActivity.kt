package com.apexvision.quotex

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apexvision.quotex.overlay.QuotexFloatingOverlayService

class MainActivity : ComponentActivity() {

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (checkOverlayPermission()) {
            startOverlayService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainScreen(
                hasOverlayPermission = checkOverlayPermission(),
                onRequestOverlay = { requestOverlayPermission() },
                onStartOverlay = { startOverlayService() },
                onStopOverlay = { stopOverlayService() }
            )
        }
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, QuotexFloatingOverlayService::class.java)
        startService(intent)
    }

    private fun stopOverlayService() {
        val intent = Intent(this, QuotexFloatingOverlayService::class.java)
        stopService(intent)
    }
}

@Composable
fun MainScreen(
    hasOverlayPermission: Boolean,
    onRequestOverlay: () -> Unit,
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070A12))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "⚡ ApexVision Quotex 1M",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Next 1-Minute Candle Analyzer with Floating Overlay",
            color = Color(0xFF94A3B8),
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(32.dp))

        if (!hasOverlayPermission) {
            Button(
                onClick = onRequestOverlay,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
            ) {
                Text("Grant Overlay Permission", color = Color(0xFF090D16), fontWeight = FontWeight.Bold)
            }
        } else {
            Button(
                onClick = onStartOverlay,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("Launch Quotex Floating Overlay", color = Color(0xFF090D16), fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = onStopOverlay,
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("Stop Overlay", color = Color(0xFFE2E8F0))
            }
        }
    }
}
