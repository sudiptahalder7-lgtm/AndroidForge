# ApexVision Quotex 1M - Native Android Project

This folder contains the complete native Android project structure using **Kotlin**, **Jetpack Compose (Material 3)**, and **Room Database**.

## Modules & Architecture
- **`QuotexFloatingOverlayService.kt`**: Uses `SYSTEM_ALERT_WINDOW` (`TYPE_APPLICATION_OVERLAY`) to float a compact glowing indicator directly over Quotex.
- **`ScreenCaptureService.kt`**: Uses `MediaProjection` to sample frames during the final 7 seconds (:53 to :59) of every 1-minute candle.
- **`SignalHistoryDao.kt` & `SignalHistoryEntity.kt`**: Local Room database ensuring accuracy is calculated strictly from completed candle outcomes.
- **`FloatingOverlayView.kt`**: Compose UI displaying the pulsing glow (Green UP, Red DOWN, Gray NO TRADE) and live countdown.

## Building in Android Studio
1. Open the project in Android Studio (Ladybug or newer).
2. Sync Gradle files.
3. Target device: Android 8.0+ (API 26 to 35).
4. Run on a physical Android phone or emulator with Google Play Services.
